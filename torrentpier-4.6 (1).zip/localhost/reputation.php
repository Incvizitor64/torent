<?php
/*************************************************************************************
 *                           reputation.php
 * Part of Democracy MOD by Carbofos < carbofos@mail.ru > and ETZel < etzel@mail.ru >
 *************************************************************************************/

/*************************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *************************************************************************************/

define('IN_PHPBB', true);

$phpbb_root_path = './';
$phpEx = 'php';
if (!defined('BB_ROOT') && !empty($phpbb_root_path))
{
	define('BB_ROOT', $phpbb_root_path);
}
if (!defined('PHP_EXT'))
{
	define('PHP_EXT', $phpEx);
}
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/bbcode.' . $phpEx);
include($phpbb_root_path . 'includes/functions_post.' . $phpEx);

// $userdata = session_pagestart($user_ip, PAGE_INDEX);
// init_userprefs($userdata);
$user->session_start();

include($phpbb_root_path . 'includes/functions_reputation.' . $phpEx); // should be included after session initialization

/**
 * Prepares message for emailing by stripping bbcodes and html tags.
 * This function must be called on the unprepared message.
 */
function email_prepare_message($message, $html_enabled = false, $bbcode_enabled = true)
{
	global $lang;

	if ($bbcode_enabled)
	{
		// QUESTION: put arrays to statics?
		$message = preg_replace(
			array('#\[quote(|="\w+")\]#si', '#\[/quote\]#si', '#\[code\]#si', '#\[/code\]#si', '#\[/?\w+(|=\w+)\]#si'),
			array("\n{$lang['Quote']} >>\n", "\n<< {$lang['Quote']}\n", "\n{$lang['Code']} >>\n", "\n<< {$lang['Code']}\n"),
			$message);
	}
	if ($html_enabled)
	{
		$message = strip_tags($message);
	}
	return $message;
}

/**
 * Reverses the result of htmlspecialchars.
 * Used to prepare usernames for plaintext emailing.
 */
function email_prepare_username($message)
{
	return preg_replace(array('#&gt;#', '#&lt;#', '#&quot;#', '#&amp;#'), array('>', '<', '"', '&'), str_replace("\'", "'", $message)); // QUESTION: is str_replace necessary?
}

/**
 * Generic mailing function
 * Woah, how far we can go from simple but powerful mail()
 */
function reputation_email($to_userdata, $template_name, $template_vars)
{
	global $db, $lang, $user_ip, $bb_cfg, $userdata, $phpbb_root_path, $phpEx;

	if (!class_exists('emailer'))
	{
		include($phpbb_root_path . 'includes/emailer.' . $phpEx);
	}
	$emailer = new emailer($bb_cfg['smtp_delivery']);

	$emailer->from($bb_cfg['board_email']);
	$emailer->replyto($bb_cfg['board_email']);

	$emailer->use_template($template_name, $to_userdata['user_lang']);
	$emailer->email_address($to_userdata['user_email']);

	$emailer->assign_vars(array(
		'SITENAME' => $bb_cfg['sitename'],
		'USERNAME' => email_prepare_username($to_userdata['username']),
		'NAME_FROM' => $userdata['username'],
		'EMAIL_SIG' => $bb_cfg['board_email_sig'] ? '' : str_replace('<br />', "\n", "-- \n" . $bb_cfg['board_email_sig']),
	) + $template_vars);

	$emailer->send();
	$emailer->reset();
}

/**
 * Sends a private message from $from_userdata to $to_userdata.
 * @param string $message Message to send, WITHOUT added slashes.
 */
function reputation_pm($from_userdata, $to_userdata, $message, $subject, $html_on = false, $bbcode_on = true, $smilies_on = true)
{
	global $db, $lang, $user_ip, $bb_cfg, $phpbb_root_path, $phpEx, $current_time;

	$privmsg_subject = trim(strip_tags($subject));

	$bbcode_uid = $bbcode_on ? make_bbcode_uid() : '';
	$message = stripslashes(prepare_message(addslashes($message), $html_on, $bbcode_on, $smilies_on, $bbcode_uid)); // damn this slashes games

	// See if recipient is at their inbox limit
	$result = db_query('SELECT COUNT(privmsgs_id) AS inbox_items, MIN(privmsgs_date) AS oldest_post_time
			FROM {PRIVMSGS_TABLE}
			WHERE ( privmsgs_type = {PRIVMSGS_NEW_MAIL}
						OR privmsgs_type = {PRIVMSGS_READ_MAIL}
						OR privmsgs_type = {PRIVMSGS_UNREAD_MAIL})
				AND privmsgs_to_userid = %d', $to_userdata['user_id']);

	if ($inbox_info = $db->sql_fetchrow($result))
	{
		if ($inbox_info['inbox_items'] >= $bb_cfg['max_inbox_privmsgs'])
		{
			$result = db_query('SELECT privmsgs_id FROM {PRIVMSGS_TABLE}
					WHERE (privmsgs_type = {PRIVMSGS_NEW_MAIL}
								OR privmsgs_type = {PRIVMSGS_READ_MAIL}
								OR privmsgs_type = {PRIVMSGS_UNREAD_MAIL})
						AND privmsgs_date = %d
						AND privmsgs_to_userid = %d', $inbox_info['oldest_post_time'], $to_userdata['user_id']);

			$old_privmsgs_id = $db->sql_fetchrow($result);
			$old_privmsgs_id = $old_privmsgs_id['privmsgs_id'];

			$sql_priority = (SQL_LAYER == 'mysql') ? 'LOW_PRIORITY' : '';
			db_query("DELETE $sql_priority FROM {PRIVMSGS_TABLE} WHERE privmsgs_id = %d", $old_privmsgs_id);
			db_query("DELETE $sql_priority FROM {PRIVMSGS_TEXT_TABLE} WHERE privmsgs_text_id = %d", $old_privmsgs_id);
		}
	}

	db_transaction(BEGIN_TRANSACTION);
	db_query('INSERT INTO {PRIVMSGS_TABLE} (privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_smilies)
		VALUES ({PRIVMSGS_NEW_MAIL}, \'%s\', %d, %d, %d, \'%s\', %d, %d)',
		$privmsg_subject, BOT_UID, $to_userdata['user_id'], $current_time, '$user_ip', $bbcode_on, $smilies_on);

	$sent_id = $db->sql_nextid();

	db_query('INSERT INTO {PRIVMSGS_TEXT_TABLE} (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text)
		VALUES (%d, \'%s\', \'%s\')', $sent_id, $bbcode_uid, $message);

	// Add to the users new pm counter
	db_query('UPDATE {USERS_TABLE}
			SET user_new_privmsg = user_new_privmsg + 1, user_last_privmsg = %d
			WHERE user_id = %d',
		$current_time, $to_userdata['user_id']);
	db_transaction(END_TRANSACTION);

	if ($to_userdata['user_notify_pm'] && $bb_cfg['pm_notify_enabled'] && $to_userdata['user_email'] && $to_userdata['user_active'])
	{
		reputation_email($to_userdata, 'privmsg_notify', array(
			'USERNAME' => email_prepare_username($to_userdata['username']),
			'U_INBOX' => server_url() . "privmsg.$phpEx?folder=inbox",
		));
	}
}

/**
 * Loads lang array for specified $language.
 * Only strings from lang_main are returned.
 */
function lang_any($language)
{
	static $cache;

	if (isset($cache[$language]))
	{
		return $cache[$language];
	}

	global $bb_cfg, $phpbb_root_path, $phpEx;

	// if ($language != $bb_cfg['default_lang'])
	// {
	//	$lang = array();
	//	include($phpbb_root_path . 'language/lang_' . $language . '/lang_main.' . $phpEx);
	// }

	return $cache[$language] = empty($lang) ? $GLOBALS['lang'] : $lang;
}

/**
 * Generates the form for entering and editing of all types of reviews.
 */
class review_editor
{
	var $review;
	var $fresh = false;
	var $limits = false;
	var $max_giving = false;

	function __construct($mode, $review = null)
	{
		global $bb_cfg, $current_time, $userdata;

		if ($mode != 'edit')
		{
			$mode_map = array('inc' => REPUTATION_INC, 'dec' => REPUTATION_DEC, 'warning' => REPUTATION_WARNING, 'ban' => REPUTATION_BAN);
			$review = array('modification' => $mode_map[$mode], 'text' => '', 'bbcode_uid' => '', 'amount' => 1, 'expire' => '0', 'date' => $current_time);
			$this->fresh = true;
		}

		$this->review = $review;
		$modification = $review['modification'];

		if ($bb_cfg['reputation_giving'] && ($modification == REPUTATION_INC || $modification == REPUTATION_DEC))
		{
			if ($mode != 'edit')
			{
				$this->max_giving = reputation_giving_power($userdata);
			}
			else
			{
				$this->max_giving = 1;
			}
		}
		if ($modification == REPUTATION_WARNING || $modification == REPUTATION_BAN)
		{
			$this->limits = $bb_cfg[($modification == REPUTATION_WARNING) ? 'reputation_warning_expire' : 'reputation_ban_expire'];
		}
	}

	function show($self_params, $post_data, $notes = null)
	{
		global $lang, $bb_cfg, $userdata, $phpEx, $template, $warned_img, $banned_img, $thumb_up_img, $thumb_dn_img;

		$template->set_filenames(array('body' => 'profile_modify_reputation.tpl'));
		// make_jumpbox(append_sid('viewforum.' . $phpEx));

		if ($post_data)
		{
			$template->assign_block_vars('postrow', array(
				'USER_NAME' => $post_data['username'],
				'POST_DATE' => create_date($bb_cfg['default_dateformat'], $post_data['post_time'], $bb_cfg['board_timezone']),
				'POST_SUBJECT' => censor($post_data['post_subject']),
				'POSTER_MESSAGE' => prepare_display($post_data['post_text'], $post_data['bbcode_uid'], $post_data['enable_smilies']),
			));
		}

		$comment = $this->review['text'];
		if ($this->review['bbcode_uid'])
		{
			$comment = preg_replace('/\:(([a-z0-9]:)?)' . $this->review['bbcode_uid'] . '/s', '', $comment);
		}

		if ($this->max_giving !== false)
		{
			$sign = ($this->review['modification'] == REPUTATION_INC) ? '+' : '&ndash;';

			if ($this->max_giving > 1)
			{
				$template->assign_block_vars('giving', array());
				for ($i = 1; $i <= $this->max_giving; ++$i)
				{
					$template->assign_block_vars('giving.amount', array('VALUE' => $i, 'TITLE' => $sign . $i));
				}
			}
			else
			{
				$amount = $sign . $this->review['amount'];
			}
		}

		if ($this->limits !== false)
		{
			if (count($this->limits) < 2) // fixed
			{
				$block = 'expire_fixed';
				$message = count($this->limits) ? sprintf($lang['reputation_expire_fixed'], $this->limits[0]) : $lang['reputation_expire_never'];
			}
			else
			{
				if (empty($this->limits[1])) // no upper limit
				{
					$block = 'expire_unlimited';
					$message = sprintf($lang['reputation_expire_limited_bottom'], empty($this->limits[0]) ? 1 : $this->limits[0]);
				}
				else
				{
					$block = 'expire_limited';
					$message = sprintf($lang['reputation_expire_limited'], $this->limits[0], $this->limits[1]);
				}

				$days = $this->review['expire'] ? round(($this->review['expire'] - $this->review['date']) / 86400) : $this->limits[0];
			}

			$l_expire_days = explode('%s', $lang['reputation_expire_fixed']);

			if (!isset($days)) $tmp_days = '';
			else $tmp_days = $days;
			$template->assign_block_vars($block, array(
				'L_EXPIRE' => $lang['reputation_expire'],
				'L_NEVER' => $lang['reputation_expire_never'],
				'L_DAYS_0' => $l_expire_days[0],
				'L_DAYS_1' => $l_expire_days[1],
				'L_MESSAGE' => $message,

				'S_DAYS' => $tmp_days,
				'S_NEVER_' . (($this->fresh || $this->review['expire']) ? '0' : '1') => 'checked="checked" ',
			));
		}

		if ($this->fresh)
		{
			$title_map = array(REPUTATION_INC => 'reputation_modify', REPUTATION_DEC => 'reputation_modify', REPUTATION_WARNING => 'reputation_warn_user', REPUTATION_BAN => 'reputation_ban_user');
			$title = $title_map[$this->review['modification']];
		}
		else
		{
			$title = 'reputation_edit_review';
		}

		// $html_status = ($userdata['user_allowhtml'] && $bb_cfg['allow_html']) ? $lang['HTML_is_ON'] : $lang['HTML_is_OFF'];
		$html_status = '';
		$bbcode_status = $lang['BBCode_is_OFF'];
		// $smilies_status = ($userdata['user_allowsmile'] && $bb_cfg['allow_smilies']) ? $lang['Smilies_are_ON'] : $lang['Smilies_are_OFF'];
		$smilies_status = '';

		$review_imgs = array(REPUTATION_INC => $thumb_up_img, REPUTATION_DEC => $thumb_dn_img, REPUTATION_WARNING => $warned_img, REPUTATION_BAN => $banned_img, REPUTATION_WARNING_EXPIRED => $warned_img, REPUTATION_BAN_EXPIRED => $banned_img);

		$template->assign_vars(array(
			'L_TITLE' => $lang[$title],
			'L_WROTE' => $lang['wrote'],
			'L_REPUTATION' => $lang['Reputation'],
			'L_POSTED' => $lang['POSTED'],
			'L_POST_SUBJECT' => $lang['POST_SUBJECT'],
			'L_DESCRIPTON' => $lang['Review'],
			'L_SUBMIT' => $lang['SUBMIT'],
			'L_OPTIONS' => $lang['OPTIONS'],

			'L_NOTE' => empty($notes['note']) ? '' : $notes['note'],
			'L_REVIEW_NOTE' => empty($notes['review_note']) ? '' : $notes['review_note'],

			'REVIEW' => $comment,
			'REVIEW_IMG' => $review_imgs[$this->review['modification']],
			'AMOUNT' => isset($amount) ? $amount : '',

			'HTML_STATUS' => $html_status,
			'BBCODE_STATUS' => sprintf($bbcode_status, '<a href="' . append_sid("faq.$phpEx?mode=bbcode") . '" target="_phpbbcode">', '</a>'),
			'SMILIES_STATUS' => $smilies_status,

			'S_HIDDEN_FIELDS' => preg_replace('#([^=]+)=([^&]+)&#si', '<input type="hidden" name="\1" value="\2" />', $self_params . '&'),
			'S_ACTION' => append_sid("reputation.$phpEx"),
		));

		$template->pparse('body');
	}

	function get_input()
	{
		global $lang, $bb_cfg;

		$input['modification'] = $this->review['modification'];
		$input['comment_orig'] = trim(input_var('message', ''));

		if (!$bb_cfg['reputation_empty_reviews'] && !$input['comment_orig'])
		{
			message_die(GENERAL_MESSAGE, $lang['reputation_no_comments_entered']);
		}

		$input['bbcode_uid'] = $bb_cfg['allow_bbcode'] ? make_bbcode_uid() : '';
		$input['comment'] = stripslashes(prepare_message($input['comment_orig'], $bb_cfg['allow_bbcode'], $input['bbcode_uid']));

		if ($this->max_giving !== false)
		{
			$giving = input_var('giving', 1);

			if ($giving < 1 || $giving > $this->max_giving)
			{
				message_die(GENERAL_MESSAGE, $lang['reputation_no_giving_entered']);
			}

			$input['giving'] = $giving;
		}
		else
		{
			$input['giving'] = 1;
		}

		if ($this->limits !== false)
		{
			$input['expire_days'] = $this->input_expire_days();
			$input['expire'] = $input['expire_days'] ? ($this->review['date'] + $input['expire_days'] * 86400) : 0;
		}

		return $input;
	}

	function input_expire_days()
	{
		global $lang;

		if (count($this->limits) < 2)
		{
			return isset($this->limits[0]) ? $this->limits[0] : 0;
		}
		else
		{
			if (empty($_POST['expire_never']))
			{
				$expire = input_var('expire_days', 0, $lang['reputation_no_expire_entered']);

				$min = empty($this->limits[0]) ? 1 : $this->limits[0];
				$max = empty($this->limits[1]) ? $expire : $this->limits[1];

				if ($expire <= $max && $expire >= $min)
				{
					return $expire;
				}
			}
			elseif (empty($this->limits[1]))
			{
				return 0;
			}
		}

		message_die(GENERAL_MESSAGE, $lang['reputation_no_expire_entered']);
	}
}
/* End local functions */

$page_title = $lang['Reputation'];

$mode = input_var('mode', '', $lang['Not_Authorised']);
$ret = input_var('ret', 'reputation');
$self_params = "mode=$mode&ret=$ret";

cache_set('respected'); // clear most respected users cache

if ($mode == 'inc' || $mode == 'dec' || $mode == 'warning' || $mode == 'ban')
{
	if ($mode == 'inc' || $mode == 'dec')
	{
		if (!$bb_cfg['reputation_enabled'] || ($mode == 'dec' && $bb_cfg['reputation_positive_only']))
		{
			message_die(GENERAL_MESSAGE, $lang['No_post_mode']);
		}
	}
	else
	{
		if (!$bb_cfg['warnings_enabled'])
		{
			message_die(GENERAL_MESSAGE, $lang['No_post_mode']);
		}
	}

	$post_id = input_var(POST_POST_URL, NO_ID);
	if ($post_id != NO_ID)
	{
		//
		// Get the referred post info
		//
		$result = db_query('SELECT u.*, p.*, pt.post_text, pt.post_subject, pt.bbcode_uid
			FROM {POSTS_TABLE} p, {USERS_TABLE} u, {POSTS_TEXT_TABLE} pt
			WHERE p.post_id = %d
				AND p.poster_id = u.user_id
				AND p.post_id = pt.post_id',
			$post_id);

		if (!($user_post_data = $db->sql_fetchrow($result)))
		{
			message_die(GENERAL_MESSAGE, $lang['No_posts_topic']);
		}

		$self_params .= '&' . POST_POST_URL . '=' . $post_id;

		// make a few variables that may come in handy later...
		$user_id = intval($user_post_data['user_id']);
		$forum_id = intval($user_post_data['forum_id']);

		$back_url = '<br /><br />' . sprintf($lang['reputation_msg_back_to_topic'], '<a href="' . append_sid("viewtopic.$phpEx?" . POST_POST_URL . "=$post_id") . "#$post_id\">", '</a>');
	}
	else
	{
		$user_id = input_var(POST_USERS_URL, 0, $lang['reputation_no_user_spec']); // QUESTION: replace with $lang['No_user_id_specified'] ?
		$forum_id = NO_ID;

		$result = db_query('SELECT u.username, u.user_id, u.user_level, u.user_warnings_dem, u.user_lang, u.user_email, u.user_notify_pm, u.user_active
			FROM {USERS_TABLE} u
			WHERE u.user_id = %d',
			$user_id);
		if (!($user_post_data = $db->sql_fetchrow($result)))
		{
			message_die(GENERAL_MESSAGE, $lang['No_user_id_specified']);
		}

		$self_params .= '&' . POST_USERS_URL . '=' . $user_id;

		$back_url = '<br /><br />' . sprintf($lang['reputation_msg_view_profile'], '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=$user_id") . '">', '</a>');
	}

	// auth check
	$is_auth = reputation_auth($forum_id, $userdata, $user_post_data, false);

	$mode_auth_keys = array('inc' => 'auth_add_rep', 'dec' => 'auth_add_rep', 'warning' => 'auth_warn', 'ban' => 'auth_ban');
	$auth_key = $mode_auth_keys[$mode];

	if (!$is_auth[$auth_key])
	{
		if (!$userdata['session_logged_in'])
		{
			redirect(append_sid("login.$phpEx?redirect=reputation.$phpEx?$self_params", true));
		}

		message_die(GENERAL_MESSAGE, isset($is_auth[$auth_key . '_msg']) ? $is_auth[$auth_key . '_msg'] : $lang['Not_Authorised']);
	}
}

if ($mode == 'inc' || $mode == 'dec')
{
	//
	// Load page header
	//
	include($phpbb_root_path . 'includes/page_header.' . $phpEx);

	if ($post_id != NO_ID)
	{
		// Check if there's already this user's review, deny reviewing this post again
		$result = db_query('SELECT id FROM {REPUTATION_TABLE}
			WHERE post_id = %d
			AND (modification = {REPUTATION_INC} OR modification = {REPUTATION_DEC})
			AND voter_id = %d',
			$post_id, $userdata['user_id']);

		if ($reputation_data = $db->sql_fetchrow($result))
		{
			$review_id = $reputation_data['id'];
			message_die(GENERAL_MESSAGE, $lang['reputation_already_voted'] . '<br /><br />' . sprintf($lang['reputation_msg_view_your_review'], '<a href="' . append_sid("profile.$phpEx?mode=reputation&" . POST_REVIEWS_URL . "=$review_id") . "#$review_id\">", '</a>') . $back_url);
		}
	}

	$editor = new review_editor($mode);
	//$editor = new review_editor(array('modification' => ($mode == 'inc') ? REPUTATION_INC : REPUTATION_DEC));

	if (isset($_POST['submit']))
	{
		$input = $editor->get_input();

		db_transaction(BEGIN_TRANSACTION);
		db_query('INSERT INTO {REPUTATION_TABLE} (modification, amount, user_id, voter_id, post_id, forum_id, poster_ip, date)
			VALUES (%d, %d, %d, %d, %d, %d, \'%s\', %d)',
			$input['modification'], $input['giving'], $user_post_data['user_id'], $userdata['user_id'], $post_id, $forum_id, $user_ip, time());

		$review_id = $db->sql_nextid();

		db_query("INSERT INTO {REPUTATION_TEXT_TABLE} (id, text, bbcode_uid) VALUES (%d, '%s', '%s')",
			$review_id, $input['comment'], $input['bbcode_uid']);

		db_query('UPDATE {USERS_TABLE} SET user_reviews = user_reviews + 1 WHERE user_id = %d', $userdata['user_id']);

		$reputation_sql = ($mode == 'inc') ? 'user_reputation = user_reputation + %2$d, user_reputation_plus = user_reputation_plus + %2$d' : 'user_reputation = user_reputation - %2$d';
		db_query('UPDATE {USERS_TABLE} SET ' . $reputation_sql . ' WHERE user_id = %1$d', $user_id, $input['giving']);
		db_query('UPDATE {POSTS_TABLE} SET post_reviews = post_reviews + 1 WHERE post_id = %d', $post_id);

		db_transaction(END_TRANSACTION);

		if ($bb_cfg['reputation_notify_reputation'] != 'none')
		{
			$plain_comments = stripslashes($input['comment_orig']);
			$review_link = server_url() . "profile.$phpEx?mode=" . ($post_id == NO_ID ? 'reputation' : 'reviews') . '&' . POST_REVIEWS_URL . "=$review_id";

			$result = db_query('SELECT ' . reputation_get_sql('ext') . ' FROM {USERS_TABLE} WHERE user_id = %d', $user_id);
			$new_reputation = $db->sql_fetchrow($result);
			$new_reputation = ($new_reputation['user_reputation'] > 0 ? '+' : '') . $new_reputation['user_reputation'];
			$giving = ($mode == 'inc' ? '+' : '-') . $input['giving'];

			if ($bb_cfg['reputation_notify_reputation'] == 'email')
			{
				reputation_email($user_post_data, 'reputation_notify', array(
					'ACTORNAME' => email_prepare_username($userdata['username']),
					'GIVING' => $giving,
					'REPUTATION' => $new_reputation,
					'MESSAGE' => $plain_comments ? email_prepare_message($plain_comments, true, $bb_cfg['allow_bbcode']) : $lang['None'],
					'U_LINK' => $review_link,
				));
			}
			else // 'pm'
			{
				$user_lang = lang_any($user_post_data['user_lang']);

				$reviewer = $bb_cfg['allow_bbcode'] ? ('[url=' . server_url() . "profile.$phpEx?mode=viewprofile&" . POST_USERS_URL . '=' . $userdata['user_id'] . ']' . $userdata['username'] . '[/url]') : $userdata['username'];
				$message = sprintf($user_lang['reputation_notify_reputation'], $reviewer, $giving, $new_reputation, $plain_comments, $review_link);

				reputation_pm($userdata, $user_post_data, $message, $user_lang['reputation_subj_reputation'], $bb_cfg['allow_bbcode']);
			}
		}

		message_die(GENERAL_MESSAGE, $lang['reputation_update_successfull'] . '<br /><br />' . sprintf($lang['reputation_msg_view_your_review'], '<a href="' . append_sid("profile.$phpEx?mode=reputation&amp;" . POST_REVIEWS_URL . "=$review_id") . "#$review_id\">", '</a>') . $back_url);
	} // End of submit
	else
	{
		$notes['note'] = $is_auth['auth_edit_rep'] ? $lang['reputation_note_can_edit'] : $lang['reputation_note_cant_edit'];
		$editor->show($self_params, ($post_id != NO_ID) ? $user_post_data : null, $notes);
	}
}
elseif ($mode == 'warning' || $mode == 'ban')
{
	// Load page header
	include($phpbb_root_path . 'includes/page_header.' . $phpEx);

	if ($post_id != NO_ID)
	{
		// Check if the user is already warned/banned, deny reviewing this post again
		$result = db_query('SELECT * FROM {REPUTATION_TABLE}
			WHERE post_id = %d
				AND (modification = {REPUTATION_BAN} OR modification = {REPUTATION_WARNING})', $post_id);
		if ($reputation_data = $db->sql_fetchrow($result))
		{
			$review_id = $reputation_data['id'];
			message_die(GENERAL_MESSAGE, $lang['reputation_already_warned'] . '<br /><br />' . sprintf($lang['reputation_msg_view_warning'], '<a href="' . append_sid("profile.$phpEx?mode=reputation&" . POST_REVIEWS_URL . "=$review_id") . "#$review_id\">", '</a>') . $back_url);
		}

		$topic_id = intval($user_post_data['topic_id']);
		$back_url .= "<br /><br /><a href=\"posting.$phpEx?mode=delete&amp;sid=" . $userdata['session_id'] . '&amp;' . POST_POST_URL . "=$post_id\">" . $lang['Delete_post'] . '</a>' .
			"<br /><br /><a href=\"modcp.$phpEx?mode=lock&amp;sid=" . $userdata['session_id'] . '&amp;' . POST_TOPIC_URL . "=$topic_id\">" . $lang['LOCK_TOPIC'] . '</a>';
	}

	if ($bb_cfg['reputation_ban_warnings'])
	{
		if ($mode == 'warning' && ($user_post_data['user_warnings_dem'] + 1 >= $bb_cfg['reputation_ban_warnings']))
		{
			$mode = 'ban';
			$notes['review_note'] = $lang['reputation_last_warning_issued'];
		}
	}

	// Check if he/she isn't already banned
	if (user_banned($user_id))
	{
		message_die(GENERAL_MESSAGE, $lang['reputation_already_banned']);
	}

	$editor = new review_editor($mode);

	if (isset($_POST['submit']))
	{
		$input = $editor->get_input();

		// If everything's ok, post the review
		db_transaction(BEGIN_TRANSACTION);

		db_query('INSERT INTO {REPUTATION_TABLE} (modification, user_id, voter_id, post_id, forum_id, poster_ip, date, expire)
			VALUES (%d, %d, %d , %d, %d, \'%s\', %d, %d)',
			$input['modification'], $user_id, $userdata['user_id'], $post_id, $forum_id, $user_ip, $current_time, $input['expire']);
		$review_id = $db->sql_nextid();

		db_query("INSERT INTO {REPUTATION_TEXT_TABLE} (id, text, bbcode_uid) VALUES (%d, '%s', '%s')",
			$review_id, $input['comment'], $input['bbcode_uid']);

		// Update user's reputation
		$reputation_sql = ($mode == 'ban') ? 'user_bans_total = user_bans_total + 1' : 'user_warnings_total = user_warnings_total + 1';
		db_query('UPDATE {USERS_TABLE} SET user_warnings_dem = user_warnings_dem + 1, ' . $reputation_sql . ' WHERE user_id = %d', $user_id);

		if ($mode == 'ban')
		{
			// Ban user and delete session
			db_query('INSERT INTO {BANLIST_TABLE} (ban_userid) VALUES (%d)', $user_id);
			db_query('DELETE FROM {SESSIONS_TABLE} WHERE session_user_id = %d', $user_id);
			// db_query('DELETE FROM {SESSIONS_KEYS_TABLE} WHERE user_id = %d', $user_id);

			global $db;
			$autologin_id = '';
			$db->query("
				UPDATE ". USERS_TABLE ." SET
					autologin_id = '$autologin_id'
				WHERE user_id = ". (int) $user_id ."
				LIMIT 1
			");

			include_once($phpbb_root_path .'includes/functions_torrent.'. $phpEx);
			if (!generate_passkey($user_id, true))
			{
				message_die(GENERAL_ERROR, 'Could not insert passkey', '', __LINE__, __FILE__, $sql);
			}
			$db->sql_query("DELETE FROM ". BT_TRACKER_TABLE ." WHERE user_id = ". (int) $user_id);

		}
		db_transaction(END_TRANSACTION);

		require_once($phpbb_root_path . 'includes/functions_admin.' . $phpEx);
		if (!isset($topic_id)) $topic_id = 0;
		if (!isset($forum_id)) $forum_id = 0;
		$log_action->admin('adm_user_ban', array(
			'forum_id' => $forum_id,
			'topic_id' => $topic_id,
			'log_msg' => 'user: '. get_usernames_for_log($user_id),
		));

		if ($bb_cfg['reputation_notify_' . $mode] != 'none')
		{
			$plain_comments = stripslashes($input['comment_orig']);

			$user_lang = lang_any($user_post_data['user_lang']);
			$period = isset($input['expire_days']) ? sprintf($user_lang['reputation_for_days'], $input['expire_days']) : $user_lang['reputation_forever'];
			$details_link = server_url() . "profile.$phpEx?mode=warnings&" . POST_REVIEWS_URL . "=$review_id";
			// NOTE: since the post user warned for may be deleted, we always link to warnings list

			if ($bb_cfg['reputation_notify_' . $mode] == 'email')
			{
				reputation_email($user_post_data, 'reputation_' . $mode, array(
					'MODERATOR' => email_prepare_username($userdata['username']),
					'TIME' => $period,
					'REASON' => email_prepare_message($plain_comments, $bb_cfg['allow_bbcode']),
					'U_LINK' => $details_link,
				));
			}
			else // 'pm'
			{
				$moderator = $bb_cfg['allow_bbcode'] ? ('[url=' . server_url() . "profile.$phpEx?mode=viewprofile&" . POST_USERS_URL . '=' . $userdata['user_id'] . ']' . $userdata['username'] . '[/url]') : $userdata['username'];
				$message = sprintf($user_lang['reputation_notify_' . $mode], $moderator, $period, $plain_comments, $details_link);

				reputation_pm($userdata, $user_post_data, $message, $user_lang['reputation_subj_warning'], $bb_cfg['allow_bbcode']);
			}
		}

		message_die(GENERAL_MESSAGE,
			$lang['reputation_warning_successfull'] . '<br /><br />' .
			sprintf($lang['reputation_msg_view_your_review'], '<a href="' . append_sid("profile.$phpEx?mode=warnings&amp;" . POST_REVIEWS_URL . "=$review_id") . "#$review_id\">", '</a>') .
			$back_url);
	} // End of submit
	else
	{
		$editor->show($self_params, ($post_id != NO_ID) ? $user_post_data : null, isset($notes) ? $notes : null);
	}
}
elseif ($mode == 'edit')
{
	//
	// User has selected to edit the review
	//
	$review_id = input_var(POST_REVIEWS_URL, 0, $lang['reputation_no_review_spec']);
	$self_params .= '&' . POST_REVIEWS_URL . '=' . $review_id;

	//
	// Check the user's rights to view/read the forum where the referred post is
	//
	$result = db_query('SELECT u.username, u.user_level, r.*, rt.text, rt.bbcode_uid
		FROM {REPUTATION_TABLE} r, {USERS_TABLE} u, {REPUTATION_TEXT_TABLE} rt
		WHERE r.id = %d
			AND r.voter_id = u.user_id
			AND r.id = rt.id', $review_id);

	if ($review_data = $db->sql_fetchrow($result))
	{
		if ($review_data['post_id'] == NO_ID && $review_data['forum_id'] != NO_ID)
		{
			// Post is deleted, nothing to do with it
			message_die(GENERAL_MESSAGE, $lang['reputation_deleted_no_edit']);
		}
	}
	else
	{
		message_die(GENERAL_MESSAGE, $lang['Topic_post_not_exist']); // review doesn't exist
	}

	$forum_id = intval($review_data['forum_id']);
	$user_id = intval($review_data['user_id']);
	$post_id = intval($review_data['post_id']);
	$modification = intval($review_data['modification']);

	//
	// Start auth check (session management started at profile.php)
	//
	$is_auth = reputation_auth($forum_id, $userdata, $review_data, true);
	$auth_key = ($modification == REPUTATION_INC || $modification == REPUTATION_DEC) ? 'auth_edit_rep' : 'auth_edit_warn';

	if (!$is_auth[$auth_key])
	{
		if (!$userdata['session_logged_in'])
		{
			redirect(append_sid("login.$phpEx?redirect=reputation.$phpEx?$self_params", true));
		}

		message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
	}

	// Load page header
	include($phpbb_root_path . 'includes/page_header.' . $phpEx);

	$editor = new review_editor($mode, $review_data);

	if (isset($_POST['submit']))
	{
		$input = $editor->get_input();

		if ($post_id != NO_ID)
		{
			$back_url = '<br /><br />' . sprintf($lang['reputation_msg_back_to_topic'], '<a href="' . append_sid("viewtopic.$phpEx?" . POST_POST_URL . "=$post_id") . "#$post_id\">", '</a>');
		}
		else
		{
			$back_url = '<br /><br />' . sprintf($lang['reputation_msg_view_profile'], '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=$user_id") . '">', '</a>');
		}

		// If everything's ok, post the review
		$set = '';
		if (!$is_auth['auth_mod'])
		{
			$set = 'edit_count = edit_count + 1, edit_time = ' . intval($current_time);
		}
		if (isset($input['expire']))
		{
			$set .= ($set ? ',' : '') . 'expire = ' . intval($input['expire']);
		}
		if ($set)
		{
			db_query("UPDATE {REPUTATION_TABLE} SET $set WHERE id = %d", $review_id);
		}

		db_query('UPDATE {REPUTATION_TEXT_TABLE}
			SET text = \'%s\', bbcode_uid = \'%s\'
			WHERE id = %d', $input['comment'], $input['bbcode_uid'], $review_id);

		message_die(GENERAL_MESSAGE, $lang['reputation_update_successfull'] . '<br /><br />' . sprintf($lang['reputation_msg_view_your_review'], '<a href="' . append_sid("profile.$phpEx?mode=reputation&" . POST_REVIEWS_URL . "=$review_id") . "#$review_id\">", '</a>') . $back_url);
	} // End of submit
	else
	{
		if ($post_id != NO_ID)
		{
			// Get the referred post info
			$result = db_query('SELECT u.username, p.*, pt.post_text, pt.post_subject, pt.bbcode_uid
				FROM {POSTS_TABLE} p, {USERS_TABLE} u, {POSTS_TEXT_TABLE} pt
				WHERE p.post_id = %d
					AND p.post_id = pt.post_id
					AND p.poster_id = u.user_id', $post_id);
			if (!($post_data = $db->sql_fetchrow($result)))
			{
				message_die(GENERAL_MESSAGE, $lang['reputation_deleted_no_edit']);
			}
		}
		else
		{
			$post_data = null;
		}

		$editor->show($self_params, $post_data);
	}
}
elseif ($mode == 'delete')
{
	//
	// User has selected to delete the review
	//
	$review_id = input_var(POST_REVIEWS_URL, 0, $lang['reputation_no_review_spec']);
	$self_params .= '&' . POST_REVIEWS_URL . '=' . $review_id;

	if (isset($_POST['cancel']))
	{
		redirect(append_sid("profile.$phpEx?mode=$ret&" . POST_REVIEWS_URL . "=$review_id", true) . "#$review_id");
	}

	//
	// Check the user's rights to view/read the forum where the referred post is
	//
	$result = db_query('SELECT p.forum_id, r.post_id, r.voter_id, r.user_id, r.modification, r.amount, u.user_level FROM {POSTS_TABLE} p, {REPUTATION_TABLE} r, {USERS_TABLE} u
		WHERE r.post_id = p.post_id
			AND r.voter_id = u.user_id
			AND r.id = %d', $review_id);
	if (!($review_data = $db->sql_fetchrow($result)))
	{
		$result = db_query('SELECT {NO_ID} AS post_id, r.forum_id, r.voter_id, r.user_id, r.modification, r.amount, u.user_level FROM {REPUTATION_TABLE} r, {USERS_TABLE} u
			WHERE r.voter_id = u.user_id
				AND r.id = %d', $review_id);
		if (!($review_data = $db->sql_fetchrow($result)))
		{
			message_die(GENERAL_MESSAGE, $lang['Topic_post_not_exist']);
		}
	}

	$user_id = intval($review_data['user_id']);
	$modification = intval($review_data['modification']);
	$post_id = intval($review_data['post_id']);

	//
	// Start auth check (session management started at profile.php)
	//
	$is_auth = reputation_auth($review_data['forum_id'], $userdata, $review_data, true);
	$auth_key = ($modification == REPUTATION_INC || $modification == REPUTATION_DEC) ? 'auth_delete_rep' : 'auth_delete_warn';

	if (!$is_auth[$auth_key])
	{
		if (!$userdata['session_logged_in'])
		{
			redirect(append_sid("login.$phpEx?redirect=profile.$phpEx?$self_params", true));
		}

		message_die(GENERAL_MESSAGE, isset($is_auth[$auth_key . '_msg']) ? $is_auth[$auth_key . '_msg'] : $lang['Not_Authorised']);
	}

	//
	// Load page header
	//
	include($phpbb_root_path . 'includes/page_header.' . $phpEx);

	if (!isset($_POST['confirm']))
	{
		//
		// Confirm deletion
		//
		$template->set_filenames(array('confirm_body' => 'confirm_body.tpl'));

		$template->assign_vars(array(
			'MESSAGE_TITLE' => $lang['INFORMATION'],
			'MESSAGE_TEXT' => $lang['reputation_confirm_delete'],

			'L_YES' => $lang['YES'],
			'L_NO' => $lang['NO'],

			'S_HIDDEN_FIELDS' => preg_replace('#([^=]+)=([^&]+)&#si', '<input type="hidden" name="\1" value="\2" />', $self_params . '&'),
			'S_CONFIRM_ACTION' => append_sid("reputation.$phpEx")
		));

		$template->pparse('confirm_body');

		include($phpbb_root_path . 'includes/page_footer.' . $phpEx);
	}
	else
	{
		if ($post_id != NO_ID)
		{
			$back_url = '<br /><br />' . sprintf($lang['reputation_msg_back_to_topic'], '<a href="' . append_sid("viewtopic.$phpEx?" . POST_POST_URL . '=' . $post_id) . '#' . $post_id . '">', '</a>');
		}
		else
		{
			$back_url = '<br /><br />' . sprintf($lang['reputation_msg_view_profile'], '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=$user_id") . '">', '</a>');
		}

		//
		// Perform review deletion
		//
		db_transaction(BEGIN_TRANSACTION);
		db_query('DELETE FROM {REPUTATION_TABLE} WHERE id = %d', $review_id);
		db_query('DELETE FROM {REPUTATION_TEXT_TABLE} WHERE id = %d', $review_id);

		switch ($modification)
		{
			case REPUTATION_INC:
				$set = 'user_reputation = user_reputation - %1$d, user_reputation_plus = user_reputation_plus - %1$d';
				break;
			case REPUTATION_DEC:
				$set = 'user_reputation = user_reputation + %1$d';
				break;
			case REPUTATION_WARNING:
				$set = 'user_warnings_dem = user_warnings_dem - 1, user_warnings_total = user_warnings_total - 1';

				require_once($phpbb_root_path . 'includes/functions_admin.' . $phpEx);
				$log_action->admin('adm_user_unban', array(
					'log_msg' => 'user: '. get_usernames_for_log($user_id),
				));

				break;
			case REPUTATION_BAN:
				$set = 'user_warnings_dem = user_warnings_dem - 1, user_bans_total = user_bans_total - 1';
				db_query('DELETE FROM {BANLIST_TABLE} WHERE ban_userid = %d', $user_id);

				require_once($phpbb_root_path . 'includes/functions_admin.' . $phpEx);
				$log_action->admin('adm_user_unban', array(
					'log_msg' => 'user: '. get_usernames_for_log($user_id),
				));

				break;
			case REPUTATION_WARNING_EXPIRED:
				$set = 'user_warnings_total = user_warnings_total - 1';
				break;
			case REPUTATION_BAN_EXPIRED:
				$set = 'user_bans_total = user_bans_total - 1';
				break;
			default:
				message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
				break;
		}

		db_query('UPDATE {USERS_TABLE} SET ' . $set . ' WHERE user_id = %2$d', $review_data['amount'], $user_id);

		if ($modification == REPUTATION_INC || $modification == REPUTATION_DEC)
		{
			db_query('UPDATE {USERS_TABLE} SET user_reviews = user_reviews - 1 WHERE user_id = %d', $review_data['voter_id']);

			if ($post_id != NO_ID)
			{
				db_query('UPDATE {POSTS_TABLE} SET post_reviews = post_reviews - 1 WHERE post_id = %d', $post_id);
			}
		}
		db_transaction(END_TRANSACTION);

		message_die(GENERAL_MESSAGE, $lang['reputation_delete_success'] . $back_url);
	}
}

include($phpbb_root_path . 'includes/page_footer.' . $phpEx);