<?php
/*************************************************************************************
 *                           admin_democracy.php
 * Part of Democracy MOD by Carbofos < carbofos@mail.ru > and ETZel < etzel@mail.ru >
 *************************************************************************************/

/*************************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *************************************************************************************/

// @define('IN_PHPBB', 1);

if (!empty($setmodules))
{
	$filename = basename(__FILE__);
	$module['General'][$lang['reputation_democracy']] = $filename;
	return;
}

//
// Set the root dir for phpBB
//
$phpbb_root_path = './../';
$phpEx = 'php';
// if (!defined('BB_ROOT') && !empty($phpbb_root_path))
// {
//	define('BB_ROOT', $phpbb_root_path);
// }
// if (!defined('PHP_EXT'))
// {
//	define('PHP_EXT', $phpEx);
//}
require('./pagestart.' . $phpEx);
require($phpbb_root_path . 'includes/functions_reputation.' . $phpEx);

// Values for reputation and warning prereqs to indicate 'disabled' state.
define('REPUTATION_MIN', -100000);
define('WARNINGS_MAX', 100000);

$mode = isset($_GET['mode']) ? $_GET['mode'] : '';

if (isset($_POST['resync']))
{
	// Reset democracy fields in users table
	db_query('UPDATE {USERS_TABLE} SET user_reputation = 0, user_reputation_plus = 0, user_warnings_dem = 0, user_warnings_total = 0, user_bans_total = 0, user_reviews = 0');

	// Update user info grouped by user_id field
	$result = db_query('SELECT user_id,
			SUM((modification = {REPUTATION_INC}) * amount) AS reputation_plus,
			SUM((modification = {REPUTATION_DEC}) * amount) AS reputation_minus,
			SUM(modification = {REPUTATION_WARNING} OR modification = {REPUTATION_BAN}) AS warnings,
			SUM(modification = {REPUTATION_WARNING} OR modification = {REPUTATION_WARNING_EXPIRED}) AS warnings_total,
			SUM(modification = {REPUTATION_BAN} OR modification = {REPUTATION_BAN_EXPIRED}) AS bans_total
		FROM {REPUTATION_TABLE}
		GROUP BY user_id');

	while ($row = $db->sql_fetchrow($result))
	{
		$reputation = $row['reputation_plus'] - $row['reputation_minus'];
		db_query('UPDATE {USERS_TABLE} SET user_reputation = %d, user_reputation_plus = %d, user_warnings_dem = %d, user_warnings_total = %d, user_bans_total = %d
			WHERE user_id = %d',
			$reputation, $row['reputation_plus'], $row['warnings'], $row['warnings_total'], $row['bans_total'], $row['user_id']);
	}

	// Update user info grouped by voter_id field
	$result = db_query('SELECT voter_id, SUM(modification = {REPUTATION_INC} || modification = {REPUTATION_DEC}) AS reviews
		FROM {REPUTATION_TABLE}
		WHERE modification IN({REPUTATION_INC}, {REPUTATION_DEC})
		GROUP BY voter_id');

	while ($row = $db->sql_fetchrow($result))
	{
		db_query('UPDATE {USERS_TABLE} SET user_reviews = %d
			WHERE user_id = %d',
			$row['reviews'], $row['voter_id']);
	}

	// Reset democracy records in posts table
	db_query('UPDATE {POSTS_TABLE} SET post_reviews = 0');

	// Update post reviews count info
	$result = db_query('SELECT post_id, COUNT(*) AS reviews
		FROM {REPUTATION_TABLE}
		WHERE modification IN({REPUTATION_INC}, {REPUTATION_DEC})
		GROUP BY post_id');

	while ($row = $db->sql_fetchrow($result))
	{
		db_query('UPDATE {POSTS_TABLE} SET post_reviews = %d WHERE post_id = %d', $row['reviews'], $row['post_id']);
	}

	// Update reviews' forum_id records
	$result = db_query('SELECT r.id, r.forum_id AS review_forum_id, p.post_id, p.forum_id AS post_forum_id
		FROM {REPUTATION_TABLE} r LEFT JOIN {POSTS_TABLE} p ON r.post_id = p.post_id
		WHERE p.forum_id <> r.forum_id OR (r.post_id <> {NO_ID} AND p.post_id IS NULL)');

	$no_post = ''; $wrong_forum = array();

	while ($row = $db->sql_fetchrow($result))
	{
		if (!$row['post_id'])
		{
			$no_post .= ($no_post ? ',' : '') . $row['id'];
		}
		elseif ($row['review_forum_id'] != $row['post_forum_id'])
		{
			if (isset($wrong_forum[$row['post_forum_id']]))
			{
				$wrong_forum[$row['post_forum_id']] .= ',' . $row['id'];
			}
			else
			{
				$wrong_forum[$row['post_forum_id']] = $row['id'];
			}
		}
	}

	if ($no_post)
	{
		db_query('UPDATE {REPUTATION_TABLE} SET post_id = {NO_ID} WHERE id IN(%s)', $no_post);
	}
	foreach ($wrong_forum as $forum_id => $review_ids)
	{
		db_query('UPDATE {REPUTATION_TABLE} SET forum_id = %d WHERE id IN(%s)', $forum_id, $review_ids);
	}

	$links = sprintf($lang['Click_return_reputation_index'], '<a href="' . append_sid("admin_democracy.$phpEx") . '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_admin_index'], '<a href="' . append_sid("index.$phpEx?pane=right") . '">', '</a>');
	$message = '<br />' . $lang['reputation_success'] . '<br /><br />' . $links . '<br /><br />';
 	message_die(GENERAL_MESSAGE, $message);
}

if (!isset($_POST['confirm']))
{
	// Display settings page
	// $template->set_filenames(array(
	//	"body" => 'admin/reputation_body.tpl')
	// );

	$auth_idx = array(AUTH_ALL => 3, AUTH_REG => 0, AUTH_MOD => 1, AUTH_ADMIN => 2); // remap AUTH_xxx constants to indices
	foreach ($reputation_auth_keys as $i => $key)
	{
		$reputation_auth[$key] = $auth_idx[$bb_cfg['reputation_perms'][$i]];
	}

	foreach ($reputation_auto_idx as $i => $key)
	{
		$reputation_auto[$key] = isset($bb_cfg['reputation_auto_data'][$i]) ? $bb_cfg['reputation_auto_data'][$i] : 0;
	}

	// trick to keep lang_admin file clean
	$prepare_keys = array('reputation_days_req', 'reputation_posts_req', 'reputation_warnings_req', 'reputation_points_req', 'reputation_time_limit', 'reputation_rotation_limit', 'reputation_most_respected', 'reputation_least_respected', 'reputation_fixed', 'reputation_modifiable', 'reputation_delete_days', 'reputation_ban_warnings', 'reputation_check_rate', 'reputation_start', 'reputation_for_days', 'reputation_for_posts', 'reputation_for_reviews', 'reputation_for_rep', 'reputation_for_warns', 'reputation_for_bans', 'reputation_giving_for_days', 'reputation_giving_for_posts', 'reputation_giving_for_rep', 'reputation_giving_max', 'reputation_giving_slowdown');
	foreach ($prepare_keys as $key)
	{
		foreach (explode('%s', $lang[$key]) as $i => $part)
		{
			$lang[$key . '_' . $i] = $part;
		}
	}

	function decode_expiration($expiration)
	{
		$mode = count($expiration);
		if ($mode == 2)
		{
			$min = empty($expiration[0]) ? '' : $expiration[0];
			$max = empty($expiration[1]) ? '' : $expiration[1];
		}
		else
		{
			$min = empty($expiration[0]) ? 3 : $expiration[0];
			$max = $min + 7;
		}
		return array($mode, $min, $max);
	}

	list($warn_expire_mode, $warn_expire_min, $warn_expire_max) = decode_expiration($bb_cfg['reputation_warning_expire']);
	list($ban_expire_mode, $ban_expire_min, $ban_expire_max) = decode_expiration($bb_cfg['reputation_ban_expire']);
	$delete_expired = $bb_cfg['reputation_delete_expired'] != -1;

	$s_default_order = html_select('default_order', array('0', '1'), array('Oldest_First', 'Newest_First'), $bb_cfg['reputation_default_order']);

	if (!isset($bb_cfg['reputation_giving'][0]))
	{
		$bb_cfg['reputation_giving'][0] = '';
	}
	if (!isset($bb_cfg['reputation_giving'][1]))
	{
		$bb_cfg['reputation_giving'][1] = '';
	}
	if (!isset($bb_cfg['reputation_giving'][2]))
	{
		$bb_cfg['reputation_giving'][2] = '';
	}
	if (!isset($bb_cfg['reputation_giving'][3]))
	{
		$bb_cfg['reputation_giving'][3] = '';
	}
	if (!isset($bb_cfg['reputation_giving'][4]))
	{
		$bb_cfg['reputation_giving'][4] = '';
	}

	$template->assign_vars(array(
		'L_DEMOCRACY' => $lang['reputation_democracy'],
		'L_DEMOCRACY_EXP' => $lang['reputation_democracy_exp'],
		'L_CHECK_CONFIRM' => $lang['reputation_check_confirm'],
		'L_SUBMIT' => $lang['SUBMIT'],
		'L_RESET' => $lang['RESET'],
		'L_CONFIRM' => $lang['CONFIRM'],
		'L_EVERYBODY' => $lang['Forum_ALL'],
		'L_USER' => $lang['Forum_REG'],
		'L_MODERATOR' => $lang['Forum_MOD'],
		'L_ADMIN' => $lang['Forum_ADMIN'],

		'L_ENABLE_REPUTATION' => $lang['reputation_enable'],
		'L_ENABLE_WARNINGS' => $lang['reputation_enable_warnings'],
		'L_REPUTATION_OPTIONS' => $lang['reputation_reputation_options'],
		'L_WARNINGS_OPTIONS' => $lang['reputation_warnings_options'],
		'L_COMMON_OPTIONS' => $lang['reputation_common_options'],
		'L_POSITIVE_ONLY' => $lang['reputation_positive_only'],
		'L_POSITIVE_ONLY_EXP' => $lang['reputation_positive_only_exp'],
		'L_EMPTY_REVIEWS' => $lang['reputation_empty_reviews'],
		'L_ACCESS_RIGHTS' => $lang['reputation_access_rights'],
		'L_VIEW_REP' => $lang['reputation_view_rep'],
		'L_ADD_REP' => $lang['reputation_add_rep'],
		'L_ADD_REP_NONPOST' => $lang['reputation_add_rep_nonpost'],
		'L_EDIT_REP' => $lang['reputation_edit_rep'],
		'L_DELETE_REP' => $lang['reputation_delete_rep'],
		'L_NO_LIMITS' => $lang['reputation_no_limits'],
		'L_VIEW_WARNS' => $lang['reputation_view_warns'],
		'L_WARN' => $lang['reputation_warn'],
		'L_WARN_NONPOST' => $lang['reputation_warn_nonpost'],
		'L_BAN_NONPOST' => $lang['reputation_ban_nonpost'],
		'L_EDIT_WARNS' => $lang['reputation_edit_warns'],
		'L_DELETE_WARNS' => $lang['reputation_delete_warns'],
		'L_NOT_APPLICABLE' => $lang['reputation_not_applicable'],
		'L_REPUTATION_PERMS_NOTE' => $lang['reputation_perms_notes'],
		'L_WARNINGS_PERMS_NOTE' => $lang['reputation_warn_perms_notes'],

		'L_AUTO_REPUTATION' => $lang['reputation_auto_reputation'],
		'L_REP_START_0' => $lang['reputation_start_0'],
		'L_REP_START_1' => $lang['reputation_start_1'],
		'L_FOR_DAYS_0' => $lang['reputation_for_days_0'],
		'L_FOR_DAYS_1' => $lang['reputation_for_days_1'],
		'L_FOR_POSTS_0' => $lang['reputation_for_posts_0'],
		'L_FOR_POSTS_1' => $lang['reputation_for_posts_1'],
		'L_FOR_REVIEWS_0' => $lang['reputation_for_reviews_0'],
		'L_FOR_REVIEWS_1' => $lang['reputation_for_reviews_1'],
		'L_FOR_REP_0' => $lang['reputation_for_rep_0'],
		'L_FOR_REP_1' => $lang['reputation_for_rep_1'],
		'L_FOR_WARNS_0' => $lang['reputation_for_warns_0'],
		'L_FOR_WARNS_1' => $lang['reputation_for_warns_1'],
		'L_FOR_BANS_0' => $lang['reputation_for_bans_0'],
		'L_FOR_BANS_1' => $lang['reputation_for_bans_1'],

		'L_GIVING_SCALE' => $lang['reputation_giving_scale'],
		'L_GIVING_SCALE_EXP' => $lang['reputation_giving_scale_exp'],
		'L_GIVING_FOR_DAYS_0' => $lang['reputation_giving_for_days_0'],
		'L_GIVING_FOR_DAYS_1' => $lang['reputation_giving_for_days_1'],
		'L_GIVING_FOR_POSTS_0' => $lang['reputation_giving_for_posts_0'],
		'L_GIVING_FOR_POSTS_1' => $lang['reputation_giving_for_posts_1'],
		'L_GIVING_FOR_REP_0' => $lang['reputation_giving_for_rep_0'],
		'L_GIVING_FOR_REP_1' => $lang['reputation_giving_for_rep_1'],
		'L_GIVING_MAX_0' => $lang['reputation_giving_max_0'],
		'L_GIVING_MAX_1' => $lang['reputation_giving_max_1'],
		'L_GIVING_SLOWDOWN_0' => $lang['reputation_giving_slowdown_0'],
		'L_GIVING_SLOWDOWN_1' => $lang['reputation_giving_slowdown_1'],
		'L_GIVING_SLOWDOWN_EXP' => $lang['reputation_giving_slowdown_exp'],

		'L_DAYS_REQ_0' => $lang['reputation_days_req_0'],
		'L_DAYS_REQ_1' => $lang['reputation_days_req_1'],
		'L_POSTS_REQ_0' => $lang['reputation_posts_req_0'],
		'L_POSTS_REQ_1' => $lang['reputation_posts_req_1'],
		'L_WARNINGS_REQ_0' => $lang['reputation_warnings_req_0'],
		'L_WARNINGS_REQ_1' => $lang['reputation_warnings_req_1'],
		'L_REPUTATION_REQ_0' => $lang['reputation_points_req_0'],
		'L_REPUTATION_REQ_1' => $lang['reputation_points_req_1'],
		'L_TIME_LIMIT_0' => $lang['reputation_time_limit_0'],
		'L_TIME_LIMIT_1' => $lang['reputation_time_limit_1'],
		'L_ROTATION_LIMIT_0' => $lang['reputation_rotation_limit_0'],
		'L_ROTATION_LIMIT_1' => $lang['reputation_rotation_limit_1'],
		'L_ROTATION_LIMIT_EXP' => $lang['reputation_rotation_limit_exp'],
		'L_MOST_RESPECTED_0' => $lang['reputation_most_respected_0'],
		'L_MOST_RESPECTED_1' => $lang['reputation_most_respected_1'],
		'L_LEAST_RESPECTED_0' => $lang['reputation_least_respected_0'],
		'L_LEAST_RESPECTED_1' => $lang['reputation_least_respected_1'],
		'L_RESPECTED_EXP' => $lang['reputation_respected_exp'],
		'L_SHOW_VALUES' => $lang['reputation_show_values'],
		'L_REPUTATION_DISPLAY' => $lang['reputation_display'],
		'L_DISPLAY_SUM' => $lang['reputation_display_sum'],
		'L_DISPLAY_PLUSMINUS' => $lang['reputation_display_plusminus'],
		'L_WARNINGS_DISPLAY' => $lang['reputation_warnings_display'],
		'L_DISPLAY_IMG' => $lang['reputation_warnings_display_img'],
		'L_DISPLAY_TEXT' => $lang['reputation_warnings_display_text'],

		'L_NOTIFY' => $lang['reputation_notify'],
		'L_EMAIL' => $lang['EMAIL'],
		'L_PM' => $lang['PRIVATE_MESSAGE'],
		'L_NONE' => $lang['None'],
		'L_REPUTATION' => $lang['Reputation'],
		'L_WARNING' => $lang['Warning'],
		'L_BAN' => $lang['reputation_ban'],

		'L_INFINITE' => $lang['reputation_infinite'],
		'L_INFINITE_EXP' => $lang['reputation_infinite_exp'],
		'L_INFINITE_BAN_EXP' => $lang['reputation_infinite_ban_exp'],
		'L_FIXED_0' => $lang['reputation_fixed_0'],
		'L_FIXED_1' => $lang['reputation_fixed_1'],
		'L_MODIFIABLE_0' => $lang['reputation_modifiable_0'],
		'L_MODIFIABLE_1' => $lang['reputation_modifiable_1'],
		'L_MODIFIABLE_2' => $lang['reputation_modifiable_2'],
		'L_MODIFIABLE_EXP' => $lang['reputation_modifiable_exp'],
		'L_STORE' => $lang['reputation_store'],
		'L_DELETE_DAYS_0' => $lang['reputation_delete_days_0'],
		'L_DELETE_DAYS_1' => $lang['reputation_delete_days_1'],
		'L_BAN_WARNINGS_0' => $lang['reputation_ban_warnings_0'],
		'L_BAN_WARNINGS_1' => $lang['reputation_ban_warnings_1'],
		'L_BAN_WARNINGS_EXP' => $lang['reputation_ban_warnings_exp'],
		'L_CHECK_RATE_0' => $lang['reputation_check_rate_0'],
		'L_CHECK_RATE_1' => $lang['reputation_check_rate_1'],
		'L_CHECK_RATE_EXP' => $lang['reputation_check_rate_exp'],

		'L_EXPIRED_WARNINGS' => $lang['reputation_expired_warnings'],
		'L_WARNING_EXPIRY' => $lang['reputation_warning_expiry'],
		'L_BAN_EXPIRY' => $lang['reputation_ban_expiry'],
		'L_INDEX_PAGE' => $lang['reputation_index_page'],
		'L_PREREQUIREMENTS' => $lang['reputation_prerequirements'],
		'L_LIMITS' => $lang['reputation_limits'],

		'L_MEMBERLIST' => $lang['reputation_memberlist'],
		'L_MEMBERLIST_REPUTATION' => $lang['reputation_memberlist_reputation'],
		'L_MEMBERLIST_WARNINGS' => $lang['reputation_memberlist_warnings'],
		'L_DEFAULT_ORDER' => $lang['reputation_default_order'],

		'L_MAINTENANCE' =>  $lang['reputation_maintenance'],
		'L_RESYNC' =>  $lang['reputation_resync'],
		'L_RESYNC_EXP' =>  $lang['reputation_resync_exp'],

		/*
		'L_REPORTS_PER_PAGE' => $lang['reputation_reports_per_page'],
		'L_REVIEWS_PER_PAGE' => $lang['reputation_reviews_per_page'],
		'L_REVIEWS_PER_PAGE_EXP' => $lang['reputation_reviews_per_page_exp'],
		*/

		'S_REPUTATION_CHECKED' => $bb_cfg['reputation_enabled'] ? 'checked="checked" ' : '',
		'S_POSITIVE_ONLY' => $bb_cfg['reputation_positive_only'] ? 'checked="checked" ' : '',
		'S_EMPTY_REVIEWS' => $bb_cfg['reputation_empty_reviews'] ? 'checked="checked" ' : '',
		'S_WARNINGS_CHECKED' => $bb_cfg['warnings_enabled'] ? 'checked="checked" ' : '',

		'S_REP_START' => $reputation_auto['rep_start'],
		'S_FOR_DAYS' => $reputation_auto['for_regdays'] == 0 ? '&infin;' : $reputation_auto['for_regdays'],
		'S_FOR_POSTS' => $reputation_auto['for_posts'] == 0 ? '&infin;' : $reputation_auto['for_posts'],
		'S_FOR_REVIEWS' => $reputation_auto['for_reviews'] == 0 ? '&infin;' : $reputation_auto['for_reviews'],
		'S_FOR_REP' => $reputation_auto['for_rep'] == 0 ? '&infin;' : $reputation_auto['for_rep'],
		'S_FOR_WARNS' => $reputation_auto['for_warns'] == 0 ? '&infin;' : $reputation_auto['for_warns'],
		'S_FOR_BANS' => $reputation_auto['for_bans'] == 0 ? '&infin;' : $reputation_auto['for_bans'],
		'S_ENABLE_REP_START' => $reputation_auto['rep_start'] ? 'checked="checked" ' : '',
		'S_ENABLE_FOR_DAYS' => $reputation_auto['for_regdays'] ? 'checked="checked" ' : '',
		'S_ENABLE_FOR_POSTS' => $reputation_auto['for_posts'] ? 'checked="checked" ' : '',
		'S_ENABLE_FOR_REVIEWS' => $reputation_auto['for_reviews'] ? 'checked="checked" ' : '',
		'S_ENABLE_FOR_REP' => $reputation_auto['for_rep'] ? 'checked="checked" ' : '',
		'S_ENABLE_FOR_WARNS' => $reputation_auto['for_warns'] ? 'checked="checked" ' : '',
		'S_ENABLE_FOR_BANS' => $reputation_auto['for_bans'] ? 'checked="checked" ' : '',

		'S_GIVING_FOR_DAYS' => intval($bb_cfg['reputation_giving'][0]),
		'S_GIVING_FOR_POSTS' => intval($bb_cfg['reputation_giving'][1]),
		'S_GIVING_FOR_REP' => intval($bb_cfg['reputation_giving'][2]),
		'S_GIVING_MAX' => intval($bb_cfg['reputation_giving'][3]),
		'S_GIVING_SLOWDOWN' => intval($bb_cfg['reputation_giving'][4]),
		'S_ENABLE_GIVING_FOR_DAYS' => $bb_cfg['reputation_giving'][0] ? 'checked="checked" ' : '',
		'S_ENABLE_GIVING_FOR_POSTS' => $bb_cfg['reputation_giving'][1] ? 'checked="checked" ' : '',
		'S_ENABLE_GIVING_FOR_REP' => $bb_cfg['reputation_giving'][2] ? 'checked="checked" ' : '',
		'S_ENABLE_GIVING_MAX' => $bb_cfg['reputation_giving'][3] ? 'checked="checked" ' : '',
		'S_ENABLE_GIVING_SLOWDOWN' => $bb_cfg['reputation_giving'][4] ? 'checked="checked" ' : '',

		'S_DAYS_REQ' => $bb_cfg['reputation_days_req'],
		'S_POSTS_REQ' => $bb_cfg['reputation_posts_req'],
		'S_WARNINGS_REQ' => ($bb_cfg['reputation_warnings_req'] != WARNINGS_MAX) ? $bb_cfg['reputation_warnings_req'] : '0',
		'S_REPUTATION_REQ' => ($bb_cfg['reputation_points_req'] != REPUTATION_MIN) ? $bb_cfg['reputation_points_req'] : '7',
		'S_TIME_LIMIT' => $bb_cfg['reputation_time_limit'],
		'S_ROTATION_LIMIT' => $bb_cfg['reputation_rotation_limit'],
		'S_ENABLE_DAYS_REQ' => $bb_cfg['reputation_days_req'] ? 'checked="checked" ' : '',
		'S_ENABLE_POSTS_REQ' => $bb_cfg['reputation_posts_req'] ? 'checked="checked" ' : '',
		'S_ENABLE_WARNINGS_REQ' => ($bb_cfg['reputation_warnings_req'] != WARNINGS_MAX) ? 'checked="checked" ' : '',
		'S_ENABLE_REPUTATION_REQ' => ($bb_cfg['reputation_points_req'] != REPUTATION_MIN) ? 'checked="checked" ' : '',
		'S_ENABLE_TIME_LIMIT' => $bb_cfg['reputation_time_limit'] ? 'checked="checked" ' : '',
		'S_ENABLE_ROTATION_LIMIT' => $bb_cfg['reputation_rotation_limit'] ? 'checked="checked" ' : '',

		'S_VIEW_REP_CHECKED_' . $reputation_auth['auth_view_rep'] => 'checked="checked" ',
		'S_ADD_REP_CHECKED_' . $reputation_auth['auth_add_rep'] => 'checked="checked" ',
		'S_ADD_REP_NONPOST_CHECKED_' . $reputation_auth['auth_add_rep_nonpost'] => 'checked="checked" ',
		'S_EDIT_REP_CHECKED_' . $reputation_auth['auth_edit_rep'] => 'checked="checked" ',
		'S_DELETE_REP_CHECKED_' . $reputation_auth['auth_delete_rep'] => 'checked="checked" ',
		'S_NO_LIMITS_CHECKED_' . $reputation_auth['auth_no_limits'] => 'checked="checked" ',
		'S_VIEW_WARNS_CHECKED_' . $reputation_auth['auth_view_warns'] => 'checked="checked" ',
		'S_WARN_CHECKED_' . $reputation_auth['auth_warn'] => 'checked="checked" ',
		'S_WARN_NONPOST_CHECKED_' . $reputation_auth['auth_warn_nonpost'] => 'checked="checked" ',
		'S_BAN_CHECKED_' . $reputation_auth['auth_ban'] => 'checked="checked" ',
		'S_BAN_NONPOST_CHECKED_' . $reputation_auth['auth_ban_nonpost'] => 'checked="checked" ',
		'S_EDIT_WARN_CHECKED_' . $reputation_auth['auth_edit_warn'] => 'checked="checked" ',
		'S_DELETE_WARN_CHECKED_' . $reputation_auth['auth_delete_warn'] => 'checked="checked" ',

		'S_NOTIFY_REPUTATION_' . strtoupper($bb_cfg['reputation_notify_reputation']) => 'checked="checked" ',
		'S_NOTIFY_WARNING_' . strtoupper($bb_cfg['reputation_notify_warning']) => 'checked="checked" ',
		'S_NOTIFY_BAN_' . strtoupper($bb_cfg['reputation_notify_ban']) => 'checked="checked" ',

		'S_DELETE_EXPIRED_CHECKED_' . ($delete_expired ? '1' : '0') => 'checked="checked" ',
		'S_DELETE_EXPIRED_DAYS' => ($delete_expired ? $bb_cfg['reputation_delete_expired'] : '0'),

		'S_EXPIRE_MODE_' . $warn_expire_mode => 'checked="checked" ',
		'S_EXPIRE_FIXED' => $warn_expire_min,
		'S_EXPIRE_MIN' => $warn_expire_min,
		'S_EXPIRE_MAX' => $warn_expire_max,
		'S_BAN_EXPIRE_MODE_' . $ban_expire_mode => 'checked="checked" ',
		'S_BAN_EXPIRE_FIXED' => $ban_expire_min,
		'S_BAN_EXPIRE_MIN' => $ban_expire_min,
		'S_BAN_EXPIRE_MAX' => $ban_expire_max,

		'S_BAN_WARNINGS' => $bb_cfg['reputation_ban_warnings'],
		'S_BAN_WARNINGS_CHECKED' => $bb_cfg['reputation_ban_warnings'] ? 'checked="checked" ' : '',

		'S_MOST_RESPECTED' => $bb_cfg['reputation_most_respected'],
		'S_LEAST_RESPECTED' => $bb_cfg['reputation_least_respected'],
		'S_ENABLE_MOST_RESPECTED' => $bb_cfg['reputation_most_respected'] ? 'checked="checked" ' : '',
		'S_ENABLE_LEAST_RESPECTED' => $bb_cfg['reputation_least_respected'] ? 'checked="checked" ' : '',
		'S_SHOW_VALUES' => $bb_cfg['reputation_show_values'] ? 'checked="checked" ' : '',

		'S_MOD_NOREP_CHECKED' => $bb_cfg['reputation_mod_norep'] ? 'checked="checked" ' : '',
		'S_ADMIN_NOREP_CHECKED' => $bb_cfg['reputation_admin_norep'] ? 'checked="checked" ' : '',

		'S_CHECK_RATE' => $bb_cfg['reputation_check_rate'],

		'S_REPUTATION_DISPLAY_' . $bb_cfg['reputation_display'] => 'checked="checked" ',
		'S_WARNINGS_DISPLAY_' . strtoupper($bb_cfg['reputation_warnings_display']) => 'checked="checked" ',
		'S_WARNINGS_DISPLAY_LINK' => 'checked="checked" ',

		'S_MEMBERLIST_REPUTATION' => $bb_cfg['reputation_memberlist'][0] ? 'checked="checked" ' : '',
		'S_MEMBERLIST_WARNINGS' => $bb_cfg['reputation_memberlist'][1] ? 'checked="checked" ' : '',

		'S_DEFAULT_ORDER' => $s_default_order,

		/*
		'S_REPORTS_PER_PAGE' => $bb_cfg['reputation_reports_per_page'],
		'S_REVIEWS_PER_PAGE' => $bb_cfg['reputation_reviews_per_page'],
		*/

		'AUTH_ALL' => AUTH_ALL,
		'AUTH_REG' => AUTH_REG,
		'AUTH_MOD' => AUTH_MOD,
		'AUTH_ADMIN' => AUTH_ADMIN,

		'REPUTATION_SUM' => REPUTATION_SUM,
		'REPUTATION_PLUSMINUS' => REPUTATION_PLUSMINUS,

		'S_REPUTATION_ACTION' => append_sid("admin_democracy.$phpEx"),
	));

	// $template->pparse("body");

	// include('./page_footer_admin.'.$phpEx);
	print_page('reputation_body.tpl', 'admin');
}
else
{
	function positive($val)
	{
		$val = intval($val);
		return max($val, 0);
	}
	function expiration($prefix)
	{
		switch ($_POST[$prefix . '_mode'])
		{
			case '1':
				return positive($_POST[$prefix . '_fixed']);
			case '2':
				return positive($_POST[$prefix . '_min']) . ',' . positive($_POST[$prefix . '_max']);
			default: // case '0':
				return '';
		}
	}

	//
	// Get posted data and evalutate it for errors
	//
	$new_config = array(
		// checkbox
		'reputation_enabled' => intval(isset($_POST['reputation'])),
		'warnings_enabled' => intval(isset($_POST['warnings'])),
		'reputation_positive_only' => intval(isset($_POST['positive_only'])),
		'reputation_empty_reviews' => intval(isset($_POST['empty_reviews'])),
		'reputation_admin_norep' => intval(isset($_POST['admin_norep'])),
		'reputation_mod_norep' => intval(isset($_POST['mod_norep'])),

		// checkbox + textbox
		'reputation_days_req' => isset($_POST['enable_days_req']) ? positive($_POST['days_req']) : '0',
		'reputation_posts_req' => isset($_POST['enable_posts_req']) ? positive($_POST['posts_req']) : '0',
		'reputation_warnings_req' => isset($_POST['enable_warnings_req']) ? positive($_POST['warnings_req']) : WARNINGS_MAX,
		'reputation_points_req' => isset($_POST['enable_reputation_req']) ? intval($_POST['reputation_req']) : REPUTATION_MIN,
		'reputation_time_limit' => isset($_POST['enable_time_limit']) ? positive($_POST['time_limit']) : '0',
		'reputation_rotation_limit' => isset($_POST['enable_rotation_limit']) ? positive($_POST['rotation_limit']) : '0',
		'reputation_most_respected' => isset($_POST['enable_most_respected']) ? positive($_POST['most_respected']) : '0',
		'reputation_least_respected' => isset($_POST['enable_least_respected']) ? positive($_POST['least_respected']) : '0',
		'reputation_show_values' => intval(isset($_POST['show_values'])),
		'reputation_ban_warnings' => isset($_POST['enable_ban_warnings']) ? positive($_POST['ban_warnings']) : '0',

		// radio
		'reputation_display' => intval($_POST['reputation_display']),
		'reputation_warnings_display' => $_POST['warnings_display'],
		'reputation_notify_reputation' => preg_match('#mail|pm#', $_POST['notify_reputation']) ? $_POST['notify_reputation'] : 'none',
		'reputation_notify_warning' => preg_match('#mail|pm#', $_POST['notify_warning']) ? $_POST['notify_warning'] : 'none',
		'reputation_notify_ban' => ($_POST['notify_ban'] == 'email') ? 'email' : 'none',

		// radio + textbox
		'reputation_delete_expired' => !empty($_POST['enable_delete_expired']) ? positive($_POST['delete_expired']) : '-1',

		// textbox
		'reputation_check_rate' => positive($_POST['check_rate']),

		// expirations
		'reputation_warning_expire' => expiration('expire'),
		'reputation_ban_expire' => expiration('ban_expire'),

		// checkboxes array
		'reputation_memberlist' => intval(isset($_POST['memberlist_reputation'])) . intval(isset($_POST['memberlist_warnings'])),

		// select
		'reputation_default_order' => intval($_POST['default_order']),
	);

	foreach ($reputation_auth_keys as $key)
	{
		$reputation_auth[] = isset($_POST[$key]) ? intval($_POST[$key]) : AUTH_ADMIN;
	}
	$new_config['reputation_perms'] = implode(',', $reputation_auth);

	// Compact auto reputation settings
	foreach ($reputation_auto_idx as $auto_idx)
	{
		$reputation_auto[] = isset($_POST['enable_' . $auto_idx]) ? intval($_POST[$auto_idx]) : 0;
	}
	$new_config['reputation_auto_data'] = array_sum($reputation_auto) ? implode(',', $reputation_auto) : '';

	// Givings
	$giving_scale = array(
		isset($_POST['enable_giving_for_regdays']) ? positive($_POST['giving_for_regdays']) : 0,
		isset($_POST['enable_giving_for_posts']) ? positive($_POST['giving_for_posts']) : 0,
		isset($_POST['enable_giving_for_rep']) ? positive($_POST['giving_for_rep']) : 0,
		isset($_POST['enable_giving_max']) ? positive($_POST['giving_max']) : 0,
		isset($_POST['enable_giving_slowdown']) ? min(100, positive($_POST['giving_slowdown'])) : 0,
	);

	$new_config['reputation_giving'] = array_sum($giving_scale) ? implode(',', $giving_scale) : '';

	foreach ($new_config as $name => $value)
	{
		db_query("UPDATE {CONFIG_TABLE} SET config_value = '%s' WHERE config_name = '%s'", $value, $name);
	}

	cache_set('respected'); // clear_cache

	$links = sprintf($lang['Click_return_reputation_index'], '<a href="' . append_sid("admin_democracy.$phpEx") . '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_admin_index'], '<a href="' . append_sid("index.$phpEx?pane=right") . '">', '</a>');
	$message = '<br />' . $lang['Config_updated'] . '<br /><br />' . $links . '<br /><br />';
 	message_die(GENERAL_MESSAGE, $message);
}