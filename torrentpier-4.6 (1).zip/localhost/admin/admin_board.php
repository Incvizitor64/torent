<?php

// ACP Header - START
if (!empty($setmodules))
{
	$module['General']['Configuration'] = basename(__FILE__);
	return;
}
require('./pagestart.php');
// ACP Header - END

require(INC_DIR .'functions_selects.'. PHP_EXT);

//
// Pull all config data
//
$sql = "SELECT *
	FROM " . CONFIG_TABLE;
if(!$result = $db->sql_query($sql))
{
	message_die(CRITICAL_ERROR, "Could not query config information in admin_board", "", __LINE__, __FILE__, $sql);
}
else
{
	while( $row = $db->sql_fetchrow($result) )
	{
		$config_name = $row['config_name'];
		$config_value = $row['config_value'];
		$default_config[$config_name] = $config_value;

		$new[$config_name] = isset($_POST[$config_name]) ? $_POST[$config_name] : $default_config[$config_name];

		// Attempt to prevent a mistake with this value.
		if ($config_name == 'avatar_path')
		{
			$new['avatar_path'] = trim($new['avatar_path']);
			if (strstr($new['avatar_path'], "\0") || !is_dir($phpbb_root_path . $new['avatar_path']) || !is_writable($phpbb_root_path . $new['avatar_path']))
			{
				$new['avatar_path'] = $default_config['avatar_path'];
			}
		}

		if (isset($_POST['submit']) && $row['config_value'] != $new[$config_name])
		{
			bb_update_config(array($config_name => $new[$config_name]));
		}
	}

	if( isset($_POST['submit']) )
	{
		$message = $lang['Config_updated'] . "<br /><br />" . sprintf($lang['Click_return_config'], "<a href=\"" . append_sid("admin_board.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

		message_die(GENERAL_MESSAGE, $message);
	}
}

$lang_select = language_select($new['default_lang'], 'default_lang', "language");
$timezone_select = tz_select($new['board_timezone'], 'board_timezone');

$disable_board_yes = ( $new['board_disable'] ) ? "checked=\"checked\"" : "";
$disable_board_no = ( !$new['board_disable'] ) ? "checked=\"checked\"" : "";

$cookie_secure_yes = ( $bb_cfg['cookie_secure'] ) ? "checked=\"checked\"" : "";
$cookie_secure_no = ( !$bb_cfg['cookie_secure'] ) ? "checked=\"checked\"" : "";

$bbcode_yes = ( $new['allow_bbcode'] ) ? "checked=\"checked\"" : "";
$bbcode_no = ( !$new['allow_bbcode'] ) ? "checked=\"checked\"" : "";

$activation_none = ( $new['require_activation'] == USER_ACTIVATION_NONE ) ? "checked=\"checked\"" : "";
$activation_user = ( $new['require_activation'] == USER_ACTIVATION_SELF ) ? "checked=\"checked\"" : "";
$activation_admin = ( $new['require_activation'] == USER_ACTIVATION_ADMIN ) ? "checked=\"checked\"" : "";

$confirm_yes = ($new['enable_confirm']) ? 'checked="checked"' : '';
$confirm_no = (!$new['enable_confirm']) ? 'checked="checked"' : '';

$allow_autologin_yes = ($new['allow_autologin']) ? 'checked="checked"' : '';
$allow_autologin_no = (!$new['allow_autologin']) ? 'checked="checked"' : '';

$board_email_form_yes = ( $new['board_email_form'] ) ? "checked=\"checked\"" : "";
$board_email_form_no = ( !$new['board_email_form'] ) ? "checked=\"checked\"" : "";

$privmsg_on = ( !$new['privmsg_disable'] ) ? "checked=\"checked\"" : "";
$privmsg_off = ( $new['privmsg_disable'] ) ? "checked=\"checked\"" : "";

$prune_yes = ( $new['prune_enable'] ) ? "checked=\"checked\"" : "";
$prune_no = ( !$new['prune_enable'] ) ? "checked=\"checked\"" : "";

// Advanced Meta Tags
$use_dynamic_description_on = ( $new['use_dynamic_description'] ) ? "checked=\"checked\"" : "";
$use_dynamic_description_off = ( !$new['use_dynamic_description'] ) ? "checked=\"checked\"" : "";
$use_dynamic_keywords_on = ( $new['use_dynamic_keywords'] ) ? "checked=\"checked\"" : "";
$use_dynamic_keywords_off = ( !$new['use_dynamic_keywords'] ) ? "checked=\"checked\"" : "";
$append_global_keywords_on = ( $new['append_global_keywords'] ) ? "checked=\"checked\"" : "";
$append_global_keywords_off = ( !$new['append_global_keywords'] ) ? "checked=\"checked\"" : "";
$append_keywords_first_on = ( $new['append_keywords_first'] ) ? "checked=\"checked\"" : "";
$append_keywords_first_off = ( !$new['append_keywords_first'] ) ? "checked=\"checked\"" : "";
// Advanced Meta Tags [END]

// Выбор логотипа
$dir = @opendir(BB_ROOT . $new['logo_image_path']);
$count = 0;
$logo = array();
while( $file = @readdir($dir) )
{
  if( !@is_dir(phpbb_realpath(BB_ROOT . $new['logo_image_path'] . '/' . $file)) )
  {
    if( preg_match('/(\.gif$|\.png$|\.jpg|\.jpeg)$/is', $file) )
    {
      $logo[$count] = $file;
      $count++;
    }
  }
}
@closedir($dir);
// Logo ListBox
$logo_list = "";
for( $i = 0; $i < count($logo); $i++ )
{
  if ($logo[$i] == $new['logo_image'])
    $logo_list .= '<option value="' . $logo[$i] . '" selected="selected">' . $logo[$i] . '</option>';
  else
    $logo_list .= '<option value="' . $logo[$i] . '">' . $logo[$i] . '</option>';
}

$logo_image = $new['logo_image'];
$logo_width = $new['logo_image_w'];
$logo_height = $new['logo_image_h'];

// invite_enabled
$invite_enabled_yes = ( $new['invite_enabled'] ) ? "checked=\"checked\"" : "";
$invite_enabled_no = ( !$new['invite_enabled'] ) ? "checked=\"checked\"" : "";
// invite_enabled [END]

// Administration
$gold_yes = ( $new['gold'] ) ? "checked=\"checked\"" : "";
$gold_no = ( !$new['gold'] ) ? "checked=\"checked\"" : "";
$torrent_style_yes = ( $new['torrent_style'] ) ? "checked=\"checked\"" : "";
$torrent_style_no = ( !$new['torrent_style'] ) ? "checked=\"checked\"" : "";
$new_user_reg_disabled_yes = ( $new['new_user_reg_disabled'] ) ? "checked=\"checked\"" : "";
$new_user_reg_disabled_no = ( !$new['new_user_reg_disabled'] ) ? "checked=\"checked\"" : "";
$unique_ip_yes = ( $new['unique_ip'] ) ? "checked=\"checked\"" : "";
$unique_ip_no = ( !$new['unique_ip'] ) ? "checked=\"checked\"" : "";
$emailer_disabled_yes = ( $new['emailer_disabled'] ) ? "checked=\"checked\"" : "";
$emailer_disabled_no = ( !$new['emailer_disabled'] ) ? "checked=\"checked\"" : "";
$topic_notify_enabled_yes = ( $new['topic_notify_enabled'] ) ? "checked=\"checked\"" : "";
$topic_notify_enabled_no = ( !$new['topic_notify_enabled'] ) ? "checked=\"checked\"" : "";
$pm_notify_enabled_yes = ( $new['pm_notify_enabled'] ) ? "checked=\"checked\"" : "";
$pm_notify_enabled_no = ( !$new['pm_notify_enabled'] ) ? "checked=\"checked\"" : "";
$groupcp_send_email_yes = ( $new['groupcp_send_email'] ) ? "checked=\"checked\"" : "";
$groupcp_send_email_no = ( !$new['groupcp_send_email'] ) ? "checked=\"checked\"" : "";
$email_change_disabled_yes = ( $new['email_change_disabled'] ) ? "checked=\"checked\"" : "";
$email_change_disabled_no = ( !$new['email_change_disabled'] ) ? "checked=\"checked\"" : "";
$show_latest_news_yes = ( $new['show_latest_news'] ) ? "checked=\"checked\"" : "";
$show_latest_news_no = ( !$new['show_latest_news'] ) ? "checked=\"checked\"" : "";
$show_quick_reply_yes = ( $new['show_quick_reply'] ) ? "checked=\"checked\"" : "";
$show_quick_reply_no = ( !$new['show_quick_reply'] ) ? "checked=\"checked\"" : "";
$show_rank_text_yes = ( $new['show_rank_text'] ) ? "checked=\"checked\"" : "";
$show_rank_text_no = ( !$new['show_rank_text'] ) ? "checked=\"checked\"" : "";
$show_rank_image_yes = ( $new['show_rank_image'] ) ? "checked=\"checked\"" : "";
$show_rank_image_no = ( !$new['show_rank_image'] ) ? "checked=\"checked\"" : "";
$show_poster_joined_yes = ( $new['show_poster_joined'] ) ? "checked=\"checked\"" : "";
$show_poster_joined_no = ( !$new['show_poster_joined'] ) ? "checked=\"checked\"" : "";
$show_poster_posts_yes = ( $new['show_poster_posts'] ) ? "checked=\"checked\"" : "";
$show_poster_posts_no = ( !$new['show_poster_posts'] ) ? "checked=\"checked\"" : "";
$show_poster_from_yes = ( $new['show_poster_from'] ) ? "checked=\"checked\"" : "";
$show_poster_from_no = ( !$new['show_poster_from'] ) ? "checked=\"checked\"" : "";
$show_poster_flag_yes = ( $new['show_poster_flag'] ) ? "checked=\"checked\"" : "";
$show_poster_flag_no = ( !$new['show_poster_flag'] ) ? "checked=\"checked\"" : "";
$show_bot_nick_yes = ( $new['show_bot_nick'] ) ? "checked=\"checked\"" : "";
$show_bot_nick_no = ( !$new['show_bot_nick'] ) ? "checked=\"checked\"" : "";
$text_buttons_yes = ( $new['text_buttons'] ) ? "checked=\"checked\"" : "";
$text_buttons_no = ( !$new['text_buttons'] ) ? "checked=\"checked\"" : "";
$parse_ed2k_links_yes = ( $new['parse_ed2k_links'] ) ? "checked=\"checked\"" : "";
$parse_ed2k_links_no = ( !$new['parse_ed2k_links'] ) ? "checked=\"checked\"" : "";
$topic_bookmark_enabled_yes = ( $new['topic_bookmark_enabled'] ) ? "checked=\"checked\"" : "";
$topic_bookmark_enabled_no = ( !$new['topic_bookmark_enabled'] ) ? "checked=\"checked\"" : "";
$show_virtual_keyboard_yes = ( $new['show_virtual_keyboard'] ) ? "checked=\"checked\"" : "";
$show_virtual_keyboard_no = ( !$new['show_virtual_keyboard'] ) ? "checked=\"checked\"" : "";
$magnet_links_enabled_yes = ( $new['magnet_links_enabled'] ) ? "checked=\"checked\"" : "";
$magnet_links_enabled_no = ( !$new['magnet_links_enabled'] ) ? "checked=\"checked\"" : "";
// Administration [END]

$smile_yes = ( $new['allow_smilies'] ) ? "checked=\"checked\"" : "";
$smile_no = ( !$new['allow_smilies'] ) ? "checked=\"checked\"" : "";

$sig_yes = ( $new['allow_sig'] ) ? "checked=\"checked\"" : "";
$sig_no = ( !$new['allow_sig'] ) ? "checked=\"checked\"" : "";

$namechange_yes = ( $new['allow_namechange'] ) ? "checked=\"checked\"" : "";
$namechange_no = ( !$new['allow_namechange'] ) ? "checked=\"checked\"" : "";

$avatars_local_yes = ( $new['allow_avatar_local'] ) ? "checked=\"checked\"" : "";
$avatars_local_no = ( !$new['allow_avatar_local'] ) ? "checked=\"checked\"" : "";
$avatars_remote_yes = ( $new['allow_avatar_remote'] ) ? "checked=\"checked\"" : "";
$avatars_remote_no = ( !$new['allow_avatar_remote'] ) ? "checked=\"checked\"" : "";
$avatars_upload_yes = ( $new['allow_avatar_upload'] ) ? "checked=\"checked\"" : "";
$avatars_upload_no = ( !$new['allow_avatar_upload'] ) ? "checked=\"checked\"" : "";

$avatar_by_default_yes = ( $new['avatar_by_default'] ) ? "checked=\"checked\"" : "";
$avatar_by_default_no = ( !$new['avatar_by_default'] ) ? "checked=\"checked\"" : "";

$smtp_yes = ( $new['smtp_delivery'] ) ? "checked=\"checked\"" : "";
$smtp_no = ( !$new['smtp_delivery'] ) ? "checked=\"checked\"" : "";

//
// Escape any quotes in the site description for proper display in the text
// box on the admin page
//
$template->assign_vars(array(
	"S_CONFIG_ACTION" => append_sid("admin_board.$phpEx"),

	"L_CONFIGURATION_TITLE" => $lang['General_Config'],
	"L_CONFIGURATION_EXPLAIN" => $lang['Config_explain'],
	"L_GENERAL_SETTINGS" => $lang['General_settings'],
	"L_SERVER_NAME" => $lang['Server_name'],
	"L_SERVER_NAME_EXPLAIN" => $lang['Server_name_explain'],
	"L_SERVER_PORT" => $lang['Server_port'],
	"L_SERVER_PORT_EXPLAIN" => $lang['Server_port_explain'],
	"L_SCRIPT_PATH" => $lang['Script_path'],
	"L_SCRIPT_PATH_EXPLAIN" => $lang['Script_path_explain'],
	"L_SITE_NAME" => $lang['Site_name'],
	"L_SITE_DESCRIPTION" => $lang['Site_desc'],

	// Advanced Meta Tags
	"l_use_dynamic_description" => $lang['DYNAMIC_DESCRIPTION'],
	"use_dynamic_description_on" => $use_dynamic_description_on,
	"use_dynamic_description_off" => $use_dynamic_description_off,
	
	"l_description_word_count"  => $lang['DESCRIPTION_WORD_COUNT'],
	"description_word_count"  => $new['description_word_count'],
	
	"l_global_keywords"         => $lang['GLOBAL_KEYWORDS'],
	"global_keywords"         => $new['global_keywords'],
	
	"l_use_dynamic_keywords"    => $lang['DYNAMIC_KEYWORDS'],
	"use_dynamic_keywords_on"    => $use_dynamic_keywords_on,
	"use_dynamic_keywords_off"    => $use_dynamic_keywords_off,
	
	"l_keyword_word_count"      => $lang['KEYWORD_WORD_COUNT'],
	"keyword_word_count"         => $new['keyword_word_count'],
	
	"l_append_global_keywords"  => $lang['APPEND_GLOBAL_KEYWORDS'],
	"append_global_keywords_on"    => $append_global_keywords_on,
	"append_global_keywords_off"    => $append_global_keywords_off,
	"l_append_global_keywords_explain"    => $lang['APPEND_GLOBAL_KEYWORDS_EXPLAIN'],
	
	"l_append_keywords_first"   => $lang['APPEND_KEYWORDS_FIRST'],
	"append_keywords_first_on"    => $append_keywords_first_on,
	"append_keywords_first_off"    => $append_keywords_first_off,
	"l_append_keywords_first_explain"    => $lang['APPEND_KEYWORDS_FIRST_EXPLAIN'],
	// Advanced Meta Tags [END]

	"L_DISABLE_BOARD" => $lang['Board_disable'],
	"L_DISABLE_BOARD_EXPLAIN" => $lang['Board_disable_explain'],
	"L_ACCT_ACTIVATION" => $lang['Acct_activation'],
	"L_NONE" => $lang['Acc_None'],
	"L_USER" => $lang['Acc_User'],
	"L_VISUAL_CONFIRM" => $lang['Visual_confirm'],
	"L_VISUAL_CONFIRM_EXPLAIN" => $lang['Visual_confirm_explain'],
	"L_ALLOW_AUTOLOGIN" => $lang['Allow_autologin'],
	"L_ALLOW_AUTOLOGIN_EXPLAIN" => $lang['Allow_autologin_explain'],
	"L_AUTOLOGIN_TIME" => $lang['Autologin_time'],
	"L_AUTOLOGIN_TIME_EXPLAIN" => $lang['Autologin_time_explain'],
	"L_COOKIE_SETTINGS" => $lang['Cookie_settings'],
	"L_COOKIE_SETTINGS_EXPLAIN" => $lang['Cookie_settings_explain'],
	"L_COOKIE_DOMAIN" => $lang['Cookie_domain'],
	"L_COOKIE_NAME" => $lang['Cookie_name'],
	"L_COOKIE_PATH" => $lang['Cookie_path'],
	"L_COOKIE_SECURE" => $lang['Cookie_secure'],
	"L_COOKIE_SECURE_EXPLAIN" => $lang['Cookie_secure_explain'],
	"L_SESSION_LENGTH" => $lang['Session_length'],
	"L_PRIVATE_MESSAGING" => $lang['Private_Messaging'],
	"L_INBOX_LIMIT" => $lang['Inbox_limits'],
	"L_SENTBOX_LIMIT" => $lang['Sentbox_limits'],
	"L_SAVEBOX_LIMIT" => $lang['Savebox_limits'],
	"L_DISABLE_PRIVATE_MESSAGING" => $lang['Disable_privmsg'],
	"L_ENABLED" => $lang['Enabled'],
	"L_DISABLED" => $lang['Disabled'],
	"L_ABILITIES_SETTINGS" => $lang['Abilities_settings'],
	"L_MAX_POLL_OPTIONS" => $lang['Max_poll_options'],
	"L_FLOOD_INTERVAL" => $lang['Flood_Interval'],
	"L_FLOOD_INTERVAL_EXPLAIN" => $lang['Flood_Interval_explain'],

	"L_JOIN_INTERVAL" => $lang['Join_Interval'],
	"L_JOIN_INTERVAL_EXPLAIN" => $lang['Join_Interval_explain'],

	'L_MAX_LOGIN_ATTEMPTS'			=> $lang['Max_login_attempts'],
	'L_MAX_LOGIN_ATTEMPTS_EXPLAIN'	=> $lang['Max_login_attempts_explain'],
	'L_LOGIN_RESET_TIME'			=> $lang['Login_reset_time'],
	'L_LOGIN_RESET_TIME_EXPLAIN'	=> $lang['Login_reset_time_explain'],
	'MAX_LOGIN_ATTEMPTS'			=> $new['max_login_attempts'],
	'LOGIN_RESET_TIME'				=> $new['login_reset_time'],

	"L_BOARD_EMAIL_FORM" => $lang['Board_email_form'],
	"L_BOARD_EMAIL_FORM_EXPLAIN" => $lang['Board_email_form_explain'],
	"L_POSTS_PER_PAGE" => $lang['Posts_per_page'],
	"L_HOT_THRESHOLD" => $lang['Hot_threshold'],
	"L_DEFAULT_STYLE" => $lang['Default_style'],
	"L_DEFAULT_LANGUAGE" => $lang['Default_language'],
	"L_DATE_FORMAT" => $lang['Date_format'],
	"L_SYSTEM_TIMEZONE" => $lang['System_timezone'],
	"L_ENABLE_GZIP" => $lang['Enable_gzip'],
	"L_ENABLE_PRUNE" => $lang['Enable_prune'],
	"L_ALLOW_BBCODE" => $lang['Allow_BBCode'],
	"L_ALLOW_SMILIES" => $lang['Allow_smilies'],
	"L_SMILIES_PATH" => $lang['Smilies_path'],
	"L_SMILIES_PATH_EXPLAIN" => $lang['Smilies_path_explain'],
	"L_ALLOW_SIG" => $lang['Allow_sig'],
	"L_MAX_SIG_LENGTH" => $lang['Max_sig_length'],
	"L_MAX_SIG_LENGTH_EXPLAIN" => $lang['Max_sig_length_explain'],
	"L_ALLOW_NAME_CHANGE" => $lang['Allow_name_change'],
	"L_AVATAR_SETTINGS" => $lang['Avatar_settings'],
	"L_ALLOW_LOCAL" => $lang['Allow_local'],
	"L_ALLOW_REMOTE" => $lang['Allow_remote'],
	"L_ALLOW_REMOTE_EXPLAIN" => $lang['Allow_remote_explain'],
	"L_ALLOW_UPLOAD" => $lang['Allow_upload'],
	"L_MAX_FILESIZE" => $lang['Max_filesize'],
	"L_MAX_FILESIZE_EXPLAIN" => $lang['Max_filesize_explain'],
	"L_MAX_AVATAR_SIZE" => $lang['Max_avatar_size'],
	"L_MAX_AVATAR_SIZE_EXPLAIN" => $lang['Max_avatar_size_explain'],
	"L_AVATAR_STORAGE_PATH" => $lang['Avatar_storage_path'],
	"L_AVATAR_STORAGE_PATH_EXPLAIN" => $lang['Avatar_storage_path_explain'],
	"L_AVATAR_GALLERY_PATH" => $lang['Avatar_gallery_path'],
	"L_AVATAR_GALLERY_PATH_EXPLAIN" => $lang['Avatar_gallery_path_explain'],
	"L_EMAIL_SETTINGS" => $lang['Email_settings'],
	"L_ADMIN_EMAIL" => $lang['Admin_email'],
	// Выбор логотипа
	"L_LOGO_SETTINGS" => $lang['Logo_settings'],
	"L_LOGO_PATH" => $lang['Logo_path'],
	"L_LOGO_PATH_EXPLAIN" => $lang['Logo_path_explain'],
	"L_LOGO" => $lang['Logo'],
	"L_LOGO_DIMENSIONS" => $lang['Logo_dimensions'],
	"L_LOGO_DIMENSIONS_EXPLAIN" => $lang['Logo_dimensions_explain'],
	// Выбор логотипа Конец
	"L_EMAIL_SIG" => $lang['Email_sig'],
	"L_EMAIL_SIG_EXPLAIN" => $lang['Email_sig_explain'],
	"L_USE_SMTP" => $lang['Use_SMTP'],
	"L_USE_SMTP_EXPLAIN" => $lang['Use_SMTP_explain'],
	"L_SMTP_SERVER" => $lang['SMTP_server'],
	"L_SMTP_USERNAME" => $lang['SMTP_username'],
	"L_SMTP_USERNAME_EXPLAIN" => $lang['SMTP_username_explain'],
	"L_SMTP_PASSWORD" => $lang['SMTP_password'],
	"L_SMTP_PASSWORD_EXPLAIN" => $lang['SMTP_password_explain'],

	"SERVER_NAME" => $bb_cfg['server_name'],
	"SCRIPT_PATH" => $bb_cfg['script_path'],
	"SERVER_PORT" => $bb_cfg['server_port'],
	"SITENAME" => htmlCHR($new['sitename']),
	"CONFIG_SITE_DESCRIPTION" => htmlCHR($new['site_desc']),
	"S_DISABLE_BOARD_YES" => $disable_board_yes,
	"S_DISABLE_BOARD_NO" => $disable_board_no,
	"ACTIVATION_NONE" => USER_ACTIVATION_NONE,
	"ACTIVATION_NONE_CHECKED" => $activation_none,
	"ACTIVATION_USER" => USER_ACTIVATION_SELF,
	"ACTIVATION_USER_CHECKED" => $activation_user,
	"ACTIVATION_ADMIN" => USER_ACTIVATION_ADMIN,
	"ACTIVATION_ADMIN_CHECKED" => $activation_admin,
	"CONFIRM_ENABLE" => $confirm_yes,
	"CONFIRM_DISABLE" => $confirm_no,
	'ALLOW_AUTOLOGIN_YES' => $allow_autologin_yes,
	'ALLOW_AUTOLOGIN_NO' => $allow_autologin_no,
	'AUTOLOGIN_TIME' => (int) $new['max_autologin_time'],
	"BOARD_EMAIL_FORM_ENABLE" => $board_email_form_yes,
	"BOARD_EMAIL_FORM_DISABLE" => $board_email_form_no,
	"MAX_POLL_OPTIONS" => $new['max_poll_options'],
	"FLOOD_INTERVAL" => $new['flood_interval'],
	"JOIN_INTERVAL" => $new['join_interval'],
	"TOPICS_PER_PAGE" => $new['topics_per_page'],
	"POSTS_PER_PAGE" => $new['posts_per_page'],
	"HOT_TOPIC" => $new['hot_threshold'],
	"STYLE_SELECT" => $bb_cfg['tpl_name'],
	"LANG_SELECT" => $lang_select,
	"L_DATE_FORMAT_EXPLAIN" => $lang['Date_format_explain'],
	"DEFAULT_DATEFORMAT" => $new['default_dateformat'],
	"TIMEZONE_SELECT" => $timezone_select,
	// Выбор логотипа
	"LOGO_PATH" => $new['logo_image_path'],
	"LOGO_IMAGE_DIR" => BB_ROOT . $new['logo_image_path'],
	"LOGO_LIST" => $logo_list,
	"LOGO_IMAGE" => ($logo_image) ? BB_ROOT . $board_config['logo_image_path'] .'/' . $logo_image : '',
	"LOGO_WIDTH" => $logo_width,
	"LOGO_HEIGHT" => $logo_height,
	// Выбор логотипа Конец
	"S_PRIVMSG_ENABLED" => $privmsg_on,
	"S_PRIVMSG_DISABLED" => $privmsg_off,
	"INBOX_LIMIT" => $new['max_inbox_privmsgs'],
	"SENTBOX_LIMIT" => $new['max_sentbox_privmsgs'],
	"SAVEBOX_LIMIT" => $new['max_savebox_privmsgs'],
	"COOKIE_DOMAIN" => $bb_cfg['cookie_domain'],
    "EMAIL_CHARSET" => $bb_cfg['email_default_charset'],
    "SYSTEM_CHARSET" => $bb_cfg['system_charset'],
    "DB_CHARSET" => $dbcharset,
	"COOKIE_NAME" => $bb_cfg['cookie_prefix'],
	"COOKIE_PATH" => $bb_cfg['cookie_path'],
	"SESSION_LENGTH" => "$bb_cfg[user_session_duration]<br />$bb_cfg[admin_session_duration]",
	"S_COOKIE_SECURE_ENABLED" => $cookie_secure_yes,
	"S_COOKIE_SECURE_DISABLED" => $cookie_secure_no,
	"GZIP" => $bb_cfg['gzip_compress'],
	"PRUNE_YES" => $prune_yes,
	"PRUNE_NO" => $prune_no,
	// invite_enabled
	"INVITE_ENABLED_YES" => $invite_enabled_yes,
	"INVITE_ENABLED_NO" => $invite_enabled_no,
	// invite_enabled [END]
	// Administration
	"GOLD_YES" => $gold_yes,
	"GOLD_NO" => $gold_no,
	"TORRENT_STYLE_YES" => $torrent_style_yes,
	"TORRENT_STYLE_NO" => $torrent_style_no,
	"NEW_USER_REG_DISABLED_YES" => $new_user_reg_disabled_yes,
	"NEW_USER_REG_DISABLED_NO" => $new_user_reg_disabled_no,
	"UNIQUE_IP_YES" => $unique_ip_yes,
	"UNIQUE_IP_NO" => $unique_ip_no,
	"EMAILER_DISABLED_YES" => $emailer_disabled_yes,
	"EMAILER_DISABLED_NO" => $emailer_disabled_no,
	"TOPIC_NOTIFY_ENABLED_YES" => $topic_notify_enabled_yes,
	"TOPIC_NOTIFY_ENABLED_NO" => $topic_notify_enabled_no,
	"PM_NOTIFY_ENABLED_YES" => $pm_notify_enabled_yes,
	"PM_NOTIFY_ENABLED_NO" => $pm_notify_enabled_no,
	"GROUPCP_SEND_EMAIL_YES" => $groupcp_send_email_yes,
	"GROUPCP_SEND_EMAIL_NO" => $groupcp_send_email_no,
	"EMAIL_CHANGE_DISABLED_YES" => $email_change_disabled_yes,
	"EMAIL_CHANGE_DISABLED_NO" => $email_change_disabled_no,
	"SHOW_LATEST_NEWS_YES" => $show_latest_news_yes,
	"SHOW_LATEST_NEWS_NO" => $show_latest_news_no,
	"SHOW_QUICK_REPLY_YES" => $show_quick_reply_yes,
	"SHOW_QUICK_REPLY_NO" => $show_quick_reply_no,
	"SHOW_RANK_TEXT_YES" => $show_rank_text_yes,
	"SHOW_RANK_TEXT_NO" => $show_rank_text_no,
	"SHOW_RANK_IMAGE_YES" => $show_rank_image_yes,
	"SHOW_RANK_IMAGE_NO" => $show_rank_image_no,
	"SHOW_POSTER_JOINED_YES" => $show_poster_joined_yes,
	"SHOW_POSTER_JOINED_NO" => $show_poster_joined_no,
	"SHOW_POSTER_POSTS_YES" => $show_poster_posts_yes,
	"SHOW_POSTER_POSTS_NO" => $show_poster_posts_no,
	"SHOW_POSTER_FROM_YES" => $show_poster_from_yes,
	"SHOW_POSTER_FROM_NO" => $show_poster_from_no,
	"SHOW_POSTER_FLAG_YES" => $show_poster_flag_yes,
	"SHOW_POSTER_FLAG_NO" => $show_poster_flag_no,
	"SHOW_BOT_NICK_YES" => $show_bot_nick_yes,
	"SHOW_BOT_NICK_NO" => $show_bot_nick_no,
	"TEXT_BUTTONS_YES" => $text_buttons_yes,
	"TEXT_BUTTONS_NO" => $text_buttons_no,
	"PARSE_ED2K_LINKS_YES" => $parse_ed2k_links_yes,
	"PARSE_ED2K_LINKS_NO" => $parse_ed2k_links_no,
	"TOPIC_BOOKMARK_ENABLED_YES" => $topic_bookmark_enabled_yes,
	"TOPIC_BOOKMARK_ENABLED_NO" => $topic_bookmark_enabled_no,
	"SHOW_VIRTUAL_KEYBOARD_YES" => $show_virtual_keyboard_yes,
	"SHOW_VIRTUAL_KEYBOARD_NO" => $show_virtual_keyboard_no,
	"MAGNET_LINKS_ENABLED_YES" => $magnet_links_enabled_yes,
	"MAGNET_LINKS_ENABLED_NO" => $magnet_links_enabled_no,
	// Administration [END]
	"BBCODE_YES" => $bbcode_yes,
	"BBCODE_NO" => $bbcode_no,
	"SMILE_YES" => $smile_yes,
	"SMILE_NO" => $smile_no,
	"SIG_YES" => $sig_yes,
	"SIG_NO" => $sig_no,
	"SIG_SIZE" => $new['max_sig_chars'],
	"NAMECHANGE_YES" => $namechange_yes,
	"NAMECHANGE_NO" => $namechange_no,
	"AVATARS_LOCAL_YES" => $avatars_local_yes,
	"AVATARS_LOCAL_NO" => $avatars_local_no,
	"AVATARS_REMOTE_YES" => $avatars_remote_yes,
	"AVATARS_REMOTE_NO" => $avatars_remote_no,
	"AVATARS_UPLOAD_YES" => $avatars_upload_yes,
	"AVATARS_UPLOAD_NO" => $avatars_upload_no,
    "AVATAR_BY_DEFAULT_YES" => $avatar_by_default_yes,
    "AVATAR_BY_DEFAULT_NO" => $avatar_by_default_no,
	"AVATAR_FILESIZE" => $new['avatar_filesize'],
	"AVATAR_MAX_HEIGHT" => $new['avatar_max_height'],
	"AVATAR_MAX_WIDTH" => $new['avatar_max_width'],
	"AVATAR_PATH" => $new['avatar_path'],
	"AVATAR_GALLERY_PATH" => $new['avatar_gallery_path'],
    "AVATAR_DEFAULT_PATH" => $new['avatar_by_default_path'],
	"SMILIES_PATH" => $new['smilies_path'],
	"INBOX_PRIVMSGS" => $new['max_inbox_privmsgs'],
	"SENTBOX_PRIVMSGS" => $new['max_sentbox_privmsgs'],
	"SAVEBOX_PRIVMSGS" => $new['max_savebox_privmsgs'],
	"EMAIL_FROM" => $new['board_email'],
	"EMAIL_SIG" => $new['board_email_sig'],
	"SMTP_YES" => $smtp_yes,
	"SMTP_NO" => $smtp_no,
	"SMTP_HOST" => $new['smtp_host'],
	"SMTP_USERNAME" => $new['smtp_username'],
	"SMTP_PASSWORD" => $new['smtp_password'],
));

print_page('admin_board.tpl', 'admin');
