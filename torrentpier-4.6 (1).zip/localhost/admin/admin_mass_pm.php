<?php
// ACP Header - START
if (!empty($setmodules))
{
	$module['General']['MASS_PM'] = basename(__FILE__);
	return;
}
require('./pagestart.php');
require(INC_DIR .'functions_selects.'. PHP_EXT);
require(INC_DIR .'functions_post.'. PHP_EXT);
require(LANG_DIR .'lang_admin_bt.'. PHP_EXT);
//
// Pull all config data
//
	$sql = "SELECT COUNT(*) FROM ".USERS_TABLE;

	if(!$result = $db->sql_query($sql))
	{
		message_die(CRITICAL_ERROR, "Couldn't obtain count user", "", __LINE__, __FILE__, $sql);
	}

	$count_users = mysql_result($result, 0, 0);

	$submit = isset($_POST['submit']);

if ($submit)
{
	$mass_pm = $_POST['mass_pm'];
	if ($mass_pm == "") {message_die(GENERAL_ERROR, "No text of private messages.", "", __LINE__, __FILE__, "");}

	$subj_pm = $_POST['subj_pm'];
	if ($subj_pm == "") {message_die(GENERAL_ERROR, "No text of the topic a private message.", "", __LINE__, __FILE__, "");}

	$id_user = $_POST['id_user'];

	if ($id_user == "1"){
		$id = $userdata['user_id'];		
	}else{
		$username = $_POST['username'];
		if ($username == "") {message_die(GENERAL_ERROR, "No user name.", "", __LINE__, __FILE__, "");}

		$sql = "SELECT u.user_id  FROM " . USERS_TABLE . " u	WHERE `username`='" . $username."'";

		if(!$result = $db->sql_query($sql))
		{
			message_die(GENERAL_ERROR, "Couldn't obtain regd user information.", "", __LINE__, __FILE__, $sql);
		}

		$id_res = $db->sql_fetchrowset($result);
		if (!isset($id_res[0]['user_id'])) message_die(GENERAL_ERROR, "Couldn't obtain regd user information.", "", __LINE__, __FILE__, $username);
		$id = $id_res[0]['user_id'];
	}

	$group_id = intval($_POST['group']);

	if ( $group_id != -1 ){
		$sql = "SELECT u.user_id, u.username FROM " . USERS_TABLE . " u, " . USER_GROUP_TABLE . " ug WHERE ug.group_id = $group_id AND ug.user_pending <> 1 AND u.user_id = ug.user_id";
	}else{
		$sql =  "SELECT u.user_id, u.username FROM " . USERS_TABLE . " u	WHERE u.user_id > 0	AND u.user_id <> " . ANONYMOUS;
	}


	if(!$result = $db->sql_query($sql))
	{
		message_die(GENERAL_ERROR, "Couldn't obtain regd user information.", "", __LINE__, __FILE__, $sql);
	}

	$users = $db->sql_fetchrowset($result);

	$reg_userid_ary = array();

	$msg_error = "OK";
	
	$cur_time=time();

	$enc_ip=encode_ip($_SERVER['REMOTE_ADDR']);

	if( count($users) )
		{
			$registered_users = 0;

			for($i=0, $cnt=count($users); $i < $cnt; $i++)
			{
				$cur_user = $users[$i]['user_id'];

				if($msg_error!=="OK") break;

 				$sql = "INSERT INTO ". PRIVMSGS_TABLE. "(privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip) VALUES(" . PRIVMSGS_NEW_MAIL . ",'" . $subj_pm . "'," . $id ."," . $cur_user. "," . $cur_time . ",'" . $enc_ip . "')";
				if(!$result = $db->sql_query($sql))
				{
					message_die(GENERAL_ERROR, "Couldn't send message", "", __LINE__, __FILE__, $sql);
				}
				$id_mess=mysql_insert_id();

 				$sql = "INSERT INTO ". PRIVMSGS_TEXT_TABLE ." VALUES(" . $id_mess . ", '', '" .$mass_pm. "')";
				if(!$result = $db->sql_query($sql))
				{
					message_die(GENERAL_ERROR, "Couldn't send text by message", "", __LINE__, __FILE__, $sql);
				}

				$sql = "SELECT u.user_new_privmsg FROM " . USERS_TABLE . " u	WHERE user_id=".$cur_user;
				if(!$result = $db->sql_query($sql))
				{
					message_die(GENERAL_ERROR, "Couldn't UPDATE popup", "", __LINE__, __FILE__, $sql);
				}

				$priv_msg = $db->sql_fetchrowset($result);
	

				$sql = "UPDATE " . USERS_TABLE . " SET user_new_privmsg=".($priv_msg[0]['user_new_privmsg'] + 1).", user_last_privmsg=" . $cur_time . ", user_newest_pm_id=". $id_mess ." WHERE user_id=" . $cur_user;
				if(!$result = $db->sql_query($sql))
				{
					message_die(GENERAL_ERROR, "Couldn't UPDATE popup", "", __LINE__, __FILE__, $sql);
				}

			}

			$message = $lang['MASS_PM_SENDED'] .'<br /><font color="#00CC00"><b>' . $lang['MASS_PM_SENDED'] . '</b></font><br />';
			$message .= sprintf($lang['MASS_PM_RETURN_SEND'], '<a href="'. append_sid("admin_mass_pm.$phpEx") .'">', '</a>') .'<br /><br />';
			$message .= sprintf($lang['Click_return_admin_index'], '<a href="'. append_sid("index.$phpEx?pane=right") .'">', '</a>');

			message_die(GENERAL_MESSAGE, $message);

	}
}

	$sql = "SELECT group_id, group_name
		FROM ".GROUPS_TABLE . "
		WHERE group_single_user <> 1";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not obtain list of groups', '', __LINE__, __FILE__, $sql);
	}

	$select_list = '<select name = "group"><option value = "-1">' . $lang['All_users'] . '</option>';
	if ( $row = $db->sql_fetchrow($result) )
	{
		do
		{
			$select_list .= '<option value = "' . $row['group_id'] . '">' . $row['group_name'] . '</option>';
		}
		while ( $row = $db->sql_fetchrow($result) );
	}
	$select_list .= '</select>';

	$template->assign_vars(array(
		'COUNT_USERS'           =>  $count_users,
		'S_GROUP_SELECT' => $select_list,
		'L_RECIPIENTS' => $lang['Recipients'],
		'L_MASS_PM' => $lang['MASS_PM'],
		'L_MASS_PM_DESCRIPTION' => $lang['MASS_PM_DESCRIPTION'],
		'L_MASS_PM_SUBJ' => $lang['MASS_PM_SUBJ'],
		'L_MASS_PM_TEXT' => $lang['MASS_PM_TEXT'],
		'L_MASS_PM_USERS' => $lang['MASS_PM_USERS'],
		'L_MASS_PM_TEXTII' => $lang['MASS_PM_TEXTII'],
		'L_MASS_PM_MESS' => $lang['MASS_PM_MESS'],
		'L_MASS_PM_SELF' => $lang['MASS_PM_SELF'],
		'L_MASS_PM_FROM_USER' => $lang['MASS_PM_FROM_USER'],
		'L_MASS_PM_USERNAME' => $lang['MASS_PM_USERNAME'],
	));

	print_page('admin_mass_pm.tpl', 'admin');