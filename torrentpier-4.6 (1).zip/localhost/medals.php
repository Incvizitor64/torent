<?php


define('IN_PHPBB', true);
define('BB_ROOT', './');
include(BB_ROOT .'common.php');

//
// Start session management
//
$user->session_start();

$user_id = $userdata['user_id'];
//
// End session management
//

//
// Obtain initial var settings
//
if ( isset($_GET[POST_MEDAL_URL]) || isset($_POST[POST_MEDAL_URL]) )
{
	$medal_id = ( isset($_POST[POST_MEDAL_URL]) ) ? intval($_POST[POST_MEDAL_URL]) : intval($_GET[POST_MEDAL_URL]);
}
else
{
	$medal_id = '';
}

if ( isset($_POST['mode']) || isset($_GET['mode']) )
{
	$mode = ( isset($_POST['mode']) ) ? $_POST['mode'] : $_GET['mode'];
	$mode = htmlspecialchars($mode);
}
else
{
	$mode = '';
}

//
// Category
//
$sql = "SELECT cat_id, cat_title, cat_order
		FROM " . BB_MEDAL_CAT . "
		ORDER BY cat_order";
if( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not query medal categories list', '', __LINE__, __FILE__, $sql);
}

$category_rows = array();
while ($row = $db->sql_fetchrow($result) )
{
	$category_rows[] = $row;
}
$db->sql_freeresult($result);

if( ( $total_categories = count($category_rows) ) )
{
	$sql = "SELECT * FROM " . BB_MEDAL . "
			ORDER BY medal_name";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not obtain medal information', '', __LINE__, __FILE__, $sql);
	}

	$medal_data = array();
	while ($row = $db->sql_fetchrow($result) )
	{
		$medal_data[] = $row;
	}
	$db->sql_freeresult($result);

	if ( !($total_medals = count($medal_data)) )
	{
		message_die(GENERAL_MESSAGE, $lang['No_medal']);
	}

	// Obtain list of moderators of each medal
	$sql = "SELECT u.user_id, u.username, u.user_rank, mm.medal_id
			FROM " . USERS_TABLE . " u, " . BB_MEDAL_MOD . " mm
			WHERE u.user_id = mm.user_id
			GROUP BY u.user_id, u.username, mm.medal_id
			ORDER BY mm.medal_id, u.user_id";

	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not query medal moderator information', '', __LINE__, __FILE__, $sql);
	}

	$medal_moderators = array();
	while( $row = $db->sql_fetchrow($result) )
	{
		$medal_moderators[$row['medal_id']][] = profile_url($row);
	}
	$db->sql_freeresult($result);

	// Obtain list of users of each medal
	$sql = "SELECT u.user_id, u.username, u.user_rank, mu.medal_id
			FROM " . USERS_TABLE . " u, " . BB_MEDAL_USER . " mu
			WHERE u.user_id = mu.user_id
			GROUP BY u.user_id, u.username, mu.medal_id
			ORDER BY u.user_id";

	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not query medal userlist information', '', __LINE__, __FILE__, $sql);
	}

	$medal_users = array();
	while( $row = $db->sql_fetchrow($result) )
	{
		$medal_users[$row['medal_id']][] = profile_url($row);
	}
	$db->sql_freeresult($result);

	//
	// Start output of page
	//
	$page_title = $lang['Medal_Information'];

	$template->assign_vars(array(
		'L_USERS_LIST' => $lang['Medal_userlist'],
		'L_MEDAL_INFORMATION' => $lang['Medal_Information'],
		'L_MEDAL_NAME' => $lang['Medal_name'],
		'L_MEDAL_DESCRIPTION' => $lang['Medal_description'],
		'L_MEDAL_MODERATOR' => $lang['Medal_moderator'],
		'L_MEDAL_IMAGE' => $lang['Medal_image'],
		'L_LINK_TO_CP' => $lang['Link_to_cp']
		)
	);

	//
	// Okay, let's build the index
	//
	for($i = 0; $i < $total_categories; $i++)
	{
		$cat_id = $category_rows[$i]['cat_id'];

		//
		// Should we display this category/medal set?
		//
		$display_medal = FALSE;
		for($k = 0; $k < $total_medals; $k++)
		{
			if ( $medal_data[$k]['cat_id'] == $cat_id )
			{
				$display_medal = TRUE;
			}
		}

		if ( $display_medal )
		{
			$template->assign_block_vars('catrow', array(
				'CAT_ID' => $cat_id,
				'CAT_DESC' => $category_rows[$i]['cat_title'])
			);

			for($j = 0; $j < $total_medals; $j++)
			{
				if ( $medal_data[$j]['cat_id'] == $cat_id )
				{
					$medal_id = $medal_data[$j]['medal_id'];

					if ( count(@$medal_moderators[$medal_id]) > 0 )
					{
						$moderator_list = implode(', ', $medal_moderators[$medal_id]);
					}
					else
					{
						$moderator_list = $lang['No_medal_mod'];
					}
					if ( count(@$medal_users[$medal_id]) > 0 )
					{
						$user_list = implode(', ', $medal_users[$medal_id]);
					}
					else
					{
						$user_list = $lang['No_medal_members'];
					}
					$template->assign_block_vars('catrow.medals', array(
						'MEDAL_ID' => $medal_data[$j]['medal_name'],
						'MEDAL_NAME' => $medal_data[$j]['medal_name'],
						'MEDAL_DESCRIPTION'  => $medal_data[$j]['medal_description'],
						'MEDAL_IMAGE' => ($medal_data[$j]['medal_image'] == '') ? '' : '<img src="'. $medal_data[$j]['medal_image'] . '" border="0" alt="' . $medal_data[$j]['medal_name'] . '" title="' . $medal_data[$j]['medal_name'] . '" align="center">',
						'MEDAL_MOD' => $moderator_list,
						'USERS_LIST' => $user_list,
						'U_MEDAL_CP' => 'medalcp.php?'. POST_MEDAL_URL .'='.$medal_data[$j]['medal_id'].'&amp;sid='.$userdata['session_id'],
					));

					$is_moderator = check_medal_mod($medal_id);

					if ( $is_moderator || $userdata['user_level'] == ADMIN )
					{
						$template->assign_block_vars('catrow.medals.switch_mod_option', array());
					}
				}
			}
		}
	} // for ... categories

}// if ... total_categories
else
{
	message_die(GENERAL_MESSAGE, $lang['No_medal']);
}

print_page('medals_body.tpl');
