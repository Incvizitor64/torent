<?php 

/*
	This file is part of TorrentPier

	TorrentPier is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	TorrentPier is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	A copy of the GPL 2.0 should have been included with the program.
	If not, see http://www.gnu.org/licenses/

	Official SVN repository and contact information can be found at
	http://code.google.com/p/torrentpier/
 */

define('IN_PHPBB', true);
define('BB_SCRIPT', 'gallery');
define('BB_ROOT', './');
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require(BB_ROOT ."common.$phpEx");

if (!$bb_cfg['gallery_enabled'])
{
	message_die(GENERAL_MESSAGE, $lang['Gallery_disabled']);
}

// Start session management
$user->session_start(array('req_login' => true));

require(LANG_DIR ."lang_gallery.$phpEx");

$go = isset($_GET['go']) ? $_GET['go'] : '';
$userid = false;
if (IS_AM && isset($_GET['u']))
{
	$userid = (int) $_GET['u'];
}
$showthumb = isset($_GET['showthumb']) ? $_GET['showthumb'] : false;
$viewmode = (isset($_GET['mode']) && $_GET['mode'] = 'view') ? true : false;
$start = abs(intval(request_var('start', 0)));
$max_size = $bb_cfg['pic_max_size'];
$dir = $bb_cfg['pic_dir'];
$url = make_url('/');

$msg = '';
$links_all = $thumbs_all = array();

// DON'T CHANGE THIS FILE TYPEs
$allowed_ext = array('jpeg', 'jpg',	'png', 'gif');

function create_thumb ($dir, $name, $att)
{
	$infile = $dir . $name . $att;
	if ($att == ".jpg" || $att == ".jpeg")
		$im = @imagecreatefromjpeg($infile);
	elseif ($att == ".png")
		$im = @imagecreatefrompng($infile);
	elseif ($att == ".gif")
		$im = @imagecreatefromgif($infile);
	if (!isset($im) || !$im) return false;

	$oh = imagesy($im);
	$ow = imagesx($im);
	$r = $oh/$ow;
	if ($ow > $oh)
	{
		$neww = 200;
		$newh = $neww*$r;
	}
	else
	{
		$newh = 200;
		$neww = $newh/$r;
	}
	$outfile = $dir ."thumb_". $name . $att;
	$im1 = imagecreatetruecolor($neww,$newh);
	imagecopyresampled($im1, $im, 0, 0, 0, 0, $neww, $newh, imagesx($im), imagesy($im));
	imagejpeg($im1, $outfile, 75);
	imagedestroy($im);
	imagedestroy($im1);
	return true;
}

function display_thumb ($dir, $name, $att, $thumb)
{
	global $url, $lang, $db, $userdata;
	if ($thumb)
	{
		$infile = $dir . 'thumb_' . $name . $att;
		if ($att == ".jpg" || $att == ".jpeg")
			$im = @imagecreatefromjpeg($infile);
		elseif ($att == ".png")
			$im = @imagecreatefrompng($infile);
		elseif ($att == ".gif")
			$im = @imagecreatefromgif($infile);
		if ($im) return $im;
		else
		{
			$thumb = false;
			$im = display_thumb($dir, $name, $att, $thumb);
			return $im;
		}
	}
	else
	{
		$infile = $dir . $name . $att;
		$fullname = $name . $att;

		if (!file_exists($infile))
		{
			$row = $db->fetch_row("SELECT image_id
					FROM " . GALLERY_TABLE . "
					WHERE image_id = '$fullname'");
			if (isset($row['image_id']))
			{
				if ($row['image_id'] == $fullname)
				{
					$sql = "DELETE FROM " . GALLERY_TABLE . "
							WHERE image_id = '$fullname'";
					if ( !($result = $db->sql_query($sql)) )
					{
						message_die(GENERAL_ERROR, 'Could not update gallery table', '', __LINE__, __FILE__, $sql);
					}
				}
			}
			return false;
		}

		if ($att == ".jpg" || $att == ".jpeg")
			$im = @imagecreatefromjpeg($infile);
		elseif ($att == ".png")
			$im = @imagecreatefrompng($infile);
		elseif ($att == ".gif")
			$im = @imagecreatefromgif($infile);
		if (!isset($im) || !$im) return false;

		$oh = imagesy($im);
		$ow = imagesx($im);
		$r = $oh/$ow;
		if ($ow > $oh)
		{
			$neww = 200;
			$newh = $neww*$r;
		}
		else
		{
			$newh = 200;
			$neww = $newh/$r;
		}
		$outfile = $dir ."thumb_". $name . $att;
		$im1 = imagecreatetruecolor($neww,$newh);
		imagecopyresampled($im1, $im, 0, 0, 0, 0, $neww, $newh, imagesx($im), imagesy($im));
		imagedestroy($im);
		return $im1;
	}
}

function paste_links($links, $thumbs = '')
{
	global $links_all, $thumbs_all, $lang;

	if (is_array($links))
	{
		$link = implode(' ', $links);
		$img  = '[img]'. implode('[/img] [img]', $links) .'[/img]';
		
		if ($thumbs)
		{
			$thumb = '';
			for ($i = 0; $i < count($links); $i++)
			{
				$thumb .= '[url='.$links[$i].'][img]'. $thumbs[$i] .'[/img][/url]';
			}
		}
	}
	else
	{
		$link = trim($links);
		$img  = '[img]'. $links .'[/img]';

		$thumb = '[url='.$link.'][img]'. $thumbs .'[/img][/url]';
	}
	$spoiler = '[spoiler="'. $lang['gallery_screenshots'] .'"]' . $img . '[/spoiler]';
	
	$text  = (!is_array($links)) ? '<br /><a href='. $link .' target=_blank>'. $link .'</a><br>' : '';
	$text .= (!is_array($links)) ? '<br /><img src='. $link .' alt="'. $lang['gallery_your_image'] .'">' : '';
	$text .= '<br /><h4 align="left"><b>'. $lang['gallery_link_url'] .':</b></h4><input type="text" readonly="" value="'. $link .'" size="140" onclick="f2(this);">';
	$text .= '<br /><h4 align="left"><b>'. $lang['gallery_tag_screen'] .':</b></h4><input type="text" readonly="" value="'.$img.'" size="140" onclick="f2(this);">';
	if ($thumbs)
	{
		$text .='<br /><h4 align="left"><b>'. $lang['gallery_tag_screen_thumb'] .':</b></h4><input type="text" readonly="" value="'. $thumb .'" size="140" onclick="f2(this);">';
	}
	$text .= (!is_array($links)) ? '<br /><h4 align="left"><b>'. $lang['gallery_tag_poster_right'] .':</b></h4><input type="text" readonly="" value="[img=right]'. $link .'[/img]" size="140" onclick="f2(this);">' : '';
	$text .= '<br /><h4 align="left"><b>'. $lang['gallery_tag_spoiler'] .':</b></h4><input type="text" readonly="" value=\''. $spoiler .'\' size="140" onclick="f2(this);">';

	$links_all[] = $links;
	$thumbs ? ($thumbs_all[] = $thumbs) : null;
	
	return $text;
}

function upload_file ($files_ary, $idx)
{
	global $max_size, $allowed_ext, $create_thumb, $dir, $url, $lang, $db, $userdata;

	if (empty($files_ary))
		message_die(GENERAL_ERROR, "<hr><span style='color:red'><h2>". $lang['gallery_file_not_uploaded'] ."</h2></span><hr><br><center><a href='gallery.php'>". $lang['gallery_back'] ."</a></center><br><hr>");
	if ($files_ary['size'][$idx] > $max_size)
		message_die(GENERAL_ERROR, "<hr><span style='color:red'><h2>". $lang['gallery_image_overload'] ."</h2></span><hr><br><center><a href='gallery.php'>". $lang['gallery_back'] ."</a></center><br><hr>");

	$name = strtolower($files_ary['name'][$idx]);
	$ext  = substr(strrchr($name, '.'), 1);

	$allow = in_array($ext, $allowed_ext);
	$att   = '.'. $ext;

	$thumb = false;

	if ($allow)
	{
		$name = md5_file($files_ary['tmp_name'][$idx]);

		if (file_exists($dir . $name . $att))
		{
			if ($create_thumb && !file_exists($dir .'thumb_'. $name . $att))
			{
				$rusult_thumb = create_thumb($dir, $name, $att);
				if ($rusult_thumb)
				{
					$thumb = $url . $dir ."thumb_". $name . $att;
					// fly_indiz [START]
					$fullname = $name . $att;
					$sql = "UPDATE " . GALLERY_TABLE . "
							SET    image_thumb = " . (int) $create_thumb . "
							WHERE  image_id    = '$fullname'";
					if ( !($result = $db->sql_query($sql)) )
					{
						message_die(GENERAL_ERROR, 'Could not update gallery table', '', __LINE__, __FILE__, $sql);
					}
					// fly_indiz [END]
				}
			}
			$msg = '<hr>'. $lang['gallery_file_exist'] . paste_links($url . $dir . $name . $att, $thumb) .'</a>';
		}
		else
		{
			if (copy($files_ary['tmp_name'][$idx], $dir.$name.$att))
			{
				// fly_indiz [START]
				$fullname = $name . $att;
				$sql = "INSERT INTO " . GALLERY_TABLE . " (image_id, image_thumb, user_id)
						VALUES ('$fullname', " . (int) $create_thumb . ", " . $userdata['user_id'] . ")";
				if ( !($result = $db->sql_query($sql)) )
				{
					message_die(GENERAL_ERROR, 'Could not update gallery table', '', __LINE__, __FILE__, $sql);
				}
				// fly_indiz [END]
				if ($create_thumb)
				{
					$result_thumb = create_thumb($dir, $name, $att);
					if ($result_thumb) $thumb = $url . $dir ."thumb_". $name . $att;
				}
				$msg = '<hr>'. $lang['gallery_upload_successful'] . paste_links($url . $dir . $name . $att, $thumb) .'</a>';
			}
			else $msg = "<hr><span style='color:red'>". $lang['gallery_upload_failed'] ."</span>";
		}
		if (IS_ADMIN)
		{
			$msg .= "<br><br>";
			$msg .= "<span style='color:red'><b>". $lang['gallery_del_link'] .": &nbsp; &nbsp;</b></span>";
			$msg .= "<a href=\"gallery.php?go=delete&fn=".$name.$att."\">".$url."gallery.php?go=delete&fn=".$name.$att."</a>";
		}
	}
	else $msg = "<hr><span style='color:red'>". $lang['gallery_invalid_type'] ."</span>";

	return $msg;
}

if ($go == 'upload')
{
	@ini_set("memory_limit", "512M");

	$create_thumb = (isset($_POST['create_thumb'])) ? true : false;

	for ($i = 0; $i < count($_FILES['imgfile']['name']); $i++)
	{
		$msg .= upload_file ($_FILES['imgfile'], $i);
	}

	if (count($_FILES['imgfile']['name']) > 1)
	{
		$msg .= '<hr />'. paste_links ($links_all, $thumbs_all);
	}
}

if ($go == 'delete' && IS_ADMIN && !empty($_GET['fn']))
{
	global $lang;
	
	$fn = clean_filename($_GET['fn']);

	$pic  = $dir . $fn;
	$prev = $dir ."thumb_". $fn;
	if (!is_file($pic)) message_die(GENERAL_ERROR, $lang['gallery_file_not_exist']);

	if (unlink($pic))
	{
		@unlink($prev);
		// fly_indiz [START]
		$row = $db->fetch_row("SELECT image_id
				FROM " . GALLERY_TABLE . "
				WHERE image_id = '$fn'");
		if (isset($row['image_id']))
		{
			if ($row['image_id'] == $fn)
			{
				$sql = "DELETE FROM " . GALLERY_TABLE . "
						WHERE image_id = '$fn'";
				if ( !($result = $db->sql_query($sql)) )
				{
					message_die(GENERAL_ERROR, 'Could not update gallery table', '', __LINE__, __FILE__, $sql);
				}
			}
		}
		// fly_indiz [END]
		message_die(GENERAL_MESSAGE, "<center><span style='color:red'><h2>". $lang['gallery_file_delete'] ."</h2></span><br><a href='gallery.php'>". $lang['gallery_back'] ."</a></center>");
	}
	else message_die(GENERAL_ERROR, "<center><span style='color:red'><h2>". $lang['gallery_failure'] ."</h2></span><br><a href='gallery.php'>". $lang['gallery_back'] ."</a></center>");
}

// fly_indiz [START]
if ($viewmode && $showthumb)
{
	$thumb = false;
	$sql = "SELECT *
			FROM " . GALLERY_TABLE . "
			WHERE image_id = '$showthumb'";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not update gallery table', '', __LINE__, __FILE__, $sql);
	}
	$finded = false;
	while ($row = $db->sql_fetchrow($result))
	{
		$finded = true;
		$name = $row['image_id'];
		if ($row['image_thumb'] == 1) $thumb = $url . $dir ."thumb_". $name;
	}
	if ($finded)
	{
		$msg = '<hr>'. paste_links($url . $dir . $name, $thumb) .'</a>';
		if (IS_ADMIN)
		{
			$msg .= "<br><br>";
			$msg .= "<span style='color:red'><b>". $lang['gallery_del_link'] .": &nbsp; &nbsp;</b></span>";
			$msg .= "<a href=\"gallery.php?go=delete&fn=".$name."\">".$url."gallery.php?go=delete&fn=".$name."</a>";
		}
	}
}
// fly_indiz [END]

$template->assign_vars(array(
	'MSG'            =>  $msg,
	'MAX_SIZE'       =>  humn_size($max_size),
	'MAX_SIZE_HINT'  =>  $lang['gallery_max_file_size'],
	'CREATE_THUMB'   =>  $lang['gallery_create_thumb'],
	'UPLOAD'         =>  $lang['gallery_upload_image'],
	'MORE'           =>  $lang['gallery_more_link'],
));

// fly_indiz [START]
if ($userid)
{
	$sql = "SELECT *
		FROM " . GALLERY_TABLE . "
		WHERE user_id = $userid
		limit $start, 20";
}
else
{
	$sql = "SELECT *
		FROM " . GALLERY_TABLE . "
		WHERE user_id = ".$userdata['user_id']."
		limit $start, 20";
}
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not update gallery table', '', __LINE__, __FILE__, $sql);
}
while ($row = $db->sql_fetchrow($result))
{
	$fn = $row['image_id'];
	$urluid = '';
	if ($userid) $urluid = '&u='.$userid;
	$template->assign_block_vars('thumbrow', array(
		'IMAGEURL'   => 'http://' . $bb_cfg['server_name'] . $bb_cfg['script_path'] . BB_SCRIPT . '.' . PHP_EXT . '?mode=view&showthumb=' . $fn . $urluid,
		'IMAGETHUMB' => 'http://' . $bb_cfg['server_name'] . $bb_cfg['script_path'] . BB_SCRIPT . '.' . PHP_EXT . '?showthumb=' . $fn,
	));
}
// Pagination
$total_images = 1;
if ($userid)
{
	$sql = "SELECT COUNT(*) AS total
		FROM " . GALLERY_TABLE . "
		WHERE user_id = $userid";
}
else
{
	$sql = "SELECT COUNT(*) AS total
		FROM " . GALLERY_TABLE . "
		WHERE user_id = ".$userdata['user_id'];
}
if (!$result = $db->sql_query($sql))
{
	message_die(GENERAL_ERROR, 'Error getting data', '', __LINE__, __FILE__, $sql);
}
if ($total = $db->sql_fetchrow($result))
{
	$total_images = $total['total'];
}
$db->sql_freeresult($result);
if ($total_images <= 20)
{
	$pagination = '&nbsp;';
}
else
{
	if ($userid) $pagination = generate_pagination(BB_SCRIPT . ".$phpEx?u=$userid", $total_images, 20, $start). '&nbsp;';
	else $pagination = generate_pagination(BB_SCRIPT . ".$phpEx?", $total_images, 20, $start). '&nbsp;';
}
$template->assign_vars(array(
	'PAGINATION' => $pagination,
	'PAGE_NUMBER' => sprintf($lang['Page_of'], ( floor( $start / 20 ) + 1 ), ceil( $total_images / 20 )),
	'PER_PAGE' => 20,
	'URL'         => BB_SCRIPT . ".$phpEx?u=$userid",
));
// fly_indiz [END]

if ($showthumb && !$viewmode)
{
	$sql = "SELECT *
			FROM " . GALLERY_TABLE . "
			WHERE image_id = '$showthumb'";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not update gallery table', '', __LINE__, __FILE__, $sql);
	}
	while ($row = $db->sql_fetchrow($result))
	{
		$name = strtok($showthumb, '.');
		$att = '.'.strtok('.');
		$thumb = $row['image_thumb'] ? true : false;
		$im = display_thumb($dir, $name, $att, $thumb);
		if ($im)
		{
			if ($att == ".jpg" || $att == ".jpeg")
			{
				Header ('Content-type: image/jpeg');
				ImageJpeg ($im);
			}
			elseif ($att == ".png")
			{
				Header ('Content-type: image/png');
				ImagePng ($im);
			}
			elseif ($att == ".gif")
			{
				Header ('Content-type: image/gif');
				ImageGif ($im);
			}
		}
	}
}
else
{
	print_page('gallery.tpl');
}