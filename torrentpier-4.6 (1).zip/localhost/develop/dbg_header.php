<style type="text/css">
<!--
	.lineTD, .codeTD {
		vertical-align: top;
		background-color: #FFFFCC;
		font-weight: normal;
		font-size: 12px;
		font-family: "Courier New", Courier, monospace;
	}

	.lineTD {
		text-align: right;
		color: #666666;
	}

	.codeTD {
		background-color: #FFFFFF;
	}

	.lineNum {
		border-bottom: 1px solid #FFFFFF;
	}

	.lineErr {
		background-color: red;
		color: white;
		border-bottom-color: #FFFFFF;
	}

	.codeLine {
		border-bottom: 1px solid #FFFFFF;
	}

	.codeErr {
		cursor: pointer;
		background-color: #E4EFEE;
		border-bottom-color: #FFFFFF;
	}

	.errTABLE {
	border: 2px groove #FF4500;
	margin: 10px;
	background: #FFF5EE;
}
	
	.errRepTD {
		font-size:12px;
		font-family: "Courier New", Courier, monospace;
	}
	
	.errType {
		font-weight: bold;
		padding-left: 30px;
	}

	.errInfo {
		font-size:13px;
		font-family: "Courier New", Courier, monospace;
		padding-right: 30px;
	}
	
	.errTip {
		font-size:10px;
	}

	.errFile {
		color:#696969;
	}

	.errFileCritical {
		color: #FF4500;
		font-weight:bold;
		letter-spacing:1px;
	}
	
	.traceBody {
		font-size:13px;
		font-family: "Courier New", Courier, monospace;
	}
-->
</style>