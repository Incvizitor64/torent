<?php

define('IN_PHPBB', true);
define('BB_ROOT', './');
include(BB_ROOT .'common.php');

//
// Start session management
//
$user->session_start();

$user_id = $userdata['user_id'];
//
// End session management
//

if ( isset($_GET[POST_MEDAL_URL]) || isset($_POST[POST_MEDAL_URL]) )
{
	$medal_id = ( isset($_POST[POST_MEDAL_URL]) ) ? intval($_POST[POST_MEDAL_URL]) : intval($_GET[POST_MEDAL_URL]);
}
else
{
	$medal_id = '';
}

if ( isset($_POST['mode']) || isset($_GET['mode']) )
{
	$mode = ( isset($_POST['mode']) ) ? $_POST['mode'] : $_GET['mode'];
	$mode = htmlspecialchars($mode);
}
else
{
	$mode = '';
}

// session id check
if (!empty($_POST['sid']) || !empty($_GET['sid']))
{
	$sid = (!empty($_POST['sid'])) ? $_POST['sid'] : $_GET['sid'];
}
else
{
	$sid = '';
}

// session id check
if ($sid == '' || $sid != $userdata['session_id'])
{
	$message = $lang['Not_Authorised'] . '<br /><br />' . sprintf($lang['Click_return_index'], '<a href="index.php">', '</a>');

	message_die(GENERAL_ERROR, $message);
}

$is_moderator = FALSE;

$sql = "SELECT *
	FROM " . BB_MEDAL . "
	WHERE medal_id =" . $medal_id;
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not obtain medal information', '', __LINE__, __FILE__, $sql);
}

if ( $medal_info = $db->sql_fetchrow($result) )
{
	$is_moderator = ($userdata['user_level'] != ADMIN) ? check_medal_mod($medal_id) : TRUE;

	// Start auth check
	if ( !$is_moderator )
	{
		$message = $lang['Not_medal_moderator'] . '<br /><br />' . sprintf($lang['Click_return_index'], '<a href="index.php">', '</a>');

		message_die(GENERAL_MESSAGE, $message);
	}
	// End Auth Check

	//
	// Handle Additions and Removals
	//
	if ( isset($_POST['submit']) )
	{
		if ( !$userdata['session_logged_in'] )
		{
			redirect("login.php?redirect=medals.php&" . POST_MEDAL_URL . "=$medal_id");
		}

		if (!isset($_POST['sid']) || $_POST['sid'] != $userdata['session_id'])
		{
			message_die(GENERAL_ERROR, 'Invalid_session');
		}

		if ( !empty($_POST['username']) )
		{
			$username = clean_username($_POST['username']);

			$sql = "SELECT user_id, user_email, user_lang
				FROM " . USERS_TABLE . "
				WHERE username = '" . str_replace("\'", "''", $username) . "'";

			if ( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, "Could not get user information", $lang['ERROR'], __LINE__, __FILE__, $sql);
			}

			if ( !($row = $db->sql_fetchrow($result)) )
			{
				$template->assign_vars(array(
					'META' => '<meta http-equiv="refresh" content="3;url="medalcp.php?'. POST_MEDAL_URL .'='.$medal_id.'&amp;sid='.$userdata['session_id'] .'">'
				));
				$message = $lang['Could_not_add_user'] . '<br /><br />' . sprintf($lang['Click_return_medal'], '<a href="medalcp.php?'. POST_MEDAL_URL .'='.$medal_id.'&amp;sid='.$userdata['session_id'].'">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_index'], '<a href="index.php">', '</a>');

				message_die(GENERAL_MESSAGE, $message);
			}

			$issue_reason = ( isset($_POST['issue_reason']) ) ? trim(htmlspecialchars($_POST['issue_reason'])) : "";

			if ( $row['user_id'] == ANONYMOUS )
			{
				$template->assign_vars(array(
					'META' => '<meta http-equiv="refresh" content="3;url="medalcp.php?'. POST_MEDAL_URL .'='.$medal_id.'&amp;sid='.$userdata['session_id'].'">'
				));

				$message = $lang['Could_not_anonymous_user'] . '<br /><br />' . sprintf($lang['Click_return_medal'], '<a href="medalcp.php?'. POST_MEDAL_URL .'='.$medal_id.'&amp;sid='.$userdata['session_id']. '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_index'], '<a href="index.php">', '</a>');

				message_die(GENERAL_MESSAGE, $message);
			}

			$sql = "INSERT INTO " . BB_MEDAL_USER . " (medal_id, user_id, issue_reason, issue_time)
				VALUES ( $medal_id, " . $row['user_id'] . ", '$issue_reason', " . TIMENOW . ")";

			if ( !$db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, 'Could not add medal to user', '', __LINE__, __FILE__, $sql);
			}

			// Get the medal name
			// Email the user and tell them they're receiving the medal
			$medal_sql = "SELECT medal_name
					FROM " . BB_MEDAL . "
					WHERE medal_id = $medal_id";
			if ( !($result = $db->sql_query($medal_sql)) )
			{
				message_die(GENERAL_ERROR, 'Could not get medal information', '', __LINE__, __FILE__, $medal_sql);
			}

			$medal_name_row = $db->sql_fetchrow($result);

			$medal_name = $medal_name_row['medal_name'];

			include(INC_DIR . 'emailer.php');
			$emailer = new emailer($bb_cfg['smtp_delivery']);
			$emailer->from($bb_cfg['board_email']);
			$emailer->replyto($bb_cfg['board_email']);

			$emailer->use_template('medal_added', stripslashes($row['user_lang']));
			$emailer->email_address($row['user_email']);
			$emailer->set_subject($lang['Medal_added']);

			$emailer->assign_vars(array(
				'USERNAME' => $username,
				'MEDAL_NAME' => $medal_name,
				'EMAIL_SIG' => (!empty($bb_cfg['board_email_sig'])) ? str_replace('<br />', "\n", "-- \n" . $bb_cfg['board_email_sig']) : '')
			);
			$emailer->send();
			$emailer->reset();

			$message = $lang['Medal_update_sucessful'] . '<br /><br />' . sprintf($lang['Click_return_medal'], '<a href="medalcp.php?'. POST_MEDAL_URL .'='.$medal_id.'&amp;sid='.$userdata['session_id'] .'">', '</a>');
		}
		else if ( !empty($_POST['unmedal_user']) )
		{
			$where_sql = '';

			if ( isset($_POST['unmedal_user']) )
			{
				$user_list = $_POST['unmedal_user'];

				for($i = 0; $i < count($user_list); $i++)
				{
					if ( $user_list[$i] != -1 )
					{
						$where_sql .= ( ( $where_sql != '' ) ? ', ' : '' ) . intval($user_list[$i]);
					}
				}
			}
			if ( $where_sql != '' )
			{
				$sql = "DELETE FROM " . BB_MEDAL_USER . "
					WHERE issue_id IN ($where_sql)";
				if ( !$db->sql_query($sql) )
				{
					message_die(GENERAL_ERROR, "Couldn't delete medal info from user", "", __LINE__, __FILE__, $sql);
				}
			}
			$message = $lang['Medal_update_sucessful'] . '<br /><br />' . sprintf($lang['Click_return_medal'], '<a href="medalcp.php?'. POST_MEDAL_URL . '='.$medal_id.'&amp;sid='.$userdata['session_id'].'">', '</a>');
		}
		else if (empty($_POST['username']) || empty($_POST['unmedal_user']))
		{
			message_die(GENERAL_MESSAGE, $lang['No_username_specified'] );
		}

		message_die(GENERAL_MESSAGE, $message);
	}

	//
	// Get medal details
	//
	$sql = "SELECT *
		FROM " . BB_MEDAL . "
		WHERE medal_id =" . $medal_id;
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error getting medal information', '', __LINE__, __FILE__, $sql);
	}

	if ( !($medal_info = $db->sql_fetchrow($result)) )
	{
		message_die(GENERAL_MESSAGE, $lang['Medal_not_exist']);
	}

	// Medal Moderators
	$sql = "SELECT u.username, u.user_id, u.user_rank
		FROM " . USERS_TABLE . " u, " . BB_MEDAL_MOD . " mm
		WHERE mm.medal_id = $medal_id
		AND u.user_id = mm.user_id
		ORDER BY u.username";

	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error getting medal moderator information', '', __LINE__, __FILE__, $sql);
	}

	$medal_moderator = '';
	while ( $row = $db->sql_fetchrow($result) )
	{
		$medal_moderator .= ( $medal_moderator != '' ) ? ', ' . profile_url($row) : profile_url($row);
	}

	//
	// Get user information for this medal
	//
	$sql = "SELECT u.username, u.user_id, mu.issue_id, mu.issue_time
		FROM " . USERS_TABLE . " u, " . BB_MEDAL_USER . " mu
		WHERE mu.medal_id = $medal_id
		AND u.user_id = mu.user_id
		ORDER BY u.username";

	if ($result = $db->sql_query($sql))
	{
		$medal_member = '';
		$rowset = array();
		while ($row = $db->sql_fetchrow($result))
		{
			$rowset[$row['user_id']]['username'] = $row['username'];
		}
	}

	while (list($user_id, $medal) = @each($rowset))
	{
		$medal_member .= ( $medal_member != '' ) ? ', ' . '<a href="medalcp_edit.php?&amp;' . POST_MEDAL_URL . '='.$medal_id.'&amp;' . POST_USERS_URL . '=' . $user_id.'&amp;sid='.$userdata['session_id'] . '" class="gen">' . $medal['username'] . '</a>' : '<a href="medalcp_edit.php?&amp;'. POST_MEDAL_URL .'='.$medal_id.'&amp;'. POST_USERS_URL .'='. $user_id.'&amp;sid='.$userdata['session_id'] . '" class="gen">' . $medal['username'] . '</a>';
	}

	$sql = "SELECT u.username, u.user_id, mu.issue_id, mu.issue_time
		FROM " . USERS_TABLE . " u, " . BB_MEDAL_USER . " mu
		WHERE mu.medal_id = $medal_id
		AND u.user_id = mu.user_id
		ORDER BY u.username";
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Error getting user list for medal', '', __LINE__, __FILE__, $sql);
	}

	$medal_members = array();
	$medal_members = $db->sql_fetchrowset($result);
	$members_count = count($medal_members);
	$db->sql_freeresult($result);

	$select_userlist = '';
	for($i = 0; $i < $members_count; $i++)
	{
		$issue_time = bb_date($medal_members[$i]['issue_time']);
		$select_userlist .= '<option value="' . $medal_members[$i]['issue_id'] . '">' . $medal_members[$i]['username'] . ' [' . $issue_time . '] ' . '</option>';
	}

	if( $select_userlist == '' )
	{
		$select_userlist = '<option value="-1">' . $lang['No_medal_members'] . '</option>';
	}

	$select_userlist = '<select name="unmedal_user[]" multiple="multiple" size="10" style="width: 250px;">' . $select_userlist . '</select>';

	$s_hidden_fields = '<input type="hidden" name="mode" value="submit" />';

	$page_title = $lang['Medal_Control_Panel'];

	//
	// Load templates
	//

	//make_jumpbox('viewforum.php');

	$s_hidden_fields .= '<input type="hidden" name="sid" value="' . $userdata['session_id'] . '" />';
	$s_hidden_fields .= '<input type="hidden" name="' . POST_MEDAL_URL . '" value="' . $medal_id . '" />';

	$template->assign_vars(array(
		'L_MEDAL_INFORMATION' => $lang['Medal_Information'],
		'L_MEDAL_NAME' => $lang['Medal_name'],
		'L_MEDAL_DESC' => $lang['Medal_description'],
		'L_MEDAL_IMAGE' => $lang['Medal_image'],
		'L_MEDAL_MODERATOR' => $lang['Medal_moderator'],
		'L_MEDAL_MEMBERS' => $lang['Medal_Members'],
		'L_MEDAL_MEMBERS_EXPLAIN' => $lang['Medal_Members_explain'],
		'L_MEDAL_USER' => $lang['Medal_user_username'],
		'L_MEDAL_REASON' => $lang['Medal_reason'],
		'L_MEDAL_REASON_EXPLAIN' => $lang['Medal_reason_explain'],
		'L_UNMEDAL_USER' => $lang['Medal_unmedal_username'],
		'L_UNMEDAL_USER_EXPLAIN' => $lang['Medal_unmedal_username_explain'],



		'MEDAL_NAME' => $medal_info['medal_name'],
		'MEDAL_DESC' => $medal_info['medal_description'],
		'MEDAL_IMAGE' => $medal_info['medal_image'],
		'MEDAL_IMAGE_DISPLAY' => ( !empty($medal_info['medal_image']) ) ? '<img src="' . $medal_info['medal_image'] . '" border="0" alt="' . $medal_info['medal_name'] . '" />' : "",
		'MEDAL_MODERATOR' => ( $medal_moderator ) ? $medal_moderator : $lang['No_medal_mod'],
		'MEDAL_MEMBER' => ( $medal_member ) ? $medal_member : $lang['No_medal_members'],

		'U_SEARCH_USER' => 'search.php?mode=searchuser',
		'S_UNMEDAL_USERLIST_SELECT' => $select_userlist,
		'S_MEDALCP_ACTION' => 'medalcp.php',
		'S_HIDDEN_FIELDS' => $s_hidden_fields)
	);

}
else
{
	message_die(GENERAL_MESSAGE, $lang['No_medals_exist']);
}

print_page('medalcp_body.tpl');
