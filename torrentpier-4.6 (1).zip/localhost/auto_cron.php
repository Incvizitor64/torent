<?php 

define('IN_PHPBB', true);
define('BB_ROOT', './');
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require(BB_ROOT ."common.$phpEx");

$user->session_start();

// Cron
if (empty($_POST) && !defined('IN_AJAX') && !defined('IN_SERVICE') && !file_exists(CRON_RUNNING) || defined('FORCE_CRON'))
{
	if (TIMENOW - $bb_cfg['cron_last_check'] > $bb_cfg['cron_check_interval'])
	{
		// Update cron_last_check
		bb_update_config(array('cron_last_check' => (time() + 10)));

		require(CFG_DIR .'cron_cfg.'. PHP_EXT);

		bb_log(date('H:i:s - ') . getmypid() .' -x-- DB-LOCK try'. LOG_LF, CRON_LOG_DIR .'auto_cron_check');

		if ($db->get_lock('cron', 1))
		{
			bb_log(date('H:i:s - ') . getmypid() .' --x- DB-LOCK OBTAINED !!!!!!!!!!!!!!!!!'. LOG_LF, CRON_LOG_DIR .'auto_cron_check');

			sleep(2);
			require(CRON_DIR .'cron_init.'. PHP_EXT);

			$db->release_lock('cron');
		}
	}
}