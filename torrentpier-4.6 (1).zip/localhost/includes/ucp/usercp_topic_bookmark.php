<?php

if (empty($bb_cfg['topic_bookmark_enabled']))
{
	bb_die($lang['Disabled']);
}

$page_cfg['use_tablesorter']   = true;
$page_cfg['include_bbcode_js'] = true;
$tracking_topics = get_tracks('topic');

$user_id = $userdata['user_id'];
$start = isset($_GET['start']) ? abs(intval($_GET['start'])) : 0;
$per_page = $bb_cfg['topics_per_page'];
$url = BB_ROOT .'profile.'. $phpEx .'?mode=bookmark';

if ( isset($_POST['bookmark_list']) )
{
    $topic_ids = implode(",", $_POST['bookmark_list']);
    $sql = "DELETE FROM ". TOPICS_BOOKMARK_TABLE ."
      WHERE topic_id IN(". $topic_ids .")
      AND user_id = $user_id";
    if ( !($result = $db->sql_query($sql)) )
    {
        message_die(GENERAL_ERROR, "Could not delete topic bookmark information", '', __LINE__, __FILE__, $sql);
    }
}

$template->assign_vars(array(
    'PAGE_TITLE'    => $lang['Bookmarks'],
    'S_FORM_ACTION' => $url,
));

$sql = "SELECT COUNT(*) as bookmark_count FROM ". TOPICS_BOOKMARK_TABLE ." WHERE user_id = $user_id";
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not obtain bookmark topic information', '', __LINE__, __FILE__, $sql);
}
$row = $db->sql_fetchrow($result);
$bookmark_count = ( $row['bookmark_count'] ) ? $row['bookmark_count'] : 0;
$db->sql_freeresult($result);

if ($bookmark_count > 0)
{
    $sql = "SELECT b.*, t.*, f.*, u.*, u2.username as last_username, u2.user_id as last_user_id,
		u2.user_level as last_user_level, u2.user_rank as last_user_rank
	FROM ". TOPICS_BOOKMARK_TABLE ." b, ". TOPICS_TABLE ." t, ". USERS_TABLE ." u, ". FORUMS_TABLE ." f, ". POSTS_TABLE ." p, " . USERS_TABLE . " u2
	WHERE b.topic_id = t.topic_id
		AND t.forum_id = f.forum_id
		AND p.post_id = t.topic_last_post_id
		AND p.poster_id = u2.user_id
		AND t.topic_poster = u.user_id
        AND b.user_id = $user_id
	GROUP BY t.topic_last_post_time DESC
	LIMIT $start, $per_page";
    if ( !($result = $db->sql_query($sql)) )
    {
		message_die(GENERAL_ERROR, 'Could not obtain bookmark topic information', '', __LINE__, __FILE__, $sql);
    }
    $bookmark = $db->sql_fetchrowset($result);

    if ($bookmark)
    {
        for ( $i = 0; $i < count($bookmark); $i++ )
        {
			$poster_url = append_sid("profile.$phpEx?mode=viewprofile&amp;". POST_USERS_URL .'='. $bookmark[$i]['user_id']);
			$bookmark[$i]['username'] = wbr($bookmark[$i]['username']);
			$poster_username = '<a class="genmed" href="'. $poster_url .'">'. $bookmark[$i]['username'] .'</a>';

			$author_url = append_sid("profile.$phpEx?mode=viewprofile&amp;". POST_USERS_URL .'='. $bookmark[$i]['last_user_id']);
			$bookmark[$i]['last_username'] = wbr($bookmark[$i]['last_username']);
			$last_username = '<a class="gensmall" href="'. $author_url .'">'. $bookmark[$i]['last_username'] .'</a>';

			$forum_url = append_sid("viewforum.$phpEx?f=". $bookmark[$i]['forum_id']);
			$forum = '<a class="genmed" href="'. $forum_url .'">'. $bookmark[$i]['forum_name'] .'</a>';
			$last_post_time = create_date($bb_cfg['default_dateformat'], $bookmark[$i]['topic_last_post_time'], $bb_cfg['board_timezone']);

            $is_unread = is_unread($bookmark[$i]['topic_last_post_time'], $bookmark[$i]['topic_id'], $bookmark[$i]['forum_id']);

			$row_class = ( !($i % 2) ) ? 'row1' : 'row2';

			$template->assign_block_vars('bookmark', array(
				'ROW_CLASS'         => $row_class,

                'POST_ID'           => $bookmark[$i]['topic_first_post_id'],

                'TOPIC_ID'          => $bookmark[$i]['topic_id'],
				'TOPIC_TITLE'       => wbr(str_short($bookmark[$i]['topic_title'], 70)),
				'FULL_TOPIC_TITLE'  => wbr($bookmark[$i]['topic_title']),
				'U_TOPIC'           => TOPIC_URL . $bookmark[$i]['topic_id'],

				'FORUM_TITLE'       => wbr($bookmark[$i]['forum_name']),
				'U_FORUM'           => FORUM_URL . $bookmark[$i]['forum_id'],

				'REPLIES'           => $bookmark[$i]['topic_replies'],

				'AUTHOR'            => $poster_username,
				'LAST_POST'         => $last_post_time .'<br />'. $last_username,
                'LAST_POST_ID'      => $bookmark[$i]['topic_last_post_id'],

                'IS_UNREAD'         => $is_unread,
			    'TOPIC_ICON'        => get_topic_icon($bookmark[$i], $is_unread),
			    'PAGINATION'        => ($bookmark[$i]['topic_status'] == TOPIC_MOVED) ? '' : build_topic_pagination(TOPIC_URL . $bookmark[$i]['topic_id'], $bookmark[$i]['topic_replies'], $bb_cfg['posts_per_page']),
			));
        }

        $pagination = generate_pagination($url, $bookmark_count, $per_page, $start);

        $count_bookmark = count($bookmark);
        $matches = ($count_bookmark == 1) ? sprintf($lang['Found_search_match'], $count_bookmark) : sprintf($lang['Found_search_matches'], $count_bookmark);

		$template->assign_vars(array(
		    'MATCHES'     => $matches,
			'PAGINATION'  => $pagination,
			'PAGE_NUMBER' => sprintf($lang['Page_of'], ( floor( $start / $per_page ) + 1 ), ceil( $bookmark_count / $per_page )),
		    'U_PER_PAGE'  => $url,
		    'PER_PAGE'    => $per_page,
		));
    }
    $db->sql_freeresult($result);
}
else
{
	meta_refresh(BB_ROOT, '3');
    bb_die($lang['No_bookmarks']);
}

print_page('usercp_topic_bookmark.tpl');