<?php
/***************************************************************************
 *                           usercp_viewprofile.php
 *                            -------------------
 *   begin                : Saturday, Feb 13, 2001
 *   copyright            : (C) 2001 The phpBB Group
 *   email                : support@phpbb.com
 *
 *   $Id: usercp_viewprofile.php,v 1.5.2.6 2005/09/14 18:14:30 acydburn Exp $
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *
 ***************************************************************************/
if ( !defined('IN_PHPBB') )
{
	die("Hacking attempt");
	exit;
}

$datastore->enqueue(array(
	'ranks',
));

if (!$userdata['session_logged_in'])
{
	redirect(append_sid("login.$phpEx?redirect={$_SERVER['REQUEST_URI']}", TRUE));
}
// Democracy Mod 0.21 adapted [START]
if ($bb_cfg['warnings_enabled'] || $bb_cfg['reputation_enabled'])
{
	include($phpbb_root_path . 'includes/functions_reputation.' . $phpEx);
}
// Democracy Mod 0.21 adapted [END]
if ( empty($_GET[POST_USERS_URL]) || $_GET[POST_USERS_URL] == ANONYMOUS )
{
	message_die(GENERAL_MESSAGE, $lang['No_user_id_specified']);
}
$profiledata = get_userdata($_GET[POST_USERS_URL]);

if (!$profiledata)
{
	message_die(GENERAL_MESSAGE, $lang['No_user_id_specified']);
}

$its_me = ($profiledata['user_id'] == $userdata['user_id']);

//
// Calculate the number of days this user has been a member ($memberdays)
// Then calculate their posts per day
//
$regdate = $profiledata['user_regdate'];
$memberdays = max(1, round( ( time() - $regdate ) / 86400 ));
$posts_per_day = $profiledata['user_posts'] / $memberdays;

// Get the users percentage of total posts
if ( $profiledata['user_posts'] != 0  )
{
	$total_posts = get_db_stat('postcount');
	$percentage = ( $total_posts ) ? min(100, ($profiledata['user_posts'] / $total_posts) * 100) : 0;
}
else
{
	$percentage = 0;
}
$avatar_img = '';
if ( $profiledata['user_avatar_type'] && $profiledata['user_allowavatar'] )
{
	switch( $profiledata['user_avatar_type'] )
	{
		case USER_AVATAR_UPLOAD:
			$avatar_img = ( $board_config['allow_avatar_upload'] ) ? '<img src="' . $board_config['avatar_path'] . '/' . $profiledata['user_avatar'] . '" alt="" border="0" />' : '';
			break;
		case USER_AVATAR_REMOTE:
			$avatar_img = ( $board_config['allow_avatar_remote'] ) ? '<img src="' . $profiledata['user_avatar'] . '" alt="" border="0" />' : '';
			break;
		case USER_AVATAR_GALLERY:
			$avatar_img = ( $board_config['allow_avatar_local'] ) ? '<img src="' . $board_config['avatar_gallery_path'] . '/' . $profiledata['user_avatar'] . '" alt="" border="0" />' : '';
			break;
	}
}

if (!$ranks = $datastore->get('ranks'))
{
	$datastore->update('ranks');
	$ranks = $datastore->get('ranks');
}
$poster_rank = $rank_image = '';

if ($user_rank = $profiledata['user_rank'] AND isset($ranks[$user_rank]))
{
	$rank_image = ($ranks[$user_rank]['rank_image']) ? '<img src="'. $ranks[$user_rank]['rank_image'] .'" alt="" title="" border="0" />' : '';
	$poster_rank = $ranks[$user_rank]['rank_title'];
}
elseif (!isset($ranks[$user_rank]))
{
    $rank_image = '<img src="' . $bb_cfg['default_user_rank_img'] . '" alt="" title="" border="0" />';
    $poster_rank = $lang['USER'];
}

$park_status = $profiledata['user_park_profile'] ? $lang['YES'] : $lang['NO'];
$template->assign_vars(array(
    'STATUS_PARK'           => $park_status,
));

$temp_url = append_sid("privmsg.$phpEx?mode=post&amp;" . POST_USERS_URL . "=" . $profiledata['user_id']);
$pm_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_pm'] . '" alt="' . $lang['Send_private_message'] . '" title="' . $lang['Send_private_message'] . '" border="0" /></a>';

$location = ($profiledata['user_from']) ? $profiledata['user_from'] : '';
$location .= ($profiledata['user_from_flag'] && $profiledata['user_from_flag'] != 'blank.gif') ? '&nbsp;'. make_user_flag($profiledata['user_from_flag']) : '';

$pm = '<a class="txtb" href="' . $temp_url . '">[' . $lang['Send_private_message'] . ']</a>';

if ( bf($profiledata['user_opt'], 'user_opt', 'viewemail') || IS_ADMIN )
{
	$email_uri = ( $board_config['board_email_form'] ) ? append_sid("profile.$phpEx?mode=email&amp;" . POST_USERS_URL .'=' . $profiledata['user_id']) : 'mailto:' . $profiledata['user_email'];
	$email_img = '<a href="' . $email_uri . '"><img src="' . $images['icon_email'] . '" alt="' . $lang['Send_email'] . '" title="' . $lang['Send_email'] . '" border="0" /></a>';
	$email = '<a class="txtb" href="' . $email_uri . '">[' . $lang['Send_email'] . ']</a>';
}
else
{
	$email_img = '';
	$email = '';
}

// Medal MOD

//
// Category
//

$sql = "SELECT cat_id, cat_title
	FROM " . BB_MEDAL_CAT . "
	ORDER BY cat_order";
if( !($result = $db->sql_query($sql)) )
{
    message_die(GENERAL_ERROR, 'Could not query medal categories list', '', __LINE__, __FILE__, $sql);
}

$category_rows = array();
while ( $row = $db->sql_fetchrow($result) )
{
    $category_rows[] = $row;
}
$db->sql_freeresult($result);

$sql = "SELECT DISTINCT m.medal_id, mu.user_id
	FROM " . BB_MEDAL . " m, " . BB_MEDAL_USER . " mu
	WHERE mu.user_id = '" . $profiledata['user_id'] . "'
	AND m.medal_id = mu.medal_id
	ORDER BY m.medal_name";

$medal_count_u = '';
if($result = $db->sql_query($sql))
{
    $medal_list = $db->sql_fetchrowset($result);
    $medal_count = count($medal_list);

    if ( $medal_count )
    {
        $medal_count_u = $medal_count;
    }
}

$sql_total = "SELECT m.medal_id, mu.user_id
	FROM " . BB_MEDAL . " m, " . BB_MEDAL_USER . " mu
	WHERE mu.user_id = '" . $profiledata['user_id'] . "'
	AND m.medal_id = mu.medal_id
	ORDER BY m.medal_name";

$medal_count_total = '';
if($result = $db->sql_query($sql_total))
{
    $medal_list_total = $db->sql_fetchrowset($result);
    $medal_count_total = count($medal_list_total);

    if ( $medal_count_total )
    {
        $medal_count_total = '(' . $lang['Medals_all'] . ': ' .  $medal_count_total . ')';
    }
}
if(!empty($medal_count_u) && !empty($medal_count_total)) {
    $template->assign_block_vars('switch_display_medal', array());
    $template->assign_block_vars('switch_display_medal.medal', array());
}

for ($i = 0; $i < count($category_rows); $i++)
{
    $cat_id = $category_rows[$i]['cat_id'];

    $sql = "SELECT m.medal_id, m.medal_name,m.medal_description, m.medal_image, m.cat_id, mu.issue_reason, mu.issue_time, c.cat_id, c.cat_title
		FROM " . BB_MEDAL . " m, " . BB_MEDAL_USER . " mu, " . BB_MEDAL_CAT . " c
		WHERE mu.user_id = '" . $profiledata['user_id'] . "'
		AND m.cat_id = c.cat_id
		AND m.medal_id = mu.medal_id
		ORDER BY c.cat_order, m.medal_name, mu.issue_time";

    if ($result = $db->sql_query($sql))
    {
        $row = $rowset = array();
        $medal_time = $lang['Medal_time'] . ':&nbsp;';
        $medal_reason = $lang['Medal_reason'] . ':&nbsp;';
        while ($row = $db->sql_fetchrow($result))
        {
            if (empty($rowset[$row['medal_name']]))
            {
                $rowset[$row['medal_name']]['cat_id'] = $row['cat_id'];
                $rowset[$row['medal_name']]['cat_title'] = $row['cat_title'];
                $rowset[$row['medal_name']]['medal_description'] = $row['medal_description'];
                $rowset[$row['medal_name']]['medal_image'] = $row['medal_image'];
                $row['issue_reason'] = ( $row['issue_reason'] ) ? $row['issue_reason'] : $lang['Medal_no_reason'];
                $rowset[$row['medal_name']]['medal_issue'] = '<tr><td><span class="genmed">' . $medal_time . bb_date($row['issue_time']) . '</span></td></tr><tr><td><span class="genmed">' . $medal_reason . $row['issue_reason']  . '</span><hr></td></tr>';
                $rowset[$row['medal_name']]['medal_count'] = '1';
            }
            else
            {
                $row['issue_reason'] = ( $row['issue_reason'] ) ? $row['issue_reason'] : $lang['Medal_no_reason'];
                $rowset[$row['medal_name']]['medal_issue'] .= '<tr><td><span class="genmed">' . $medal_time . bb_date($row['issue_time']) . '</span></td></tr><tr><td><span class="genmed">' . $medal_reason . $row['issue_reason'] . '</span><hr /></td></tr>';
                $rowset[$row['medal_name']]['medal_count'] += '1';
            }
        }

        $medal_width = ( $bb_cfg['medal_display_width'] ) ? 'width="'.$bb_cfg['medal_display_width'].'"' : '';
        $medal_height = ( $bb_cfg['medal_display_height'] ) ? 'height="'.$bb_cfg['medal_display_height'].'"' : '';

        $medal_name = array();
        $data = array();

        //
        // Should we display this category/medal set?
        //
        $display_medal = 0;

        while (list($medal_name, $data) = @each($rowset))
        {
            if ( $cat_id == $data['cat_id'] ) { $display_medal = 1; }

            if ( !empty($display_medal) )
            {
                $template->assign_block_vars('switch_display_medal.details', array(
                        'MEDAL_CAT' => $data['cat_title'],
                        'MEDAL_NAME' => $medal_name,
                        'MEDAL_DESCRIPTION' => $data['medal_description'],
                        'MEDAL_IMAGE' => '<img src="'. BB_ROOT . $data['medal_image'] . '" border="0" alt="' . $medal_name . '" title="' . $medal_name . '" />',
                        'MEDAL_IMAGE_SMALL' => '<img src="'. BB_ROOT . $data['medal_image'] . '" border="0" alt="' . $medal_name . '"' . $medal_width . $medal_height . ' />',
                        'MEDAL_ISSUE' => $data['medal_issue'],
                        'MEDAL_COUNT' => $lang['Medal_amount'] . $data['medal_count'],

                        'L_MEDAL_DESCRIPTION' => $lang['Medal_description'],
                ));
                $display_medal = 0;
            }
        }
    }
}
//Medal MOD [END]

$www_img = ( $profiledata['user_website'] ) ? '<a href="' . $profiledata['user_website'] . '" target="_userwww"><img src="' . $images['icon_www'] . '" alt="' . $lang['Visit_website'] . '" title="' . $lang['Visit_website'] . '" border="0" /></a>' : '';
$www = ( $profiledata['user_website'] ) ? '<a href="' . $profiledata['user_website'] . '" target="_userwww">' . $profiledata['user_website'] . '</a>' : '';
if ( !empty($profiledata['user_icq']) )
{
	$icq_status_img = '<a href="http://wwp.icq.com/' . $profiledata['user_icq'] . '#pager"><img src="http://web.icq.com/whitepages/online?icq=' . $profiledata['user_icq'] . '&img=5" width="18" height="18" border="0" /></a>';
	$icq_img = '<a href="http://www.icq.com/people/searched=1&uin=' . $profiledata['user_icq'] . '"><img src="' . $images['icon_icq'] . '" alt="' . $lang['ICQ'] . '" title="' . $lang['ICQ'] . '" border="0" /></a>';
	$icq =  '<a class="txtb" href="http://www.icq.com/people/' . $profiledata['user_icq'] . '">[' . $profiledata['user_icq'] . ']</a>';
}
else
{
	$icq_status_img = '';
	$icq_img = '';
	$icq = '';
}
$aim_img = ( $profiledata['user_aim'] ) ? '<a href="aim:goim?screenname=' . $profiledata['user_aim'] . '&amp;message=Hello+Are+you+there?"><img src="' . $images['icon_aim'] . '" alt="' . $lang['AIM'] . '" title="' . $lang['AIM'] . '" border="0" /></a>' : '';
$aim = ( $profiledata['user_aim'] ) ? '<a class="txtb" href="aim:goim?screenname=' . $profiledata['user_aim'] . '&amp;message=Hello+Are+you+there?">[' . $lang['AIM'] . ']</a>' : '';
$msn_img = ( $profiledata['user_msnm'] ) ? '<a href="mailto:' . $profiledata['user_msnm'] . '"><img src="' . $images['icon_msnm'] . '" alt="' . $lang['MSNM'] . '" title="' . $lang['MSNM'] . '" border="0" /></a>' : '';
$msn = ( $profiledata['user_msnm'] ) ? '<a class="txtb" href="mailto:' . $profiledata['user_msnm'] . '">[' . $lang['MSNM'] . ']</a>' : '';
$magent_img = ( $profiledata['user_magent'] ) ? '<a href="http://www.mail.ru/agent?message&to=' . $profiledata['user_magent'] . '"><img src="' . $images['icon_magent'] . '" alt="' . $lang['MAGENT'] . '" title="' . $lang['MAGENT'] . '" border="0" /></a>' : '';
$magent = ( $profiledata['user_magent'] ) ? '<a class="txtb" href="http://www.mail.ru/agent?message&to=' . $profiledata['user_magent'] . '">[' . $lang['MAGENT'] . ']</a>' : '';
$yim_img = ( $profiledata['user_yim'] ) ? '<a href="http://edit.yahoo.com/config/send_webmesg?.target=' . $profiledata['user_yim'] . '&amp;.src=pg"><img src="' . $images['icon_yim'] . '" alt="' . $lang['YIM'] . '" title="' . $lang['YIM'] . '" border="0" /></a>' : '';
$yim = ( $profiledata['user_yim'] ) ? '<a class="txtb" href="http://edit.yahoo.com/config/send_webmesg?.target=' . $profiledata['user_yim'] . '&amp;.src=pg">[' . $lang['YIM'] . ']</a>' : '';
$temp_url = append_sid("search.$phpEx?search_author=1&amp;uid={$profiledata['user_id']}");
$search_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_search'] . '" alt="' . $lang['Search_user_posts'] . '" title="' . sprintf($lang['Search_user_posts'], $profiledata['username']) . '" border="0" /></a>';
$search = '<a href="' . $temp_url . '">' . sprintf($lang['Search_user_posts'], $profiledata['username']) . '</a>';

// Internet Speed [Mod]
$dwsp = $profiledata['user_dwsp'];
$upsp = $profiledata['user_upsp'];

if($dwsp && $upsp) {
    $dwsp = $bb_cfg['user_speeds'][$dwsp];
    $upsp = $bb_cfg['user_speeds'][$upsp];
}
else {
    $dwsp = '?';
    $upsp = '?';
}

// Report
//
// Get report user module and create report link
//
include_once(INC_DIR . "functions_report.$phpEx");
$report_user = report_modules('name', 'report_user');

if ($report_user && $report_user->auth_check('auth_write'))
{
	$template->assign_block_vars('switch_report_user', array());
	$template->assign_vars(array(
		'U_REPORT_USER' => append_sid("report.$phpEx?mode=" . $report_user->mode . '&amp;id=' . $profiledata['user_id']),
		'L_REPORT_USER' => $report_user->lang['Write_report'])
	);
}
// Report [END]

// Start add - Gender MOD
if ( !empty($profiledata['user_gender']))
{
    switch ($profiledata['user_gender'])
    {
        case 1: $gender=$lang['Male'];break;
        case 2: $gender=$lang['Female'];break;
        default:$gender=$lang['No_gender_specify'];
    }
} else $gender=$lang['No_gender_specify'];
// End add - Gender MOD

//
// Generate page
//
if ($its_me || IS_ADMIN)
{
	require(BB_ROOT .'attach_mod/attachment_mod.'. PHP_EXT);
	display_upload_attach_box_limits($profiledata['user_id']);
}

// IP Mod (c) Pandora
if ($profiledata['user_level'] == ADMIN && !IS_ADMIN)
{
	$reg_ip	= $last_ip = $useragent = $lang['Hidden'];
} elseif ($profiledata['user_level'] == MOD && IS_MOD)
{
	$reg_ip	= $last_ip = $useragent = $lang['Hidden'];
} else {
	$reg_ip	= decode_ip($profiledata['user_reg_ip']);
	$last_ip = decode_ip($profiledata['user_last_ip']);
	$useragent = $profiledata['user_agent'];
    if (strtolower($useragent) != '') {
        $useragent = $profiledata['user_agent'];
    } else {
        $useragent = $lang['No_match'];
    }
}
// IP Mod End

// Invites mod [START]
$sql = 'SELECT * FROM `invites` WHERE `new_user_id`='.$profiledata['user_id'];
if (!($result = $db->sql_query($sql))) message_die(GENERAL_ERROR, 'Error in getting invites list', '', __LINE__, __FILE__, $sql);
$invite_row = $db->sql_fetchrowset($result);
$num_invite_row = $db->sql_numrows($result);
$db->sql_freeresult($result);
if ($num_invite_row > 0 && get_userdata($invite_row[0]['user_id']) != false)
{
	$old_user_data = get_userdata($invite_row[0]['user_id']);
	$template->assign_vars(array(
		'YOU_INVITED' => true,
		'OLD_USER' => '<a href="profile.php?mode=viewprofile&u='.$invite_row[0]['user_id'].'">'.$old_user_data['username'].'</a>',
	));
}
else
{
	$template->assign_vars(array(
		'YOU_INVITED' => false,
	));
}

$sql = 'SELECT * FROM `invites` WHERE `user_id`='.$profiledata['user_id'].' and `new_user_id`!='.$profiledata['user_id'].' and `active`!=1 ORDER BY `activation_date` DESC LIMIT 10';
if (!($result = $db->sql_query($sql))) message_die(GENERAL_ERROR, 'Error in getting invites list', '', __LINE__, __FILE__, $sql);
$invite_row = $db->sql_fetchrowset($result);
$num_invite_row = $db->sql_numrows($result);
$db->sql_freeresult($result);
if ($num_invite_row > 0)
{
	$template->assign_vars(array('INVITES_PRESENT' => true));
	$j = 0;
	for ($i = 0; $i < $num_invite_row; $i++)
	{
		$k = $i + $j;
		if ($k%2===0)
		{
			$invite_rowclass = false;
		}
		else
		{
			$invite_rowclass = true;
		}
		$new_user_data = get_userdata($invite_row[$i]['new_user_id']);
		if ($new_user_data['username'] == '')
		{
			$j = $j + 1;
		}
		else
		{
		$template->assign_block_vars('invite_row', array(
			'ACTIVE' => ($invite_row[$i]['active'] == '1') ? $lang['YES'] : $lang['NO'],
			'NEW_USER' => ($invite_row[$i]['active'] == '1') ? 'user deleted' : '<a href="profile.php?mode=viewprofile&u='.$invite_row[$i]['new_user_id'].'">'.$new_user_data['username'].'</a>',
			'ACTIVATION_DATE' => ($invite_row[$i]['active'] == '1') ? 'user deleted' : date('d.m.Y H:i', $invite_row[$i]['activation_date']),
			'INVITE_ROWCLASS' => $invite_rowclass,
		));
		$template->assign_vars(array('INVITE_ROWCLASS' => $invite_rowclass));
		}
	}
}
else
{
	$template->assign_vars(array('INVITES_PRESENT' => false));
}
// Invites mod [END]

// User group
$group_rowclass = false;
$user_id = $userdata['user_id'];
$view_user_id = $profiledata['user_id'];
$groups = array();
$sql = '
	SELECT
		g.group_id,
		g.group_name,
		g.group_type,
		g.group_moderator
   FROM
      '.USER_GROUP_TABLE.' as l,
      '.GROUPS_TABLE.' as g
   WHERE
      l.user_pending = 0 AND
      g.group_single_user = 0 AND
      l.user_id ='. $view_user_id.' AND
      g.group_id = l.group_id
   ORDER BY
      g.group_name,
      g.group_id';
if ( !($result = $db->sql_query($sql)) ) message_die(GENERAL_ERROR, 'Could not read groups', '', __LINE__, __FILE__, $sql);
while ($group = $db->sql_fetchrow($result)) $groups[] = $group;

$template->assign_vars(array(
   'L_USERGROUPS' => $lang['USERGROUPS'],
   )
);
if (count($groups) > 0)
{
    $groupsw=TRUE;
	$j = 0;
    for ($i=0; $i < count($groups); $i++)
    {
        $is_ok = false;
        // group invisible ?
        if ( ($groups[$i]['group_type'] != GROUP_HIDDEN) || ($userdata['user_level'] == ADMIN) )
        {
            $is_ok=true;
        }
        else
        {
            $group_id = $groups[$i]['group_id'];
            $sql = 'SELECT * FROM '.USER_GROUP_TABLE.' WHERE group_id='.$group_id.' AND user_id='.$user_id.' AND user_pending=0';
            if ( !($result = $db->sql_query($sql)) ) message_die(GENERAL_ERROR, 'Couldn\'t obtain viewer group list', '', __LINE__, __FILE__, $sql);
            $is_ok = ( $group = $db->sql_fetchrow($result) );
        }  // end if ($view_list[$i]['group_type'] == GROUP_HIDDEN)
        // group visible
        if ($is_ok)
        {
            $j = $j + 1;
			if ($j%2 === 0)
			{
				$group_rowclass = true;
			}
			else
			{
				$group_rowclass = false;
			}

            $u_group_name = append_sid("groupcp.php?g=".$groups[$i]['group_id']);
            $l_group_name = $groups[$i]['group_name'];

		    if($groups[$i]['group_moderator'] == $view_user_id) // $l_group_name = "<font color=\"#006600\"><b>".$l_group_name."</font></b>";
            {
			    $m_group_name = true;
		    }
		    else
		    {
			    $m_group_name = false;
		    }
            $template->assign_block_vars('groups',array(
                'U_GROUP_NAME' => $u_group_name,
                'L_GROUP_NAME' => $l_group_name,
			    'M_GROUP_NAME' => $m_group_name,
			    'GROUP_ROWCLASS' => $group_rowclass,
            ));
        }  // end if ($is_ok)
    }  // end for ($i=0; $i < count($groups); $i++)
}  // end if (count($groups) > 0)
else
{
    $groupsw = false;
}
$template->assign_vars(array('GROUP_ROWCLASS' => $group_rowclass || !$groupsw));
//user group#

switch ($profiledata['user_level'])
{
	case ADMIN :
		$profiledata['user_level'] = '<span class="colorAdmin">' . $lang['ONLINE_ADMIN'] . '</span>';
		$style_color = '';
		break;
	case MOD :
		$profiledata['user_level'] = '<span class="colorMod">' . $lang['ONLINE_MOD'] . '</span>';
		$style_color = '';
		break;
	case GROUP_MEMBER :
		$profiledata['user_level'] = '<span class="colorGroup">' . $lang['ONLINE_GROUP_MEMBER'] . '</span>';
		$style_color = '';
		break;
	case USER :
		$profiledata['user_level'] = '<span class="nick">' . $lang['USER'] . '</span>';
		$style_color = '';
		break;
	default: $style_color = '';
}

// Democracy Mod 0.21 adapted [START]
$banned = false;
if ($bb_cfg['warnings_enabled'] || $bb_cfg['reputation_enabled'])
{
	$is_auth = reputation_auth(NO_ID, $userdata, $profiledata);

	if ($bb_cfg['warnings_enabled'] && $is_auth['auth_view_warns'] && !$is_auth['no_warn'])
	{
		$banned = user_banned($profiledata['user_id']);

		$template->assign_block_vars('warnings', ($banned ? array() : reputation_buttons_tpl($profiledata, $is_auth, false, true)) + array(
			'L_WARNINGS' => $lang['Warnings'],
			'WARNINGS' => reputation_warnings($profiledata, $banned, 'text', false),
		));

		if ($profiledata['user_warnings_dem'])
		{
			$template->assign_block_vars('warnings.details', array(
				'U_SEARCH' => append_sid("profile.$phpEx?mode=warnings&amp;" . POST_USERS_URL . '=' . $profiledata['user_id']),
				'L_SEARCH' => sprintf($lang['reputation_search_warnings'], $profiledata['username']),
			));
		}

		if ($profiledata['user_warnings_total'] + $profiledata['user_bans_total'] > $profiledata['user_warnings_dem'])
		{
			$warnings_expired = $profiledata['user_warnings_total'] - $profiledata['user_warnings_dem'] + intval($banned);
			$bans_expired = $profiledata['user_bans_total'] - intval($banned);
			$template->assign_block_vars('warnings.expired', array(
				'L_EXPIRED' => sprintf($lang['reputation_expired_details'], $warnings_expired, $bans_expired),
				'U_SEARCH' => append_sid("profile.$phpEx?mode=expired&amp;" . POST_USERS_URL . '=' . $profiledata['user_id']),
				'L_SEARCH' => sprintf($lang['reputation_search_expired'], $profiledata['username']),
			));
		}
	}
	if ($bb_cfg['reputation_enabled'] && $is_auth['auth_view_rep'] && !$is_auth['no_rep'])
	{
		$template->assign_block_vars('reputation', reputation_buttons_tpl($profiledata, $is_auth, true, false) + array(
			'L_REPUTATION' => $lang['Reputation'],
			'U_VIEW_REPUTATION' => append_sid("profile.$phpEx?mode=reputation&amp;" . POST_USERS_URL . '=' . $profiledata['user_id']),
			'REPUTATION' => reputation_display($profiledata, $bb_cfg['reputation_display'], false),
		));

		if ($bb_cfg['reputation_giving'])
		{
			$template->assign_block_vars('reputation.power', array('L_POWER' => sprintf($lang['reputation_giving_power'], reputation_giving_power($profiledata))));
		}

		if ($bb_cfg['reputation_auto_data'])
		{
			if ($bonuses = reputation_bonuses_tpl($profiledata, true))
			{
				$template->assign_block_vars('reputation.bonuses', array(
					'L_INCLUDING' => $lang['reputation_including']
				));
				foreach ($bonuses as $bonus)
				{
					$template->assign_block_vars('reputation.bonuses.list', $bonus);
				}
			}
		}

		if ($profiledata['user_has_reviews'])
		{
			$template->assign_block_vars('reputation.details', array(
				'U_SEARCH' => append_sid("profile.$phpEx?mode=reputation&amp;" . POST_USERS_URL . '=' . $profiledata['user_id']),
				'L_SEARCH' => sprintf($lang['reputation_search_reputation'], $profiledata['username']),
			));
		}
	}
}
$user_active = $profiledata['user_active'];
if ($banned) $user_active = false;
// Democracy Mod 0.21 adapted [END]

// ReadOnly [START]
$profile_user_id = $profiledata['user_id'];
$profile_readonly = '';
$sql = 'SELECT * FROM '.READONLY_TABLE.' WHERE user_id = '.$profile_user_id.' AND (endtime > '.time().' OR endtime = 0)';
if ( !($result2 = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not obtain readonly information', '', __LINE__, __FILE__, $sql);
}
$rorow = $db->sql_fetchrow($result2);
if ( !empty($rorow['user_id']) )
{
	$langreadonly = $lang['DEL_READONLY'];
	$readonly_sign = true;
	$moderator_id = $rorow['moderator_id'];
	$readonly_sign_moderator = '<a href='. BB_ROOT . 'profile.php?mode=viewprofile&u=' . $moderator_id . '>' . get_username($moderator_id) . '</a>';
}
else
{
	$langreadonly = $lang['ADD_READONLY'];
	$readonly_sign = false;
	$readonly_sign_moderator = '';
}

if ( $userdata['user_level'] == ADMIN )
{
	$profile_readonly = '
		<form action="modcp.php" method=get>
		<input type="hidden" name="mode" value="readonlyprofile" />
		<input type="hidden" name="user" value="'.$profile_user_id.'" />
		<input type="hidden" name="sid" value="'.$userdata['session_id'].'" />
		<input type="hidden" name="all" value="on" />
	'.' | &nbsp;';
	if (!$readonly_sign)
	{
		// $profile_readonly.='<br />';
		$profile_readonly.='<input type="text" name="time" value="1" size=3 />'.$lang['Days'];
	}
	$profile_readonly.='<input class="liteoption" type="submit" name="submit" value=\''.$langreadonly.'\' /></form>';
}
// ReadOnly [END]

// Friends [START]
if($bb_cfg['friends'])
{
    $count = '';
    $friends = '';

    $sql_f = 'SELECT COUNT(friends_id) AS friends FROM bb_friends WHERE user_id = '. $profiledata['user_id'];
    if ( !($result_f = $db->sql_query($sql_f)) )
    {
        message_die(GENERAL_ERROR, 'Could not obtain count friends', '', __LINE__, __FILE__, $sql);
    }
    $count = $db->sql_fetchrow($result_f);
    if($profile_user_id)
    {
        $sql_f2 = 'SELECT * FROM bb_friends WHERE user_id = '. $userdata['user_id'] .' AND friends_id = '. $profiledata['user_id'];
        if ( !($result_f2 = $db->sql_query($sql_f2)) )
        {
            message_die(GENERAL_ERROR, 'Could not obtain count friends', '', __LINE__, __FILE__, $sql);
        }
        $friends = $db->sql_fetchrow($result_f2);
    }
}
// Friends [END]

$this_date = bb_date_v2(TIMENOW, 'md', false);
$user_birthday = (!empty($profiledata['user_birthday']) && $profiledata['user_birthday'] != '1900-01-01') ? date('md', strtotime($profiledata['user_birthday'])) : '';

$template->assign_vars(array(
	'PAGE_TITLE' 	=> sprintf($lang['Viewing_user_profile'], $profiledata['username']),
	'USERNAME' 		=> $profiledata['username'],
	'USER_LEVEL' 	=> $profiledata['user_level'],
	'PROFILE_USER_ID' => $profiledata['user_id'],
    'PROFILE_USER'  => $its_me,
	'USER_REGDATE' 	=> bb_date($profiledata['user_regdate']),
	'POSTER_RANK' 	=> $poster_rank,
	'RANK_IMAGE' 	=> $rank_image,
	'POSTS_PER_DAY' => $posts_per_day,
	'POSTS' 		=> $profiledata['user_posts'],
	'PERCENTAGE' 	=> $percentage . '%',
	'POST_DAY_STATS' => sprintf($lang['User_post_day_stats'], $posts_per_day),
	'POST_PERCENT_STATS' => sprintf($lang['User_post_pct_stats'], $percentage),
	'SEARCH_IMG' => $search_img,
	'SEARCH' 	=> $search,
	'PM_IMG' 	=> $pm_img,
	'PM' 		=> $pm,
	'EMAIL_IMG' => $email_img,
	'EMAIL' 	=> $email,
	'WWW_IMG' 	=> $www_img,

	'GROUPSW'   => $groupsw,
	'L_GROUP'   => $lang['Group_member'],

	'WWW' 		=> $www,
	'ICQ_STATUS_IMG' => $icq_status_img,
	'ICQ_IMG' 	=> $icq_img,
	'ICQ' 		=> $icq,
	'AIM_IMG' 	=> $aim_img,
	'AIM' 		=> $aim,
	'MSN_IMG' 	=> $msn_img,
	'MSN' 		=> $msn,
	'MAGENT_IMG' => $magent_img,
	'MAGENT'    => $magent,
	'YIM_IMG' 	=> $yim_img,
	'YIM' 		=> $yim,
	'LAST_VISIT_TIME' => ($profiledata['user_lastvisit']) ? bb_date($profiledata['user_lastvisit']) : $lang['Never'],
	'LAST_ACTIVITY_TIME' => ($profiledata['user_session_time']) ? bb_date($profiledata['user_session_time']) : $lang['Never'],
	'LOCATION' => $location,

	'UPSP'    => $upsp,
    'DWSP'    => $dwsp,
    'L_UPSP'    => $lang['upsp'],
    'L_DWSP'    => $lang['dwsp'],
    'L_YOUR_SPEED'    => $lang['your_speed'],

	'REG_IP'    => $reg_ip,
	'LAST_IP'   => $last_ip,
	'USER_AGENT'=> $useragent,
	'L_REG_IP'  => $lang['reg_ip'],
	'L_LAST_IP' => $lang['last_ip'],

	'USER_ACTIVE' 	=> $user_active,

	'OCCUPATION' 	=> ( $profiledata['user_occ'] ) ? $profiledata['user_occ'] : '',
	'INTERESTS' 	=> ( $profiledata['user_interests'] ) ? $profiledata['user_interests'] : '',

    // Start add - Gender MOD
    'GENDER' => $gender,
    // End add - Gender MOD

    'BIRTHDAY_ICON' => ($bb_cfg['birthday_enabled'] && $this_date == $user_birthday) ? '<img src="' . $images['icon_birthday'] . '" alt="" title="' . $lang['HAPPY_BIRTHDAY'] . '" border="0" />' : '',
    'BIRTHDAY' => ($bb_cfg['birthday_enabled'] && !empty($profiledata['user_birthday']) && $profiledata['user_birthday'] != '1900-01-01') ? $profiledata['user_birthday'] : '',
    'AGE' => ($bb_cfg['birthday_enabled'] && !empty($profiledata['user_birthday']) && $profiledata['user_birthday'] != '1900-01-01') ? birthday_age($profiledata['user_birthday']) : '',

    'AVATAR_IMG' 	=> $avatar_img,

	'L_VIEWING_PROFILE' => sprintf($lang['Viewing_user_profile'], $profiledata['username']),
	'L_ABOUT_USER' 	=> sprintf($lang['About_user'], $profiledata['username']),
	'L_AVATAR' 		=> $lang['Avatar'],
	'L_POSTER_RANK' => $lang['Poster_rank'],
	'L_TOTAL_POSTS' => $lang['Total_posts'],
	'L_SEARCH_USER_POSTS'  => sprintf($lang['Search_user_posts'], '<b>'. $profiledata['username'] .'</b>'),
	'L_SEARCH_USER_TOPICS' => $lang['Search_user_topics'],
	'L_CONTACT' 	=> $lang['Contact'],
	'L_EMAIL_ADDRESS' => $lang['Email_address'],
	'L_OCCUPATION' 	=> $lang['Occupation'],
	'L_INTERESTS' 	=> $lang['Interests'],

    // Start add - Gender MOD
    'L_GENDER' => $lang['Gender'],
    // End add - Gender MOD

	'U_SEARCH_USER'     => "search.$phpEx?search_author=1&amp;uid={$profiledata['user_id']}",
	'U_SEARCH_TOPICS'   => "search.$phpEx?uid={$profiledata['user_id']}&amp;myt=1",
	'U_SEARCH_RELEASES' => "tracker.$phpEx?rid={$profiledata['user_id']}#results",
	'L_SEARCH_RELEASES' => $lang['Search_user_releases'],

	'S_PROFILE_ACTION'  => "profile.$phpEx",

	'READONLY_SIGN'  => $readonly_sign,
	'READONLY_SIGN_MODERATOR'  => $readonly_sign_moderator,
	'PROFILE_READONLY'  => $profile_readonly,

    'FRIENDS'   => $count['friends'],
    'MY_FRIEND' => $friends,

    'USER_MEDAL_COUNT' => !empty($medal_count_u) ? $medal_count_u : '0',	// Medal MOD
    'USER_MEDAL_COUNT_TOTAL' => !empty($medal_count_u) ? $medal_count_total : '',	// Medal MOD
    'L_USER_MEDAL' => $lang['Medals'],	// Medal MOD
    'L_MEDAL_INFORMATION' => $lang['Medal_Information'], // Medal MOD
    'L_MEDAL_NAME' => $lang['Medal_name'],		// Medal MOD
    'L_MEDAL_DETAIL' => $lang['Medal_details'],	// Medal MOD
));

//bt
// Show users torrent-profile
define('IN_VIEWPROFILE', TRUE);
include(INC_DIR .'ucp/torrent_userprofile.'. $phpEx);
//bt end

$template->assign_vars(array(
	'SHOW_ACCESS_PRIVILEGE' => IS_ADMIN,
	'L_ACCESS'              => $lang['Access'],
	'L_ACCESS_SRV_LOAD'     => $lang['Access_srv_load'],
	'IGNORE_SRV_LOAD'       => ($profiledata['user_level'] != USER || $profiledata['ignore_srv_load']) ? $lang['NO'] : $lang['YES'],
	'IGNORE_SRV_LOAD_EDIT'  => ($profiledata['user_level'] == USER),
));

if (IS_ADMIN)
{
	$template->assign_vars(array(
		'EDITABLE_TPLS' => true,

		'U_MANAGE'      => "admin/admin_users.$phpEx?mode=edit&amp;u={$profiledata['user_id']}",
		'U_PERMISSIONS' => "admin/admin_ug_auth.$phpEx?mode=user&amp;u={$profiledata['user_id']}",

		'L_MANAGE'      => 'Profile',
		'L_PERMISSIONS' => 'Permissions',
	));
}

print_page('usercp_viewprofile.tpl');
