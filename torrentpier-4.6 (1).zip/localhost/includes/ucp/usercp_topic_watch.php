<?php

if (empty($bb_cfg['topic_bookmark_enabled']))
{
	bb_die($lang['Disabled']);
}

$page_cfg['use_tablesorter']   = true;
$page_cfg['include_bbcode_js'] = true;
$tracking_topics = get_tracks('topic');

$user_id = $userdata['user_id'];
$start = isset($_GET['start']) ? abs(intval($_GET['start'])) : 0;
$per_page = $bb_cfg['topics_per_page'];
$url = BB_ROOT .'profile.'. $phpEx .'?mode=watch';

if ( isset($_POST['watch_list']) )
{
    $topic_ids = implode(",", $_POST['watch_list']);
    $sql = "DELETE FROM ". TOPICS_WATCH_TABLE ."
      WHERE topic_id IN(". $topic_ids .")
      AND user_id = $user_id";
    if ( !($result = $db->sql_query($sql)) )
    {
        message_die(GENERAL_ERROR, "Could not delete topic watch information", '', __LINE__, __FILE__, $sql);
    }
}

$template->assign_vars(array(
    'PAGE_TITLE'    => $lang['Watched_topics'],
    'S_FORM_ACTION' => $url,
));

$sql = "SELECT COUNT(*) as watch_count FROM ". TOPICS_WATCH_TABLE ." WHERE user_id = $user_id";
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not obtain watch topic information', '', __LINE__, __FILE__, $sql);
}
$row = $db->sql_fetchrow($result);
$watch_count = ( $row['watch_count'] ) ? $row['watch_count'] : 0;
$db->sql_freeresult($result);

if ($watch_count > 0)
{
    $sql = "SELECT w.*, t.*, f.*, u.*, u2.username as last_username, u2.user_id as last_user_id,
		u2.user_level as last_user_level, u2.user_rank as last_user_rank
	FROM ". TOPICS_WATCH_TABLE ." w, ". TOPICS_TABLE ." t, ". USERS_TABLE ." u, ". FORUMS_TABLE ." f, ". POSTS_TABLE ." p, " . USERS_TABLE . " u2
	WHERE w.topic_id = t.topic_id
		AND t.forum_id = f.forum_id
		AND p.post_id = t.topic_last_post_id
		AND p.poster_id = u2.user_id
		AND t.topic_poster = u.user_id
        AND w.user_id = $user_id
	GROUP BY t.topic_last_post_time DESC
	LIMIT $start, $per_page";
    if ( !($result = $db->sql_query($sql)) )
    {
		message_die(GENERAL_ERROR, 'Could not obtain watch topic information', '', __LINE__, __FILE__, $sql);
    }
    $watch = $db->sql_fetchrowset($result);

    if ($watch)
    {
        for ( $i = 0; $i < count($watch); $i++ )
        {
			$poster_url = append_sid("profile.$phpEx?mode=viewprofile&amp;". POST_USERS_URL .'='. $watch[$i]['user_id']);
			$watch[$i]['username'] = wbr(colornick_level($watch[$i]['username'], $watch[$i]['user_level']));
			$poster_username = '<a class="genmed" href="'. $poster_url .'">'. $watch[$i]['username'] .'</a>';

			$author_url = append_sid("profile.$phpEx?mode=viewprofile&amp;". POST_USERS_URL .'='. $watch[$i]['last_user_id']);
			$watch[$i]['last_username'] = wbr(colornick_level($watch[$i]['last_username'], $watch[$i]['last_user_level']));
			$last_username = '<a class="gensmall" href="'. $author_url .'">'. $watch[$i]['last_username'] .'</a>';

			$forum_url = append_sid("viewforum.$phpEx?f=". $watch[$i]['forum_id']);
			$forum = '<a class="genmed" href="'. $forum_url .'">'. $watch[$i]['forum_name'] .'</a>';
			$last_post_time = create_date($bb_cfg['default_dateformat'], $watch[$i]['topic_last_post_time'], $bb_cfg['board_timezone']);

            $is_unread = is_unread($watch[$i]['topic_last_post_time'], $watch[$i]['topic_id'], $watch[$i]['forum_id']);

			$row_class = ( !($i % 2) ) ? 'row1' : 'row2';

			$template->assign_block_vars('watch', array(
				'ROW_CLASS'         => $row_class,

                'POST_ID'           => $watch[$i]['topic_first_post_id'],

                'TOPIC_ID'          => $watch[$i]['topic_id'],
				'TOPIC_TITLE'       => wbr(str_short($watch[$i]['topic_title'], 70)),
				'FULL_TOPIC_TITLE'  => wbr($watch[$i]['topic_title']),
				'U_TOPIC'           => TOPIC_URL . $watch[$i]['topic_id'],

				'FORUM_TITLE'       => wbr($watch[$i]['forum_name']),
				'U_FORUM'           => FORUM_URL . $watch[$i]['forum_id'],

				'REPLIES'           => $watch[$i]['topic_replies'],

				'AUTHOR'            => $poster_username,
				'LAST_POST'         => $last_post_time .'<br />'. $last_username,
                'LAST_POST_ID'      => $watch[$i]['topic_last_post_id'],

                'IS_UNREAD'         => $is_unread,
			    'TOPIC_ICON'        => get_topic_icon($watch[$i], $is_unread),
			    'PAGINATION'        => ($watch[$i]['topic_status'] == TOPIC_MOVED) ? '' : build_topic_pagination(TOPIC_URL . $watch[$i]['topic_id'], $watch[$i]['topic_replies'], $bb_cfg['posts_per_page']),
			));
        }

        $pagination = generate_pagination($url, $watch_count, $per_page, $start);

        $count_watch = count($watch);
        $matches = ($count_watch == 1) ? sprintf($lang['Found_search_match'], $count_watch) : sprintf($lang['Found_search_matches'], $count_watch);

		$template->assign_vars(array(
		    'MATCHES'     => $matches,
			'PAGINATION'  => $pagination,
			'PAGE_NUMBER' => sprintf($lang['Page_of'], ( floor( $start / $per_page ) + 1 ), ceil( $watch_count / $per_page )),
		    'U_PER_PAGE'  => $url,
		    'PER_PAGE'    => $per_page,
		));
    }
    $db->sql_freeresult($result);
}
else
{
	meta_refresh(BB_ROOT, '3');
    bb_die($lang['No_watched_topics']);
}

print_page('usercp_topic_watch.tpl');