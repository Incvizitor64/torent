<?php

/**
 * -------------------------------
 * Improved captcha for TP
 * by corew
 * Version 1.0
 * -------------------------------
*/

if (!defined('IN_PHPBB')) {
    die('Hacking attempt');
    exit;
}

// Do we have an id? No, then just exit
if (empty($_GET['id']))
{
	exit;
}

$confirm_id = htmlspecialchars($_GET['id']);

if (!preg_match('/^[A-Za-z0-9]+$/', $confirm_id)) {
    $confirm_id = '';
}

// Try and grab code for this id and session
$sql = 'SELECT code  
	FROM ' . CONFIRM_TABLE . " 
	WHERE session_id = '" . $userdata['session_id'] . "' 
		AND confirm_id = '$confirm_id'";
$result = $db->sql_query($sql);

// If we have a row then grab data else create a new id
if ($row = $db->sql_fetchrow($result)) {
    $db->sql_freeresult($result);
    $code = $row['code'];
} else {
    exit;
}
$code = strtolower($code);

/* ------------------------- */
$builder = new \Gregwar\Captcha\CaptchaBuilder($code);
$builder->build();
header('Content-type: image/jpeg');
$builder->output();
/* ------------------------- */

exit;