<?php
/*************************************************************************************
 *                           usercp_reputation.php
 * Part of Democracy MOD by Carbofos < carbofos@mail.ru > and ETZel < etzel@mail.ru >
 *************************************************************************************/

/*************************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *************************************************************************************/

if (!defined('IN_PHPBB'))
{
	die('Hacking attempt');
}

include($phpbb_root_path . 'includes/functions_reputation.' . $phpEx);
include($phpbb_root_path . 'includes/bbcode.' . $phpEx);

// local functions
function reputation_block_title($plus, $plus_amount, $minus, $minus_amount)
{
	global $bb_cfg, $lang, $thumb_up_img, $thumb_dn_img;

	$block_title = '';
	if ($plus)
	{
		$block_title .= ' &nbsp; ' . $thumb_up_img . ' ' . ($bb_cfg['reputation_giving'] ? "$plus (+$plus_amount)" : "+$plus_amount");
	}
	if ($minus)
	{
		$block_title .= ' &nbsp; ' . $thumb_dn_img . ' ' . ($bb_cfg['reputation_giving'] ? "$minus (&ndash;$minus_amount)" : "&ndash;$minus_amount");;
	}
	if ($plus && $minus)
	{
		$block_title .= ' &nbsp; ' . $lang['reputation_total'] . ': ' . ($plus_amount > $minus_amount ? '+' : '') . ($plus_amount - $minus_amount);
	}
	return $block_title;
}

function warnings_block_title($warnings, $bans)
{
	global $warned_img, $banned_img;

	$block_title = '';

	if ($warnings)
	{
		$block_title .= $warned_img . $warnings;
	}
	if ($bans)
	{
		$block_title .= '&nbsp;' . $banned_img . ($bans > 1 ? $bans : '');
	}

	return $block_title;
}
// end local functions

$page_title = $lang['Reputation'];

// Input variables
$post_order = input_var('postorder', $bb_cfg['reputation_default_order'] ? array('desc', 'asc') : array('asc', 'desc'));

if ($review_id = input_var(POST_REVIEWS_URL, 0))
{
	$result = db_query('SELECT * FROM {REPUTATION_TABLE} WHERE id = %d', $review_id);
	if (!$row = $db->sql_fetchrow($result))
	{
		message_die(GENERAL_MESSAGE, $lang['reputation_no_review_spec']);
	}

	$user_id = $row['user_id'];
	$voter_id = $row['voter_id'];
	$post_id = $row['post_id'];

	switch ($row['modification'])
	{
		case REPUTATION_WARNING:
		case REPUTATION_BAN:
			$mode = 'warnings';
			break;
		case REPUTATION_WARNING_EXPIRED:
		case REPUTATION_BAN_EXPIRED:
			$mode = 'expired';
			break;
		default:
			// here we decide between user reputation details page (reputation mode) and post reviews page (reviews mode)
			$mode = input_var('mode', array('reputation', 'given', 'reviews'));
	}
}
elseif ($post_id = input_var(POST_POST_URL, 0))
{
	$mode = 'reviews';
}
else
{
	$mode = input_var('mode', 'reputation', $lang['No_post_mode']);
	$user_id = $voter_id = input_var(POST_USERS_URL, 0, $lang['reputation_no_user_spec']);
}

switch ($mode)
{
	case 'given':
		$reviews_sql = "r.voter_id = $voter_id";
		$view_param = POST_USERS_URL . '=' . $voter_id;
		break;
	case 'reviews':
		$reviews_sql = "r.post_id = $post_id";
		$view_param = POST_POST_URL . '=' . $post_id;
		break;
	default:
		$reviews_sql = "r.user_id = $user_id";
		$view_param = POST_USERS_URL . '=' . $user_id;
}

if ($mode == 'warnings' || $mode == 'expired')
{
	if (!$bb_cfg['warnings_enabled'])
	{
		message_die(GENERAL_MESSAGE, $lang['No_post_mode']);
	}

	$reviews_sql .= ($mode == 'warnings')
		? ' AND (r.modification = {REPUTATION_WARNING} OR r.modification = {REPUTATION_BAN})'
		: ' AND (r.modification = {REPUTATION_WARNING_EXPIRED} OR r.modification = {REPUTATION_BAN_EXPIRED})';

	$auth_view_key = 'auth_view_warns';
	$block_type = 'warn';
}
else
{
	if (!$bb_cfg['reputation_enabled'])
	{
		message_die(GENERAL_MESSAGE, $lang['No_post_mode']);
	}

	$reviews_sql .= $bb_cfg['reputation_positive_only']
		? ' AND r.modification = {REPUTATION_INC}'
		: ' AND (r.modification = {REPUTATION_INC} OR r.modification = {REPUTATION_DEC})';
	$auth_view_key = 'auth_view_rep';
	$block_type = 'rep';
}

if ($review_id)
{
	// calculate on which page review is
	$result = db_query("SELECT COUNT(*) AS cnt
		FROM {REPUTATION_TABLE} r
		WHERE $reviews_sql AND id %s %d", ($post_order == 'asc') ? '<' : '>', $review_id);

	$start = ($row = $db->sql_fetchrow($result)) ? ($row['cnt'] - $row['cnt'] % $bb_cfg['reputation_reviews_per_page']) : 0;
}
else
{
	$start = input_var('start', 0);
}

//
// Count reputation
//
$ban_expired = $warnings_expired = $ban = $warnings = $plus = $minus = $plus_amount = $minus_amount = 0;
$result = db_query("SELECT modification, COUNT(modification) AS cnt, SUM(amount) AS amount FROM {REPUTATION_TABLE} r
		WHERE $reviews_sql
		GROUP BY modification");
while ($row = $db->sql_fetchrow($result))
{
	switch ($row['modification'])
	{
		case REPUTATION_INC: $plus = $row['cnt']; $plus_amount = $row['amount']; break;
		case REPUTATION_DEC: $minus = $row['cnt']; $minus_amount = $row['amount']; break;
		case REPUTATION_WARNING: $warnings = $row['cnt']; break;
		case REPUTATION_WARNING_EXPIRED: $warnings_expired = $row['cnt']; break;
		case REPUTATION_BAN: $ban = $row['cnt']; break;
		case REPUTATION_BAN_EXPIRED: $ban_expired = $row['cnt']; break;
	}
}
$reputation = $plus_amount - $minus_amount;

//
// Load page header
//
include($phpbb_root_path . 'includes/page_header.' . $phpEx);

//
// Set filenames
//
$template->set_filenames(array('body' => 'profile_view_reputation.tpl'));

$template->assign_block_vars($block_type, array());

if ($mode == 'reviews')
{
	// check if post exists
	$result = db_query('SELECT p.*, pt.post_text, pt.post_subject, pt.bbcode_uid, t.topic_last_post_id, u.username, u.user_id, u.user_level, u.user_posts, u.user_from, u.user_website, u.user_email, u.user_icq, u.user_aim, u.user_yim, u.user_regdate, u.user_msnm, u.user_magent, u.user_rank, u.user_sig, u.user_sig_bbcode_uid, u.user_avatar, u.user_avatar_type, u.user_allowavatar, ' . reputation_get_sql('ext', 'u.') . ', u.user_warnings_dem
		FROM {POSTS_TABLE} p, {USERS_TABLE} u, {POSTS_TEXT_TABLE} pt, {TOPICS_TABLE} t
		WHERE p.post_id = %d
			AND pt.post_id = p.post_id
			AND u.user_id = p.poster_id
			AND p.topic_id = t.topic_id', $post_id);
	if (!$postrow = $db->sql_fetchrow($result))
	{
		message_die(GENERAL_MESSAGE, $lang['Topic_post_not_exist']);
	}
	if ($postrow['poster_id'] == ANONYMOUS)
	{
		message_die(GENERAL_MESSAGE, $lang['reputation_anonymous_no_reviews']);
	}
	if (!$plus && !$minus)
	{
		message_die(GENERAL_MESSAGE, $lang['reputation_no_reviews'] . '<br /><br />' . sprintf($lang['reputation_msg_back_to_topic'], "<a href=\"" . append_sid("viewtopic.$phpEx?" . POST_POST_URL . "=$post_id") . "#$post_id\">", "</a>"));
	}
	$num_reviews = $plus + $minus;

	// begin render post

	$is_auth = reputation_auth($postrow['forum_id'], $userdata, $postrow, true); // personalized here
	$forums_auth = array($postrow['forum_id'] => $is_auth);

	if (!$is_auth['auth_view_rep'])
	{
		if (!$userdata['session_logged_in'])
		{
			redirect(append_sid("login.$phpEx?redirect=profile.$phpEx&mode=$mode&postorder=$post_order&start=$start&$view_param", true));
		}
		message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
	}

/*            HH  HH  UU  UU   GGGGF  EEEEEE
 *            HH  HH  UU  UU  GG      EE
 *            HHHHHH  UU  UU  GG GGG  EEEE
 *            HH  HH  UU  UU  GG  GG  EE               ( to display related post )
 */	    // A  HH  HH   UUUU    GGGGG  EEEEEE ( modified ) piece of code from viewtopic.php

	$post_date = create_date($bb_cfg['default_dateformat'], $postrow['post_time'], $bb_cfg['board_timezone']);
	$poster_posts = $lang['POSTS'] . ': ' . $postrow['user_posts'];
	$poster_from = $postrow['user_from'] ? ($lang['LOCATION'] . ': ' . $postrow['user_from']) : '';
	$poster_joined = $lang['JOINED'] . ': ' . create_date($lang['DATE_FORMAT'], $postrow['user_regdate'], $bb_cfg['board_timezone']);

	//
	// Define the little post icon
	//
	if ($userdata['session_logged_in'] && $postrow['post_time'] > $userdata['user_lastvisit']) // TODO: && $postrow['post_time'] > $topic_last_read
	{
		$mini_post_img = $images['icon_minipost_new'];
		$mini_post_alt = $lang['New_post'];
	}
	else
	{
		$mini_post_img = $images['icon_minipost'];
		$mini_post_alt = $lang['Post'];
	}
	$mini_post_url = append_sid("viewtopic.$phpEx?" . POST_POST_URL . '=' . $post_id) . '#' . $post_id;

	// Generate ranks
	list($poster_rank, $rank_image) = user_rank($postrow);

	$edit_img = $edit = $delpost_img = $delpost = $ip_img = $ip = $reportpost_img = $reportpost = $user_sig = $l_edited_by = $user_warnings_dem = $user_reputation = $post_warning = $temp_url = '';

	$reputation_tpl = user_buttons_tpl($postrow, $is_auth['auth_mod']);

	// NOTE: mode implies that reputation is enabled, so we dont check
	$reputation_tpl['POSTER_REPUTATION'] = reputation_display($postrow, $bb_cfg['reputation_display'], true);
	$reputation_tpl += reputation_buttons_tpl($postrow, $is_auth, true, false);

	if ($bb_cfg['warnings_enabled'] && $is_auth['auth_view_warns'])
	{
		$reputation_tpl['POSTER_WARNINGS'] = reputation_warnings($postrow, user_banned($postrow['user_id']), $bb_cfg['reputation_warnings_display'], true);
		$reputation_tpl += reputation_buttons_tpl($postrow, $is_auth, false, true);

		$result = db_query('SELECT r.*, rt.*, u.username, u.user_level FROM {REPUTATION_TABLE} r, {REPUTATION_TEXT_TABLE} rt, {USERS_TABLE} u
			WHERE r.post_id = %d
				AND r.modification IN ({REPUTATION_WARNING}, {REPUTATION_BAN}, {REPUTATION_WARNING_EXPIRED}, {REPUTATION_BAN_EXPIRED})
				AND r.id = rt.id
				AND r.voter_id = u.user_id
				LIMIT 1', $post_id);

		if ($post_warning = $db->sql_fetchrow($result))
		{
			$post_warning = reputation_warning_tpl($post_warning);
		}
	}

	if ($bb_cfg['reports_enabled'] && !$is_auth['auth_mod'] && $userdata['session_logged_in'])
	{
		$temp_url = '';
		$reputation_tpl['REPORTPOST_IMG'] = '';
		$reputation_tpl['REPORTPOST'] = '';
	}

	if (($userdata['user_id'] == $postrow['user_id'] && $is_auth['auth_edit']) || $is_auth['auth_mod'])
	{
		$temp_url = append_sid("posting.$phpEx?mode=editpost&amp;" . POST_POST_URL . "=" . $post_id);
		$edit_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_edit'] . '" alt="' . $lang['Edit_delete_post'] . '" title="' . $lang['Edit_delete_post'] . '" border="0" /></a>';
		$edit = '<a href="' . $temp_url . '" title="' . $lang['Edit_delete_post'] . '">' . $lang['Edit'] . '</a>';
	}

	if (($userdata['user_id'] == $postrow['user_id'] && $is_auth['auth_delete'] && $postrow['topic_last_post_id'] == $post_id) || $is_auth['auth_mod'])
	{
		$temp_url = "posting.$phpEx?mode=delete&amp;" . POST_POST_URL . "=" . $post_id . "&amp;sid=" . $userdata['session_id'];
		$delpost_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_delpost'] . '" alt="' . $lang['Delete_post'] . '" title="' . $lang['Delete_post'] . '" border="0" /></a>';
		$delpost = '<a href="' . $temp_url . '" title="' . $lang['Delete_post'] . '">' . $lang['DELETE'] . '</a>';
	}

	if ($is_auth['auth_mod'])
	{
		$temp_url = "modcp.$phpEx?mode=ip&amp;" . POST_POST_URL . "=" . $post_id . "&amp;" . POST_TOPIC_URL . "=" . $postrow['topic_id'] . "&amp;sid=" . $userdata['session_id'];
		$ip_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_ip'] . '" alt="' . $lang['View_IP'] . '" title="' . $lang['View_IP'] . '" border="0" /></a>';
		$ip = '<a href="' . $temp_url . '" title="' . $lang['View_IP'] . '">IP</a>';
	}

	$message = prepare_display($postrow['post_text'], $postrow['bbcode_uid']);
	$post_subject = censor($postrow['post_subject']);

	if ($postrow['enable_sig'] && $postrow['user_sig'] && $bb_cfg['allow_sig'])
	{
		$user_sig = prepare_display($postrow['user_sig'], $postrow['user_sig_bbcode_uid'], true, true);
		$user_sig = '<br clear="all" />_________________<br />' . $user_sig;
	}

	//
	// Editing information
	//
	if ($postrow['post_edit_count'])
	{
		$l_edit_time_total = ($postrow['post_edit_count'] == 1) ? $lang['Edited_time_total'] : $lang['Edited_times_total'];
		$l_edited_by = '<br /><br />' . sprintf($l_edit_time_total, $postrow['username'], create_date($bb_cfg['default_dateformat'], $postrow['post_edit_time'], $bb_cfg['board_timezone']), $postrow['post_edit_count']);
	}

	$template->assign_block_vars('postrow', $reputation_tpl + array(
		'ROW_COLOR' => '',
		'ROW_CLASS' => '',
		'POSTER_NAME' => $postrow['username'],
		'POSTER_RANK' => $poster_rank,
		'RANK_IMAGE' => $rank_image,
		'POSTER_JOINED' => $poster_joined,
		'POSTER_POSTS' => $poster_posts,
		'POSTER_FROM' => $poster_from,
		'POSTER_AVATAR' => user_avatar($postrow),
		'POST_DATE' => $post_date,
		'POST_SUBJECT' => $post_subject,
		'MESSAGE' => $message,
		'SIGNATURE' => $user_sig,
		'EDITED_MESSAGE' => $l_edited_by,

		'MINI_POST_IMG' => $mini_post_img,
		'EDIT_IMG' => $edit_img,
		'EDIT' => $edit,
		'IP_IMG' => $ip_img,
		'IP' => $ip,
		'DELETE_IMG' => $delpost_img,
		'DELETE' => $delpost,

		'L_POST' => $lang['Post'],
		'L_POST_SUBJECT' => $lang['POST_SUBJECT'],
		'L_MINI_POST_ALT' => $mini_post_alt,

		'U_RETURN_TOPIC' => sprintf($lang['reputation_msg_back_to_topic'], '<a class="nav" href="' . append_sid("viewtopic.$phpEx?" . POST_POST_URL . '=' . $post_id) . '#' . $post_id . '">', '</a>'),
		'U_MINI_POST' => $mini_post_url,
		'U_POST_ID' => $post_id)
	);

	if ($post_warning)
	{
		$template->assign_block_vars('postrow.warning', $post_warning);
	}
	// end render post

	$block_title = $lang['reputation_post_reviews'] . ':' . reputation_block_title($plus, $plus_amount, $minus, $minus_amount);

	$user_profile_img = $user_profile = '';
}
else // $mode != 'reviews'
{
	// check if user exists
	$result = db_query('SELECT user_id, username, user_level, ' . reputation_get_sql('full') . ', user_warnings_dem FROM {USERS_TABLE} WHERE user_id = %d', $user_id);
	if (!($user = $db->sql_fetchrow($result)))
	{
		message_die(GENERAL_ERROR, $lang['reputation_no_user_spec']);
	}

	$forums_auth = reputation_auth(AUTH_LIST_ALL, $userdata);

	if ($mode != 'given')
	{
		// personalize auth for the following check
		$forums_auth[NO_ID] = reputation_auth($forums_auth[NO_ID], $userdata, $user, true);
	}

	if (!$forums_auth[NO_ID][$auth_view_key])
	{
		if (!$userdata['session_logged_in'])
		{
			redirect(append_sid("login.$phpEx?redirect=profile.$phpEx&mode=$mode&postorder=$post_order&start=$start&$view_param", true));
		}
		message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
	}

	$temp_url = append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=$user_id");
	$user_profile_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_profile'] . '" alt="' . $lang['Read_profile'] . '" title="' . $lang['Read_profile'] . '" border="0" /></a>';
	$user_profile = '<a href="' . $temp_url . '">' . $lang['Read_profile'] . '</a>';
	$user_link = '<a href="' . $temp_url . '">' . $user['username'] . '</a>';

	//
	// Block title and number of reviews
	//
	switch ($mode)
	{
		case 'warnings':
			if (!$warnings && !$ban)
			{
				message_die(GENERAL_MESSAGE, $lang['reputation_no_warnings'] . '<br /><br />' . sprintf($lang['reputation_msg_view_profile'], '<a href="' . $temp_url . '">', '</a>'));
			}

			$num_reviews = $warnings + $ban;
			$block_title = sprintf($lang['reputation_warnings_to'], $user_link) . ': &nbsp; ' . warnings_block_title($warnings, $ban);
			break;

		case 'expired':
			if (!$warnings_expired && !$ban_expired)
			{
				message_die(GENERAL_MESSAGE, $lang['reputation_no_warnings'] . '<br /><br />' . sprintf($lang['reputation_msg_view_profile'], '<a href="' . $temp_url . '">', '</a>'));
			}

			$num_reviews = $warnings_expired + $ban_expired;
			$block_title = sprintf($lang['reputation_warnings_expired'], $user_link) . ': &nbsp;' . warnings_block_title($warnings_expired, $ban_expired);
			break;

		case 'reputation':
			if (!$plus && !$minus)
			{
				message_die(GENERAL_MESSAGE, $lang['reputation_no_details'] . '<br /><br />' . sprintf($lang['reputation_msg_view_profile'], '<a href="' . $temp_url . '">', '</a>'));
			}

			$num_reviews = $plus + $minus;
			$block_title = sprintf($lang['reputation_of'], $user_link) . ': ';

			if ($bb_cfg['reputation_auto_data'])
			{
				$block_title .= reputation_display($user, REPUTATION_SUM);

				$details = array();
				if ($plus)
				{
					$details[] = array('TYPE' => $lang['reputation_positive_reviews'], 'TYPE_IMG' => $images['rep_positive'], 'VALUE' => $bb_cfg['reputation_giving'] ? "$plus (+$plus_amount)" : "+$plus_amount");
				}
				if ($minus) // $minus is zero when $bb_cfg['reputation_positive_only']
				{
					$details[] = array('TYPE' => $lang['reputation_negative_reviews'], 'TYPE_IMG' => $images['rep_negative'], 'VALUE' => $bb_cfg['reputation_giving'] ? "$minus (&ndash;$minus_amount)" : "&ndash;$minus_amount");
				}
				$details = array_merge($details, reputation_bonuses_tpl($user, false));

				$wrap = (count($details) > 8) ? 3 : ((count($details) > 4) ? 2 : 1);

				$template->assign_block_vars('rep.details', array(
					'L_INCLUDING' => $lang['reputation_including'],
					'S_ROWSPAN' => $wrap,
				));

				foreach ($details as $i => $bonus)
				{
					$template->assign_block_vars('rep.details.columns', $bonus);

					if ($i % $wrap == ($wrap - 1))
					{
						$template->assign_block_vars('rep.details.columns.wrap', array());
					}
				}
			}
			else
			{
				$block_title .= reputation_block_title($plus, $plus_amount, $minus, $minus_amount);
			}
			break;
	}
}

if ($mode == 'warnings' || $mode == 'expired')
{
	$l_read = $lang['Warning'];
	$l_unread = $lang['New_warning'];

	$auth_edit_key = 'auth_edit_warn';
	$auth_delete_key = 'auth_delete_warn';
}
else
{
	$l_read = $lang['Review'];
	$l_unread = $lang['New_review'];

	$auth_edit_key = 'auth_edit_rep';
	$auth_delete_key = 'auth_delete_rep';
}

$pagination = generate_pagination("profile.$phpEx?mode=$mode&postorder=$post_order&$view_param", $num_reviews, $bb_cfg['reputation_reviews_per_page'], $start);
$select_post_order = html_select('postorder', array('asc', 'desc'), array('Oldest_First', 'Newest_First'), $post_order);

$template->assign_vars(array(
	'L_DISPLAY_POSTS' => $lang['reputation_display'],
	'L_GO' => $lang['GO'],
	'L_BACK_TO_TOP' => $lang['BACK_TO_TOP'],
	'L_REASON' => $lang['reputation_reason'],
	'L_AUTHOR' => $lang['AUTHOR'],
	'L_OFFICIAL' => $lang['Official'],
	'L_WARNING' => $lang['Warning'],
	'L_REVIEW' => $lang['Review'],
	'L_ISSUED' => $lang['reputation_issued'],
	'L_POST_REF' => $lang['reputation_post_ref'],
	'L_EXPIRE' => ($mode == 'warnings') ? $lang['reputation_expire'] : $lang['reputation_expired'],
	'L_POSTED' => $lang['POSTED'],

	'S_REVIEW_OREDR_ACTION' => append_sid("profile.$phpEx?mode=$mode&start=$start&$view_param"),
	'S_SELECT_POST_ORDER' => $select_post_order,

	'U_VIEWPROFILE' => $user_profile,
	'U_VIEWPROFILE_IMG' => $user_profile_img,

	'BLOCK_TITLE' => $block_title,
	'PAGINATION' => $pagination,
));

// display reviews list

$review_images = array(REPUTATION_INC => $thumb_up_img, REPUTATION_DEC => $thumb_dn_img, REPUTATION_WARNING => $warned_img, REPUTATION_WARNING_EXPIRED => $warned_img, REPUTATION_BAN => $banned_img, REPUTATION_BAN_EXPIRED => $banned_img);

$reviews_sql .= ($mode == 'given') ? ' AND r.user_id = u.user_id' : ' AND r.voter_id = u.user_id';
$result = db_query("SELECT r.*, rt.*, u.* FROM {REPUTATION_TABLE} r, {REPUTATION_TEXT_TABLE} rt, {USERS_TABLE} u
		WHERE $reviews_sql
			AND r.id = rt.id
		ORDER BY r.date %s
		LIMIT %d, %d",
		($post_order == 'asc') ? 'ASC' : 'DESC', $start, $bb_cfg['reputation_reviews_per_page'], 0, $bb_cfg['reputation_reviews_per_page']);

$report_button = $bb_cfg['reports_enabled'] && $userdata['session_logged_in'] && ($userdata['user_level'] == USER) && ($mode == 'reputation' || $mode == 'given');
$show_giving = ($mode != 'warnings' && $mode != 'expired' && $bb_cfg['reputation_giving']);

for ($i = true; $row = $db->sql_fetchrow($result); $i = !$i) // $i is a row color ticker
{
	// fly_indiz fix
	if (!isset($forums_auth[$row['forum_id']]))
	{
		$row['forum_id'] = NO_ID;
	}
	// fly_indiz fix
	$is_auth = reputation_auth($forums_auth[$row['forum_id']], $userdata, $row, true);

	//
	// Get images & urls
	//
	if ($row['post_id'] != NO_ID)
	{
		$post_reference = '<a href="' . append_sid("viewtopic.$phpEx?" . POST_POST_URL . '=' . $row['post_id']) . '#' . $row['post_id'] . '"><img src="' . $images['icon_latest_reply'] . '" title="' . $lang['reputation_post_ref'] . '" border="0" /></a>';
	}
	elseif ($row['forum_id'] != NO_ID)
	{
		$post_reference = $lang['reputation_post_deleted'];
	}
	else
	{
		$post_reference = $lang['NO'];
	}

	$expire = $row['expire'] ? create_date($bb_cfg['default_dateformat'], $row['expire'], $bb_cfg['board_timezone']) : $lang['reputation_expire_never'];

	$ip_img = $ip = $delpost_img = $delpost = $edit_img = $edit = $reportpost_img = $reportpost = $l_edited_by = $amount ='';

	if ($is_auth['auth_mod'])
	{
		//$temp_url = "modcp.$phpEx?mode=ip&amp;" . POST_REVIEWS_URL . '=' . $row['id'] . "&amp;sid=" . $userdata['session_id'];
		$temp_url = 'http://www.dnsstuff.com/tools/whois.ch?ip=' . decode_ip($row['poster_ip']);
		$ip_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_ip'] . '" alt="' . $lang['View_IP'] . '" title="' . $lang['View_IP'] . '" border="0" /></a>';
		$ip = '<a href="' . $temp_url . '" title="' . $lang['View_IP'] . '">IP</a>';
	}

	if ($is_auth[$auth_delete_key])
	{
		$temp_url = "reputation.$phpEx?mode=delete&amp;" . POST_REVIEWS_URL . '=' . $row['id'] . '&amp;ret=' . $mode . '&amp;sid=' . $userdata['session_id'];
		$delpost_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_delpost'] . '" alt="' . $lang['reputation_delete_review'] . '" title="' . $lang['reputation_delete_review'] . '" border="0" /></a>';
		$delpost = '<a href="' . $temp_url . '" title="' . $lang['reputation_delete_review'] . '">' . $lang['DELETE'] . '</a>';
	}

	if ($is_auth[$auth_edit_key])
	{
		$temp_url = "reputation.$phpEx?mode=edit&amp;" . POST_REVIEWS_URL . '=' . $row['id'] . '&amp;ret=' . $mode . '&amp;sid=' . $userdata['session_id'];
		$edit_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_edit'] . '" alt="' . $lang['reputation_edit_review'] . '" title="' . $lang['reputation_edit_review'] . '" border="0" /></a>';
		$edit = '<a href="' . $temp_url . '" title="' . $lang['reputation_edit_review'] . '">' . $lang['Edit'] . '</a>';
	}

	if ($report_button)
	{
		$temp_url = '';
		$reportpost_img = '';
		$reportpost = '';
	}

	if ($userdata['session_logged_in'] && $row['date'] > $userdata['user_lastvisit'])
	{
		$mini_post_img = $images['icon_minipost_new'];
		$mini_post_alt = $l_unread;
	}
	else
	{
		$mini_post_img = $images['icon_minipost'];
		$mini_post_alt = $l_read;
	}

	$mini_post_url = append_sid("profile.$phpEx?mode=$mode&amp;" . POST_REVIEWS_URL . '=' . $row['id'] . "&amp;postorder=$post_order");

	list($poster_rank, $poster_rank_image) = user_rank($row);

	//
	// Editing information
	//
	if ($row['edit_count'])
	{
		$l_edit_time_total = ($row['edit_count'] == 1) ? $lang['Edited_time_total'] : $lang['Edited_times_total'];
		$l_edited_by = '<br />' . sprintf($l_edit_time_total, $row['username'], create_date($bb_cfg['default_dateformat'], $row['edit_time'], $bb_cfg['board_timezone']), $row['edit_count']);
	}

	$row_color = '';
	$row_class = '';

	$message = prepare_display($row['text'], $row['bbcode_uid'], true, true);

	if ($show_giving)
	{
		$amount = ($row['modification'] == REPUTATION_INC ? '+' : '&ndash;') . $row['amount'];
	}

	$template->assign_block_vars($block_type . '.rows', user_buttons_tpl($row, $is_auth['auth_mod']) + array(
		'L_MINI_POST_ALT' => $mini_post_alt,

		'U_MINI_POST' => $mini_post_url,
		'U_REVIEW_ID' => $row['id'],

		'COMMENTS' => $message,
		'EDITED_COMMENTS' => $l_edited_by,
		'REVIEWER_NAME' => $row['username'],
		'REVIEW' => $review_images[$row['modification']],
		'AMOUNT' => $amount,
		'EXPIRE' => $expire,
		'ROW_COLOR' => '#' . $row_color,
		'ROW_CLASS' => $row_class,
		'POST_REF' => $post_reference,
		'POST_DATE' => create_date($bb_cfg['default_dateformat'], $row['date'], $bb_cfg['board_timezone']),
		'POSTER_RANK' => $poster_rank,
		'RANK_IMAGE' => $poster_rank_image,
		//'POSTER_AVATAR' => user_avatar($row),

		'REPORTPOST' => $reportpost,
		'REPORTPOST_IMG' => $reportpost_img,
		'EDIT_IMG' => $edit_img,
		'EDIT' => $edit,
		'IP_IMG' => $ip_img,
		'IP' => $ip,
		'DELETE_IMG' => $delpost_img,
		'DELETE' => $delpost,
		'MINI_POST_IMG' => $mini_post_img
	));
}

$template->pparse('body');

include($phpbb_root_path . 'includes/page_footer.' . $phpEx);
