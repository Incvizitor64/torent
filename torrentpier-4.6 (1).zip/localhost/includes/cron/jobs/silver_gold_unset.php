<?php
if (!defined('BB_ROOT')) die(basename(__FILE__));
require(INC_DIR .'functions_torrent.'. PHP_EXT);
$timer_silver_gold_cron = true;
$sql='SELECT attach_id FROM bb_bt_torrents WHERE '.time().' > tor_type_time  AND tor_type_time != -1 AND tor_type IN(1,2)';
if($result=$db->sql_query($sql))
{
	while ($row = $db->sql_fetchrow($result))
	{
	change_tor_type($row['attach_id'], 0);
	}
}
$timer_silver_gold_cron = false;