<?php
/**
 *
 * @author lEx0
 * @version 1.0.2
 * @name Update External Tracker's peer's
 * @package TorrentPier
 *  
 */

if (!defined('BB_ROOT')) die(basename(__FILE__));
include_once INC_DIR . 'functions_multi_tracker.' . PHP_EXT;

$upNeTrAr = $db->fetch_rowset("
	SELECT
		attach_id
	FROM 
		" . BT_TORRENTS_TABLE . "
	WHERE
		multi_tracker_use = 1");

if( $upNeTrAr && count($upNeTrAr) > 0 )
{
	foreach ( $upNeTrAr AS $cAtt)
	{
		multi_tracker_update($cAtt['attach_id']);
	}
}
