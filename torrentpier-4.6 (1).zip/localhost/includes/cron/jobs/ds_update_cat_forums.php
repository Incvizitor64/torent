<?php

if (!defined('BB_ROOT')) die(basename(__FILE__));

$datastore->update('cat_forums');