<?php

if (!defined('BB_ROOT')) die(basename(__FILE__));

// global $page_cfg, $db, $bb_cache, $userdata, $user, $ads, $bb_cfg, $template, $lang, $images, $phpEx;
global $db, $userdata, $bb_cfg;

$logged_in = (int) !empty($userdata['session_logged_in']);
$is_admin  = ($logged_in && IS_ADMIN);
$is_mod    = ($logged_in && IS_MOD);

$current_time = time();

// if ($bb_cfg['reputation_last_check_time'] + $bb_cfg['reputation_check_rate'] * 60 < $current_time)
// {
	if ($bb_cfg['reputation_delete_expired'] != -1)
	{
		$delete_time = $current_time - $bb_cfg['reputation_delete_expired'] * 86400;

		$result = db_query('SELECT id
			FROM {REPUTATION_TABLE}
			WHERE (modification = {REPUTATION_WARNING_EXPIRED} OR modification = {REPUTATION_BAN_EXPIRED})
				AND expire BETWEEN 1 AND %d', $delete_time);

		$in_sql = '';
		while ($row = $db->sql_fetchrow($result))
		{
			$in_sql .= ($in_sql ? ',' : '') . $row['id'];
		}
		if ($in_sql)
		{
			db_query('DELETE FROM {REPUTATION_TABLE}
				WHERE id IN (' . $in_sql . ')');
			db_query('DELETE FROM {REPUTATION_TEXT_TABLE}
				WHERE id IN (' . $in_sql . ')');
		}
	}
	else
	{
		$delete_time = -1;
	}

	$result = db_query('SELECT id, user_id, modification FROM {REPUTATION_TABLE}
			WHERE (modification = {REPUTATION_WARNING} OR modification = {REPUTATION_BAN})
				AND expire BETWEEN 1 AND %d', $current_time);

	while ($row = $db->sql_fetchrow($result))
	{
		if ($delete_time != -1 && $row['expire'] < $delete_time)
		{
			db_query('DELETE FROM {REPUTATION_TABLE} WHERE id = ' . $row['id']);
			db_query('DELETE FROM {REPUTATION_TEXT_TABLE} WHERE id = ' . $row['id']);
		}
		else
		{
			$set = ($row['modification'] == REPUTATION_WARNING) ? REPUTATION_WARNING_EXPIRED : REPUTATION_BAN_EXPIRED;
			db_query('UPDATE {REPUTATION_TABLE} SET modification = %d WHERE id = %d', $set, $row['id']);
		}
		if ($row['modification'] == REPUTATION_BAN)
		{
			db_query('DELETE FROM {BANLIST_TABLE} WHERE ban_userid = %d', $row['user_id']);

			require_once(INC_DIR .'functions_admin.'. PHP_EXT);
			$log_action->admin('adm_user_unban', array(
				'log_msg' => 'user: '. get_usernames_for_log($row['user_id']),
			));
		}
		db_query('UPDATE {USERS_TABLE} SET user_warnings_dem = user_warnings_dem - 1 WHERE user_id = %d', $row['user_id']);
	}

	// db_query('UPDATE {CONFIG_TABLE} SET config_value = %d WHERE config_name = \'reputation_last_check_time\'', $current_time);
// }
