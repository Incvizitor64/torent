<?php
if (!defined('BB_ROOT')) die(basename(__FILE__));
$db->query("UPDATE ".BT_USERS_TABLE."
			SET
				up_yesterday = up_today,
				down_yesterday = down_today,
				release_yesterday = release_today,
				bonus_yesterday = bonus_today,
				speed_up_yesterday = speed_up_today,
				speed_down_yesterday = speed_down_today
		");
// $db->sql_freeresult($result);
$db->query("UPDATE ".BT_USERS_TABLE."
			SET
				up_today = 0,
				down_today = 0,
				release_today = 0,
				bonus_today = 0,
				speed_up_today = 0,
				speed_down_today = 0
		");
// GROUP BY user_id