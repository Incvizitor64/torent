<?php

if (!defined('BB_ROOT')) die(basename(__FILE__));

// Sync
require_once(INC_DIR .'functions_admin.'. PHP_EXT);
sync('topic', 'all');
sync('forum', 'all');
sync('user_posts', 'all');

