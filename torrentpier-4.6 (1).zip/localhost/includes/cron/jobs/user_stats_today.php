<?php

if (!defined('BB_ROOT')) die(basename(__FILE__));
$db->query("UPDATE ".BT_USERS_TABLE." u,
                   ".BT_LAST_USERSTAT_TABLE." lus
            SET
               u.up_last = lus.up_add,
               u.down_last = lus.down_add,
               u.release_last = lus.release_add,
               u.bonus_last =  lus.bonus_add,
               u.speed_up_last = lus.speed_up,
               u.speed_down_last = lus.speed_down,
               u.up_today = u.up_today + lus.up_add,
               u.down_today = u.down_today + lus.down_add,
               u.release_today = u.release_today + lus.release_add,
               u.bonus_today = u.bonus_today + lus.bonus_add,
               u.speed_up_today = u.speed_up_today + lus.speed_up,
               u.speed_down_today = u.speed_down_today + lus.speed_down
            WHERE u.user_id = lus.user_id
       ");