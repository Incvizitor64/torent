<?php

// Parse and show the overall page header

if (!defined('BB_ROOT')) die(basename(__FILE__));
if (defined('PAGE_HEADER_SENT')) return;

global $page_cfg, $db, $bb_cache, $userdata, $user, $ads, $bb_cfg, $template, $lang, $images, $phpEx, $board_config;

$logged_in = (int) !empty($userdata['session_logged_in']);
$is_admin  = ($logged_in && IS_ADMIN);
$is_mod    = ($logged_in && IS_MOD);

// Generate logged in/logged out status
if ($logged_in)
{
	$u_login_logout = BB_ROOT ."login.$phpEx?logout=1";
}
else
{
	$u_login_logout = BB_ROOT ."login.$phpEx";
}

// Online userlist
if (defined('SHOW_ONLINE') && SHOW_ONLINE)
{
	$online_full = !empty($_REQUEST['online_full']);
	$online_list = ($online_full) ? 'online' : 'online_short';

	${$online_list} = array(
		'stat'     => '',
		'userlist' => '',
		'cnt'      => '',
	);

	if (defined('IS_GUEST') && !(IS_GUEST || IS_USER))
	{
		$template->assign_var('SHOW_ONLINE_LIST');

		if (!${$online_list} = $bb_cache->get($online_list))
		{
			require(INC_DIR .'online_userlist.'. PHP_EXT);
		}
	}

	$template->assign_vars(array(
		'TOTAL_USERS_ONLINE'  => ${$online_list}['stat'],
		'LOGGED_IN_USER_LIST' => ${$online_list}['userlist'],
		'USERS_ONLINE_COUNTS' => ${$online_list}['cnt'],
		'RECORD_USERS'        => sprintf($lang['Record_online_users'], $bb_cfg['record_online_users'], bb_date($bb_cfg['record_online_date'])),
		'U_VIEWONLINE'        => "viewonline.$phpEx",
	));
}

// Info about new private messages
$icon_pm = $images['pm_no_new_msg'];
$pm_info = $lang['No_new_pm'];
$have_new_pm = $have_unread_pm = 0;

if ($logged_in && empty($gen_simple_header) && !defined('IN_ADMIN'))
{
	if ($userdata['user_new_privmsg'])
	{
		$have_new_pm = $userdata['user_new_privmsg'];
		$icon_pm = $images['pm_new_msg'];
		$pm_info = declension($userdata['user_new_privmsg'], $lang['New_pms_declension'], $lang['New_pms_format']);

		if ($userdata['user_last_privmsg'] > $userdata['user_lastvisit'] && defined('IN_PM'))
		{
			$userdata['user_last_privmsg'] = $userdata['user_lastvisit'];

			db_update_userdata($userdata, array(
				'user_last_privmsg' => $userdata['user_lastvisit'],
			));

			$have_new_pm = ($userdata['user_new_privmsg'] > 1);
		}
	}
	if (!$have_new_pm && $userdata['user_unread_privmsg'])
	{
		// synch unread pm count
		if (defined('IN_PM'))
		{
			$row = $db->fetch_row("
				SELECT COUNT(*) AS pm_count
				FROM ". PRIVMSGS_TABLE ."
				WHERE privmsgs_to_userid = ". $userdata['user_id'] ."
					AND privmsgs_type = ". PRIVMSGS_UNREAD_MAIL ."
				GROUP BY privmsgs_to_userid
			");

			$real_unread_pm_count = (int) $row['pm_count'];

			if ($userdata['user_unread_privmsg'] != $real_unread_pm_count)
			{
				$userdata['user_unread_privmsg'] = $real_unread_pm_count;

				db_update_userdata($userdata, array(
					'user_unread_privmsg' => $real_unread_pm_count,
				));
			}
		}

		$pm_info = declension($userdata['user_unread_privmsg'], $lang['Unread_pms_declension'], $lang['Unread_pms_format']);
		$have_unread_pm = true;
	}
}
$template->assign_vars(array(
	'HAVE_NEW_PM'    => $have_new_pm,
	'HAVE_UNREAD_PM' => $have_unread_pm,
));

// The following assigns all _common_ variables that may be used at any point in a template
// Report
//
// Report list link
//
if ($bb_cfg['reports_enabled'])
{
	if (empty($gen_simple_header) && ($userdata['user_level'] == ADMIN || (!$bb_cfg['report_list_admin'] && $userdata['user_level'] == MOD)))
	{
		include_once(INC_DIR . "functions_report.". $phpEx);
	
		$report_count = report_count_obtain();
		if ($report_count > 0)
		{
			$template->assign_block_vars('switch_report_list_new', array());
		
			$report_list = $lang['Reports'];
			$report_list .= ($report_count == 1) ? $lang['New_report'] : sprintf($lang['New_reports'], $report_count);
		}
		else
		{
			$template->assign_block_vars('switch_report_list', array());
		
			$report_list = $lang['Reports'] . $lang['No_new_reports'];
		}
	}
	else
	{
		$report_list = '';
	}
	//
	// Get report general module and create report link
	//
	if (empty($gen_simple_header))
	{
		include_once(INC_DIR . "functions_report.$phpEx");
		$report_general = report_modules('name', 'report_general');
	
		if ($report_general && $report_general->auth_check('auth_write'))
		{
			$template->assign_block_vars('switch_report_general', array());
			
			$template->assign_vars(array(
				'U_WRITE_REPORT' => append_sid("report.$phpEx?mode=" . $report_general->mode),
				'L_WRITE_REPORT' => $report_general->lang['Write_report'])
			);
		}
	}
}
else $report_list = '';
// Report [END]

// Avatar in home [Start]
$avatar_img_home = '';
if ($userdata['user_avatar_type'] && $userdata['user_allowavatar']) {
    switch ($userdata['user_avatar_type']) {
        case USER_AVATAR_UPLOAD:
             $avatar_img_home = ($bb_cfg['allow_avatar_upload']) ? $bb_cfg['avatar_path'] . '/' . $userdata['user_avatar'] : '';
             break;
        case USER_AVATAR_REMOTE:
            $avatar_img_home = ($bb_cfg['allow_avatar_remote']) ? $userdata['user_avatar'] : '';
            break;
        case USER_AVATAR_GALLERY:
            $avatar_img_home = ($bb_cfg['allow_avatar_local']) ? $bb_cfg['avatar_gallery_path'] . '/' . $userdata['user_avatar'] : '';
            break;
    }
 }
$template->assign_vars(array('AVATAR_IMG_HOME' => $avatar_img_home));
// Avatar in home [End]

if (defined('IS_GUEST') && !(IS_GUEST || IS_USER))
{
	$template->assign_var('SHOW_GROUP_OPTIONS');
}

if (!isset($userdata['session_id']))
{
	$userdata['session_id'] = '';
}

$template->assign_vars(array(
    'SERVER_PROTOCOL'    => $bb_cfg['cookie_secure'] ? 'https://' : 'http://',
    'SERVER_NAME'        => $bb_cfg['server_name'],
    'SCRIPT_PATH'        => $bb_cfg['script_path'],
    'PHPEX'              => $phpEx,
    'FULL_URL'           => FULL_URL,
    'FORUM_PATH'         => FORUM_PATH,

	'SIMPLE_HEADER'      => !empty($gen_simple_header),
	'IN_ADMIN'           => defined('IN_ADMIN'),
	'QUIRKS_MODE'        => !empty($page_cfg['quirks_mode']),
	'SHOW_ADS'           => (!$logged_in || isset($bb_cfg['show_ads_users'][$user->id]) || (!($is_admin || $is_mod) && $user->show_ads)),

	'INCLUDE_BBCODE_JS'  => !empty($page_cfg['include_bbcode_js']),
	'USER_OPTIONS_JS'    => ($logged_in) ? bb_json_encode($user->opt_js) : '{}',
	
	'USE_TABLESORTER'    => !empty($page_cfg['use_tablesorter']),

	'POST_POST_URL'      => POST_POST_URL,

	'SITENAME'           => $bb_cfg['sitename'],
	'U_INDEX'            => BB_ROOT ."index.$phpEx",
	'T_INDEX'            => sprintf($lang['Forum_Index'], $bb_cfg['sitename']),

	'IS_GUEST'           => IS_GUEST,
	'IS_USER'            => IS_USER,
	'IS_ADMIN'           => IS_ADMIN,
	'IS_MOD'             => IS_MOD,
	'IS_AM'              => IS_AM,

	'LAST_VISIT_DATE'    => ($logged_in) ? sprintf($lang['You_last_visit'], create_date($bb_cfg['last_visit_date_format'], $userdata['user_lastvisit'])) : '',
	'CURRENT_TIME'       => sprintf($lang['Current_time'], create_date($bb_cfg['last_visit_date_format'], TIMENOW)),
	'S_TIMEZONE'         => sprintf($lang['All_times'], $lang[''.str_replace(',', '.', floatval($bb_cfg['board_timezone'])).'']),

	'PM_INFO'            => $pm_info,
	'PRIVMSG_IMG'        => $icon_pm,
	
	// Report
	'REPORT_LIST'        => $report_list,
	'U_REPORT_LIST'      => append_sid("report.$phpEx"),
	// Report [END]

	'LOGGED_IN'          => $logged_in,
	'SESSION_USER_ID'    => $userdata['user_id'],
	'THIS_USERNAME'      => $userdata['username'],
	'SHOW_LOGIN_LINK'    => !defined('IN_LOGIN'),
	'AUTOLOGIN_DISABLED' => !$bb_cfg['allow_autologin'],
	'S_LOGIN_ACTION'     => BB_ROOT . "login.$phpEx",
    'U_CANONICAL'        => BB_ROOT . "login.$phpEx",

	'U_CUR_DOWNLOADS'    => PROFILE_URL . $userdata['user_id'] .'#torrent',
	'U_FAQ'              => $bb_cfg['faq_url'],
	'U_FORUM'            => "viewforum.$phpEx",
	'U_GROUP_CP'         => "groupcp.$phpEx",
	'U_LOGIN_LOGOUT'     => $u_login_logout,
	'U_MEMBERLIST'       => "memberlist.$phpEx",
	'U_MODCP'            => "modcp.$phpEx",
	'U_OPTIONS'          => "profile.$phpEx?mode=editprofile",
	'U_PRIVATEMSGS'      => "privmsg.$phpEx?folder=inbox",
	'U_PROFILE'          => PROFILE_URL . $userdata['user_id'],
	'U_READ_PM'          => "privmsg.$phpEx?folder=inbox". (($userdata['user_newest_pm_id'] && $userdata['user_new_privmsg'] == 1) ? "&mode=read&p={$userdata['user_newest_pm_id']}" : ''),
	'U_REGISTER'         => "profile.$phpEx?mode=register",
	'U_SEARCH'           => "search.$phpEx",
	'U_SEND_PASSWORD'    => "profile.$phpEx?mode=sendpassword",
	'U_TERMS'            => $bb_cfg['terms_and_conditions_url'],
	'U_TRACKER'          => "tracker.$phpEx",

	'U_GALLERY'          => "gallery.$phpEx",
	'SHOW_GALLERY'       => (!empty($bb_cfg['gallery_enabled']) && !empty($bb_cfg['gallery_show_link']) ? true : false),

	'SHOW_ADMIN_OPTIONS' => $is_admin,
	'SHOW_MODER_OPTIONS' => $is_admin || $is_mod,
	'SHOW_SUPERADMIN_OPTIONS' => IS_SUPER_ADMIN,
	'SHOW_SIDEBAR1'      => (!empty($page_cfg['show_sidebar1'][BB_SCRIPT]) || $bb_cfg['show_sidebar1_on_every_page']),
	'SHOW_SIDEBAR2'      => (!empty($page_cfg['show_sidebar2'][BB_SCRIPT]) || $bb_cfg['show_sidebar2_on_every_page']),

	// Common urls
	'CAT_URL'            => BB_ROOT . CAT_URL,
	'DOWNLOAD_URL'       => BB_ROOT . DOWNLOAD_URL,
	'FORUM_URL'          => BB_ROOT . FORUM_URL,
	'GROUP_URL'          => BB_ROOT . GROUP_URL,
	'NEWEST_URL'         => '&amp;view=newest#newest',
	'POST_URL'           => BB_ROOT . POST_URL,
	'PROFILE_URL'        => BB_ROOT . PROFILE_URL,
	'TOPIC_URL'          => BB_ROOT . TOPIC_URL,

	'AJAX_HTML_DIR'      => AJAX_HTML_DIR,
	'AJAX_HANDLER'       => BB_ROOT .'ajax.'. PHP_EXT,

	'ONLY_NEW_POSTS'     => ONLY_NEW_POSTS,
	'ONLY_NEW_TOPICS'    => ONLY_NEW_TOPICS,

	// Misc
	'DEBUG'              => DEBUG,
	'BOT_UID'            => BOT_UID,
	'COOKIE_MARK'        => COOKIE_MARK,
	'SID'                => $userdata['session_id'],
	'SID_HIDDEN'         => '<input type="hidden" name="sid" value="'. $userdata['session_id'] .'" />',

	'CHECKED'            => HTML_CHECKED,
	'DISABLED'           => HTML_DISABLED,
	'READONLY'           => HTML_READONLY,
	'SELECTED'           => HTML_SELECTED,

	'U_SEARCH_SELF_BY_LAST' => "search.$phpEx?uid={$userdata['user_id']}&amp;o=5",
));

if (!empty($page_cfg['dl_links_user_id']))
{
	$dl_link = "search.$phpEx?dlu={$page_cfg['dl_links_user_id']}&amp;";

	$template->assign_vars(array(
		'SHOW_SEARCH_DL'       => true,
		'U_SEARCH_DL_WILL'     => $dl_link .'dlw=1',
		'U_SEARCH_DL_DOWN'     => $dl_link .'dld=1',
		'U_SEARCH_DL_COMPLETE' => $dl_link .'dlc=1',
		'U_SEARCH_DL_CANCEL'   => $dl_link .'dla=1',
	));
}

if (!empty($page_cfg['show_torhelp'][BB_SCRIPT]) && !empty($userdata['torhelp']))
{
	$ignore_time = !empty($_COOKIE['torhelp']) ? (int) $_COOKIE['torhelp'] : 0;

	if (TIMENOW > $ignore_time)
	{
		if ($ignore_time)
		{
			bb_setcookie('torhelp', '', COOKIE_EXPIRED);
		}

		$sql = "
			SELECT topic_id, topic_title
			FROM ". TOPICS_TABLE ."
			WHERE topic_id IN(". $userdata['torhelp'] .")
			LIMIT 8
		";
		$torhelp_topics = array();

		foreach ($db->fetch_rowset($sql) as $row)
		{
			$torhelp_topics[] = '<a href="viewtopic.php?t='. $row['topic_id'] .'">'. $row['topic_title'] .'</a>';
		}

		$template->assign_vars(array(
			'TORHELP_TOPICS'  => join("</li>\n<li>", $torhelp_topics),
		));
	}
}

if (DBG_USER)
{
	$template->assign_vars(array(
		'INCLUDE_DEVELOP_JS' => true,
		'EDITOR_PATH'        => @addslashes($bb_cfg['dbg']['editor_path']),
		'EDITOR_ARGS'        => @addslashes($bb_cfg['dbg']['editor_args']),
	));
}

// Ads
if ($user->show_ads)
{
	$load_ads = array('trans');
	if (defined('BB_SCRIPT'))
	{
		$load_ads[] = BB_SCRIPT;
	}
	foreach ($ads->get($load_ads) as $block_id => $ad_html)
	{
		$template->assign_var("AD_BLOCK_{$block_id}", $ad_html);
	}
}

//Online/Offline
if ($userdata['user_id'] > -1)
{
	$timer = time();
	$sql = "UPDATE " .USERS_TABLE ." SET user_timer = '$timer' WHERE user_id = " . intval($userdata['user_id']);
	if ( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not update users table', '', __LINE__, __FILE__, $sql);
	}
}
//Online/Offline

// Login box
$in_out = ($logged_in) ? 'in' : 'out';
$template->assign_block_vars("switch_user_logged_{$in_out}", array());

// Work around for "current" Apache 2 + PHP module which seems to not
// cope with private cache control setting
if (!empty($_SERVER['SERVER_SOFTWARE']) && strstr($_SERVER['SERVER_SOFTWARE'], 'Apache/2'))
{
	header('Cache-Control: no-cache, pre-check=0, post-check=0');
}
else
{
	header('Cache-Control: private, pre-check=0, post-check=0, max-age=0');
}

// Advanced Meta Tags [START]
$template->assign_vars(array(
    'SITE_DESCRIPTION' => $bb_cfg['site_desc'],
    // Выбор логотипа
    'LOGO_HEADER' => ($board_config['logo_image'] && file_exists(BB_ROOT . $board_config['logo_image_path'] . '/' . $board_config['logo_image'])) ? BB_ROOT . $board_config['logo_image_path'] . '/' . $board_config['logo_image'] : '',
    'LOGO_WIDTH_HEADER' => ($board_config['logo_image_w'] == 0) ? "" : 'width="' . $board_config['logo_image_w'] . '" ',
    'LOGO_HEIGHT_HEADER' => ($board_config['logo_image_h'] == 0) ? "" : 'height="' . $board_config['logo_image_h'] . '" ',
    // Выбор логотипа Конец
));
// Advanced Meta Tags [END]

header('Expires: 0');
header('Pragma: no-cache');

$template->set_filenames(array('page_header' => 'page_header.tpl'));
$template->pparse('page_header');

define('PAGE_HEADER_SENT', true);

if (!$bb_cfg['gzip_compress']) {
    flush();
}
