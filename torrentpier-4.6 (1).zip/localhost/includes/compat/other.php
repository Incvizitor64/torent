<?php

/**
 * Backwards compatibility library for obsolete PHP functions
 *
 * @author     Kitson Consulting <github at kitson minus consulting dot co dot uk>
 * @copyright  2019-2020 Kitson Consulting Limited
 * @license    https://www.apache.org/licenses/LICENSE-2.0
 * @package    php7-compat
 * @see        https://github.com/kitserve/php7-compat
 */

if (!function_exists('ereg_replace')) {
    function ereg_replace($pattern, $replacement, $string)
    {
        return preg_replace('/' . preg_quote($pattern, '/') . '/', $replacement, $string);
    }
}

if (!function_exists('eregi_replace')) {
    function eregi_replace($pattern, $replacement, $string)
    {
        return preg_replace('/' . preg_quote($pattern, '/') . '/i', $replacement, $string);
    }
}

if (!function_exists('ereg')) {
    function ereg($pattern, $string, $regs = null)
    {
        if ($regs) return preg_match('/' . preg_quote($pattern, '/') . '/', $string, $regs);
        else return preg_match('/' . preg_quote($pattern, '/') . '/', $string);
    }
}

if (!function_exists('eregi')) {
    function eregi($pattern, $string, $regs = null)
    {
        if ($regs) return preg_match('/' . preg_quote($pattern, '/') . '/i', $string, $regs);
        else return preg_match('/' . preg_quote($pattern, '/') . '/i', $string);
    }
}

if (!function_exists('split')) {
    function split($pattern, $string, $limit = -1)
    {
        return preg_split('/' . preg_quote($pattern, '/') . '/', $string, $limit);
    }
}

if (!function_exists('spliti')) {
    function spliti($pattern, $string, $limit = -1)
    {
        return preg_split('/' . preg_quote($pattern, '/') . '/i', $string, $limit);
    }
}

if (!function_exists('set_magic_quotes_runtime')) {
    function set_magic_quotes_runtime($new_setting)
    {
        if ($new_setting) return false;
        else return true;
    }
}