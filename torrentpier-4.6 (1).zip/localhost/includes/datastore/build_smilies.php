<?php

if (!defined('BB_ROOT')) die(basename(__FILE__));

global $db, $bb_cfg;

$smilies = array();

$rowset = $db->fetch_rowset("SELECT * FROM ". SMILIES_TABLE);
usort($rowset, 'smiley_sort');

foreach ($rowset as $smile)
{
	$smilies['orig'][] = '#(?<=^|\W)'. preg_quote($smile['code'], '#') .'(?=$|\W)#';
	$smilies['repl'][] = ' <img class="smile" src="'. $bb_cfg['smilies_path'] .'/'. $smile['smile_url'] .'" alt="'. $smile['emoticon'] .'" align="absmiddle" border="0" />';
}

$this->store('smile_replacements', $smilies);
