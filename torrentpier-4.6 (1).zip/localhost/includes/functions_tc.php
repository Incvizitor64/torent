<?php
/***************************************************************************
 *                            functions_tc.php
 *                            -------------------
 *   begin                : Monday, Oct 16, 2006
 *   copyright            : (C) 2006 bbAntiSpam
 *   email                : support@bbantispam.com
 *
 *   $Id: functions_tc.php 1853 2007-02-19 11:01:29Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

//
// Load language resources
//
function tc_load_lang()
{
    global $lang, $board_config, $phpbb_root_path, $phpEx;
    $path_pre = $phpbb_root_path . 'language/lang_';
    $path_post = '/lang_tc.' . $phpEx;
    $bb_lang = $board_config['default_lang'];
    $lang_file = $path_pre . $bb_lang . $path_post;
    if (!file_exists(@phpbb_realpath($lang_file))) {
        $lang_file = $path_pre . 'english' . $path_post;
    }

    include_once($lang_file);
    return true;
}


//
// Get the data from database. Format:
// question => array(id of the question, "\n"-separated answers)
//
function tc_load_raw_data()
{
    global $db;
    $db_data = array();
    $sql = 'SELECT * FROM ' . TEXTUAL_CONFIRMATION_TABLE;
    if (!($result = $db->sql_query($sql))) {
        // Most likely, the error is due to the missed table:
        // The MOD files are installed, but the database isn't updated.
        // Therefore, don't raise an error. Instead, deactivate the MOD.
        // message_die(GENERAL_ERROR, "Could not get questions!", "", __LINE__, __FILE__, $sql);
        return array();
    }
    $rowset = $db->sql_fetchrowset($result);
    if (!$rowset) {
        return array();
    }
    foreach ($rowset as $row) {
        $db_data[$row['question']] = array('id' => $row['id'], 'a' => $row['answers']);
    }
    return $db_data;
}

//
// Validate the answer
//
function tc_hook_register()
{
    global $db, $mode, $HTTP_POST_VARS;
    //
    // Any action only when registering
    //
    if ('register' != $mode) {
        return false;
    }
    //
    // Load the questions from the database.
    // If none, the MOD is disabled
    //
    $db_data = tc_load_raw_data();
    if (!count($db_data)) {
        return false;
    }
    //
    // Check if an answer is given
    //
    if (!array_key_exists('tc_question_id', ($HTTP_POST_VARS))) {
        return tc_bad_answer();
    }
    if (!array_key_exists('tc_answer', ($HTTP_POST_VARS))) {
        return tc_bad_answer();
    }
    $question_id = intval($HTTP_POST_VARS['tc_question_id']);
    $answer = trim(stripslashes($HTTP_POST_VARS['tc_answer']));
    //
    // Find the question/answers pair.
    // If the pair isn't found, it's the error.
    // If the question has no answers, then any answer is ok.
    //
    foreach ($db_data as $q => $a) {
        if ($a['id'] == $question_id) {
            $answers = $a['a'];
            break;
        }
    }
    if (!isset($answers)) {
        return tc_bad_answer();
    }
    $answers = trim($answers);
    if (empty($answers)) {
        return false;
    }
    //
    // Check if the answer is correct
    //
    $as = preg_split("/\n/", $answers, -1, PREG_SPLIT_NO_EMPTY);
    foreach ($as as $a) {
        $a = trim($a);
        if (strtolower($a) == strtolower($answer)) {
            return true;
        }
    }
    tc_bad_answer();
}

//
// Send mail if the answer is incorrect
//
function tc_send_main()
{
    global $lang, $email, $username, $website, $board_config, $HTTP_SERVER_VARS;
    //
    // Collect: user name, e-mail domain name, website, HTTP data
    //
    $domain = strstr($email, '@');
    if (!$domain) {
        $domain = $email;
    }
    $server = '';
    foreach (array('REMOTE_ADDR', 'HTTP_USER_AGENT', 'HTTP_VIA', 'HTTP_X_FORWARDED_FOR') as $k) {
        if (isset($HTTP_SERVER_VARS[$k])) {
            $server .= "\n" . $k . '=' . $HTTP_SERVER_VARS[$k];
        }
    }
    //
    // Send the message
    //
    include(INC_DIR . 'emailer.php');
    $emailer = new emailer($board_config['smtp_delivery']);
    $emailer->from($board_config['board_email']);
    $emailer->replyto($board_config['board_email']);
    $emailer->use_template('textual_confirmation', stripslashes($board_config['default_lang']));
    $emailer->email_address($board_config['board_email']);
    $emailer->set_subject($lang['tc_mail_subject']);
    $emailer->extra_headers('X-bbAniSpam-spam: Yes');
    $emailer->assign_vars(array(
        'NAME' => $username,
        'SUBJECT' => $lang['tc_mail_subject'],
        'DOMAIN' => $domain,
        'WEBSITE' => $website,
        'EMAIL_SIG' => (!empty($board_config['board_email_sig'])) ? str_replace('<br />', "\n", "-- \n" . $board_config['board_email_sig']) : '',
        'SERVER' => $server
    ));
    $emailer->send();
    $emailer->reset();

    return true;
}

//
// The answer is incorrect
//
function tc_bad_answer()
{
    global $error, $error_msg, $lang;
    //
    // Set the error flag and the error message
    //
    tc_load_lang();
    $error = TRUE;
    $s = $lang['tc_bad_answer'];
    if (isset($error_msg) && (!empty($error_msg))) {
        $error_msg = $error_msg . '<br />' . $s;
    } else {
        $error_msg = $s;
    }

    // Send mail call
    tc_send_main();

    return $error_msg;
}

//
// Called before generating an HTML registration form.
// Randomly select a question and assign the form values.
//
function tc_hook_template($mode, &$template, &$s_hidden_fields, &$tc_question)
{
    //
    // Any action only when registering
    //
    if ('register' != $mode) {
        return false;
    }
    //
    // Get the questions. If none, disable textual confirmation.
    //
    $db_data = tc_load_raw_data();
    if (!count($db_data)) {
        return false;
    }
    //
    // Select a question, assign template variables
    //
    tc_load_lang();
    srand(time());
    $tc_question = array_rand($db_data);
    $s_hidden_fields .= sprintf('<input type="hidden" name="tc_question_id" value="%d" />', $db_data[$tc_question]['id']);
    $template->assign_block_vars('switch_textual_confirm', array());

    return true;
}
