<?php

if (!defined('BB_ROOT')) die(basename(__FILE__));

global $bb_cfg, $lang, $userdata, $gen_simple_header, $template, $db, $phpEx;
global $datastore, $bb_cache, $session_cache;

$logged_in = !empty($userdata['session_logged_in']);

$start_date = create_date($bb_cfg['default_dateformat'], $bb_cfg['board_startdate'], $bb_cfg['board_timezone']);

if (!empty($template))
{
	$template->assign_vars(array(
		'SIMPLE_FOOTER'    => !empty($gen_simple_header),

		'TRANSLATION_INFO' => isset($lang['TRANSLATION_INFO']) ? $lang['TRANSLATION_INFO'] : '',
		'SHOW_ADMIN_LINK'  => (IS_ADMIN && !defined('IN_ADMIN')),
		'ADMIN_LINK_HREF'  => "admin/index.$phpEx",
		'L_GOTO_ADMINCP'   => $lang['Admin_panel'],

        "SITE_WORKS_TIME" => $start_date,

		'TORRENTPIER_POWERED' => BB_ROOT . 'images/torrentpier.png',
        'RSS_LOGO'            => BB_ROOT . 'images/rss2.png',

		'U_SELF_LOGS'      => "mod_log.$phpEx?sid={$userdata['session_id']}&amp;u={$userdata['user_id']}&amp;db=900",
		'U_LOGS'           => "mod_log.$phpEx?sid={$userdata['session_id']}&amp;db=900",
        'U_MODER_PANEL'    => "mod.$phpEx",
	));

	$template->set_filenames(array('page_footer' => 'page_footer.tpl'));
	$template->pparse('page_footer');
}

if (DBG_USER && IS_ADMIN) {
	$show_dbg_info = true;
} else {
	$show_dbg_info = false;
}


if (!$bb_cfg['gzip_compress']) {
    flush();
}

if ($show_dbg_info)
{
	$gen_time = utime() - TIMESTART;
	$gen_time_txt = sprintf('%.3f', $gen_time);
	$gzip_text = (UA_GZIP_SUPPORTED) ? 'GZIP ' : '<s>GZIP</s>';
	$gzip_text .= ($bb_cfg['gzip_compress']) ? $lang['Icon_online_txtb'] : $lang['Icon_offline_txtb'];
	$debug_text = (DEBUG) ? $lang['Debug_on'] : $lang['Debug_off'];

	$stat = '[&nbsp; ';
	$stat .= $lang['Execution_time'] . $gen_time_txt . $lang['Sec'];

	if (!empty($db))
	{
		$sql_time = ($db->sql_timetotal) ? sprintf('%.3f' . $lang['Sec'] . '(%d%%)' . $lang['In'], $db->sql_timetotal, round($db->sql_timetotal*100/$gen_time)) : '';
		$stat .= '&nbsp;|&nbsp; MySQL: ' . $sql_time .$db->num_queries . $lang['Queries'];
	}

	$stat .= "&nbsp;|&nbsp; $gzip_text";

	if (MEM_USAGE)
	{
		$stat .= ' &nbsp;|&nbsp;' . $lang['Memory'];
		$stat .= humn_size($bb_cfg['mem_on_start'], 2) .' / ';
		$stat .= humn_size(memory_get_peak_usage(), 2) .' / ';
		$stat .= humn_size(memory_get_usage(), 2);
	}

	if (LOADAVG AND $l = explode(' ', LOADAVG))
	{
		for ($i=0; $i < 3; $i++)
		{
			$l[$i] = round($l[$i], 1);
			$l[$i] = (IS_ADMIN && $bb_cfg['max_srv_load'] && $l[$i] > ($bb_cfg['max_srv_load'] + 4)) ? "<span style='color: red'><b>$l[$i]</b></span>" : $l[$i];
		}
		$stat .= ' &nbsp;|&nbsp;' . $lang['Load'] . "$l[0] $l[1] $l[2]";
	}

	$stat .= ' &nbsp;]';

    $stat .= " [$debug_text]";

    if (SQL_DEBUG && $userdata['user_dbg'] == 2) {
        $stat .= '
            <label><input type="checkbox" onclick="setCookie(\'compact_sql_log\', 0); setCookie(\'sql_log\', this.checked ? 1 : 0); window.location.reload();" ' . ((!empty($_COOKIE['sql_log']) && empty($_COOKIE['compact_sql_log'])) ? HTML_CHECKED : '') . ' />' . $lang['show_log'] . ' </label>
		    <label><input type="checkbox" onclick="setCookie(\'sql_log\', this.checked ? 1 : 0); setCookie(\'compact_sql_log\', this.checked ? 1 : 0); window.location.reload();" ' . ((!empty($_COOKIE['compact_sql_log']) && !empty($_COOKIE['sql_log'])) ? HTML_CHECKED : '') . ' />' . $lang['show_log_compact'] . ' </label>
	    ';
        $stat .= (!empty($_COOKIE['compact_sql_log']) && !empty($_COOKIE['sql_log'])) ? '[ <a href="#" class="med" onclick="$p(\'sqlLog\').className=\'sqlLog sqlLogWrapped\'; return false;">' . $lang['wrap_log'] . '</a> &middot; <a href="#sqlLog" class="med" onclick="$(\'#sqlLog\').css({ height: $(window).height()-50 }); return false;">' . $lang['max_log'] . '</a> ]' : '';

        $sql_log = (!empty($_COOKIE['sql_log']) && empty($_COOKIE['compact_sql_log'])) ? true : false;
    }

    echo '<div style="margin: 6px; font-size:10px; color: #444444; letter-spacing: -1px; text-align: center;">' . $stat . '</div>';
}

echo '
	</div><!--/body_container-->
';

if (IS_ADMIN && DBG_USER && SQL_DEBUG && $userdata['user_dbg'] > 0)
{
    require(INC_DIR . 'page_footer_dev.'. PHP_EXT);

    if ($userdata['user_dbg'] == 2 && $sql_log)
    {
        foreach($db->queries as $key => $q)
        {
            prn_r($q['query'], $key+1 .' - '. $q['time']);
        }
    }
}

##### LOG #####
global $log_ip_resp;

if (isset($log_ip_resp[USER_IP]) || isset($log_ip_resp[CLIENT_IP]))
{
    $contents = null;
	$str = date('H:i:s') . LOG_SEPR . preg_replace("#\s+#", ' ', $contents) . LOG_LF;
	$file = 'sessions/'. date('m-d') .'_{'. USER_IP .'}_'. CLIENT_IP .'_resp';
	bb_log($str, $file);
}
### LOG END ###

if (!empty($GLOBALS['timer_markers']) && DBG_USER)
{
	$GLOBALS['timer']->display();
}

echo '
	</body>
	</html>
';

if (defined('REQUESTED_PAGE') && !defined('DISABLE_CACHING_OUTPUT'))
{
	if (IS_GUEST === true)
	{
		caching_output(true, 'store', REQUESTED_PAGE .'_guest');
	}
}

bb_exit();
