<?php
function get_user_thanks ($uid)
{
	if (!$uid)
	{
		$count2 ='0';
		return $count2;
	}
	$query2 = "SELECT SUM(thanked) AS thanked FROM " . ATTACHMENTS_RATING_TABLE . " WHERE user_id=$uid" ;
	$result2 = mysql_query($query2) or die(mysql_error());
	$row2 = mysql_fetch_assoc($result2);
	$count2 = $row2['thanked'];
	if ($count2 == 0)
	{
		$count2 = '0';
	}
	return $count2;
}
function get_user_thanked ($uid)
{
	if (!$uid)
	{
		$count3 ='0';
		return $count3;
	}
	$query = "SELECT SUM(r.thanked) AS thanked FROM (
	" . ATTACHMENTS_RATING_TABLE . " r
    LEFT JOIN " . ATTACHMENTS_TABLE . " a ON ( a.attach_id=r.attach_id) )
    WHERE a.user_id_1=$uid";
	$result3 = mysql_query($query) or die(mysql_error());
	$row3 = mysql_fetch_assoc($result3);
	$count3 = $row3['thanked'];
	if ($count3 == 0)
	{
		$count3 = '0';
	}
	return $count3;
}
