<?php

if (!defined('IN_PHPBB')) die(basename(__FILE__));

$selects = array(
	'SEL_VIDEO_QUALITY' => array(
        'DVDRip',
        'HDRip',
		'BDRip',
		'WEB-DLRip',
		'HDTVRip',
        'HDTV',
        'WEBRip',
        'DVDRip-AVC',
        'HDRip-AVC',
        'BDRip-AVC',
        'WEB-DLRip-AVC',
        'HDTVRip-AVC',
        'WEBRip-AVC',
        'SATRip',
        'DVB',
		'DVDRemux',
        'TVRip',
        'VHSRip',
        'CAMRip',
        'VHSRip -> DVD',
        'TVRip -> DVD',
        'HDDVDRip',
        'DVD9',
        'DVD5',
        "DVD5 {$lang['tpl']['compressed']}",
        'DTheaterRip',
		'DVDScreener',
        'Telecine',
        'Telesync',
	),

	'SEL_VIDEO_CODECS' => array(
		'DivX',
		'XviD',
		'Angelpotion',
		'Sorenson',
        'Theora',
        'MT',
        'VCRx',
        'WINNOV',
        'X263',
        'VP3',
		'VP4',
        'VP5',
        'VP6',
        'ASV1',
        'WIN TV',
		'M-JPEG',
		'PICVideo Motion JPEG',
        'iview321',
        'Intel Indeo i263',
        'Intel Indeo IR21',
        'nAVI',
		'Intel Indeo IR3',
        'IV4',
        'IV5',
        'Cinepak',
		"{$lang['bt_other']} MPEG4",
		'VPx',
		'MPEG1',
		'MPEG2',
		'Windows Media',
		'QuickTime',
		'H.26x',
		'Flash Video',
	),

	'SEL_VIDEO_FORMATS' => array(
		'AVI',
		'DVD Video',
		'OGM',
		'MKV',
		'WMV',
		'MPG',
        'MP4',
        'TS',
	),

	'SEL_AUDIO_CODECS' => array(
		'AC3',
		'ALAC (image + .cue)',
		'ALAC (tracks)',
		'APE (image + .cue)',
		'APE (tracks)',
        'AAC',
		'DTS',
		'DVD-Audio',
		'FLAC (image + .cue)',
		'FLAC (tracks)',
		'M4A (image + .cue)',
		'M4A (tracks)',
        'MP1/MP2',
		'MP3',
		'MPEG Audio',
		'OGG Vorbis',
		'SHN (image + .cue)',
		'SHN (tracks)',
		'TTA (image + .cue)',
		'TTA (tracks)',
		'WAVPack (image + .cue)',
		'WAVPack (tracks)',
		'Windows Media',
        'EAC3',
        'LPCM',
        'Vorbis',
        'TrueHD',
        'True Audio',
	),

	'SEL_BITRATE' => array(
		'lossless',
		'64 kbps',
		'128 kbps',
		'160 kbps',
		'192 kbps',
		'224 kbps',
		'256 kbps',
		'320 kbps',
		'VBR 128-192 kbps',
		'VBR 192-320 kbps',
	),

	'SEL_TEXT_FORMATS' => array(
		$lang['tpl']['simple_text'],
		'PDF',
		'DjVu',
		'CHM',
		'HTML',
		'DOC',
	),

	'SEL_TEXT_QUALITY' => array(
		$lang['tpl']['scanned'],
		$lang['tpl']['native'],
		$lang['tpl']['ocr_w_o_errors'],
		$lang['tpl']['ocr_w_errors'],
	),

	'SEL_SOURCE_TYPE' => $lang['tpl']['source_type_options'],

	'SEL_LOCALIZATION' => array(
		$lang['tpl']['not_needed'],
		$lang['tpl']['included'],
		$lang['tpl']['not_included'],
	),

	'SEL_LANG' => $lang['tpl']['lang_options'],

	'SEL_UI_LANG' => $lang['tpl']['ui_lang_options'],

	'SEL_UI_LANG_PS' => $lang['tpl']['ui_lang_options_ps'],

	'SEL_AUDIOBOOK_TYPE' => $lang['tpl']['audiobook_type_options'],

	'SEL_MEDICINE' => array(
        $lang['tpl']['cracked'],
		$lang['tpl']['not_needed'],
		$lang['tpl']['included'],
		$lang['tpl']['not_included'],
	),

	'SEL_WINDOWS_COMPATIBLE' => array(
	    'Windows 95',
	    'Windows 98',
        'Windows 95/98',
        'Windows ME',
        'Windows 2000',
        'Windows 2000/ME',
        'Windows 95/98/ME/2000',
        'Windows XP x32',
        'Windows XP x64',
        'Windows XP/2000',
        'Windows Longhorn (XP)',
        'Windows Longhorn (Vista)',
	    'Windows Vista',
        'Windows 7',
        'Windows 7/Vista',
        'windows 8/8.1',
        'Windows 10',
        'Windows 11',
        'Windows 8/8.1/10/11',
        'Windows XP-7',
        'Windows 7-11',
    ),
    'SEL_WINDOWS_BITS' => array(
        '32-Bit',
        '64-Bit',
        '32/64-Bit',
    ),

    'SEL_LINUX_COMPATIBLE' => array(
        /* TODO */
    ),
    'SEL_MACOS_COMPATIBLE' => array(
        /* TODO */
    ),

	'SEL_TRANSLATION' => $lang['tpl']['translation_options'],

	'SEL_TRANSLATION_TYPE' => $lang['tpl']['translation_types'],

	'SEL_PLATFORM_PS' => array('PS1', 'PS2', 'PS3', 'PS4', 'PS5'),
    'SEL_PLATFORM_XBOX' => array('Xbox Original', 'Xbox360', 'Xbox Series X', 'Xbox Series S'),

	'SEL_MULTIPLAYER' => $lang['tpl']['multiplayer_options'],

	'SEL_REGION' => array('PAL', 'NTSC', 'NTSC-U', 'NTSC-J', 'SECAM', 'PAL/NTSC', 'PAL/NTSC-J', 'Region Free'),
);

foreach ($selects as $tpl_name => $sel_ary)
{
	$template->assign_vars(array(
		$tpl_name => join("','", replace_quote($sel_ary))
	));
}

