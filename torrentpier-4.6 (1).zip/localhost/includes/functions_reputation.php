<?php
/*************************************************************************************
 *                           functions_reputation.php
 * Part of Democracy MOD by Carbofos < carbofos@mail.ru > and ETZel < etzel@mail.ru >
 *************************************************************************************/

/*************************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *************************************************************************************/

if (!defined('BB_ROOT')) die(basename(__FILE__));

/**
 * Get required input var and (optionally) die if it isn't present.
 * Return value is addslash'ed automatically for compatibility with phpBB code.
 * @param string $required_msg Message (or $lang key) to die with when the variable is not set
 * @return mixed Request variable cast to the same type as the $default param
 */
function input_var($name, $default, $required_msg = null)
{
	if (isset($_POST[$name]))
	{
		$var = $_POST[$name];
	}
	elseif (isset($_GET[$name]))
	{
		$var = $_GET[$name];
	}
	elseif ($required_msg)
	{
		message_die(GENERAL_ERROR, $required_msg);
	}
	else
	{
		return addslashes(is_array($default) ? $default[0] : $default);
	}

	if (is_array($default))
	{
		settype($var, gettype($default[0]));

		if (in_array($var, $default))
		{
			return $var;
		}
		return $default[0];
	}
	return settype($var, gettype($default)) ? $var : $default; // QUESTION: settype never fails?
}

/**
 * Replace censored words
 * @param boolean $html Must be set to true for messages containing html
 * @return string Censored message
 */
function censor($message, $html = false)
{
	static $orig_word, $replacement_word;

	if (!isset($orig_word))
	{
		// avoid calling obtain_word_list twice
		if (isset($GLOBALS['orig_word']) && isset($GLOBALS['replacement_word']))
		{
			$orig_word = $GLOBALS['orig_word'];
			$replacement_word = $GLOBALS['replacement_word'];
		}
		else
		{
			obtain_word_list($orig_word, $replacement_word);
		}
	}
	if ($orig_word)
	{
		return $html ? str_replace('\"', '"', substr(@preg_replace('#(\>(((?>([^><]+|(?R)))*)\<))#se', "@preg_replace(\$orig_word, \$replacement_word, '\\0')", '>' . $message . '<'), 1, -1)) : preg_replace($orig_word, $replacement_word, $message);
	}
	return $message;
}

/**
 * Prepare message/signature for display: substitute bbcode, smilies, urls if enabled.
 * @return string Message containing HTML and ready for display
 */
function prepare_display($message, $bbcode_uid = '', $enable_html = false, $enable_smilies = true, $enable_links = true)
{
	global $bb_cfg;

	// If the board has HTML off but the post has HTML on then we process it, else leave it alone
	// if (!$bb_cfg['allow_html'] && $enable_html)
	// {
		$message = preg_replace('#(<)([\/]?.*?)(>)#is', "&lt;\\2&gt;", $message);
	// }

	// Parse message and/or sig for BBCode if reqd
	if ($bbcode_uid)
	{
		if ($bb_cfg['allow_bbcode'])
		{
			$message = bbencode_second_pass($message, $bbcode_uid);
		}
		else
		{
			$message = preg_replace('/\:[0-9a-z\:]+\]/si', ']', $message);
		}
	}

	// Make URLs clickable
	if ($enable_links)
	{
		$message = make_clickable($message);
	}

	// Parse smilies
	if ($bb_cfg['allow_smilies'] && $enable_smilies)
	{
		$message = smilies_pass($message);
	}

	// Replace naughty words
	$message = censor($message, true);

	return nl2br($message);
}

/**
 * Generates template variables for user information buttons seen around post or review (www/email/profile/etc).
 * @param array $userdata Row from the users table
 * @param boolean $is_mod Generate buttons as they are viewed by moderator (affects emails display)
 * @return array Array of template variables wich can be readily feed to $template->assign_vars()
 */
function user_buttons_tpl($userdata, $is_mod = false)
{
	global $lang, $phpEx, $images, $bb_cfg;
	static $cache = array();

	$poster_id = isset($userdata['voter_id']) ? $userdata['voter_id'] : $userdata['poster_id']; // posts have poster_id and reviews have voter_id

	if (isset($cache[$poster_id]))
	{
		return $cache[$poster_id];
	}

	$email_img = $email = $icq_status_img = $icq_img = $icq = '';

	$temp_url = append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . '=' . $poster_id);
	$profile_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_profile'] . '" alt="' . $lang['Read_profile'] . '" title="' . $lang['Read_profile'] . '" border="0" /></a>';
	$profile = '<a href="' . $temp_url . '" title="' . $lang['Read_profile'] . '">' . $lang['PROFILE'] . '</a>';

	$temp_url = append_sid("privmsg.$phpEx?mode=post&amp;" . POST_USERS_URL . '=' . $poster_id);
	$pm_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_pm'] . '" alt="' . $lang['Send_private_message'] . '" title="' . $lang['Send_private_message'] . '" border="0" /></a>';
	$pm = '<a href="' . $temp_url . '" title="' . $lang['Send_private_message'] . '">' . $lang['PRIVATE_MESSAGE'] . '</a>';

	if (!empty($userdata['user_viewemail']) || $is_mod)
	{
		$email_uri = $bb_cfg['board_email_form'] ? append_sid("profile.$phpEx?mode=email&amp;" . POST_USERS_URL .'=' . $poster_id) : 'mailto:' . $userdata['user_email'];

		$email_img = '<a href="' . $email_uri . '"><img src="' . $images['icon_email'] . '" alt="' . $lang['Send_email'] . '" title="' . $lang['Send_email'] . '" border="0" /></a>';
		$email = '<a href="' . $email_uri . '" title="' . $lang['Send_email'] . '">' . $lang['EMAIL'] . '</a>';
	}

	$www_img = $userdata['user_website'] ? '<a href="' . $userdata['user_website'] . '" target="_userwww"><img src="' . $images['icon_www'] . '" alt="' . $lang['Visit_website'] . '" title="' . $lang['Visit_website'] . '" border="0" /></a>' : '';
	$www = $userdata['user_website'] ? '<a href="' . $userdata['user_website'] . '" target="_userwww" title="' . $lang['Visit_website'] . '">WWW</a>' : '';

	if (!empty($userdata['user_icq']))
	{
		$icq_status_img = '<a href="http://wwp.icq.com/' . $userdata['user_icq'] . '#pager"><img src="http://web.icq.com/whitepages/online?icq=' . $userdata['user_icq'] . '&img=5" width="18" height="18" border="0" /></a>';
		$icq_img = '<a href="http://wwp.icq.com/scripts/search.dll?to=' . $userdata['user_icq'] . '"><img src="' . $images['icon_icq'] . '" alt="' . $lang['ICQ'] . '" title="' . $lang['ICQ'] . '" border="0" /></a>';
		$icq = '<a href="http://wwp.icq.com/scripts/search.dll?to=' . $userdata['user_icq'] . '">ICQ</a>';
	}

	$aim_img = $userdata['user_aim'] ? '<a href="aim:goim?screenname=' . $userdata['user_aim'] . '&amp;message=Hello+Are+you+there?"><img src="' . $images['icon_aim'] . '" alt="' . $lang['AIM'] . '" title="' . $lang['AIM'] . '" border="0" /></a>' : '';
	$aim = $userdata['user_aim'] ? '<a href="aim:goim?screenname=' . $userdata['user_aim'] . '&amp;message=Hello+Are+you+there?">AIM</a>' : '';

	$msn_img = $userdata['user_msnm'] ? '<a href="mailto:' . $userdata['user_msnm'] . '"><img src="' . $images['icon_msnm'] . '" alt="' . $lang['MSNM'] . '" title="' . $lang['MSNM'] . '" border="0" /></a>' : '';
	$msn = $userdata['user_msnm'] ? '<a href="mailto:' . $userdata['user_msnm'] . '">MSNM</a>' : '';

    $magent_img = $userdata['user_magent'] ? '<a href="http://www.mail.ru/agent?message&to=' . $userdata['user_magent'] . '"><img src="' . $images['icon_magent'] . '" alt="' . $lang['MAGENT'] . '" title="' . $lang['MAGENT'] . '" border="0" /></a>' : '';
    $magent = $userdata['user_magent'] ? '<a href="http://www.mail.ru/agent?message&to=' . $userdata['user_magent'] . '">M-Agent</a>' : '';

    $yim_img = $userdata['user_yim'] ? '<a href="http://edit.yahoo.com/config/send_webmesg?.target=' . $userdata['user_yim'] . '&amp;.src=pg"><img src="' . $images['icon_yim'] . '" alt="' . $lang['YIM'] . '" title="' . $lang['YIM'] . '" border="0" /></a>' : '';
    $yim = $userdata['user_yim'] ? '<a href="http://edit.yahoo.com/config/send_webmesg?.target=' . $userdata['user_yim'] . '&amp;.src=pg">YIM</a>' : '';

	$temp_url = append_sid("search.$phpEx?search_author=" . urlencode($userdata['username']) . "&amp;showresults=posts");
	$search_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_search'] . '" alt="' . $lang['Search_user_posts'] . '" title="' . sprintf($lang['Search_user_posts'], $userdata['username']) . '" border="0" /></a>';
	$search = '<a href="' . $temp_url . '">' . sprintf($lang['Search_user_posts'], $userdata['username']) . '</a>';

	return $cache[$poster_id] = array(
		'PROFILE_IMG' => $profile_img,
		'PROFILE' => $profile,
		'SEARCH_IMG' => $search_img,
		'SEARCH' => $search,
		'PM_IMG' => $pm_img,
		'PM' => $pm,
		'EMAIL_IMG' => $email_img,
		'EMAIL' => $email,
		'WWW_IMG' => $www_img,
		'WWW' => $www,
		'ICQ_STATUS_IMG' => $icq_status_img,
		'ICQ_IMG' => $icq_img,
		'ICQ' => $icq,
		'AIM_IMG' => $aim_img,
		'AIM' => $aim,
		'MSN_IMG' => $msn_img,
		'MSN' => $msn,
        'MAGENT_IMG' => $magent_img,
        'MAGENT' => $magent,
		'YIM_IMG' => $yim_img,
		'YIM' => $yim,
	);
}

/**
 * Determine user's rank
 * @return array First element will contain user's rank and second will contain a corrsponding rank image. Both are always returned but can be empty strings.
 */
function user_rank($userdata)
{
	global $db;
	static $ranks = null, $special_ranks = null, $cache = array();

	if (isset($cache[$userdata['user_id']]))
	{
		return $cache[$userdata['user_id']];
	}

	if (is_null($ranks))
	{
		if (isset($GLOBALS['ranksrow']))
		{
			$ranks = $GLOBALS['ranksrow'];
		}
		else
		{
			$result = db_query('SELECT * FROM {RANKS_TABLE} ORDER BY rank_min DESC');

			$ranks = $special_ranks = array();
			while ($row = $db->sql_fetchrow($result))
			{
				if ($row['rank_special'])
				{
					$special_ranks[$row['rank_id']] = $row;
				}
				else
				{
					$ranks[] = $row;
				}
			}
			$ranks[] = array('rank_min' => 0, 'rank_title' => '', 'rank_image' => '');
			$db->sql_freeresult($result);
		}
	}

	if ($userdata['user_rank'])
	{
		$row = $special_ranks[$userdata['user_rank']];
	}
	else
	{
		for ($i = 0; $userdata['user_posts'] < $ranks[$i]['rank_min']; $i++);
		$row = $ranks[$i];
	}

	return $cache[$userdata['user_id']] = array(
		$row['rank_title'],
		$row['rank_image'] ? '<img src="' . $row['rank_image'] . '" alt="' . $row['rank_title'] . '" title="' . $row['rank_title'] . '" border="0" /><br />' : ''
	);
}

/**
 * Return path to user's avatar or an empty string if the user has no avatar
 */
function user_avatar($userdata, $url_only = false)
{
	global $bb_cfg;

	if ($userdata['user_avatar_type'] && $userdata['user_allowavatar'])
	{
		switch ($userdata['user_avatar_type'])
		{
			case USER_AVATAR_UPLOAD:
				$avatar = $bb_cfg['allow_avatar_upload'] ? $bb_cfg['avatar_path'] . '/' . $userdata['user_avatar'] : '';
				break;
			case USER_AVATAR_REMOTE:
				$avatar = $bb_cfg['allow_avatar_remote'] ? $userdata['user_avatar'] : '';
				break;
			case USER_AVATAR_GALLERY:
				$avatar = $bb_cfg['allow_avatar_local'] ? $bb_cfg['avatar_gallery_path'] . '/' . $userdata['user_avatar'] : '';
				break;
		}
		return $url_only ? $avatar : ('<img src="' . $avatar . '" alt="" />');
	}
	return '';
}

/**
 * Check if the user is banned.
 * @param int $user_id ID of the user.
 * @param bool $preload Preload banlist table to speedup subsequent calls.
 */
function user_banned($user_id, $preload = false)
{
	global $db;
	static $banned;

	if (!isset($banned))
	{
		if ($preload)
		{
			$result = db_query('SELECT ban_userid FROM {BANLIST_TABLE}');

			$banned = array();
			while ($row = $db->sql_fetchrow($result))
			{
				$banned[$row['ban_userid']] = true;
			}
		}
		else
		{
			$result = db_query('SELECT ban_userid FROM {BANLIST_TABLE} WHERE ban_userid = %d', $user_id);
			return (bool) $db->sql_fetchrow($result);
		}
	}

	return isset($banned[$user_id]);
}

/**
 * Generates array of tpl vars for approve/disapprove/warn/ban buttons.
 * @param array $user_post_data
 * @param array $auth
 * @param boolean $show_rep Generate approve/disapprove buttons
 * @param boolean $show_warn Generate warn/ban buttons
 */
function reputation_buttons_tpl($user_post_data, $auth, $show_rep = true, $show_warn = true)
{
	global $bb_cfg, $phpEx, $userdata, $lang, $images, $thumb_up_img, $thumb_dn_img;

	$url_param = isset($user_post_data['post_id']) ? (POST_POST_URL . '=' . $user_post_data['post_id']) : (POST_USERS_URL . '=' . $user_post_data['user_id']);

	$buttons = array();

	if ($show_rep)
	{
		if ($auth['auth_add_rep'])
		{
			$tmp_url = append_sid("reputation.$phpEx?mode=inc&amp;" . $url_param);
			$buttons['APPROVE_IMG'] = '<a href="' . $tmp_url . '" title="' . $lang['reputation_approve'] . '">' . $thumb_up_img . '</a>';
			$buttons['APPROVE'] = '<a href="' . $tmp_url . '" title="' . $lang['reputation_approve'] . '">[+]</a>';

			if (!$bb_cfg['reputation_positive_only'])
			{
				$tmp_url = append_sid("reputation.$phpEx?mode=dec&amp;" . $url_param);
				$buttons['DISAPPROVE_IMG'] = '<a href="' . $tmp_url . '" title="' . $lang['reputation_disapprove'] . '">' . $thumb_dn_img . '</a>';
				$buttons['DISAPPROVE'] = '<a href="' . $tmp_url . '" title="' . $lang['reputation_disapprove'] . '">[&ndash;]</a>';
			}
		}
	}
	if ($show_warn)
	{
		if ($auth['auth_warn'])
		{
			$temp_url = "reputation.$phpEx?mode=warning&amp;" . $url_param . "&amp;sid=" . $userdata['session_id'];
			$buttons['YELLOW_IMG'] = '<a href="' . $temp_url . '"><img src="' . $images['warn_user'] . '" alt="' . $lang['reputation_warn_user'] . '" title="' . $lang['reputation_warn_user'] . '" border="0" /></a>';
			$buttons['YELLOW'] = '<a class="txtb" href="' . $temp_url . '">' . '[' . $lang['reputation_warn'] . ']' . '</a>';
		}

		if ($auth['auth_ban'])
		{
			$temp_url = "reputation.$phpEx?mode=ban&amp;" . $url_param . "&amp;sid=" . $userdata['session_id'];
			$buttons['RED_IMG'] = '<a href="' . $temp_url . '"><img src="' . $images['ban_user'] . '" alt="' . $lang['reputation_ban_user'] . '" title="' . $lang['reputation_ban_user'] . '" border="0" /></a>';
			$buttons['RED'] = '<a class="txtb" href="' . $temp_url . '">' . '[' . $lang['reputation_ban'] . ']' . '</a>';
		}
	}

	return $buttons;
}

/**
 * Generate template vars for inline post warning display
 * @param array $warning
 * @return array
 */
function reputation_warning_tpl($warning)
{
	global $lang, $images, $phpEx, $bb_cfg, $warned_img, $banned_img, $theme;

	if (isset($warning['user_level']))
	{
		// $style_color = '" style="color: #' . $theme[($warning['user_level'] == ADMIN) ? 'fontcolor3' : 'fontcolor2'];
		$style_color = '';
	}
	$issuer = '<b><a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . '=' . $warning['voter_id']) . $style_color . '">' . $warning['username'] . '</a></b>';

	$temp_url = append_sid("profile.$phpEx?mode=warnings&amp;" . POST_REVIEWS_URL . '=' . $warning['id']) . '#' . $warning['id'];
	if ($warning['modification'] == REPUTATION_WARNING || $warning['modification'] == REPUTATION_WARNING_EXPIRED)
	{
		$icon = "<a href=\"$temp_url\">$warned_img</a>";
		$details = $lang['reputation_post_warning'];
	}
	else
	{
		$icon = "<a href=\"$temp_url\">$banned_img</a>";
		$details = $lang['reputation_post_ban'];
	}
	if ($warning['modification'] == REPUTATION_WARNING_EXPIRED || $warning['modification'] == REPUTATION_BAN_EXPIRED)
	{
		$expire = $lang['reputation_expired'];
	}
	else
	{
		$expire = $warning['expire'] ? create_date($bb_cfg['default_dateformat'], $warning['expire'], $bb_cfg['board_timezone']) : $lang['reputation_expire_never'];
	}
	$details = sprintf($details, $issuer, create_date($bb_cfg['default_dateformat'], $warning['date'], $bb_cfg['board_timezone']), $expire);
	$message = $warning['text'] ? $warning['text'] : $lang['None'];

	return array('ICON' => $icon, 'DETAILS' => $details, 'MESSAGE' => $message);
}

/**
 * TODO: document
 */
function reputation_bonuses_tpl($userdata, $show_base)
{
	global $bb_cfg, $lang, $images, $reputation_auto_idx, $template;

	$result = array();

	if ($show_base && $userdata['user_reputation_base'])
	{
		$result[] = array(
			'TYPE' => $lang['reputation_base'],
			'TYPE_EXP' => $lang['reputation_base_exp'],
			'VALUE' => ($userdata['user_reputation_base'] > 0 ? '+' : '') . $userdata['user_reputation_base'],
			'TYPE_IMG' => $images['rep_rep_base'],
		);
	}

	foreach ($reputation_auto_idx as $i => $auto_idx)
	{
		if ($bb_cfg['reputation_auto_data'][$i] && $userdata['user_' . $auto_idx])
		{
			$result[] = array(
				'TYPE' => $lang['reputation_' . $auto_idx],
				'TYPE_EXP' => $lang['reputation_' . $auto_idx . '_exp'],
				'VALUE' => ($userdata['user_' . $auto_idx] > 0 ? '+' : '') . $userdata['user_' . $auto_idx],
				'TYPE_IMG' => $images['rep_' . $auto_idx],
			);
		}
	}

	return $result;
}

/**
 * Generate HTML code for displaying dropdown list. Useful for providing sorting options and such.
 * @param string $name
 * @param array $values
 * @param array $titles
 * @param string $default
 * @return string Generated HTML code for displaying the list
 */
function html_select($name, $values, $titles, $default = null)
{
	global $lang;

	$select = '<select name="' . $name . '" onchange="this.form.submit();">';

	foreach ($values as $i => $value)
	{
		$checked = ($value == $default) ? ' selected="selected"' : '';
		$select .= "<option value=\"$value\"$checked>" . htmlspecialchars($lang[$titles[$i]]) . '</option>';
	}

	$select .= '</select>';

	return $select;
}

/**
 * Generate string with user's reputation in configurable format and plus/minus buttons if appropriate.
 * @param array $userdata User data array with user_id, reputation, reputation_plus fields
 * @param $mode
 * @param bool $for_post
 * @return string $decor_mode One of 'link', 'label', null
 */
function reputation_display($userdata, $mode, $for_post = false)
{
	global $lang, $bb_cfg, $phpEx, $bb_cfg;

	if ((isset($userdata['user_reputation']) && $userdata['user_reputation']) || (isset($userdata['user_reputation_plus']) && $userdata['user_reputation_plus']))
	{
		$result = $for_post ? '<br /><a href="' . append_sid("profile.$phpEx?mode=reputation&amp;" . POST_USERS_URL . '=' . $userdata['user_id']) . '" title="' . sprintf($lang['reputation_search_reputation'], $userdata['username']) . '">' . $lang['Reputation'] . '</a>: ' : '';

		if ($mode == REPUTATION_SUM)
		{
			$result .= $userdata['user_reputation'];
		}
		else // $mode == REPUTATION_PLUSMINUS
		{
			if ($userdata['user_reputation_plus'])
			{
				$result .= '+' . $userdata['user_reputation_plus'];
			}
			if ($reputation_minus = $userdata['user_reputation_plus'] - $userdata['user_reputation'])
			{
				$result .= ($userdata['user_reputation_plus'] ? '/' : '') . '&ndash;' . $reputation_minus;
			}
		}
	}
	else
	{
		$result = $for_post ? ('<br />' . $lang['Reputation'] . ': 0') : '0';
	}

	return $result;
}

/**
 * TODO: write desc
 */
function reputation_warnings($userdata, $banned, $mode, $for_post = false)
{
	global $warned_img, $banned_img, $lang, $phpEx;

	if ($userdata['user_warnings_dem'] || $banned)
	{
		if ($mode == 'img')
		{
			if ($userdata['user_warnings_dem'])
			{
				$result = str_repeat($warned_img, $banned ? ($userdata['user_warnings_dem'] - 1) : $userdata['user_warnings_dem']) . ($banned ? $banned_img : '');
				if ($for_post)
				{
					$title = sprintf($lang['reputation_warnings_to'], $userdata['username']);
					$result = '<a href="' . append_sid("profile.$phpEx?mode=warnings&amp;" . POST_USERS_URL . '=' . $userdata['user_id']) . '" title="' . $title . '">' . $result . '</a>';
				}
			}
			else // $banned
			{
				$result = '<span title="' . $lang['reputation_banned_permanently'] . '">' . $banned_img . '</span>';
			}

			if ($for_post)
			{
				$result = '<br style="line-height: 4px" />' . $result;
			}
		}
		else // $display == 'text'
		{
			$result = $for_post ? '<br /><a href="' . append_sid("profile.$phpEx?mode=warnings&amp;" . POST_USERS_URL . '=' . $userdata['user_id']) . '" title="' . sprintf($lang['reputation_search_reputation'], $userdata['username']) . '">' . $lang['Warnings'] . '</a>:&nbsp;' : '';

			if ($banned)
			{
				$result .= $userdata['user_warnings_dem'] . '&nbsp;' . $lang['reputation_banned_note'];
			}
			else
			{
				$result .= $userdata['user_warnings_dem'];
			}
		}
	}
	else
	{
		$result = ($mode == 'img' || $for_post) ? '' : '0';
	}

	return $result;
}

/**
 * Writes a string to cache.
 * @param string $id Unique identifier of cached string. Alphanumeric only, please.
 * @param string $data Data to store or null to clear.
 */
function cache_set($id, $data = null, $ttl = 2592000)
{
	global $phpbb_root_path, $current_time, $phpEx;

	$cache_file = $phpbb_root_path . "cache/cache_$id.$phpEx";

	if (is_null($data))
	{
		@unlink($cache_file);
	}
	else
	{
		if ($f = @fopen($cache_file, 'wb'))
		{
			@flock($f, LOCK_EX);
			fwrite($f, '<?php if (time() < ' . ($current_time + $ttl) . ') { $data = unserialize(\'' . str_replace('\'', '\\\'', str_replace('\\', '\\\\', serialize($data))) . '\'); } ?>');
			@flock($f, LOCK_UN);
			fclose($f);
		}
	}
}

/**
 * Reads cached string.
 * @param string $id Unique identifier of cached string. Alphanumeric only, please.
 */
function cache_get($id)
{
	global $phpbb_root_path, $phpEx;

	$cache_file = $phpbb_root_path . "cache/cache_$id.$phpEx";

	if (file_exists($cache_file))
	{
		include($cache_file);

		if (isset($data))
		{
			return $data;
		}
	}

	return false;
}

/**
 * TODO: Write desc
 * @param $auth_or_forum_id
 * @param array $userdata
 * @param null $subject
 * @param bool $quick
 * @return array
 */
function reputation_auth($auth_or_forum_id, $userdata, $subject = null, $quick = false)
{
	global $bb_cfg, $reputation_auth_keys;

	if (is_array($auth_or_forum_id))
	{
		$auth = $auth_or_forum_id;
	}
	elseif ($auth_or_forum_id == NO_ID)
	{
		// fake some auth values
		$auth = array('auth_read' => true, 'auth_view' => true, 'auth_mod' => ($userdata['user_level'] == MOD || $userdata['user_level'] == ADMIN));
	}
	else
	{
		$auth = auth(AUTH_ALL, $auth_or_forum_id, $userdata);
	}

	if ($auth_or_forum_id == AUTH_LIST_ALL) // NOTE: null will pass this! use NO_ID when forum auth is not available
	{
		$auth[NO_ID] = NO_ID; // nonpost warns/reviews/reports belong to the phantom forum with forum_id = NO_ID.

		foreach ($auth as $forum_id => $forum_auth)
		{
			$auth[$forum_id] = reputation_auth($forum_auth, $userdata, $subject, $quick);
		}

		return $auth;
	}

	if (!isset($auth['auth_add_rep']))
	{
		$admin = ($userdata['user_id'] != ANONYMOUS) && ($userdata['user_level'] == ADMIN);
		$guest = $auth['auth_read'] && $auth['auth_view'];
		$reg = ($userdata['user_id'] != ANONYMOUS) && $guest;

		foreach ($reputation_auth_keys as $i => $key)
		{
			switch ($bb_cfg['reputation_perms'][$i])
			{
				case AUTH_ADMIN:
					$auth[$key] = $admin;
					break;
				case AUTH_MOD:
					$auth[$key] = (bool) $auth['auth_mod'];
					break;
				case AUTH_REG:
					$auth[$key] = $reg;
					break;
				case AUTH_ALL:
					$auth[$key] = $guest;
					break;
				default:
					message_die(GENERAL_ERROR, 'Reputation config is damaged');
			}
		}
		if ($auth_or_forum_id == NO_ID)
		{
			$auth['auth_add_rep'] = $auth['auth_add_rep_nonpost'];
			$auth['auth_warn'] = $auth['auth_warn_nonpost'];
			$auth['auth_ban'] = $auth['auth_ban_nonpost'];
		}
	}

	if (!empty($subject))
	{
		reputation_auth_personal($auth, $userdata, $subject, $quick);
	}

	return $auth;
}

/**
 * TODO: Write desc
 * @return mixed Either error message or boolean false (no limitations apply)
 */
function reputation_check_limits($actor, $subject, $quick = false)
{
	global $db, $bb_cfg, $lang, $current_time;

	if ($actor['user_posts'] < $bb_cfg['reputation_posts_req'])
	{
		return $lang['reputation_limits_apply'];
	}
	if (($current_time - $actor['user_regdate']) < $bb_cfg['reputation_days_req'] * 86400)
	{
		return $lang['reputation_limits_apply'];
	}
	if ($actor['user_warnings_dem'] > $bb_cfg['reputation_warnings_req'])
	{
		return $lang['reputation_limits_apply'];
	}
	if ($actor['user_reputation'] < $bb_cfg['reputation_points_req'])
	{
		return $lang['reputation_limits_apply'];
	}

	// The complex thing: time & rotation limits
	if (!$quick && ($bb_cfg['reputation_time_limit'] || $bb_cfg['reputation_rotation_limit']))
	{
		$result = db_query('SELECT id, date FROM {REPUTATION_TABLE}
			WHERE voter_id = %d AND user_id = %d
				AND (modification = {REPUTATION_INC} OR modification = {REPUTATION_DEC})
			ORDER BY id DESC
			LIMIT 1', $actor['user_id'], empty($subject['voter_id']) ? $subject['user_id'] : $subject['voter_id']);
		if ($row = $db->sql_fetchrow($result))
		{
			if ($bb_cfg['reputation_time_limit'] && ($current_time < $row['date'] + $bb_cfg['reputation_time_limit'] * 60))
			{
				return sprintf($lang['reputation_time_limit'], $bb_cfg['reputation_time_limit']);
			}
			if ($bb_cfg['reputation_rotation_limit'])
			{
				$result = db_query('SELECT COUNT(*) AS cnt FROM {REPUTATION_TABLE}
					WHERE voter_id = %d AND id > %d
						AND (modification = {REPUTATION_INC} OR modification = {REPUTATION_DEC})
					GROUP BY voter_id',
					$actor['user_id'], $row['id']);

				if (!($row = $db->sql_fetchrow($result)) || $row['cnt'] < $bb_cfg['reputation_rotation_limit'])
				{
					return sprintf($lang['reputation_rotation_limit'], $bb_cfg['reputation_rotation_limit']);
				}
			}
		}
	}

	return false;
}

function reputation_not_applicable($userdata, $key = false)
{
	global $bb_cfg;
	static $cache = array(ANONYMOUS => array('no_rep' => true, 'no_warn' => true));

	$user_id = empty($userdata['voter_id']) ? $userdata['user_id'] : $userdata['voter_id']; // voter_id have priopity because reviews may have user_id too

	if (!isset($cache[$user_id]))
	{
		$cache[$user_id] = array(
			'no_rep' => ($userdata['user_level'] == MOD && $bb_cfg['reputation_mod_norep']) || ($userdata['user_level'] == ADMIN && $bb_cfg['reputation_admin_norep']),
			'no_warn' => ($userdata['user_level'] == ADMIN) || ($userdata['user_level'] == MOD),
		);
	}

	return $key ? $cache[$user_id][$key] : $cache[$user_id];
}

/**
 * Adjusts $auth array takin into account that $actor is performing some reputation-related action towards $subject.
 * For all changed values error message is provided in the form of $auth['auth_add_rep_msg'] ('_msg' added to auth key)
 */
function reputation_auth_personal(&$auth, $actor, $subject, $quick)
{
/* TODO: rearchitect personalized auth system
			add_rep		edit/delete_rep			add_warn/ban			edit/delete_warn/ban
USER1		!self		self					0						0
MOD1		!self		self && !(mod2,admin2)	!self && !(mod2,admin2)	self && !(mod2,admin2)
ADMIN1		!self		1						!self && !(mod2,admin2)	1

*/
	global $db, $lang, $bb_cfg;

	static $cache = array();
	$subject_id = empty($subject['voter_id']) ? $subject['user_id'] : $subject['voter_id']; // voter_id have priopity because reviews may have user_id too
	$pair_id = $actor['user_id'] . ',' . $subject_id;

	if (isset($cache[$pair_id]))
	{
		$fix = $cache[$pair_id];
	}
	else
	{
		$subject_is_mod = ($subject['user_level'] == ADMIN || $subject['user_level'] == MOD);

		// NOTE: this is the same as reputation_not_applicable(). Have to rework somehow.
		$fix = array(
			'no_rep' => ($subject_id == ANONYMOUS || $subject['user_level'] == MOD && $bb_cfg['reputation_mod_norep'] || $subject['user_level'] == ADMIN && $bb_cfg['reputation_admin_norep']),
			'no_warn' => ($subject_id == ANONYMOUS || $subject_is_mod),
		);

		if ($subject_id == ANONYMOUS)
		{
			$fix['auth_view_rep'] = $fix['auth_add_rep'] = $fix['auth_warn'] = $lang['reputation_anonymous_no_reputation'];
		}
		elseif ($actor['user_id'] == $subject_id)
		{
			$fix['auth_add_rep'] = $fix['auth_warn'] = $fix['auth_ban'] = $lang['reputation_self_no_modify'];

			$auth['auth_view_warns'] = true; // can view own warns/bans
		}
		else
		{
			if ($fix['no_rep'])
			{
				$fix['auth_view_rep'] = $fix['auth_add_rep'] = $lang['reputation_not_applicable'];
			}
			elseif (!$auth['auth_no_limits'])
			{
				if ($message = reputation_check_limits($actor, $subject, $quick))
				{
					$fix['auth_add_rep'] = $message;
				}
			}

			if ($subject_is_mod)
			{
				$fix['auth_view_warns'] = $fix['auth_warn'] = $fix['auth_ban'] = $lang['reputation_cant_warn_mods'];
			}

			if ($actor['user_level'] == MOD)
			{
				/*if ($subject_is_mod)
				{
					$fix['auth_edit_rep'] = $fix['auth_delete_rep'] = $lang['reputation_other_mods_no_edit'];
				}*/
			}
			elseif ($actor['user_level'] != ADMIN)
			{
				$fix['auth_edit_rep'] = $fix['auth_delete_rep'] = $lang['reputation_others_no_edit'];
			}
		}

		/*if ($subject_is_mod)
		{
			if ($actor['user_level'] == MOD) // admins are unconstrained, users never have warning perms
			{
				$fix['auth_edit_warn'] = $fix['auth_delete_warn'] = false;
			}
		}*/

		$cache[$pair_id] = $fix;
	}

	foreach ($fix as $key => $value)
	{
		if (!empty($auth[$key]))
		{
			$auth[$key] = false;
			if ($value)
			{
				$auth[$key . '_msg'] = $value;
			}
		}
	}
	$auth['no_rep'] = $fix['no_rep']; $auth['no_warn'] = $fix['no_warn'];
}

function reputation_giving_power($userdata)
{
	global $bb_cfg, $current_time;

	if ($giving_coeffs = $bb_cfg['reputation_giving'])
	{
		// NOTE: $giving_coeffs are array(giving_for_days, giving_for_posts, giving_for_rep, giving_max, giving_slowdown)

		$max_giving = 1
			+ ($giving_coeffs[0] ? floor(max(($current_time - $userdata['user_regdate']) / 86400 - $bb_cfg['reputation_days_req'], 0) / $giving_coeffs[0]) : 0)
			+ ($giving_coeffs[1] ? floor(max($userdata['user_posts'] - $bb_cfg['reputation_posts_req'], 0) / $giving_coeffs[1]) : 0)
			+ ($giving_coeffs[2] ? floor(max($userdata['user_reputation'] - max($bb_cfg['reputation_points_req'], 0), 0) / $giving_coeffs[2]) : 0);

		if ($giving_coeffs[4])
		{
			$max_giving = max(1, round(pow($max_giving, 1. - 0.01 * $giving_coeffs[4])));
		}
		if ($giving_coeffs[3])
		{
			$max_giving = min($max_giving, $giving_coeffs[3]);
		}

		return intval($max_giving);
	}
	return 1;
}

function server_url()
{
	static $server_ur;

	if (isset($server_url))
	{
		return $server_url;
	}

	global $bb_cfg, $phpEx;

	if ($script_name = preg_replace('/^\/?(.*?)\/?$/', '\1', trim($bb_cfg['script_path'])))
	{
		$script_name .= '/';
	}

	$server_port = ($bb_cfg['server_port'] != 80) ? (':' . trim($bb_cfg['server_port']) . '/') : '/';

	return $server_url = ($bb_cfg['cookie_secure'] ? 'https://' : 'http://') . trim($bb_cfg['server_name']) . $server_port . $script_name;
}

function board_load_lang($name)
{
	global $lang, $userdata, $bb_cfg, $phpEx, $phpbb_root_path;

	$filename = $phpbb_root_path . 'language/lang_' . $bb_cfg['default_lang'] . '/' . $name . '.' . $phpEx;

	if (!file_exists($filename))
	{
		$filename = $phpbb_root_path . 'language/lang_english/' . $name . '.' . $phpEx;
	}

	include($filename);
}

board_load_lang('lang_democracy');

/*
 * Common images
 */
if (!empty($images))
{
	$warned_img = '<img src="' . $images['user_warning'] . '" alt="' . $lang['Warning'] . '" border="0" />';
	$banned_img = '<img src="' . $images['user_ban'] . '" alt="' . $lang['reputation_ban'] . '" border="0" />';
	$thumb_up_img = '<img src="' . $images['thumb_up'] . '" alt="' . $lang['reputation_approve'] . '" border="0" align="top" />';
	$thumb_dn_img = '<img src="' . $images['thumb_dn'] . '" alt="' . $lang['reputation_disapprove'] . '" border="0" align="top" />';
}
$current_time = time();

/*
 * Reputation auth keys (not related to forum auth keys)
 */
$reputation_auth_keys = array('auth_view_rep', 'auth_view_warns', 'auth_add_rep', 'auth_add_rep_nonpost', 'auth_edit_rep', 'auth_delete_rep', 'auth_warn', 'auth_warn_nonpost', 'auth_ban', 'auth_ban_nonpost', 'auth_edit_warn', 'auth_delete_warn', 'auth_no_limits');
$reputation_auto_idx = array('rep_start', 'for_regdays', 'for_posts', 'for_reviews', 'for_rep', 'for_warns', 'for_bans');

/*
 * Some reputation options are kept together in comma-separated lists for compactness.
 */
$bb_cfg['reputation_perms'] = explode(',', $bb_cfg['reputation_perms']);
$bb_cfg['reputation_warning_expire'] = $bb_cfg['reputation_warning_expire'] ? explode(',', $bb_cfg['reputation_warning_expire']) : array();
$bb_cfg['reputation_ban_expire'] = $bb_cfg['reputation_ban_expire'] ? explode(',', $bb_cfg['reputation_ban_expire']) : array();
$bb_cfg['reputation_giving'] = $bb_cfg['reputation_giving'] ? explode(',', $bb_cfg['reputation_giving']) : array();

if ($bb_cfg['reputation_auto_data'])
{
	$bb_cfg['reputation_auto_data'] = $auto_data = explode(',', $bb_cfg['reputation_auto_data']);

	$userdata['user_reputation'] = $auto_data[0]
		+ ($auto_data[1] ? floor(($current_time - $userdata['user_regdate']) / ($auto_data[1] * 86400)) : 0)
		+ ($auto_data[2] ? floor($userdata['user_posts'] / $auto_data[2]) : 0)
		+ ($auto_data[3] ? floor($userdata['user_reviews'] / $auto_data[3]) : 0)
		+ ($auto_data[4] ? floor($userdata['user_reputation'] / $auto_data[4]) : 0)
		- ($auto_data[5] * $userdata['user_warnings_total'])
		- ($auto_data[6] * $userdata['user_bans_total']);
}
else
{
	$bb_cfg['reputation_auto_data'] = array();
}
