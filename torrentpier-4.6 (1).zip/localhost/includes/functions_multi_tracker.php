<?php
/**
 *
 * @author lEx0
 * @version 1.0.0
 * @package TorrentPier
 * @name TorrentPier Multi Tracker Mod
 *
 */

function httpPost($ip = null, $port = 80, $uri = null, $content = null)
{
    if (empty($ip)) {
        return false;
    }
    if (!is_numeric($port)) {
        return false;
    }
    if (empty($uri)) {
        return false;
    }
    //if (empty($content))    { return false; }

    // generate headers in array.
    $t = array();
    $t[] = 'GET ' . $uri . ' HTTP/1.1';
    //$t[] = 'Content-Type: text/html';
    $t[] = 'Host: ' . $ip . ':' . $port;
    $t[] = 'User-Agent: uTorrent/1850(17091)';
    $t[] = 'Accept-Encoding: gzip';
    //$t[] = 'Content-Length: ' . strlen($content);
    //$t[] = 'Connection: close';
    $t = implode("\r\n", $t) . "\r\n\r\n" . $content;
    //
    // Open socket, provide error report vars and timeout of 10
    // seconds.
    //
    $fp = @fsockopen($ip, $port, $errno, $errstr, 5);
    //
    // Send headers and content.
    //
    if (!@fwrite($fp, $t)) {
        @fclose($fp);
        return false;
    }
    //
    // Read all of response into $rsp and close the socket.
    //
    $rsp = '';
    while (!feof($fp)) {
        $rsp .= fgets($fp, 8192);
    }
    fclose($fp);
    //
    // Call parseHttpResponse() to return the results.
    //
    return parseHttpResponse($rsp);
}

//
// Accepts provided http content, checks for a valid http response,
// unchunks if needed, returns http content without headers on
// success, false on any errors.
//
function parseHttpResponse($content = null)
{
    if (empty($content)) {
        return false;
    }
    // split into array, headers and content.
    $hunks = explode("\r\n\r\n", trim($content));
    if (!is_array($hunks) or count($hunks) < 2) {
        return false;
    }
    $header = $hunks[count($hunks) - 2];
    $body = $hunks[count($hunks) - 1];
    $headers = explode("\n", $header);
    unset($hunks);
    unset($header);
    if (!validateHttpResponse($headers)) {
        return false;
    }
    if (in_array('Transfer-Coding: chunked', $headers)) {
        return trim(unchunkHttpResponse($body));
    } else {
        return trim($body);
    }
}

//
// Validate http responses by checking header.  Expects array of
// headers as argument.  Returns boolean.
//
function validateHttpResponse($headers = null)
{
    if (!is_array($headers) or count($headers) < 1) {
        return false;
    }
    switch (trim(strtolower($headers[0]))) {
        case 'http/1.0 100 ok':
        case 'http/1.0 200 ok':
        case 'http/1.1 100 ok':
        case 'http/1.1 200 ok':
            return true;
            break;
    }
    return false;
}

//
// Unchunk http content.  Returns unchunked content on success,
// false on any errors...  Borrows from code posted above by
// jbr at ya-right dot com.
//
function unchunkHttpResponse($str = null)
{
    if (!is_string($str) or strlen($str) < 1) {
        return false;
    }
    $eol = "\r\n";
    $add = strlen($eol);
    $tmp = $str;
    $str = '';
    do {
        $tmp = ltrim($tmp);
        $pos = strpos($tmp, $eol);
        if ($pos === false) {
            return false;
        }
        $len = hexdec(substr($tmp, 0, $pos));
        if (!is_numeric($len) or $len < 0) {
            return false;
        }
        $str .= substr($tmp, ($pos + $add), $len);
        $tmp = substr($tmp, ($len + $pos + $add));
        $check = trim($tmp);
    } while (!empty($check));
    unset($tmp);
    return $str;
}

function _use_mulitracker($attach_id)
{
    global $db;

    $torrent = $db->fetch_row('
		SELECT 
			multi_updated_date,
			multi_tracker_use
		FROM 
			' . BT_TORRENTS_TABLE . '
		WHERE
			attach_id = ' . $db->escape_string($attach_id));

    if (!$torrent['multi_tracker_use']) {
        return FALSE;
    }

    return $torrent;
}

function multi_tracker_update($attach_id, $force_update = FALSE, $return_result = FALSE)
{
    global $db, $bb_cfg, $userdata;

    $attach_id = (int)$attach_id;

    if ($attach_id == '' || $attach_id == 0) {
        return FALSE;
    }

    if ($force_update === FALSE) {
        $torrent = _use_mulitracker($attach_id);
        if ($torrent === FALSE) {
            return FALSE;
        }

        if (time() < $torrent['multi_updated_date'] + $bb_cfg['m_expire_time']) {
            return FALSE;
        }
    }

    $result = $db->fetch_row("
		SELECT 
			physical_filename
		FROM
			" . ATTACHMENTS_DESC_TABLE . "
		WHERE
				attach_id = " . $db->escape_string($attach_id) . "
			AND
				extension = 'torrent'
			AND
				tracker_status = 1
		LIMIT 1		
	");

    if (
        !count($result) ||
        @$result['physical_filename'] == '' ||
        is_null(@$result['physical_filename'])    /*||
		@$result['physical_filename'] == 0*/
    ) {
        return FALSE;
    }

    require_once INC_DIR . 'class.bdecode.' . PHP_EXT;
    require_once INC_DIR . 'class.http.' . PHP_EXT;
    $torToParse = new BDECODE(BB_PATH . '/files/' . $result['physical_filename']);

    $parsedTrackers = return_announcers($torToParse->result);
    if ($parsedTrackers === FALSE) {
        return FALSE;
    }

    $dbId['complete'] = 0;
    $dbId['incomplete'] = 0;

    foreach ($parsedTrackers as $trackers) {
        if (array_key_exists('6', $trackers)) {
            //echo $trackers[6]."\n".strlen($trackers[6])."\n".strpos($trackers[6],'&');
            if (strpos($trackers[6], '?')) {
                $perf = '&amp;';
                if (strrpos($trackers[6], '&')) {
                    if (strlen($trackers[6]) == (strpos($trackers[6], '&') + 1)) {
                        $perf = '';
                    }
                }
            } else {
                $perf = '?';
            }
        } else {
            $perf = '?';
        }

        if (!$trackers[5]) {
            $port = 80;
        } else {
            $port = $trackers[5];
        }

        $info_hash = sha1(bencode($torToParse->result['info']), true);

        $request =
            $trackers[6] .
            $perf .
            "info_hash=" . urlencode($info_hash) .
            "&peer_id=-UT1850-%c3B%bb%04%1eYz%c6%11%0e%c7%e7" .
            "&port=" . mt_rand(10000, 50000) .
            "&uploaded=0&downloaded=0&left=0&corrupt=0&key=8C5EC0D3&event=started&numwant=200&compact=1&no_peer_id=1";
        $request = str_replace('&amp;', '&', $request);
        $requestOut = httpPost($trackers[2], $port, $request);
        if (!is_string($requestOut)) {
            continue;
        }

        require_once INC_DIR . 'functions_torrent.' . PHP_EXT;
        $bDa = bdecode($requestOut);
        $dbId['complete'] += @$bDa['complete'];
        $dbId['incomplete'] += @$bDa['incomplete'];
    }

    if (!$dbId['complete'] && !$dbId['incomplete']) {
        //$dbId['m_dead_torrent'] = @$dbId['m_dead_torrent']++;

        /*if( $bb_cfg['m_dead_torrent'] <= @$dbId['m_dead_torrent'] )
        {*/
        $db->query("
					UPDATE
						" . BT_TORRENTS_TABLE . "
					SET
						multi_tracker_use = 0
					WHERE
						attach_id = " . $db->escape_string($attach_id) . "");
        return FALSE;
        /*}*/
    }
    $db->query("
		UPDATE
			" . BT_TORRENTS_TABLE . "
		SET
			multi_trackers_and_peers = '" . $db->escape_string(serialize($dbId)) . "',
			multi_updated_date = " . time() . "
		WHERE
			attach_id = " . $db->escape_string($attach_id) . "");
    if ($return_result === TRUE) {
        return $dbId;
    }

    return TRUE;


}

function _update_torrent_state($a, $s = 0)
{
    global $db;

    $db->query("
		UPDATE
			" . BT_TORRENTS_TABLE . " b
		SET
			b.multi_tracker_use = $s
		WHERE
			attach_id = $a");
}

function get_external_peers($attach_id)
{
    global $db, $bb_cfg;

    $attach_id = (int)$attach_id;

    if ($attach_id == '' || $attach_id == 0) {
        return FALSE;
    }

    if (!$result = $db->fetch_row("
				SELECT 
					multi_trackers_and_peers,
					multi_updated_date
				FROM
					" . BT_TORRENTS_TABLE . "
				WHERE
					attach_id = " . $db->escape_string($attach_id))) {
        return FALSE;
    }

    if ($result['multi_updated_date'] + $bb_cfg['m_expire_time'] >= time()) {
        multi_tracker_update($attach_id);
    }

    if (!is_array($result) || !array_key_exists('multi_trackers_and_peers', $result)) {
        return FALSE;
    }
    $result = unserialize($result['multi_trackers_and_peers']);
    return $result;
}

function return_announcers($bencode)
{
    global $bb_cfg;

    if (array_key_exists('announce-list', $bencode)) {
        foreach ($bencode['announce-list'] as $torTracker) {
            if (!stristr($bb_cfg['bt_announce_url'], $torTracker[0])) {
                $parsedTrackers[] = $torTracker[0];
            }
        }
    } else {
        if (!stristr($bb_cfg['bt_announce_url'], $bencode['announce'])) {
            $parsedTrackers[] = $bencode['announce'];
        }
    }

    $goodTrackers = array();

    foreach ($parsedTrackers as $tracker2parse) {
        if (preg_match('#^
			(http|udp)
			\\:\\/\\/
			([a-z0-9\-]+\.([a-z0-9\-]+\.)?
			[a-z]{2,5})
			(\:([0-9]{2,5}))?
			(\\/(.*))?		
		#ix', $tracker2parse, $oTu)) {
            $goodTrackers[] = $oTu;
        } else {
            continue;
        }
    }
    if (count($goodTrackers) > 0) {
        return $goodTrackers;
    } else {

        return FALSE;
    }
}













