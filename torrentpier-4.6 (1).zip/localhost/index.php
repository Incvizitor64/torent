<?php

/*
	This file is part of TorrentPier

	TorrentPier is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	TorrentPier is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	A copy of the GPL 2.0 should have been included with the program.
	If not, see http://www.gnu.org/licenses/

	Official SVN repository and contact information can be found at
	http://code.google.com/p/torrentpier/
 */

define('IN_PHPBB',   true);
define('BB_SCRIPT', 'index');
define('BB_ROOT', './');
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require(BB_ROOT ."common.$phpEx");

$page_cfg['load_tpl_vars'] = array(
	'post_icons',
);

$page_cfg['include_bbcode_js'] = true;

$show_last_topic    = true;
$last_topic_max_len = 28;
$show_online_users  = true;
$show_subforums     = true;

$datastore->enqueue(array(
	'stats',
	'moderators',
));
if ($bb_cfg['show_latest_news'])
{
	$datastore->enqueue('latest_news');
}

//Enqueue last added
if ($bb_cfg['t_last_added_num'])
{
	$datastore->enqueue('last_added');
}
//Enqueue top downloaded
if ($bb_cfg['t_top_downloaded'])
{
	$datastore->enqueue('top_downloaded');
}
//Enqueue top uploaders
if ($bb_cfg['t_top_uploaders'])
{
	$datastore->enqueue('top_uploaders');
}
//Enqueue top downloaders
if ($bb_cfg['t_top_downloaders'])
{
	$datastore->enqueue('top_downloaders');
}

if ($bb_cfg['new_add_post_num'])
{
    $datastore->enqueue('new_added_post');
}

// Init userdata
$user->session_start();

// Init main vars
$viewcat = isset($_GET['c']) ? (int) $_GET['c'] : 0;
$lastvisit = (IS_GUEST) ? TIMENOW : $userdata['user_lastvisit'];
$showhide = isset($_GET['sh']) ? (int) $_GET['sh'] : 0;

// Show map
$viewtree = false;
if (isset($_GET['c']))
{
	if ($_GET['c'] == 'map')
	{
		$viewtree = true;
	}
}
// Show map [END]

// Caching output
$req_page = 'index_page';
$req_page .= ($viewcat) ? "_c{$viewcat}" : '';

define('REQUESTED_PAGE', $req_page);
caching_output(IS_GUEST, 'send', REQUESTED_PAGE .'_guest');

$hide_cat_opt = (@$user->opt_js['h_cat']) ? @$user->opt_js['h_cat'] : 0;
$hide_cat_opt = str_replace('-',',',$hide_cat_opt);

// Topics read tracks
$tracking_topics = get_tracks('topic');
$tracking_forums = get_tracks('forum');

// Statistics
if (!$stats = $datastore->get('stats'))
{
	$datastore->update('stats');
	$stats = $datastore->get('stats');
}

// Forums data
if (!$forums = $datastore->get('cat_forums'))
{
	$datastore->update('cat_forums');
	$forums = $datastore->get('cat_forums');
}
$cat_title_html = $forums['cat_title_html'];
$cat_image = $forums['cat_image'];
$forum_name_html = $forums['forum_name_html'];

$anon = ANONYMOUS;
$excluded_forums_csv = $user->get_excluded_forums(AUTH_VIEW);
$only_new = $user->opt_js['only_new'];

// Validate requested category id
if ($viewcat AND !$viewcat =& $forums['c'][$viewcat]['cat_id'])
{
	redirect("index.$phpEx");
}
// Forums
$forums_join_sql = 'f.cat_id = c.cat_id';
$forums_join_sql .= ($viewcat) ? "
	AND f.cat_id = $viewcat
" : '';
$forums_join_sql .= ($excluded_forums_csv) ? "
	AND f.forum_id NOT IN($excluded_forums_csv)
	AND f.forum_parent NOT IN($excluded_forums_csv)
" : '';

// Posts
$posts_join_sql = "p.post_id = f.forum_last_post_id";
$posts_join_sql .= ($only_new == ONLY_NEW_POSTS) ? "
	AND p.post_time > $lastvisit
" : '';
$join_p_type = ($only_new == ONLY_NEW_POSTS) ? 'INNER JOIN' : 'LEFT JOIN';

// Topics
$topics_join_sql = "t.topic_last_post_id = p.post_id";
$topics_join_sql .= ($only_new == ONLY_NEW_TOPICS) ? "
	AND t.topic_time > $lastvisit
" : '';
$join_t_type = ($only_new == ONLY_NEW_TOPICS) ? 'INNER JOIN' : 'LEFT JOIN';

$where_cat_h_sql = "";
$where_cat_h_sql = ($showhide) ? "" : "WHERE c.cat_id NOT IN($hide_cat_opt)";

$sql = "
	SELECT SQL_CACHE
		f.cat_id, f.forum_id, f.forum_status, f.forum_parent, f.show_on_index,
		p.post_id AS last_post_id, p.post_time AS last_post_time,
		t.topic_id AS last_topic_id, t.topic_title AS last_topic_title,
		u.user_id AS last_post_user_id,
		IF(p.poster_id = $anon, p.post_username, u.username) AS last_post_username
	FROM       ". CATEGORIES_TABLE ." c
	INNER JOIN ". FORUMS_TABLE     ." f ON($forums_join_sql)
	$join_p_type ". POSTS_TABLE      ." p ON($posts_join_sql)
	$join_t_type ". TOPICS_TABLE     ." t ON($topics_join_sql)
	 LEFT JOIN ". USERS_TABLE      ." u ON(u.user_id = p.poster_id)
	 $where_cat_h_sql
	ORDER BY c.cat_order, f.forum_order
";
$cat_forums = array();

$replace_in_parent = array(
	'last_post_id',
	'last_post_time',
	'last_post_user_id',
	'last_post_username',
	'last_topic_title',
	'last_topic_id',
);

foreach ($db->fetch_rowset($sql) as $row)
{
	if (!$cat_id = $row['cat_id'] OR !$forum_id = $row['forum_id'])
	{
		continue;
	}

	if ($parent_id = $row['forum_parent'])
	{
		if (!$parent =& $cat_forums[$cat_id]['f'][$parent_id])
		{
			$parent = $forums['f'][$parent_id];
			$parent['last_post_time'] = 0;
		}
		if ($row['last_post_time'] > $parent['last_post_time'])
		{
			foreach ($replace_in_parent as $key)
			{
				$parent[$key] = $row[$key];
			}
		}
		if ($show_subforums && $row['show_on_index'])
		{
			$parent['last_sf_id'] = $forum_id;
		}
		else
		{
			continue;
		}
	}
	else
	{
		$f =& $forums['f'][$forum_id];
		$row['forum_desc']   = $f['forum_desc'];
		$row['forum_posts']  = $f['forum_posts'];
		$row['forum_topics'] = $f['forum_topics'];
	}

	$cat_forums[$cat_id]['f'][$forum_id] = $row;
}

if($forums['cat_title_html'])
{
	while (list($h_c_id, $h_c_title) = each($forums['cat_title_html'])) {
	$h_c_checked = (in_array($h_c_id, preg_split("/[,]+/",$hide_cat_opt))) ? 'checked' : '';
	$template->assign_block_vars('h_c', array(
		'H_C_ID'     => $h_c_id,
		'H_C_TITLE'  => $h_c_title,
		'H_C_CHEKED' => $h_c_checked
	));
	}
	$template->assign_vars(array(
		'H_C_AL_MESS'  => ($hide_cat_opt) ? true : false
	));
}

unset($forums);
$datastore->rm('cat_forums');

// Obtain list of moderators
$moderators = array();
if (!$mod = $datastore->get('moderators'))
{
	$datastore->update('moderators');
	$mod = $datastore->get('moderators');
}

if (!empty($mod))
{
	foreach ($mod['mod_users'] as $forum_id => $user_ids)
	{
		foreach ($user_ids as $user_id)
		{
			$moderators[$forum_id][] = '<a href="'. (PROFILE_URL . $user_id) .'">'. $mod['name_users'][$user_id] .'</a>';
		}
	}
	foreach ($mod['mod_groups'] as $forum_id => $group_ids)
	{
		foreach ($group_ids as $group_id)
		{
			$moderators[$forum_id][] = '<a href="'. (GROUP_URL . $group_id) .'">'. $mod['name_groups'][$group_id] .'</a>';
		}
	}
}

unset($mod);
$datastore->rm('moderators');

if (!$forums_count = count($cat_forums) AND $viewcat)
{
	redirect("index.$phpEx");
}

$template->assign_vars(array(
	'SHOW_FORUMS'           => $forums_count,
	'PAGE_TITLE'            => $lang['Index'],
	'NO_FORUMS_MSG'         => ($only_new) ? $lang['NO_NEW_POSTS'] : $lang['NO_FORUMS'],

	'TOTAL_TOPICS'          => sprintf($lang['Posted_topics_total'], $stats['topiccount']),
	'TOTAL_POSTS'           => sprintf($lang['Posted_articles_total'], $stats['postcount']),
	'TOTAL_USERS'           => sprintf($lang['Registered_users_total'], $stats['usercount']),
    'TOTAL_GENDER' => sprintf(
        $lang['USERS_TOTAL_GENDER'],
        $stats['male'],
        $stats['female'],
        $stats['unselect']
    ),
    'NEWEST_USER'           => sprintf($lang['Newest_user'], '<a target="_blank" href="'. PROFILE_URL . $stats['newestuser']['user_id'] .'">', $stats['newestuser']['username'], '</a>'),

    //+MOD: DHTML Collapsible Forum Index MOD
    'U_CFI_JSLIB'       => $phpbb_root_path . 'misc/js/collapsible_forum_index.js',
    'CFI_COOKIE_NAME'   => get_cfi_cookie_name(),
    'COOKIE_PATH'       => $board_config['cookie_path'],
    'COOKIE_DOMAIN'     => $board_config['cookie_domain'],
    'COOKIE_SECURE'     => $board_config['cookie_secure'],
    'L_CFI_OPTIONS'     => str_replace(array("'",' '), array("\'",'&nbsp;'), $lang['CFI_options']),
    'L_CFI_OPTIONS_EX'  => str_replace(array("'",' '), array("\'",'&nbsp;'), $lang['CFI_options_ex']),
    'L_CFI_CLOSE'       => str_replace(array("'",' '), array("\'",'&nbsp;'), $lang['CFI_close']),
    'L_CFI_DELETE'      => str_replace(array("'",' '), array("\'",'&nbsp;'), $lang['CFI_delete']),
    'L_CFI_RESTORE'     => str_replace(array("'",' '), array("\'",'&nbsp;'), $lang['CFI_restore']),
    'L_CFI_SAVE'        => str_replace(array("'",' '), array("\'",'&nbsp;'), $lang['CFI_save']),
    'L_CFI_EXPAND_ALL'  => str_replace(array("'",' '), array("\'",'&nbsp;'), $lang['CFI_Expand_all']),
    'L_CFI_COLLAPSE_ALL'=> str_replace(array("'",' '), array("\'",'&nbsp;'), $lang['CFI_Collapse_all']),
    'IMG_UP_ARROW'      => $phpbb_root_path . $images['up_arrow'],
    'IMG_DW_ARROW'      => $phpbb_root_path . $images['down_arrow'],
    'IMG_PLUS'          => $phpbb_root_path . $images['icon_sign_plus'],
    'IMG_MINUS'         => $phpbb_root_path . $images['icon_sign_minus'],
    'SPACER'            => $phpbb_root_path . 'images/spacer.gif',
    //-MOD: DHTML Collapsible Forum Index MOD

	// Tracker stats
	'TORRENTS_STAT'         => $bb_cfg['tor_stats'] ? sprintf($lang['Torrents_stat'], $stats['torrentcount'], humn_size($stats['size'])) : '',
	'PEERS_STAT'		    => $bb_cfg['tor_stats'] ? sprintf($lang['Peers_stat'], $stats['peers'], $stats['seeders'], $stats['leechers']) : '',
	'SPEED_STAT'		    => $bb_cfg['tor_stats'] ? sprintf($lang['Speed_stat'], humn_size($stats['speed']) .'/s') : '',

	'FORUM_IMG'             => $images['forum'],
	'FORUM_NEW_IMG'         => $images['forum_new'],
	'FORUM_LOCKED_IMG'      => $images['forum_locked'],

	'SHOW_ONLY_NEW_MENU'    => true,
	'ONLY_NEW_POSTS_ON'     => ($only_new == ONLY_NEW_POSTS),
	'ONLY_NEW_TOPICS_ON'    => ($only_new == ONLY_NEW_TOPICS),

	'U_SEARCH_NEW'          => "search.$phpEx?new=1",
	'U_SEARCH_SELF_BY_MY'   => "search.$phpEx?uid={$userdata['user_id']}&amp;o=1",
	'U_SEARCH_LATEST'       => "search.$phpEx?search_id=latest",
	'U_SEARCH_UNANSWERED'   => "search.$phpEx?search_id=unanswered",
	'U_CANONICAL'           => (!$viewcat) ? FULL_URL : '',

	'SHOW_LAST_TOPIC'       => $show_last_topic,
));

//
// BEGIN last 10.
//
if($bb_cfg['t_last_added_num'])
{
	$last_added = $datastore->get('last_added');

	if(!empty($last_added)) {
        $template -> assign_vars(array(
            'LAST_ADDED_ON' => true,
        ));

        foreach ($last_added as $last_add)
        {
            $template -> assign_block_vars('lastAdded',array(
                'TITLE' => str_short($last_add['topic_title'], 25),
                'TOPIC_ID' => $last_add['topic_id'],
                'FORUM' => $last_add['forum_name'],
                'FORUM_ID' => $last_add['forum_id'],
                'POSTER' => $last_add['username'],
                'POSTER_ID' => $last_add['user_id'],
                'TORRENT_TIME' => create_date($bb_cfg['default_dateformat'], $last_add['reg_time'], $userdata['user_timezone'])
            )) ;
        }
    }
}
//
// END last 10
//

//
// BEGIN TopDownloaded
//
if($bb_cfg['t_top_downloaded'])
{
	$top_downloaded = $datastore->get('top_downloaded');

	if(!empty($top_downloaded)) {
        $template -> assign_vars(array(
            'TOP_DOWNLOADED_ON' => true,
        ));

        foreach ($top_downloaded as $top_download)
        {
            $template -> assign_block_vars('TopDownloaded',array(
                'TITLE' => str_short($top_download['topic_title'], 25),
                'TOPIC_ID' => $top_download['topic_id'],
                'FORUM' => $top_download['forum_name'],
                'FORUM_ID' => $top_download['forum_id'],
                'POSTER' => $top_download['username'],
                'POSTER_ID' => $top_download['user_id'],
                'COMPLETED' => $top_download['complete_count'] . $lang['LAST_TIMES'],
                'TORRENT_TIME' => create_date($bb_cfg['default_dateformat'], $top_download['reg_time'], $userdata['user_timezone'])
            )) ;
        }
    }
}
//
// END TopDownloaded
//

//
// BEGIN Top Uploaders.
//
if($bb_cfg['t_top_uploaders']) {
	$top_uploaders = $datastore->get('top_uploaders');

	if(!empty($top_uploaders)) {
        $template -> assign_vars(array(
            'TOP_UPLOADERS_ON' => true,
            'UL_TOP_COUNT'     => $bb_cfg['t_top_uploaders'],
        ));

        foreach ($top_uploaders as $top_uploader)
        {
            $template -> assign_block_vars('TopUploaders',array(
                'USER_ID'  => $top_uploader['user_id'],
                'UPL_NAME' => $top_uploader['username'],
                'UPLOADED' => (humn_size($top_uploader['sum'])),
            )) ;
        }
    }
}
//
// END Top Uploaders
//

//
// BEGIN Top Downloaders.
//
if($bb_cfg['t_top_downloaders']) {
	$top_downloaders = $datastore->get('top_downloaders');

	if(!empty($top_downloaders)) {
        $template -> assign_vars(array(
            'TOP_DOWNLOADERS_ON' => true,
            'DL_TOP_COUNT'       => $bb_cfg['t_top_downloaders'],
        ));

        foreach ($top_downloaders as $top_downloader)
        {
            $template -> assign_block_vars('TopDownloaders',array(
                'USER_ID'    => $top_downloader['user_id'],
                'DOWNL_NAME' => $top_downloader['username'],
                'DOWNLOADED' => (humn_size($top_downloader['sum'])),
            )) ;
        }
    }
}
//
// END Top Downloaders
//

if ($bb_cfg['new_add_post_num']) {
    $new_added_post = $datastore->get('new_added_post');

    if(!empty($new_added_post)) {
        $template -> assign_vars(array(
            'LAST_POST_SHOW' => true,
        ));

        foreach ($new_added_post as $new_post) {
            if(!empty($new_post['topic_title'])) {
                $template->assign_block_vars('newaddpost', array(
                    'TOPIC_TITLE' => $new_post['topic_title'],
                    'TOPIC_ID' => $new_post['topic_id'],
                    'FORUM' => $new_post['forum_name'],
                    'NEW_P_CLASS' => (is_unread($new_post['topic_last_post_time'], $new_post['topic_id'], $new_post['forum_id'])) ? $bb_cfg['new_add_post_col'] : '',
                    'FORUM_ID' => $new_post['forum_id'],
                    'AUTOR_POST' => $new_post['username'],
                    'AUTOR_POST_ID' => $new_post['user_id'],
                    'POST_TIME' => create_date('Y-m-d H:i', $new_post['topic_last_post_time'], $bb_cfg['board_timezone']),
                    'URL_NEW_POST' => append_sid(BB_ROOT . "viewtopic.$phpEx?" . POST_POST_URL . "=" . $new_post['topic_last_post_id'] . "#" . $new_post['topic_last_post_id'])
                ));
            }
        }
    }
}

// Build index page
foreach ($cat_forums as $cid => $c)
{
	$template->assign_block_vars('c', array(
        //+MOD: DHTML Collapsible Forum Index MOD
        'DISPLAY' => (is_category_collapsed($cid) ? '' : 'none'),
        //-MOD: DHTML Collapsible Forum Index MOD
		'CAT_ID'    => $cid,
        'CAT_IMG'   => !empty($cat_image[$cid]) ? '<img width="18" height="auto" alt="" title="' . $cat_title_html[$cid] . '" src="' . BB_ROOT . $cat_image[$cid] . '" />' : '',
		'CAT_TITLE' => $cat_title_html[$cid],
		'U_VIEWCAT' => "index.$phpEx?c=$cid",
	));

	foreach ($c['f'] as $fid => $f)
	{
		if (!$fname_html =& $forum_name_html[$fid])
		{
			continue;
		}
		$is_sf = $f['forum_parent'];

		$new = is_unread($f['last_post_time'], $f['last_topic_id'], $f['forum_id']) ? '_new' : '';
		$folder_image = ($is_sf) ? $images["icon_minipost{$new}"] : $images["forum{$new}"];

		if ($f['forum_status'] == FORUM_LOCKED)
		{
			$folder_image = ($is_sf) ? $images['icon_minipost'] : $images['forum_locked'];
		}

		if ($is_sf)
		{
			$template->assign_block_vars('c.f.sf', array(
				'SF_ID'   => $fid,
				'SF_NAME' => $fname_html,
				'SF_NEW'  => $new ? ' new' : '',
			));
			continue;
		}

		$template->assign_block_vars('c.f',	array(
			'FORUM_FOLDER_IMG' => $folder_image,

			'FORUM_ID'   => $fid,

            //+MOD: DHTML Collapsible Forum Index MOD
            'DISPLAY' => (is_category_collapsed($cid) ? 'none' : ''),
            //-MOD: DHTML Collapsible Forum Index MOD

			'FORUM_NAME' => $fname_html,
			'FORUM_DESC' => $f['forum_desc'],
			'POSTS'      => commify($f['forum_posts']),
			'TOPICS'     => commify($f['forum_topics']),
			'LAST_SF_ID' => isset($f['last_sf_id']) ? $f['last_sf_id'] : null,

			'MODERATORS'  => isset($moderators[$fid]) ? join(', ', $moderators[$fid]) : '',
			'FORUM_FOLDER_ALT' => ($new) ? 'new' : 'old',
		));

		if ($f['last_post_id'])
		{
			$template->assign_block_vars('c.f.last', array(
				'LAST_TOPIC_ID'       => $f['last_topic_id'],
				'LAST_TOPIC_TIP'      => $f['last_topic_title'],
				'LAST_TOPIC_TITLE'    => wbr(str_short($f['last_topic_title'], $last_topic_max_len)),

				'LAST_POST_TIME'      => create_date($bb_cfg['last_post_date_format'], $f['last_post_time']),
				'LAST_POST_USER_ID'   => ($f['last_post_user_id'] != ANONYMOUS) ? $f['last_post_user_id'] : false,
				'LAST_POST_USER_NAME' => ($f['last_post_username']) ? str_short($f['last_post_username'], 15) : $lang['Guest'],
			));
		}
	}
}

// Set tpl vars for bt_userdata
if ($bb_cfg['bt_show_dl_stat_on_index'] && !IS_GUEST)
{
	show_bt_userdata($userdata['user_id']);
}

// [MOD] users who have visited
$now = time();
$time_h = (int)date('H',$now);
$time_m = (int)date('i',$now);
$time_s = (int)date('s',$now);
$day = $now - $time_h * 60 * 60 - $time_m * 60 - $time_s;
$get_users = mysql_query("SELECT u.username, u.user_id, u.user_allow_viewonline, u.user_level, u.ignore_srv_load, s.session_logged_in, s.session_ip, (s.session_time - s.session_start) AS ses_len, COUNT(s.session_id) AS sessions, COUNT(DISTINCT s.session_ip) AS ips FROM ". SESSIONS_TABLE ." s, ". USERS_TABLE ." u WHERE s.session_time > $day AND u.user_id = s.session_user_id AND u.user_active = 1 GROUP BY s.session_user_id ORDER BY u.username");
$visitors = $lang['users_today'];
while ($u_db = mysql_fetch_assoc($get_users))
{
    if(!empty($u_db)) {
        $visitors .= '<a href=profile.php?mode=viewprofile&u='.$u_db['user_id'].' target=_blank><b>'.$u_db['username'].'</b></a>, ';
    } else {
        $visitors .= '';
    }
}
if(!empty($visitors)) {
    $visitors = substr($visitors, 0, -2);
    $template->assign_vars(array(
        'USERS_TODAY' => $visitors,
    ));
}
// [END] users who have visited

// Latest news
if ($bb_cfg['show_latest_news'])
{
	if (!$latest_news = $datastore->get('latest_news'))
	{
		$datastore->update('latest_news');
		$latest_news = $datastore->get('latest_news');
	}

	$template->assign_vars(array(
		'SHOW_LATEST_NEWS' => true,
	));

	foreach ($latest_news as $news)
	{
		$template->assign_block_vars('news', array(
			'NEWS_TOPIC_ID' => $news['topic_id'],
			'NEWS_TITLE'    => $news['topic_title'],
			'NEWS_TIME'     => create_date('d-M', $news['topic_time']),
			'NEWS_IS_NEW'   => $news['topic_time'] > $lastvisit,
		));
	}
}

if ($bb_cfg['birthday_check_day'] && $bb_cfg['birthday_enabled']) {
    $week_list = $today_list = array();
    $week_all = $today_all = false;

    if (!empty($stats['birthday_week_list'])) {
        shuffle($stats['birthday_week_list']);
        foreach ($stats['birthday_week_list'] as $i => $week) {
            if ($i >= 5) {
                $week_all = true;
                continue;
            }
            $week_list[] = profile_url($week) . ' <span class="small">(' . birthday_age($week['user_birthday']) . ')</span>';
        }
        $week_all = $week_all ? '&nbsp;<a class="txtb" href="#" onclick="ajax.exec({ action : \'birthday_list\', mode: \'birthday_week\' }); return false;" title="' . $lang['All'] . '">...</a>' : '';
        $week_list = sprintf($lang['BIRTHDAY_WEEK'], $bb_cfg['birthday_check_day'], implode(', ', $week_list)) . $week_all;
    } else {
        $week_list = sprintf($lang['NOBIRTHDAY_WEEK'], $bb_cfg['birthday_check_day']);
    }

    if (!empty($stats['birthday_today_list'])) {
        shuffle($stats['birthday_today_list']);
        foreach ($stats['birthday_today_list'] as $i => $today) {
            if ($i >= 5) {
                $today_all = true;
                continue;
            }
            $today_list[] = profile_url($today) . ' <span class="small">(' . birthday_age($today['user_birthday']) . ')</span>';
        }
        $today_all = $today_all ? '&nbsp;<a class="txtb" href="#" onclick="ajax.exec({ action : \'birthday_list\', mode: \'birthday_today\' }); return false;" title="' . $lang['All'] . '">...</a>' : '';
        $today_list = $lang['BIRTHDAY_TODAY'] . implode(', ', $today_list) . $today_all;
    } else {
        $today_list = $lang['NOBIRTHDAY_TODAY'];
    }

    $template->assign_vars(array(
        'WHOSBIRTHDAY_WEEK' => $week_list,
        'WHOSBIRTHDAY_TODAY' => $today_list,
    ));
}

// Allow cron
if (IS_ADMIN || IS_MOD)
{
	if (@file_exists(CRON_RUNNING)) {
		if (@file_exists(CRON_ALLOWED))
		{
			unlink (CRON_ALLOWED);
		}
		rename(CRON_RUNNING, CRON_ALLOWED);
	}
}

// Display page
define('SHOW_ONLINE', $show_online_users);

// Advanced Meta Tags
$global_keywords = $bb_cfg['global_keywords'];
$site_description = $bb_cfg['site_desc'];
$template->assign_vars(array(
	'PAGE_DESCRIPTION_ON' => true,
	'PAGE_DESCRIPTION' => $site_description,
	'PAGE_KEYWORDS_ON' => true,
	'PAGE_KEYWORDS' => $global_keywords,
));
// Advanced Meta Tags [END]


// Show map
if($viewtree)
{
	$template->assign_vars(array(
		'PAGE_TITLE' => $lang['MAP_TITLE'],
	));
	print_page('showmap.tpl');
}
else
{
	print_page('index.tpl');
}
