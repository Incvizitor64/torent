<?php

/*
  This is a modules config!
  This file contain the settings for:
   - Advanced Report Hack
   - Gold/Silver releases
   - Gallery
   - Internet Speed
   - Friends
   - Chat
   - Block posting for new accounts
   - Secure content
   - Dynamic site title
   - Bonus upload
   - Show names of voted users in polls
   - Parking accounts addons
   - Registration at certain hours
   - Latest news in sidebar
   - Improved captcha
   - Birthday check
*/

if (!defined('BB_ROOT')) die(basename(__FILE__));

// Advanced Report Hack
$bb_cfg['reports_enabled']  =  true;

// Gold/Silver releases
$bb_cfg['gold_silver_enabled']  =  true;

// Gallery
$bb_cfg['gallery_enabled'] = true;
$bb_cfg['gallery_show_link'] = true;
$bb_cfg['pic_dir'] = 'pictures/';
$bb_cfg['pic_max_size'] = 2*1024*1024; // 2 MiB
$bb_cfg['auto_delete_posted_pics'] = true; // Delete pictures while delete post?

// Internet Speed
$bb_cfg['user_speeds'][1] = '64kbps';
$bb_cfg['user_speeds'][2] = '128kbps';
$bb_cfg['user_speeds'][3] = '256kbps';
$bb_cfg['user_speeds'][4] = '512kbps';
$bb_cfg['user_speeds'][5] = '768kbps';
$bb_cfg['user_speeds'][6] = '1Mbps';
$bb_cfg['user_speeds'][7] = '1.5Mbps';
$bb_cfg['user_speeds'][8] = '2Mbps';
$bb_cfg['user_speeds'][9] = '3Mbps';
$bb_cfg['user_speeds'][10] = '4Mbps';
$bb_cfg['user_speeds'][11] = '5Mbps';
$bb_cfg['user_speeds'][12] = '6Mbps';
$bb_cfg['user_speeds'][13] = '7Mbps';
$bb_cfg['user_speeds'][14] = '8Mbps';
$bb_cfg['user_speeds'][15] = '9Mbps';
$bb_cfg['user_speeds'][16] = '10Mbps';
$bb_cfg['user_speeds'][17] = '12Mbps';
$bb_cfg['user_speeds'][18] = '14Mbps';
$bb_cfg['user_speeds'][19] = '20Mbps';
$bb_cfg['user_speeds'][20] = '25Mbps';
$bb_cfg['user_speeds'][21] = '30Mbps';
$bb_cfg['user_speeds'][22] = '48Mbps';
$bb_cfg['user_speeds'][23] = '100Mbit';
$bb_cfg['user_speeds'][24] = '1Gbit';

// Friends
$bb_cfg['friends'] = true;

// Chat AJAX
$bb_cfg['ajax_chat'] = true;

// Block posting for new accounts
$bb_cfg['reg_block'] = true;
$bb_cfg['reg_block_time'] = 72000; // 3 часа

// Site content secure
$bb_cfg['content_secure'] = false;

// Dynamic site title
$bb_cfg['dy_site_title'] = false;
$bb_cfg['dy_site_title_speed'] = 300;

// Bonus upload
$bb_cfg['bt_bonus_upload'] = true;
$bb_cfg['bt_bonus_upload_size'] = 1073741824; // 1 GB

// Show names of voted users in polls
$bb_cfg['show_voted_users_polls'] = true;

// Parking accounts addons
$bb_cfg['parking_no_pm'] = true;
$bb_cfg['parking_no_post'] = true;

// Registration at certain hours
$bb_cfg['regtime'] = false;
$bb_cfg['regtime_st'] = 15;
$bb_cfg['regtime_end'] = 19;

// Latest news in sidebar
$bb_cfg['new_add_post_num'] = 5; // количество выводимых сообщений (false - чтобы выключить)
$bb_cfg['new_add_post_ignor_f'] = '0'; // Форумы которые нужно игнорировать ('0' - чтобы выключить)
$bb_cfg['new_add_post_col'] = '#FAA'; // цвет нового сообщения

// Improved captcha
$bb_cfg['use_improved_captcha'] = true;

// Birthday check
$bb_cfg['birthday_enabled'] = true;
$bb_cfg['birthday_check_day'] = 14; // дни (false - чтобы выключить)
$bb_cfg['birthday_max_age'] = 101;
$bb_cfg['birthday_min_age'] = 13;
