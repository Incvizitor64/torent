SET sql_mode = "";

--
-- Удаление старых таблиц
--

DROP TABLE IF EXISTS `bb_ads`;
DROP TABLE IF EXISTS `bb_attach_quota`;
DROP TABLE IF EXISTS `bb_attachments`;
DROP TABLE IF EXISTS `bb_attachments_config`;
DROP TABLE IF EXISTS `bb_attachments_desc`;
DROP TABLE IF EXISTS `bb_attachments_rating`;
DROP TABLE IF EXISTS `bb_auth_access`;
DROP TABLE IF EXISTS `bb_auth_access_snap`;
DROP TABLE IF EXISTS `bb_banlist`;
DROP TABLE IF EXISTS `bb_bt_cheater`;
DROP TABLE IF EXISTS `bb_bt_dlstatus_main`;
DROP TABLE IF EXISTS `bb_bt_dlstatus_mrg`;
DROP TABLE IF EXISTS `bb_bt_dlstatus_new`;
DROP TABLE IF EXISTS `bb_bt_dlstatus_snap`;
DROP TABLE IF EXISTS `bb_bt_last_torstat`;
DROP TABLE IF EXISTS `bb_bt_last_userstat`;
DROP TABLE IF EXISTS `bb_bt_tor_dl_stat`;
DROP TABLE IF EXISTS `bb_bt_torhelp`;
DROP TABLE IF EXISTS `bb_bt_torrents`;
DROP TABLE IF EXISTS `bb_bt_torrents_del`;
DROP TABLE IF EXISTS `bb_bt_torstat`;
DROP TABLE IF EXISTS `bb_bt_tracker`;
DROP TABLE IF EXISTS `bb_bt_tracker_snap`;
DROP TABLE IF EXISTS `bb_bt_user_settings`;
DROP TABLE IF EXISTS `bb_bt_users`;
DROP TABLE IF EXISTS `bb_categories`;
DROP TABLE IF EXISTS `bb_config`;
DROP TABLE IF EXISTS `bb_confirm`;
DROP TABLE IF EXISTS `bb_countries`;
DROP TABLE IF EXISTS `bb_cron`;
DROP TABLE IF EXISTS `bb_datastore`;
DROP TABLE IF EXISTS `bb_disallow`;
DROP TABLE IF EXISTS `bb_extension_groups`;
DROP TABLE IF EXISTS `bb_extensions`;
DROP TABLE IF EXISTS `bb_forums`;
DROP TABLE IF EXISTS `bb_friends`;
DROP TABLE IF EXISTS `bb_gallery`;
DROP TABLE IF EXISTS `bb_groups`;
DROP TABLE IF EXISTS `bb_log`;
DROP TABLE IF EXISTS `bb_posts`;
DROP TABLE IF EXISTS `bb_posts_html`;
DROP TABLE IF EXISTS `bb_posts_search`;
DROP TABLE IF EXISTS `bb_posts_text`;
DROP TABLE IF EXISTS `bb_privmsgs`;
DROP TABLE IF EXISTS `bb_privmsgs_text`;
DROP TABLE IF EXISTS `bb_quota_limits`;
DROP TABLE IF EXISTS `bb_ranks`;
DROP TABLE IF EXISTS `bb_readonly`;
DROP TABLE IF EXISTS `bb_reports`;
DROP TABLE IF EXISTS `bb_reports_changes`;
DROP TABLE IF EXISTS `bb_reports_modules`;
DROP TABLE IF EXISTS `bb_reports_reasons`;
DROP TABLE IF EXISTS `bb_reputation`;
DROP TABLE IF EXISTS `bb_reputation_text`;
DROP TABLE IF EXISTS `bb_search_rebuild`;
DROP TABLE IF EXISTS `bb_search_results`;
DROP TABLE IF EXISTS `bb_shout`;
DROP TABLE IF EXISTS `bb_sessions`;
DROP TABLE IF EXISTS `bb_smilies`;
DROP TABLE IF EXISTS `bb_topic_templates`;
DROP TABLE IF EXISTS `bb_topics`;
DROP TABLE IF EXISTS `bb_topics_bookmark`;
DROP TABLE IF EXISTS `bb_topics_watch`;
DROP TABLE IF EXISTS `bb_textual_confirmation`;
DROP TABLE IF EXISTS `bb_user_group`;
DROP TABLE IF EXISTS `bb_users`;
DROP TABLE IF EXISTS `bb_vote_desc`;
DROP TABLE IF EXISTS `bb_vote_results`;
DROP TABLE IF EXISTS `bb_vote_voters`;
DROP TABLE IF EXISTS `bb_words`;
DROP TABLE IF EXISTS `buf_last_seeder`;
DROP TABLE IF EXISTS `buf_topic_view`;
DROP TABLE IF EXISTS `bb_untrusted_ips`;
DROP TABLE IF EXISTS `invite_rules`;
DROP TABLE IF EXISTS `invites`;
DROP TABLE IF EXISTS `bb_medal`;
DROP TABLE IF EXISTS `bb_medal_cat`;
DROP TABLE IF EXISTS `bb_medal_mod`;
DROP TABLE IF EXISTS `bb_medal_user`;
DROP TABLE IF EXISTS `bb_order`;
DROP TABLE IF EXISTS `bb_order_comment`;

--
-- Структура таблицы `bb_ads`
--

CREATE TABLE IF NOT EXISTS `bb_ads`
(
    `ad_id`          mediumint(8) unsigned NOT NULL auto_increment,
    `ad_block_ids`   varchar(255)          NOT NULL default '',
    `ad_start_time`  datetime              NOT NULL default '1900-01-01 00:00:00',
    `ad_active_days` smallint(6)           NOT NULL default '0',
    `ad_status`      tinyint(4)            NOT NULL default '1',
    `ad_desc`        varchar(255)          NOT NULL default '',
    `ad_html`        text                  NOT NULL,
    PRIMARY KEY (`ad_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_attachments`
--

CREATE TABLE IF NOT EXISTS `bb_attachments`
(
    `attach_id` mediumint(8) unsigned NOT NULL default '0',
    `post_id`   mediumint(8) unsigned NOT NULL default '0',
    `user_id_1` mediumint(8)          NOT NULL default '0',
    PRIMARY KEY (`attach_id`, `post_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_attachments_config`
--

CREATE TABLE IF NOT EXISTS `bb_attachments_config`
(
    `config_name`  varchar(255) NOT NULL default '',
    `config_value` varchar(255) NOT NULL default '',
    PRIMARY KEY (`config_name`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

--
-- Дамп данных таблицы `bb_attachments_config`
--

INSERT INTO `bb_attachments_config`
VALUES ('upload_dir', 'files');
INSERT INTO `bb_attachments_config`
VALUES ('upload_img', 'images/icon_clip.gif');
INSERT INTO `bb_attachments_config`
VALUES ('topic_icon', 'images/icon_clip.gif');
INSERT INTO `bb_attachments_config`
VALUES ('display_order', '0');
INSERT INTO `bb_attachments_config`
VALUES ('max_filesize', '262144');
INSERT INTO `bb_attachments_config`
VALUES ('attachment_quota', '52428800');
INSERT INTO `bb_attachments_config`
VALUES ('max_filesize_pm', '262144');
INSERT INTO `bb_attachments_config`
VALUES ('max_attachments', '1');
INSERT INTO `bb_attachments_config`
VALUES ('max_attachments_pm', '1');
INSERT INTO `bb_attachments_config`
VALUES ('disable_mod', '0');
INSERT INTO `bb_attachments_config`
VALUES ('allow_pm_attach', '1');
INSERT INTO `bb_attachments_config`
VALUES ('allow_ftp_upload', '0');
INSERT INTO `bb_attachments_config`
VALUES ('attach_version', '2.3.14');
INSERT INTO `bb_attachments_config`
VALUES ('default_upload_quota', '0');
INSERT INTO `bb_attachments_config`
VALUES ('default_pm_quota', '0');
INSERT INTO `bb_attachments_config`
VALUES ('ftp_server', '');
INSERT INTO `bb_attachments_config`
VALUES ('ftp_path', '');
INSERT INTO `bb_attachments_config`
VALUES ('download_path', '');
INSERT INTO `bb_attachments_config`
VALUES ('ftp_user', '');
INSERT INTO `bb_attachments_config`
VALUES ('ftp_pass', '');
INSERT INTO `bb_attachments_config`
VALUES ('ftp_pasv_mode', '1');
INSERT INTO `bb_attachments_config`
VALUES ('img_display_inlined', '1');
INSERT INTO `bb_attachments_config`
VALUES ('img_max_width', '200');
INSERT INTO `bb_attachments_config`
VALUES ('img_max_height', '200');
INSERT INTO `bb_attachments_config`
VALUES ('img_link_width', '0');
INSERT INTO `bb_attachments_config`
VALUES ('img_link_height', '0');
INSERT INTO `bb_attachments_config`
VALUES ('img_create_thumbnail', '0');
INSERT INTO `bb_attachments_config`
VALUES ('img_min_thumb_filesize', '12000');
INSERT INTO `bb_attachments_config`
VALUES ('img_imagick', '/usr/bin/convert');
INSERT INTO `bb_attachments_config`
VALUES ('use_gd2', '1');
INSERT INTO `bb_attachments_config`
VALUES ('wma_autoplay', '0');
INSERT INTO `bb_attachments_config`
VALUES ('flash_autoplay', '0');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_attachments_desc`
--

CREATE TABLE IF NOT EXISTS `bb_attachments_desc`
(
    `attach_id`         mediumint(8) unsigned NOT NULL auto_increment,
    `physical_filename` varchar(255)          NOT NULL default '',
    `real_filename`     varchar(255)          NOT NULL default '',
    `download_count`    mediumint(8) unsigned NOT NULL default '0',
    `comment`           varchar(255)          NOT NULL default '',
    `extension`         varchar(100)          NOT NULL default '',
    `mimetype`          varchar(100)          NOT NULL default '',
    `filesize`          int(20)               NOT NULL default '0',
    `filetime`          int(11)               NOT NULL default '0',
    `thumbnail`         tinyint(1)            NOT NULL default '0',
    `tracker_status`    tinyint(1)            NOT NULL default '0',
    `thanks`            mediumint(8)          NOT NULL default '0',
    `rating_sum`        int(11)               NOT NULL default '0',
    `rating_count`      mediumint(8)          NOT NULL default '0',
    PRIMARY KEY (`attach_id`),
    KEY `filetime` (`filetime`),
    KEY `filesize` (`filesize`),
    KEY `physical_filename` (`physical_filename`(10))
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_attachments_rating`
--

CREATE TABLE IF NOT EXISTS `bb_attachments_rating`
(
    `attach_id` mediumint(8) unsigned NOT NULL default '0',
    `user_id`   mediumint(9)          NOT NULL default '0',
    `thanked`   tinyint(1)            NOT NULL default '0',
    `rating`    tinyint(1)            NOT NULL default '0',
    PRIMARY KEY (`attach_id`, `user_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_attach_quota`
--

CREATE TABLE IF NOT EXISTS `bb_attach_quota`
(
    `user_id`        mediumint(8) unsigned NOT NULL default '0',
    `group_id`       mediumint(8) unsigned NOT NULL default '0',
    `quota_type`     smallint(2)           NOT NULL default '0',
    `quota_limit_id` mediumint(8) unsigned NOT NULL default '0',
    KEY `quota_type` (`quota_type`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_auth_access`
--

CREATE TABLE IF NOT EXISTS `bb_auth_access`
(
    `group_id`   mediumint(8)         NOT NULL default '0',
    `forum_id`   smallint(5) unsigned NOT NULL default '0',
    `forum_perm` int(11)              NOT NULL default '0',
    PRIMARY KEY (`group_id`, `forum_id`),
    KEY `forum_id` (`forum_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_auth_access_snap`
--

CREATE TABLE IF NOT EXISTS `bb_auth_access_snap`
(
    `user_id`    mediumint(9) NOT NULL default '0',
    `forum_id`   smallint(6)  NOT NULL default '0',
    `forum_perm` int(11)      NOT NULL default '0',
    PRIMARY KEY (`user_id`, `forum_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_banlist`
--

CREATE TABLE IF NOT EXISTS `bb_banlist`
(
    `ban_id`     mediumint(8) unsigned NOT NULL auto_increment,
    `ban_userid` mediumint(8)          NOT NULL default '0',
    `ban_ip`     varchar(32)           NOT NULL default '',
    `ban_email`  varchar(255)          NOT NULL default '',
    PRIMARY KEY (`ban_id`),
    KEY `ban_ip_user_id` (`ban_ip`, `ban_userid`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_cheater`
--

CREATE TABLE IF NOT EXISTS `bb_bt_cheater`
(
    `log_id`     INT unsigned        NOT NULL auto_increment,
    `user_id`    bigint(20)          NOT NULL,
    `time`       bigint(20) unsigned NOT NULL default '0',
    `torrent_id` bigint(20)          NOT NULL,
    `speed_up`   bigint(20)          NOT NULL,
    `ch_up_tor`  bigint(20) unsigned NOT NULL default '0',
    `ch_up_up`   bigint(20) unsigned NOT NULL default '0',
    `user_ip`    char(8)             not null default '',
    PRIMARY KEY (`log_id`),
    KEY `user_id` (`user_id`),
    KEY `torrent_id` (`torrent_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_dlstatus_main`
--

CREATE TABLE IF NOT EXISTS `bb_bt_dlstatus_main`
(
    `user_id`                mediumint(9)          NOT NULL default '0',
    `topic_id`               mediumint(8) unsigned NOT NULL default '0',
    `user_status`            tinyint(1)            NOT NULL default '0',
    `last_modified_dlstatus` timestamp             NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`, `topic_id`),
    KEY `topic_id` (`topic_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_dlstatus_new`
--

CREATE TABLE IF NOT EXISTS `bb_bt_dlstatus_new`
(
    `user_id`                mediumint(9)          NOT NULL default '0',
    `topic_id`               mediumint(8) unsigned NOT NULL default '0',
    `user_status`            tinyint(1)            NOT NULL default '0',
    `last_modified_dlstatus` timestamp             NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`, `topic_id`),
    KEY `topic_id` (`topic_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_dlstatus_mrg`
--

CREATE TABLE IF NOT EXISTS `bb_bt_dlstatus_mrg`
(
    `user_id`                mediumint(9)          NOT NULL default '0',
    `topic_id`               mediumint(8) unsigned NOT NULL default '0',
    `user_status`            tinyint(1)            NOT NULL default '0',
    `last_modified_dlstatus` timestamp             NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
    KEY `user_topic` (`user_id`, `topic_id`),
    KEY `topic_id` (`topic_id`)
) ENGINE = MRG_MyISAM
  DEFAULT CHARSET = utf8
  UNION = (`bb_bt_dlstatus_main`,`bb_bt_dlstatus_new`);

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_dlstatus_snap`
--

CREATE TABLE IF NOT EXISTS `bb_bt_dlstatus_snap`
(
    `topic_id`    mediumint(8) unsigned NOT NULL default '0',
    `dl_status`   tinyint(4)            NOT NULL default '0',
    `users_count` smallint(5) unsigned  NOT NULL default '0',
    KEY `topic_id` (`topic_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_last_torstat`
--

CREATE TABLE IF NOT EXISTS `bb_bt_last_torstat`
(
    `topic_id`    mediumint(8) unsigned NOT NULL default '0',
    `user_id`     mediumint(9)          NOT NULL default '0',
    `dl_status`   tinyint(1)            NOT NULL default '0',
    `up_add`      bigint(20) unsigned   NOT NULL default '0',
    `down_add`    bigint(20) unsigned   NOT NULL default '0',
    `release_add` bigint(20) unsigned   NOT NULL default '0',
    `bonus_add`   bigint(20) unsigned   NOT NULL default '0',
    `speed_up`    bigint(20) unsigned   NOT NULL default '0',
    `speed_down`  bigint(20) unsigned   NOT NULL default '0',
    PRIMARY KEY USING BTREE (`topic_id`, `user_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_last_userstat`
--

CREATE TABLE IF NOT EXISTS `bb_bt_last_userstat`
(
    `user_id`     mediumint(9)        NOT NULL default '0',
    `up_add`      bigint(20) unsigned NOT NULL default '0',
    `down_add`    bigint(20) unsigned NOT NULL default '0',
    `release_add` bigint(20) unsigned NOT NULL default '0',
    `bonus_add`   bigint(20) unsigned NOT NULL default '0',
    `speed_up`    bigint(20) unsigned NOT NULL default '0',
    `speed_down`  bigint(20) unsigned NOT NULL default '0',
    PRIMARY KEY (`user_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_tor_dl_stat`
--

CREATE TABLE IF NOT EXISTS `bb_bt_tor_dl_stat`
(
    `topic_id`      mediumint(8) unsigned NOT NULL default '0',
    `user_id`       mediumint(9)          NOT NULL default '0',
    `attach_id`     mediumint(8) unsigned NOT NULL default '0',
    `t_up_total`    bigint(20) unsigned   NOT NULL default '0',
    `t_down_total`  bigint(20) unsigned   NOT NULL default '0',
    `t_bonus_total` bigint(20) unsigned   NOT NULL default '0',
    PRIMARY KEY (`topic_id`, `user_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;
-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_torhelp`
--

CREATE TABLE IF NOT EXISTS `bb_bt_torhelp`
(
    `user_id`      mediumint(9) NOT NULL default '0',
    `topic_id_csv` text         NOT NULL,
    PRIMARY KEY (`user_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_torrents`
--

CREATE TABLE IF NOT EXISTS `bb_bt_torrents`
(
    `info_hash`                varbinary(20)         NOT NULL,
    `post_id`                  mediumint(8) unsigned NOT NULL default '0',
    `poster_id`                mediumint(9)          NOT NULL default '0',
    `topic_id`                 mediumint(8) unsigned NOT NULL default '0',
    `forum_id`                 smallint(5) unsigned  NOT NULL default '0',
    `attach_id`                mediumint(8) unsigned NOT NULL default '0',
    `size`                     bigint(20) unsigned   NOT NULL default '0',
    `reg_time`                 int(11)               NOT NULL default '0',
    `call_seed_time`           int(11)               NOT NULL default '0',
    `complete_count`           mediumint(8) unsigned NOT NULL default '0',
    `seeder_last_seen`         int(11)               NOT NULL default '0',
    `tor_status`               tinyint(4)            NOT NULL default '0',
    `checked_user_id`          mediumint(8)          NOT NULL default '0',
    `checked_time`             int(11)               NOT NULL default '0',
    `tor_type`                 TINYINT(1)            NOT NULL default '0',
    `tor_type_time`            int(11)               NOT NULL default '-1',
    `speed_up`                 mediumint(8)          NOT NULL default '0',
    `speed_down`               mediumint(8)          NOT NULL default '0',
    `multi_trackers_and_peers` text                  NOT NULL,
    `multi_updated_date`       int                   NOT NULL,
    `multi_tracker_use`        tinyint(1)            NOT NULL DEFAULT '0',
    PRIMARY KEY (`info_hash`),
    UNIQUE KEY `post_id` (`post_id`),
    UNIQUE KEY `topic_id` (`topic_id`),
    UNIQUE KEY `attach_id` (`attach_id`),
    KEY `reg_time` (`reg_time`),
    KEY `forum_id` (`forum_id`),
    KEY `poster_id` (`poster_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_torrents_del`
--

CREATE TABLE IF NOT EXISTS `bb_bt_torrents_del`
(
    `topic_id`   mediumint(8) unsigned NOT NULL,
    `info_hash`  tinyblob              NOT NULL,
    `is_del`     tinyint(4)            NOT NULL default '1',
    `dl_percent` tinyint(4)            NOT NULL default '100',
    PRIMARY KEY (`topic_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;
-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_torstat`
--

CREATE TABLE IF NOT EXISTS `bb_bt_torstat`
(
    `topic_id`              mediumint(8) unsigned NOT NULL default '0',
    `user_id`               mediumint(9)          NOT NULL default '0',
    `last_modified_torstat` timestamp             NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
    `completed`             tinyint(1)            NOT NULL default '0',
    PRIMARY KEY (`topic_id`, `user_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_tracker`
--

CREATE TABLE IF NOT EXISTS `bb_bt_tracker`
(
    `peer_hash`        varchar(32) character set utf8 collate utf8_bin NOT NULL default '',
    `topic_id`         mediumint(8) unsigned                           NOT NULL default '0',
    `peer_id`          varchar(20)                                     NOT NULL,
    `user_id`          mediumint(9)                                    NOT NULL default '0',
    `ip`               char(8) character set utf8 collate utf8_bin     NOT NULL default '0',
    `ipv6`             varchar(32)                                              DEFAULT NULL,
    `port`             smallint(5) unsigned                            NOT NULL default '0',
    `seeder`           tinyint(1)                                      NOT NULL default '0',
    `releaser`         tinyint(1)                                      NOT NULL default '0',
    `tor_type`         TINYINT(1)                                      NOT NULL DEFAULT '0',
    `uploaded`         bigint(20) unsigned                             NOT NULL default '0',
    `downloaded`       bigint(20) unsigned                             NOT NULL default '0',
    `remain`           bigint(20) unsigned                             NOT NULL default '0',
    `speed_up`         mediumint(8) unsigned                           NOT NULL default '0',
    `speed_down`       mediumint(8) unsigned                           NOT NULL default '0',
    `up_add`           bigint(20) unsigned                             NOT NULL default '0',
    `down_add`         bigint(20) unsigned                             NOT NULL default '0',
    `update_time`      int(11)                                         NOT NULL default '0',
    `xbt_error`        varchar(200)                                             DEFAULT NULL,
    `ul_gdc`           bigint(20) unsigned                             NOT NULL DEFAULT '0',
    `ul_gdc_c`         mediumint(9) unsigned                           NOT NULL DEFAULT '0',
    `ul_16k_c`         mediumint(9) unsigned                           NOT NULL DEFAULT '0',
    `ul_eq_dl`         mediumint(9) unsigned                           NOT NULL DEFAULT '0',
    `complete_percent` bigint(20)                                      NOT NULL default '0',
    PRIMARY KEY (`peer_hash`),
    KEY `topic_id` (`topic_id`),
    KEY `user_id` (`user_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_tracker_snap`
--

CREATE TABLE IF NOT EXISTS `bb_bt_tracker_snap`
(
    `topic_id`   mediumint(8) unsigned NOT NULL default '0',
    `seeders`    mediumint(8) unsigned NOT NULL default '0',
    `leechers`   mediumint(8) unsigned NOT NULL default '0',
    `speed_up`   int(10) unsigned      NOT NULL default '0',
    `speed_down` int(10) unsigned      NOT NULL default '0',
    PRIMARY KEY (`topic_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_users`
--

CREATE TABLE IF NOT EXISTS `bb_bt_users`
(
    `user_id`              mediumint(9)                                 NOT NULL default '0',
    `auth_key`             char(10) character set utf8 collate utf8_bin NOT NULL default '',
    `u_up_total`           bigint(20) unsigned                          NOT NULL default '0',
    `u_down_total`         bigint(20) unsigned                          NOT NULL default '0',
    `u_up_release`         bigint(20) unsigned                          NOT NULL default '0',
    `u_up_bonus`           bigint(20) unsigned                          NOT NULL default '0',
    `up_last`              bigint(20) unsigned                          NOT NULL default '0',
    `down_last`            bigint(20) unsigned                          NOT NULL default '0',
    `release_last`         bigint(20) unsigned                          NOT NULL default '0',
    `bonus_last`           bigint(20) unsigned                          NOT NULL default '0',
    `speed_up_last`        bigint(20) unsigned                          NOT NULL default '0',
    `speed_down_last`      bigint(20) unsigned                          NOT NULL default '0',
    `up_today`             bigint(20) unsigned                          NOT NULL default '0',
    `down_today`           bigint(20) unsigned                          NOT NULL default '0',
    `release_today`        bigint(20) unsigned                          NOT NULL default '0',
    `bonus_today`          bigint(20) unsigned                          NOT NULL default '0',
    `speed_up_today`       bigint(20) unsigned                          NOT NULL default '0',
    `speed_down_today`     bigint(20) unsigned                          NOT NULL default '0',
    `up_yesterday`         bigint(20) unsigned                          NOT NULL default '0',
    `down_yesterday`       bigint(20) unsigned                          NOT NULL default '0',
    `release_yesterday`    bigint(20) unsigned                          NOT NULL default '0',
    `bonus_yesterday`      bigint(20) unsigned                          NOT NULL default '0',
    `speed_up_yesterday`   bigint(20) unsigned                          NOT NULL default '0',
    `speed_down_yesterday` bigint(20) unsigned                          NOT NULL default '0',
    PRIMARY KEY (`user_id`),
    UNIQUE KEY `auth_key` (`auth_key`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_bt_user_settings`
--

CREATE TABLE IF NOT EXISTS `bb_bt_user_settings`
(
    `user_id`        mediumint(9) NOT NULL default '0',
    `tor_search_set` text         NOT NULL,
    `last_modified`  int(11)      NOT NULL default '0',
    PRIMARY KEY (`user_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_categories`
--

CREATE TABLE IF NOT EXISTS `bb_categories`
(
    `cat_id`    smallint(5) unsigned NOT NULL auto_increment,
    `cat_title` varchar(100)         NOT NULL default '',
    `cat_order` smallint(5) unsigned NOT NULL default '0',
    `cat_image` varchar(40)          NOT NULL default '',
    PRIMARY KEY (`cat_id`),
    KEY `cat_order` (`cat_order`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 2;

--
-- Дамп данных таблицы `bb_categories`
--

INSERT INTO `bb_categories`
VALUES (1, 'Test category 1', 10, '');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_config`
--

CREATE TABLE IF NOT EXISTS `bb_config`
(
    `config_name`  varchar(255) NOT NULL default '',
    `config_value` text         NOT NULL,
    PRIMARY KEY (`config_name`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

--
-- Дамп данных таблицы `bb_config`
--

INSERT INTO `bb_config`
VALUES ('allow_autologin', '1');
INSERT INTO `bb_config`
VALUES ('allow_avatar_local', '0');
INSERT INTO `bb_config`
VALUES ('allow_avatar_remote', '0');
INSERT INTO `bb_config`
VALUES ('allow_avatar_upload', '1');
INSERT INTO `bb_config`
VALUES ('allow_bbcode', '1');
INSERT INTO `bb_config`
VALUES ('allow_namechange', '0');
INSERT INTO `bb_config`
VALUES ('allow_sig', '1');
INSERT INTO `bb_config`
VALUES ('allow_smilies', '1');
INSERT INTO `bb_config`
VALUES ('avatar_filesize', '10000');
INSERT INTO `bb_config`
VALUES ('avatar_gallery_path', 'images/avatars/gallery');
INSERT INTO `bb_config`
VALUES ('avatar_max_height', '100');
INSERT INTO `bb_config`
VALUES ('avatar_max_width', '100');
INSERT INTO `bb_config`
VALUES ('avatar_path', 'images/avatars');
INSERT INTO `bb_config`
VALUES ('board_disable', '0');
INSERT INTO `bb_config`
VALUES ('board_email', 'board_email@yourdomain.com');
INSERT INTO `bb_config`
VALUES ('board_email_form', '0');
INSERT INTO `bb_config`
VALUES ('board_email_sig', 'Thanks, The Management');
INSERT INTO `bb_config`
VALUES ('board_startdate', UNIX_TIMESTAMP());
INSERT INTO `bb_config`
VALUES ('board_timezone', '3');
INSERT INTO `bb_config`
VALUES ('bt_add_auth_key', '1');
INSERT INTO `bb_config`
VALUES ('bt_add_comment', '');
INSERT INTO `bb_config`
VALUES ('bt_add_publisher', 'YourSiteName');
INSERT INTO `bb_config`
VALUES ('bt_allow_spmode_change', '1');
INSERT INTO `bb_config`
VALUES ('bt_announce_url', 'http://yourdomain.com/bt/announce.php');
INSERT INTO `bb_config`
VALUES ('bt_disable_dht', '0');
INSERT INTO `bb_config`
VALUES ('bt_check_announce_url', '0');
INSERT INTO `bb_config`
VALUES ('bt_del_addit_ann_urls', '1');
INSERT INTO `bb_config`
VALUES ('bt_dl_list_only_1st_page', '1');
INSERT INTO `bb_config`
VALUES ('bt_dl_list_only_count', '1');
INSERT INTO `bb_config`
VALUES ('bt_gen_passkey_on_reg', '1');
INSERT INTO `bb_config`
VALUES ('bt_newtopic_auto_reg', '1');
INSERT INTO `bb_config`
VALUES ('bt_replace_ann_url', '1');
INSERT INTO `bb_config`
VALUES ('bt_search_bool_mode', '1');
INSERT INTO `bb_config`
VALUES ('bt_set_dltype_on_tor_reg', '1');
INSERT INTO `bb_config`
VALUES ('bt_show_dl_but_cancel', '1');
INSERT INTO `bb_config`
VALUES ('bt_show_dl_but_compl', '1');
INSERT INTO `bb_config`
VALUES ('bt_show_dl_but_down', '0');
INSERT INTO `bb_config`
VALUES ('bt_show_dl_but_will', '1');
INSERT INTO `bb_config`
VALUES ('bt_show_dl_list', '0');
INSERT INTO `bb_config`
VALUES ('bt_show_dl_list_buttons', '1');
INSERT INTO `bb_config`
VALUES ('bt_show_dl_stat_on_index', '1');
INSERT INTO `bb_config`
VALUES ('bt_show_ip_only_moder', '1');
INSERT INTO `bb_config`
VALUES ('bt_show_peers', '1');
INSERT INTO `bb_config`
VALUES ('bt_show_peers_mode', '1');
INSERT INTO `bb_config`
VALUES ('bt_show_port_only_moder', '1');
INSERT INTO `bb_config`
VALUES ('bt_tor_browse_only_reg', '0');
INSERT INTO `bb_config`
VALUES ('bt_unset_dltype_on_tor_unreg', '0');
INSERT INTO `bb_config`
VALUES ('config_id', '1');
INSERT INTO `bb_config`
VALUES ('cron_last_check', '1211477514');
INSERT INTO `bb_config`
VALUES ('default_dateformat', 'Y-m-d H:i');
INSERT INTO `bb_config`
VALUES ('default_lang', 'russian');
INSERT INTO `bb_config`
VALUES ('enable_confirm', '1');
INSERT INTO `bb_config`
VALUES ('flood_interval', '15');
INSERT INTO `bb_config`
VALUES ('hot_threshold', '300');
INSERT INTO `bb_config`
VALUES ('login_reset_time', '30');
INSERT INTO `bb_config`
VALUES ('max_autologin_time', '10');
INSERT INTO `bb_config`
VALUES ('max_inbox_privmsgs', '200');
INSERT INTO `bb_config`
VALUES ('max_login_attempts', '5');
INSERT INTO `bb_config`
VALUES ('max_poll_options', '6');
INSERT INTO `bb_config`
VALUES ('max_savebox_privmsgs', '50');
INSERT INTO `bb_config`
VALUES ('max_sentbox_privmsgs', '25');
INSERT INTO `bb_config`
VALUES ('max_sig_chars', '255');
INSERT INTO `bb_config`
VALUES ('posts_per_page', '15');
INSERT INTO `bb_config`
VALUES ('privmsg_disable', '0');
INSERT INTO `bb_config`
VALUES ('prune_enable', '1');
INSERT INTO `bb_config`
VALUES ('record_online_date', '1211477508');
INSERT INTO `bb_config`
VALUES ('record_online_users', '2');
INSERT INTO `bb_config`
VALUES ('require_activation', '0');
INSERT INTO `bb_config`
VALUES ('sendmail_fix', '0');
INSERT INTO `bb_config`
VALUES ('site_desc', 'A _little_ text to describe your forum');
INSERT INTO `bb_config`
VALUES ('sitename', 'yourdomain.com');
INSERT INTO `bb_config`
VALUES ('smilies_path', 'images/smiles');
INSERT INTO `bb_config`
VALUES ('smtp_delivery', '0');
INSERT INTO `bb_config`
VALUES ('smtp_host', '');
INSERT INTO `bb_config`
VALUES ('smtp_password', '');
INSERT INTO `bb_config`
VALUES ('smtp_username', '');
INSERT INTO `bb_config`
VALUES ('topics_per_page', '50');
INSERT INTO `bb_config`
VALUES ('version', '.0.22');
INSERT INTO `bb_config`
VALUES ('xs_add_comments', '0');
INSERT INTO `bb_config`
VALUES ('xs_auto_compile', '1');
INSERT INTO `bb_config`
VALUES ('xs_auto_recompile', '1');
INSERT INTO `bb_config`
VALUES ('xs_php', 'php');
INSERT INTO `bb_config`
VALUES ('xs_shownav', '17');
INSERT INTO `bb_config`
VALUES ('xs_template_time', '0');
INSERT INTO `bb_config`
VALUES ('xs_use_cache', '1');
INSERT INTO `bb_config`
VALUES ('xs_version', '8');
INSERT INTO `bb_config`
VALUES ('active_ads', 'a:0:{}');

INSERT INTO `bb_config`
VALUES ('report_subject_auth', '1');
INSERT INTO `bb_config`
VALUES ('report_modules_cache', '1');
INSERT INTO `bb_config`
VALUES ('report_hack_count', '0');
INSERT INTO `bb_config`
VALUES ('report_notify', '0');
INSERT INTO `bb_config`
VALUES ('report_list_admin', '0');
INSERT INTO `bb_config`
VALUES ('report_new_window', '0');

INSERT INTO `bb_config`
VALUES ('join_interval', '18');

INSERT INTO `bb_config`
VALUES ('warnings_enabled', '1');
INSERT INTO `bb_config`
VALUES ('reputation_enabled', '1');
INSERT INTO `bb_config`
VALUES ('reputation_least_respected', '0');
INSERT INTO `bb_config`
VALUES ('reputation_ban_warnings', '5');
INSERT INTO `bb_config`
VALUES ('reputation_delete_expired', '-1');
INSERT INTO `bb_config`
VALUES ('reputation_warning_expire', '3,30');
INSERT INTO `bb_config`
VALUES ('reputation_ban_expire', '3,30');
INSERT INTO `bb_config`
VALUES ('reputation_perms', '1,1,1,3,3,3,3,5,3,5,3,3,3');
INSERT INTO `bb_config`
VALUES ('reputation_none', '0,0');
INSERT INTO `bb_config`
VALUES ('reputation_mod_norep', '0');
INSERT INTO `bb_config`
VALUES ('reputation_reviews_per_page', '25');
INSERT INTO `bb_config`
VALUES ('reputation_reports_per_page', '25');
INSERT INTO `bb_config`
VALUES ('reputation_display', '1');
INSERT INTO `bb_config`
VALUES ('reputation_warnings_display', 'img');
INSERT INTO `bb_config`
VALUES ('reputation_most_respected', '0');
INSERT INTO `bb_config`
VALUES ('reputation_days_req', '0');
INSERT INTO `bb_config`
VALUES ('reputation_posts_req', '0');
INSERT INTO `bb_config`
VALUES ('reputation_points_req', '-100000');
INSERT INTO `bb_config`
VALUES ('reputation_warnings_req', '100000');
INSERT INTO `bb_config`
VALUES ('reputation_rotation_limit', '0');
INSERT INTO `bb_config`
VALUES ('reputation_time_limit', '0');
INSERT INTO `bb_config`
VALUES ('reputation_check_rate', '60');
INSERT INTO `bb_config`
VALUES ('reputation_last_check_time', '0');
INSERT INTO `bb_config`
VALUES ('reputation_empty_reviews', '0');
INSERT INTO `bb_config`
VALUES ('reputation_positive_only', '0');
INSERT INTO `bb_config`
VALUES ('reputation_admin_norep', '0');
INSERT INTO `bb_config`
VALUES ('reputation_giving', '');
INSERT INTO `bb_config`
VALUES ('reputation_notify_reputation', 'none');
INSERT INTO `bb_config`
VALUES ('reputation_notify_warning', 'none');
INSERT INTO `bb_config`
VALUES ('reputation_notify_ban', 'email');
INSERT INTO `bb_config`
VALUES ('reputation_auto_data', '');
INSERT INTO `bb_config`
VALUES ('reputation_memberlist', '11');
INSERT INTO `bb_config`
VALUES ('reputation_show_values', '0');
INSERT INTO `bb_config`
VALUES ('reputation_default_order', '1');

INSERT INTO `bb_config`
VALUES ('invite_enabled', '0');

INSERT INTO `bb_config`
VALUES ('description_word_count', 150);
INSERT INTO `bb_config`
VALUES ('use_dynamic_description', 1);
INSERT INTO `bb_config`
VALUES ('append_keywords_first', 0);
INSERT INTO `bb_config`
VALUES ('global_keywords', 'подставьте, сюда, свои, ключевые, слова');
INSERT INTO `bb_config`
VALUES ('append_global_keywords', 1);
INSERT INTO `bb_config`
VALUES ('keyword_word_count', 50);
INSERT INTO `bb_config`
VALUES ('use_dynamic_keywords', 1);

INSERT INTO `bb_config`
VALUES ('gold', '0');
INSERT INTO `bb_config`
VALUES ('torrent_style', '1');
INSERT INTO `bb_config`
VALUES ('new_user_reg_disabled', '0');
INSERT INTO `bb_config`
VALUES ('unique_ip', '0');
INSERT INTO `bb_config`
VALUES ('emailer_disabled', '0');
INSERT INTO `bb_config`
VALUES ('topic_notify_enabled', '0');
INSERT INTO `bb_config`
VALUES ('pm_notify_enabled', '0');
INSERT INTO `bb_config`
VALUES ('groupcp_send_email', '1');
INSERT INTO `bb_config`
VALUES ('email_change_disabled', '0');
INSERT INTO `bb_config`
VALUES ('show_latest_news', '1');
INSERT INTO `bb_config`
VALUES ('show_quick_reply', '1');
INSERT INTO `bb_config`
VALUES ('show_rank_text', '0');
INSERT INTO `bb_config`
VALUES ('show_rank_image', '1');
INSERT INTO `bb_config`
VALUES ('show_poster_joined', '1');
INSERT INTO `bb_config`
VALUES ('show_poster_posts', '1');
INSERT INTO `bb_config`
VALUES ('show_poster_from', '1');
INSERT INTO `bb_config`
VALUES ('show_poster_flag', '1');
INSERT INTO `bb_config`
VALUES ('show_bot_nick', '1');
INSERT INTO `bb_config`
VALUES ('text_buttons', '0');
INSERT INTO `bb_config`
VALUES ('parse_ed2k_links', '1');
INSERT INTO `bb_config`
VALUES ('topic_bookmark_enabled', '1');
INSERT INTO `bb_config`
VALUES ('show_virtual_keyboard', '1');
INSERT INTO `bb_config`
VALUES ('magnet_links_enabled', '1');
INSERT INTO `bb_config`
VALUES ('avatar_by_default', '1');
INSERT INTO `bb_config`
VALUES ('avatar_by_default_path', 'noavatar.png');
INSERT INTO `bb_config`
VALUES ('logo_image_path', 'images/logo');
INSERT INTO `bb_config`
VALUES ('logo_image', 'logo.gif');
INSERT INTO `bb_config`
VALUES ('logo_image_w', '285');
INSERT INTO `bb_config`
VALUES ('logo_image_h', '90');

INSERT INTO `bb_config`
VALUES ('allow_medal_display', '1');
INSERT INTO `bb_config`
VALUES ('medal_display_row', '6');
INSERT INTO `bb_config`
VALUES ('medal_display_col', '4');
INSERT INTO `bb_config`
VALUES ('medal_display_width', '');
INSERT INTO `bb_config`
VALUES ('medal_display_height', '');
INSERT INTO `bb_config`
VALUES ('medal_display_order', '0');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_confirm`
--

CREATE TABLE IF NOT EXISTS `bb_confirm`
(
    `confirm_id` char(12) character set utf8 collate utf8_bin NOT NULL default '',
    `session_id` char(20) character set utf8 collate utf8_bin NOT NULL default '',
    `code`       char(6)                                      NOT NULL default '',
    PRIMARY KEY (`session_id`, `confirm_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_countries`
--

CREATE TABLE IF NOT EXISTS `bb_countries`
(
    `country_id`    mediumint(3) NOT NULL auto_increment,
    `country_code`  varchar(3)   NOT NULL default '0',
    `country_code2` varchar(2)   NOT NULL,
    `country_code3` varchar(3)   NOT NULL,
    PRIMARY KEY (`country_id`),
    KEY `country_code2` (`country_code2`),
    KEY `country_code3` (`country_code3`),
    KEY `country_code` (`country_code`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 245;

--
-- Дамп данных таблицы `bb_countries`
--

INSERT INTO `bb_countries` (`country_id`, `country_code`, `country_code2`, `country_code3`)
VALUES (1, '036', 'AU', 'AUS'),
       (2, '040', 'AT', 'AUT'),
       (3, '031', 'AZ', 'AZE'),
       (4, '248', 'AX', 'ALA'),
       (5, '008', 'AL', 'ALB'),
       (6, '012', 'DZ', 'DZA'),
       (7, '581', 'UM', 'UMI'),
       (8, '850', 'VI', 'VIR'),
       (9, '016', 'AS', 'ASM'),
       (10, '660', 'AI', 'AIA'),
       (11, '024', 'AO', 'AGO'),
       (12, '020', 'AD', 'AND'),
       (13, '010', 'AQ', 'ATA'),
       (14, '028', 'AG', 'ATG'),
       (15, '032', 'AR', 'ARG'),
       (16, '051', 'AM', 'ARM'),
       (17, '533', 'AW', 'ABW'),
       (18, '004', 'AF', 'AFG'),
       (19, '044', 'BS', 'BHS'),
       (20, '050', 'BD', 'BGD'),
       (21, '052', 'BB', 'BRB'),
       (22, '048', 'BH', 'BHR'),
       (23, '084', 'BZ', 'BLZ'),
       (24, '112', 'BY', 'BLR'),
       (25, '056', 'BE', 'BEL'),
       (26, '204', 'BJ', 'BEN'),
       (27, '060', 'BM', 'BMU'),
       (28, '100', 'BG', 'BGR'),
       (29, '068', 'BO', 'BOL'),
       (30, '070', 'BA', 'BIH'),
       (31, '072', 'BW', 'BWA'),
       (32, '076', 'BR', 'BRA'),
       (33, '086', 'IO', 'IOT'),
       (34, '092', 'VG', 'VGB'),
       (35, '096', 'BN', 'BRN'),
       (36, '854', 'BF', 'BFA'),
       (37, '108', 'BI', 'BDI'),
       (38, '064', 'BT', 'BTN'),
       (39, '548', 'VU', 'VUT'),
       (40, '336', 'VA', 'VAT'),
       (41, '826', 'GB', 'GBR'),
       (42, '348', 'HU', 'HUN'),
       (43, '862', 'VE', 'VEN'),
       (44, '626', 'TL', 'TLS'),
       (45, '704', 'VN', 'VNM'),
       (46, '266', 'GA', 'GAB'),
       (47, '332', 'HT', 'HTI'),
       (48, '328', 'GY', 'GUY'),
       (49, '270', 'GM', 'GMB'),
       (50, '288', 'GH', 'GHA'),
       (51, '312', 'GP', 'GLP'),
       (52, '320', 'GT', 'GTM'),
       (53, '324', 'GN', 'GIN'),
       (54, '624', 'GW', 'GNB'),
       (55, '276', 'DE', 'DEU'),
       (56, '292', 'GI', 'GIB'),
       (57, '340', 'HN', 'HND'),
       (58, '344', 'HK', 'HKG'),
       (59, '308', 'GD', 'GRD'),
       (60, '304', 'GL', 'GRL'),
       (61, '300', 'GR', 'GRC'),
       (62, '268', 'GE', 'GEO'),
       (63, '316', 'GU', 'GUM'),
       (64, '208', 'DK', 'DNK'),
       (65, '180', 'CD', 'COD'),
       (66, '262', 'DJ', 'DJI'),
       (67, '212', 'DM', 'DMA'),
       (68, '214', 'DO', 'DOM'),
       (69, 'EU', 'EU', ''),
       (70, '818', 'EG', 'EGY'),
       (71, '894', 'ZM', 'ZMB'),
       (72, '732', 'EH', 'ESH'),
       (73, '716', 'ZW', 'ZWE'),
       (74, '376', 'IL', 'ISR'),
       (75, '356', 'IN', 'IND'),
       (76, '360', 'ID', 'IDN'),
       (77, '400', 'JO', 'JOR'),
       (78, '368', 'IQ', 'IRQ'),
       (79, '364', 'IR', 'IRN'),
       (80, '372', 'IE', 'IRL'),
       (81, '352', 'IS', 'ISL'),
       (82, '724', 'ES', 'ESP'),
       (83, '380', 'IT', 'ITA'),
       (84, '887', 'YE', 'YEM'),
       (85, '408', 'KP', 'PRK'),
       (86, '132', 'CV', 'CPV'),
       (87, '398', 'KZ', 'KAZ'),
       (88, '136', 'KY', 'CYM'),
       (89, '116', 'KH', 'KHM'),
       (90, '120', 'CM', 'CMR'),
       (91, '124', 'CA', 'CAN'),
       (92, '634', 'QA', 'QAT'),
       (93, '404', 'KE', 'KEN'),
       (94, '196', 'CY', 'CYP'),
       (95, '417', 'KG', 'KGZ'),
       (96, '296', 'KI', 'KIR'),
       (97, '156', 'CN', 'CHN'),
       (98, '166', 'CC', 'CCK'),
       (99, '170', 'CO', 'COL'),
       (100, '174', 'KM', 'COM'),
       (101, '188', 'CR', 'CRI'),
       (102, '384', 'CI', 'CIV'),
       (103, '192', 'CU', 'CUB'),
       (104, '414', 'KW', 'KWT'),
       (105, '418', 'LA', 'LAO'),
       (106, '428', 'LV', 'LVA'),
       (107, '426', 'LS', 'LSO'),
       (108, '430', 'LR', 'LBR'),
       (109, '422', 'LB', 'LBN'),
       (110, '434', 'LY', 'LBY'),
       (111, '440', 'LT', 'LTU'),
       (112, '438', 'LI', 'LIE'),
       (113, '442', 'LU', 'LUX'),
       (114, '480', 'MU', 'MUS'),
       (115, '478', 'MR', 'MRT'),
       (116, '450', 'MG', 'MDG'),
       (117, '175', 'YT', 'MYT'),
       (118, '446', 'MO', 'MAC'),
       (119, '807', 'MK', 'MKD'),
       (120, '454', 'MW', 'MWI'),
       (121, '458', 'MY', 'MYS'),
       (122, '466', 'ML', 'MLI'),
       (123, '462', 'MV', 'MDV'),
       (124, '470', 'MT', 'MLT'),
       (125, '504', 'MA', 'MAR'),
       (126, '474', 'MQ', 'MTQ'),
       (127, '584', 'MH', 'MHL'),
       (128, '484', 'MX', 'MEX'),
       (129, '508', 'MZ', 'MOZ'),
       (130, '498', 'MD', 'MDA'),
       (131, '492', 'MC', 'MCO'),
       (132, '496', 'MN', 'MNG'),
       (133, '500', 'MS', 'MSR'),
       (134, '104', 'MM', 'MMR'),
       (135, '516', 'NA', 'NAM'),
       (136, '520', 'NR', 'NRU'),
       (137, '524', 'NP', 'NPL'),
       (138, '562', 'NE', 'NER'),
       (139, '566', 'NG', 'NGA'),
       (140, '530', 'AN', 'ANT'),
       (141, '528', 'NL', 'NLD'),
       (142, '558', 'NI', 'NIC'),
       (143, '570', 'NU', 'NIU'),
       (144, '540', 'NC', 'NCL'),
       (145, '554', 'NZ', 'NZL'),
       (146, '578', 'NO', 'NOR'),
       (147, '784', 'AE', 'ARE'),
       (148, '512', 'OM', 'OMN'),
       (149, '162', 'CX', 'CXR'),
       (150, '184', 'CK', 'COK'),
       (151, '334', 'HM', 'HMD'),
       (152, '586', 'PK', 'PAK'),
       (153, '585', 'PW', 'PLW'),
       (154, '275', 'PS', 'PSE'),
       (155, '591', 'PA', 'PAN'),
       (156, '598', 'PG', 'PNG'),
       (157, '600', 'PY', 'PRY'),
       (158, '604', 'PE', 'PER'),
       (159, '612', 'PN', 'PCN'),
       (160, '616', 'PL', 'POL'),
       (161, '620', 'PT', 'PRT'),
       (162, '630', 'PR', 'PRI'),
       (163, '178', 'CG', 'COG'),
       (164, '638', 'RE', 'REU'),
       (165, '643', 'RU', 'RUS'),
       (166, '646', 'RW', 'RWA'),
       (167, '642', 'RO', 'ROU'),
       (168, '840', 'US', 'USA'),
       (169, '222', 'SV', 'SLV'),
       (170, '882', 'WS', 'WSM'),
       (171, '674', 'SM', 'SMR'),
       (172, '678', 'ST', 'STP'),
       (173, '682', 'SA', 'SAU'),
       (174, '748', 'SZ', 'SWZ'),
       (175, '744', 'SJ', 'SJM'),
       (176, '580', 'MP', 'MNP'),
       (177, '690', 'SC', 'SYC'),
       (178, '686', 'SN', 'SEN'),
       (179, '670', 'VC', 'VCT'),
       (180, '659', 'KN', 'KNA'),
       (181, '662', 'LC', 'LCA'),
       (182, '666', 'PM', 'SPM'),
       (183, '688', 'RS', 'SRB'),
       (184, '891', 'CS', 'SCG'),
       (185, '702', 'SG', 'SGP'),
       (186, '760', 'SY', 'SYR'),
       (187, '703', 'SK', 'SVK'),
       (188, '705', 'SI', 'SVN'),
       (189, '090', 'SB', 'SLB'),
       (190, '706', 'SO', 'SOM'),
       (191, '736', 'SD', 'SDN'),
       (192, '740', 'SR', 'SUR'),
       (193, '694', 'SL', 'SLE'),
       (194, '810', 'SU', 'SUN'),
       (195, '762', 'TJ', 'TJK'),
       (196, '764', 'TH', 'THA'),
       (197, '158', 'TW', 'TWN'),
       (198, '834', 'TZ', 'TZA'),
       (199, '768', 'TG', 'TGO'),
       (200, '772', 'TK', 'TKL'),
       (201, '776', 'TO', 'TON'),
       (202, '780', 'TT', 'TTO'),
       (203, '798', 'TV', 'TUV'),
       (204, '788', 'TN', 'TUN'),
       (205, '795', 'TM', 'TKM'),
       (206, '792', 'TR', 'TUR'),
       (207, '800', 'UG', 'UGA'),
       (208, '860', 'UZ', 'UZB'),
       (209, '804', 'UA', 'UKR'),
       (210, '858', 'UY', 'URY'),
       (211, '234', 'FO', 'FRO'),
       (212, '583', 'FM', 'FSM'),
       (213, '242', 'FJ', 'FJI'),
       (214, '608', 'PH', 'PHL'),
       (215, '246', 'FI', 'FIN'),
       (216, '238', 'FK', 'FLK'),
       (217, '250', 'FR', 'FRA'),
       (218, '254', 'GF', 'GUF'),
       (219, '258', 'PF', 'PYF'),
       (220, '260', 'TF', 'ATF'),
       (221, '191', 'HR', 'HRV'),
       (222, '140', 'CF', 'CAF'),
       (223, '148', 'TD', 'TCD'),
       (224, '499', 'ME', 'MNE'),
       (225, '203', 'CZ', 'CZE'),
       (226, '152', 'CL', 'CHL'),
       (227, '756', 'CH', 'CHE'),
       (228, '752', 'SE', 'SWE'),
       (229, '144', 'LK', 'LKA'),
       (230, '218', 'EC', 'ECU'),
       (231, '226', 'GQ', 'GNQ'),
       (232, '232', 'ER', 'ERI'),
       (233, '233', 'EE', 'EST'),
       (234, '231', 'ET', 'ETH'),
       (235, '710', 'ZA', 'ZAF'),
       (236, '410', 'KR', 'KOR'),
       (237, '239', 'GS', 'SGS'),
       (238, '388', 'JM', 'JAM'),
       (239, '392', 'JP', 'JPN'),
       (240, '074', 'BV', 'BVT'),
       (241, '574', 'NF', 'NFK'),
       (242, '654', 'SH', 'SHN'),
       (243, '796', 'TC', 'TCA'),
       (244, '876', 'WF', 'WLF');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_cron`
--

CREATE TABLE IF NOT EXISTS `bb_cron`
(
    `cron_id`         smallint(5) unsigned                                  NOT NULL auto_increment,
    `cron_active`     tinyint(4)                                            NOT NULL                                                                            default '1',
    `cron_title`      char(120)                                             NOT NULL                                                                            default '',
    `cron_script`     char(120)                                             NOT NULL                                                                            default '',
    `schedule`        enum ('hourly','daily','weekly','monthly','interval') NOT NULL                                                                            default 'daily',
    `run_day`         enum ('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28') default NULL,
    `run_time`        time                                                                                                                                      default '04:00:00',
    `run_order`       tinyint(4) unsigned                                   NOT NULL,
    `last_run`        DATETIME                                              NOT NULL                                                                            DEFAULT '1900-01-01 00:00:00',
    `next_run`        DATETIME                                              NOT NULL                                                                            DEFAULT '1900-01-01 00:00:00',
    `run_interval`    time                                                                                                                                      default NULL,
    `log_enabled`     tinyint(1)                                            NOT NULL                                                                            default '0',
    `log_file`        char(120)                                             NOT NULL                                                                            default '',
    `log_sql_queries` tinyint(4)                                            NOT NULL                                                                            default '0',
    `disable_board`   tinyint(1)                                            NOT NULL                                                                            default '0',
    `run_counter`     bigint(20) unsigned                                   NOT NULL                                                                            default '0',
    PRIMARY KEY (`cron_id`),
    UNIQUE KEY `title` (`cron_title`),
    UNIQUE KEY `script` (`cron_script`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 30;

--
-- Дамп данных таблицы `bb_cron`
--

INSERT INTO `bb_cron`
VALUES (1, 0, 'Site backup', 'site_backup.php', 'daily', '1', '05:00:00', 10, '1900-01-01 00:00:00',
        '1900-01-01 00:00:00', NULL, 1, '', 0, 1, 0);
INSERT INTO `bb_cron`
VALUES (2, 0, 'DB backup', 'db_backup.php', 'daily', '1', '05:00:00', 20, '1900-01-01 00:00:00', '1900-01-01 00:00:00',
        NULL, 1, '', 0, 1, 0);
INSERT INTO `bb_cron`
VALUES (3, 1, 'Avatars cleanup', 'avatars_cleanup.php', 'weekly', '1', '05:00:00', 30, '2008-05-22 19:11:10',
        '2008-05-26 05:00:00', NULL, 1, '', 0, 1, 0);
INSERT INTO `bb_cron`
VALUES (4, 1, 'Board maintenance', 'bb_maintenance.php', 'daily', NULL, '05:00:00', 40, '2008-05-22 19:11:14',
        '2008-05-23 05:00:00', NULL, 1, '', 0, 1, 0);
INSERT INTO `bb_cron`
VALUES (5, 1, 'Prune forums', 'prune_forums.php', 'daily', NULL, '05:00:00', 50, '2008-05-22 19:11:17',
        '2008-05-23 05:00:00', NULL, 1, '', 0, 1, 0);
INSERT INTO `bb_cron`
VALUES (6, 1, 'Prune topic moved stubs', 'prune_topic_moved.php', 'daily', NULL, '05:00:00', 60, '2008-05-22 19:11:20',
        '2008-05-23 05:00:00', NULL, 1, '', 0, 1, 0);
INSERT INTO `bb_cron`
VALUES (7, 1, 'Logs cleanup', 'clean_log.php', 'daily', NULL, '05:00:00', 70, '2008-05-22 19:11:23',
        '2008-05-23 05:00:00', NULL, 1, '', 0, 1, 0);
INSERT INTO `bb_cron`
VALUES (8, 1, 'Tracker maintenance', 'tr_maintenance.php', 'daily', NULL, '05:00:00', 90, '2008-05-22 19:11:26',
        '2008-05-23 05:00:00', NULL, 1, '', 0, 1, 0);
INSERT INTO `bb_cron`
VALUES (9, 1, 'Clean dlstat', 'clean_dlstat.php', 'daily', NULL, '05:00:00', 100, '2008-05-22 19:11:29',
        '2008-05-23 05:00:00', NULL, 1, '', 0, 1, 0);
INSERT INTO `bb_cron`
VALUES (10, 1, 'Prune inactive users', 'prune_inactive_users.php', 'daily', NULL, '05:00:00', 110,
        '2008-05-22 19:11:32', '2008-05-23 05:00:00', NULL, 1, '', 0, 1, 0);
INSERT INTO `bb_cron`
VALUES (11, 1, 'Sessions cleanup', 'sessions_cleanup.php', 'interval', NULL, NULL, 255, '2008-05-22 19:18:07',
        '2008-05-22 19:21:07', '00:03:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (12, 1, 'DS update ''cat_forums''', 'ds_update_cat_forums.php', 'interval', NULL, NULL, 255,
        '2008-05-22 19:18:10', '2008-05-22 19:23:10', '00:05:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (13, 1, 'DS update ''stats''', 'ds_update_stats.php', 'interval', NULL, NULL, 255, '2008-05-22 19:11:46',
        '2008-05-22 19:21:46', '00:10:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (14, 1, 'Flash topic view', 'flash_topic_view.php', 'interval', NULL, NULL, 255, '2008-05-22 19:11:49',
        '2008-05-22 19:21:49', '00:10:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (15, 1, 'Clean search results', 'clean_search_results.php', 'interval', NULL, NULL, 255, '2008-05-22 19:11:52',
        '2008-05-22 19:21:52', '00:10:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (16, 1, 'Tracker cleanup and dlstat', 'tr_cleanup_and_dlstat.php', 'interval', NULL, NULL, 20,
        '2008-05-22 20:31:41', '2008-05-22 20:46:41', '00:15:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (17, 1, 'Make tracker snapshot', 'tr_make_snapshot.php', 'interval', NULL, NULL, 10, '2008-05-22 20:31:38',
        '2008-05-22 20:41:38', '00:10:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (18, 1, 'Seeder last seen', 'tr_update_seeder_last_seen.php', 'interval', NULL, NULL, 255, '2008-05-22 19:11:55',
        '2008-05-22 20:11:55', '01:00:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (19, 1, 'Clean torrents search options', 'clean_tor_search_options.php', 'interval', NULL, NULL, 255,
        '2008-05-22 19:11:58', '2008-05-23 01:11:58', '06:00:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (20, 1, 'Tracker dl-complete count', 'tr_complete_count.php', 'interval', NULL, NULL, 255, '2008-05-22 19:12:01',
        '2008-05-23 01:12:01', '06:00:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (21, 1, 'Cache garbage collector', 'cache_gc.php', 'interval', NULL, NULL, 255, '2008-05-22 19:18:13',
        '2008-05-22 19:23:13', '00:05:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (22, 1, 'Manage Antibroot', 'bb_manage_untrusted.php', 'interval', NULL, NULL, 255, '2008-05-22 19:18:13',
        '2008-05-22 19:23:13', '00:10:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (23, 1, 'User stats yesterday', 'user_stats_yesterday.php', 'daily', NULL, '00:01:00', 80, '2008-05-22 00:01:00',
        '2008-05-23 00:01:00', NULL, 1, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (24, 1, 'User stats today', 'user_stats_today.php', 'interval', NULL, NULL, 20, '2008-05-22 20:30:00',
        '2008-05-22 20:45:00', '00:15:00', 0, '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (25, 1, 'Prune inactive invites', 'invites_prune.php', 'daily', NULL, '05:00:00', 255, '0', '0', NULL, 1, '', 0,
        0, 0);
INSERT INTO `bb_cron`
VALUES (26, 1, 'Change gold_silver', 'silver_gold_unset.php', 'interval', NULL, NULL, 255, '0', '0', '00:10:00', 0, '',
        0, 0, 0);
INSERT INTO `bb_cron`
VALUES (27, 1, 'Democracy Warnings cleanup', 'democracy_warn_cleanup.php', 'hourly', NULL, NULL, 255, '0', '0', NULL, 1,
        '', 0, 0, 0);
INSERT INTO `bb_cron`
VALUES (28, 1, 'Sync forums, topics and posts', 'bb_synctopics.php', 'hourly', NULL, NULL, 255, '0', '0', NULL, 1, '',
        0, 0, 0);
INSERT INTO `bb_cron`
VALUES (29, 1, 'External trackers update', 'bt_external_trackers_update.php', 'hourly', NULL, NULL, 255, '0', '0', NULL,
        1, '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `bb_datastore`
--

CREATE TABLE IF NOT EXISTS `bb_datastore`
(
    `ds_title` varchar(255) NOT NULL default '',
    `ds_data`  longtext     NOT NULL,
    PRIMARY KEY (`ds_title`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_disallow`
--

CREATE TABLE IF NOT EXISTS `bb_disallow`
(
    `disallow_id`       mediumint(8) unsigned NOT NULL auto_increment,
    `disallow_username` varchar(25)           NOT NULL default '',
    PRIMARY KEY (`disallow_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_extensions`
--

CREATE TABLE IF NOT EXISTS `bb_extensions`
(
    `ext_id`    mediumint(8) unsigned NOT NULL auto_increment,
    `group_id`  mediumint(8) unsigned NOT NULL default '0',
    `extension` varchar(100)          NOT NULL default '',
    `comment`   varchar(100)          NOT NULL default '',
    PRIMARY KEY (`ext_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 30;

--
-- Дамп данных таблицы `bb_extensions`
--

INSERT INTO `bb_extensions`
VALUES (1, 1, 'gif', '');
INSERT INTO `bb_extensions`
VALUES (2, 1, 'png', '');
INSERT INTO `bb_extensions`
VALUES (3, 1, 'jpeg', '');
INSERT INTO `bb_extensions`
VALUES (4, 1, 'jpg', '');
INSERT INTO `bb_extensions`
VALUES (5, 1, 'tif', '');
INSERT INTO `bb_extensions`
VALUES (6, 1, 'tga', '');
INSERT INTO `bb_extensions`
VALUES (7, 2, 'gtar', '');
INSERT INTO `bb_extensions`
VALUES (8, 2, 'gz', '');
INSERT INTO `bb_extensions`
VALUES (9, 2, 'tar', '');
INSERT INTO `bb_extensions`
VALUES (10, 2, 'zip', '');
INSERT INTO `bb_extensions`
VALUES (11, 2, 'rar', '');
INSERT INTO `bb_extensions`
VALUES (12, 2, 'ace', '');
INSERT INTO `bb_extensions`
VALUES (13, 3, 'txt', '');
INSERT INTO `bb_extensions`
VALUES (14, 3, 'c', '');
INSERT INTO `bb_extensions`
VALUES (15, 3, 'h', '');
INSERT INTO `bb_extensions`
VALUES (16, 3, 'cpp', '');
INSERT INTO `bb_extensions`
VALUES (17, 3, 'hpp', '');
INSERT INTO `bb_extensions`
VALUES (18, 3, 'diz', '');
INSERT INTO `bb_extensions`
VALUES (19, 4, 'xls', '');
INSERT INTO `bb_extensions`
VALUES (20, 4, 'doc', '');
INSERT INTO `bb_extensions`
VALUES (21, 4, 'dot', '');
INSERT INTO `bb_extensions`
VALUES (22, 4, 'pdf', '');
INSERT INTO `bb_extensions`
VALUES (23, 4, 'ai', '');
INSERT INTO `bb_extensions`
VALUES (24, 4, 'ps', '');
INSERT INTO `bb_extensions`
VALUES (25, 4, 'ppt', '');
INSERT INTO `bb_extensions`
VALUES (26, 5, 'rm', '');
INSERT INTO `bb_extensions`
VALUES (27, 6, 'wma', '');
INSERT INTO `bb_extensions`
VALUES (28, 7, 'swf', '');
INSERT INTO `bb_extensions`
VALUES (29, 8, 'torrent', '');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_extension_groups`
--

CREATE TABLE IF NOT EXISTS `bb_extension_groups`
(
    `group_id`          mediumint(8)        NOT NULL auto_increment,
    `group_name`        varchar(20)         NOT NULL default '',
    `cat_id`            tinyint(2)          NOT NULL default '0',
    `allow_group`       tinyint(1)          NOT NULL default '0',
    `download_mode`     tinyint(1) unsigned NOT NULL default '1',
    `upload_icon`       varchar(100)        NOT NULL default '',
    `max_filesize`      int(20)             NOT NULL default '0',
    `forum_permissions` text                NOT NULL,
    PRIMARY KEY (`group_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 9;

--
-- Дамп данных таблицы `bb_extension_groups`
--

INSERT INTO `bb_extension_groups`
VALUES (1, 'Images', 1, 1, 1, '', 262144, '');
INSERT INTO `bb_extension_groups`
VALUES (2, 'Archives', 0, 1, 1, '', 262144, '');
INSERT INTO `bb_extension_groups`
VALUES (3, 'Plain Text', 0, 0, 1, '', 262144, '');
INSERT INTO `bb_extension_groups`
VALUES (4, 'Documents', 0, 0, 1, '', 262144, '');
INSERT INTO `bb_extension_groups`
VALUES (5, 'Real Media', 0, 0, 2, '', 262144, '');
INSERT INTO `bb_extension_groups`
VALUES (6, 'Streams', 2, 0, 1, '', 262144, '');
INSERT INTO `bb_extension_groups`
VALUES (7, 'Flash Files', 3, 0, 1, '', 262144, '');
INSERT INTO `bb_extension_groups`
VALUES (8, 'Torrent', 0, 1, 1, '', 122880, '');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_forums`
--

CREATE TABLE IF NOT EXISTS `bb_forums`
(
    `forum_id`            smallint(5) unsigned  NOT NULL auto_increment,
    `cat_id`              smallint(5) unsigned  NOT NULL default '0',
    `forum_name`          varchar(150)          NOT NULL default '',
    `forum_desc`          text                  NOT NULL,
    `forum_status`        tinyint(4)            NOT NULL default '0',
    `forum_order`         smallint(5) unsigned  NOT NULL default '1',
    `forum_posts`         mediumint(8) unsigned NOT NULL default '0',
    `forum_topics`        mediumint(8) unsigned NOT NULL default '0',
    `forum_last_post_id`  mediumint(8) unsigned NOT NULL default '0',
    `prune_days`          smallint(5) unsigned  NOT NULL default '0',
    `auth_view`           tinyint(2)            NOT NULL default '0',
    `auth_read`           tinyint(2)            NOT NULL default '0',
    `auth_post`           tinyint(2)            NOT NULL default '0',
    `auth_reply`          tinyint(2)            NOT NULL default '0',
    `auth_edit`           tinyint(2)            NOT NULL default '0',
    `auth_delete`         tinyint(2)            NOT NULL default '0',
    `auth_sticky`         tinyint(2)            NOT NULL default '0',
    `auth_announce`       tinyint(2)            NOT NULL default '0',
    `auth_vote`           tinyint(2)            NOT NULL default '0',
    `auth_pollcreate`     tinyint(2)            NOT NULL default '0',
    `auth_attachments`    tinyint(2)            NOT NULL default '0',
    `auth_download`       tinyint(2)            NOT NULL default '0',
    `allow_reg_tracker`   tinyint(1)            NOT NULL default '0',
    `allow_dl_topic`      tinyint(1)            NOT NULL default '0',
    `self_moderated`      tinyint(1)            NOT NULL default '0',
    `forum_parent`        smallint(5) unsigned  NOT NULL default '0',
    `show_on_index`       tinyint(1)            NOT NULL default '1',
    `forum_display_sort`  tinyint(1)            NOT NULL default '0',
    `forum_display_order` tinyint(1)            NOT NULL default '0',
    `topic_tpl_id`        smallint(6)           NOT NULL default '0',
    PRIMARY KEY (`forum_id`),
    KEY `forums_order` (`forum_order`),
    KEY `cat_id` (`cat_id`),
    KEY `forum_last_post_id` (`forum_last_post_id`),
    KEY `forum_parent` (`forum_parent`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 2;

--
-- Дамп данных таблицы `bb_forums`
--

INSERT INTO `bb_forums`
VALUES (1, 1, 'Test Forum 1', 'This is just a test forum.', 0, 10, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 0, 0,
        0, 0, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `bb_friends`
--

CREATE TABLE IF NOT EXISTS `bb_friends`
(
    `user_id`    mediumint(8) unsigned NOT NULL DEFAULT '0',
    `friends_id` mediumint(8) unsigned NOT NULL DEFAULT '0'
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

--
-- Дамп данных таблицы `bb_friends`
--

INSERT INTO `bb_friends`
VALUES (`user_id`, `friends_id`);

-- --------------------------------------------------------

--
-- Структура таблицы `bb_gallery`
--

CREATE TABLE IF NOT EXISTS `bb_gallery`
(
    `image_id`    varchar(37)  NOT NULL default '',
    `image_thumb` smallint(1)  NOT NULL default '0',
    `user_id`     mediumint(8) NOT NULL default '0',
    PRIMARY KEY (`image_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_groups`
--

CREATE TABLE IF NOT EXISTS `bb_groups`
(
    `group_id`          mediumint(8) NOT NULL auto_increment,
    `group_type`        tinyint(4)   NOT NULL default '1',
    `group_name`        varchar(40)  NOT NULL default '',
    `group_description` varchar(255) NOT NULL default '',
    `group_moderator`   mediumint(8) NOT NULL default '0',
    `group_single_user` tinyint(1)   NOT NULL default '1',
    `group_rank`        smallint(5)  NOT NULL default '0',
    PRIMARY KEY (`group_id`),
    KEY `group_single_user` (`group_single_user`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

--
-- Дамп данных таблицы `bb_groups`
--

INSERT INTO `bb_groups` (`group_id`, `group_type`, `group_name`, `group_description`, `group_moderator`,
                         `group_single_user`, `group_rank`)
VALUES (1, 0, 'Admins', '', 2, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `bb_log`
--

CREATE TABLE IF NOT EXISTS `bb_log`
(
    `log_type_id`         mediumint(8) unsigned                           NOT NULL default '0',
    `log_user_id`         mediumint(9)                                    NOT NULL default '0',
    `log_username`        varchar(25)                                     NOT NULL default '',
    `log_user_ip`         varchar(32) character set utf8 collate utf8_bin NOT NULL default '',
    `log_forum_id`        smallint(5) unsigned                            NOT NULL default '0',
    `log_forum_id_new`    smallint(5) unsigned                            NOT NULL default '0',
    `log_topic_id`        mediumint(8) unsigned                           NOT NULL default '0',
    `log_topic_id_new`    mediumint(8) unsigned                           NOT NULL default '0',
    `log_topic_title`     varchar(250)                                    NOT NULL default '',
    `log_topic_title_new` varchar(250)                                    NOT NULL default '',
    `log_time`            int(11)                                         NOT NULL default '0',
    `log_msg`             text                                            NOT NULL,
    KEY `log_time` (`log_time`),
    FULLTEXT KEY `log_topic_title` (`log_topic_title`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_order`
--

CREATE TABLE IF NOT EXISTS `bb_order`
(
    `order_id`                int(10) unsigned NOT NULL default '0',
    `order_forum_id`          smallint(5)      NOT NULL default '0',
    `order_name`              text,
    `order_desc`              text,
    `order_time`              int(11)          NOT NULL,
    `order_user_performed_id` int(1)           NOT NULL default '0',
    `order_topic_id`          mediumint(8)     NOT NULL default '0',
    `order_yes`               int(1)           NOT NULL default '0',
    `order_user_id`           int(10)          NOT NULL default '0',
    `order_vote`              int(10)          NOT NULL default '0',
    `order_abuse`             int(1)           NOT NULL default '0',
    PRIMARY KEY (`order_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_order_comment`
--

CREATE TABLE IF NOT EXISTS `bb_order_comment`
(
    `comment_id`      int(10) unsigned NOT NULL default '0',
    `order_id`        int(10) unsigned NOT NULL,
    `comment`         text,
    `comment_time`    int(11)          NOT NULL,
    `comment_user_id` int(10)          NOT NULL default '0',
    PRIMARY KEY (`comment_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_posts`
--

CREATE TABLE IF NOT EXISTS `bb_posts`
(
    `post_id`         mediumint(8) unsigned                        NOT NULL auto_increment,
    `topic_id`        mediumint(8) unsigned                        NOT NULL default '0',
    `forum_id`        smallint(5) unsigned                         NOT NULL default '0',
    `poster_id`       mediumint(8)                                 NOT NULL default '0',
    `post_time`       int(11)                                      NOT NULL default '0',
    `poster_ip`       char(32) character set utf8 collate utf8_bin NOT NULL default '',
    `post_username`   varchar(25)                                  NOT NULL default '',
    `enable_bbcode`   tinyint(1)                                   NOT NULL default '1',
    `enable_smilies`  tinyint(1)                                   NOT NULL default '1',
    `enable_sig`      tinyint(1)                                   NOT NULL default '1',
    `post_edit_time`  int(11)                                      NOT NULL default '0',
    `post_edit_count` smallint(5) unsigned                         NOT NULL default '0',
    `post_attachment` tinyint(1)                                   NOT NULL default '0',
    `post_reported`   tinyint(1)                                   NOT NULL default '0',
    `post_reviews`    smallint(5) unsigned                         NOT NULL default '0',
    `post_locked`     tinyint(1) unsigned                          NOT NULL default '0',
    `post_editor`     varchar(25)                                  NOT NULL default '',
    PRIMARY KEY (`post_id`),
    KEY `topic_id` (`topic_id`),
    KEY `poster_id` (`poster_id`),
    KEY `post_time` (`post_time`),
    KEY `forum_id_post_time` (`forum_id`, `post_time`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 2;

--
-- Дамп данных таблицы `bb_posts`
--

INSERT INTO `bb_posts`
VALUES (1, 1, 1, 2, 972086460, '', '', 1, 1, 1, 0, 0, 0, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_posts_html`
--

CREATE TABLE IF NOT EXISTS `bb_posts_html`
(
    `post_id`        mediumint(9) NOT NULL default '0',
    `post_html_time` timestamp    NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
    `post_html`      longtext     NOT NULL,
    PRIMARY KEY (`post_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_posts_search`
--

CREATE TABLE IF NOT EXISTS `bb_posts_search`
(
    `post_id`      mediumint(8) unsigned NOT NULL default '0',
    `search_words` text                  NOT NULL,
    PRIMARY KEY (`post_id`),
    FULLTEXT KEY `search_words` (`search_words`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_posts_text`
--

CREATE TABLE IF NOT EXISTS `bb_posts_text`
(
    `post_id`      mediumint(8) unsigned NOT NULL default '0',
    `bbcode_uid`   varchar(10)           NOT NULL default '',
    `post_subject` enum ('','kFpILr5')   NOT NULL default '',
    `post_text`    longtext              NOT NULL,
    PRIMARY KEY (`post_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

--
-- Дамп данных таблицы `bb_posts_text`
--

INSERT INTO `bb_posts_text`
VALUES (1, '', '',
        'This is an example post in your TorrentPier installation. You may delete this post, this topic and even this forum if you like since everything seems to be working!');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_privmsgs`
--

CREATE TABLE IF NOT EXISTS `bb_privmsgs`
(
    `privmsgs_id`             mediumint(8) unsigned                           NOT NULL auto_increment,
    `privmsgs_type`           tinyint(4)                                      NOT NULL default '0',
    `privmsgs_subject`        varchar(255)                                    NOT NULL default '0',
    `privmsgs_from_userid`    mediumint(8)                                    NOT NULL default '0',
    `privmsgs_to_userid`      mediumint(8)                                    NOT NULL default '0',
    `privmsgs_date`           int(11)                                         NOT NULL default '0',
    `privmsgs_ip`             varchar(32) character set utf8 collate utf8_bin NOT NULL default '',
    `privmsgs_enable_bbcode`  tinyint(1)                                      NOT NULL default '1',
    `privmsgs_enable_smilies` tinyint(1)                                      NOT NULL default '1',
    `privmsgs_reported`       tinyint(1)                                      NOT NULL default '0',
    PRIMARY KEY (`privmsgs_id`),
    KEY `privmsgs_from_userid` (`privmsgs_from_userid`),
    KEY `privmsgs_to_userid` (`privmsgs_to_userid`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_privmsgs_text`
--

CREATE TABLE IF NOT EXISTS `bb_privmsgs_text`
(
    `privmsgs_text_id`    mediumint(8) unsigned NOT NULL default '0',
    `privmsgs_bbcode_uid` varchar(10)           NOT NULL default '0',
    `privmsgs_text`       text                  NOT NULL,
    PRIMARY KEY (`privmsgs_text_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_quota_limits`
--

CREATE TABLE IF NOT EXISTS `bb_quota_limits`
(
    `quota_limit_id` mediumint(8) unsigned NOT NULL auto_increment,
    `quota_desc`     varchar(20)           NOT NULL default '',
    `quota_limit`    bigint(20) unsigned   NOT NULL default '0',
    PRIMARY KEY (`quota_limit_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 4;

--
-- Дамп данных таблицы `bb_quota_limits`
--

INSERT INTO `bb_quota_limits`
VALUES (1, 'Low', 262144);
INSERT INTO `bb_quota_limits`
VALUES (2, 'Medium', 10485760);
INSERT INTO `bb_quota_limits`
VALUES (3, 'High', 15728640);

-- --------------------------------------------------------

--
-- Структура таблицы `bb_ranks`
--

CREATE TABLE IF NOT EXISTS `bb_ranks`
(
    `rank_id`      smallint(5) UNSIGNED NOT NULL,
    `rank_title`   varchar(50)          NOT NULL DEFAULT '',
    `rank_min`     mediumint(8)         NOT NULL DEFAULT '0',
    `rank_special` tinyint(1)           NOT NULL DEFAULT '1',
    `rank_image`   varchar(255)         NOT NULL DEFAULT ''
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

--
-- Дамп данных таблицы `bb_ranks`
--

INSERT INTO `bb_ranks`
VALUES (1, 'Site Admin', -1, 1, 'images/ranks/admin.gif');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_readonly`
--

CREATE TABLE IF NOT EXISTS `bb_readonly`
(
    `user_id`      mediumint(8) NOT NULL default '0',
    `moderator_id` mediumint(8) NOT NULL default '0',
    `forum_id`     mediumint(8) NOT NULL default '0',
    `endtime`      int(32)      NOT NULL default '0'
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;


-- --------------------------------------------------------
--
-- Структура таблицы `bb_reports`
--

CREATE TABLE IF NOT EXISTS `bb_reports`
(
    `report_id`           mediumint(8) unsigned NOT NULL auto_increment,
    `user_id`             mediumint(8)          NOT NULL,
    `report_time`         int(11)               NOT NULL,
    `report_last_change`  mediumint(8) unsigned default NULL,
    `report_module_id`    mediumint(8) unsigned NOT NULL,
    `report_status`       tinyint(1)            NOT NULL,
    `report_reason_id`    mediumint(8) unsigned NOT NULL,
    `report_subject`      int(11)               NOT NULL,
    `report_subject_data` mediumtext,
    `report_title`        varchar(255)          NOT NULL,
    `report_desc`         text                  NOT NULL,
    PRIMARY KEY (`report_id`),
    KEY `user_id` (`user_id`),
    KEY `report_time` (`report_time`),
    KEY `report_type_id` (`report_module_id`),
    KEY `report_status` (`report_status`),
    KEY `report_reason_id` (`report_reason_id`),
    KEY `report_subject` (`report_subject`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;


-- --------------------------------------------------------

--
-- Структура таблицы `bb_reports_changes`
--

CREATE TABLE IF NOT EXISTS `bb_reports_changes`
(
    `report_change_id`      mediumint(8) unsigned NOT NULL auto_increment,
    `report_id`             mediumint(8) unsigned NOT NULL,
    `user_id`               mediumint(8)          NOT NULL,
    `report_change_time`    int(11)               NOT NULL,
    `report_status`         tinyint(1)            NOT NULL,
    `report_change_comment` text                  NOT NULL,
    PRIMARY KEY (`report_change_id`),
    KEY `report_id` (`report_id`),
    KEY `user_id` (`user_id`),
    KEY `report_change_time` (`report_change_time`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_reports_modules`
--

CREATE TABLE IF NOT EXISTS `bb_reports_modules`
(
    `report_module_id`         mediumint(8) unsigned NOT NULL auto_increment,
    `report_module_order`      mediumint(8) unsigned NOT NULL,
    `report_module_notify`     tinyint(1)            NOT NULL,
    `report_module_prune`      smallint(6)           NOT NULL,
    `report_module_last_prune` int(11) default NULL,
    `report_module_name`       varchar(50)           NOT NULL,
    `auth_write`               tinyint(1)            NOT NULL,
    `auth_view`                tinyint(1)            NOT NULL,
    `auth_notify`              tinyint(1)            NOT NULL,
    `auth_delete`              tinyint(1)            NOT NULL,
    PRIMARY KEY (`report_module_id`),
    KEY `report_module_order` (`report_module_order`),
    KEY `auth_view` (`auth_view`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 6;

--
-- Дамп данных таблицы `bb_reports_modules`
--

INSERT INTO `bb_reports_modules` (`report_module_id`, `report_module_order`, `report_module_notify`,
                                  `report_module_prune`, `report_module_last_prune`, `report_module_name`, `auth_write`,
                                  `auth_view`, `auth_notify`, `auth_delete`)
VALUES (1, 1, 0, 0, NULL, 'report_general', 0, 1, 1, 1),
       (2, 2, 0, 0, NULL, 'report_post', 0, 1, 1, 1),
       (3, 3, 0, 0, NULL, 'report_topic', 0, 1, 1, 1),
       (4, 4, 0, 0, NULL, 'report_user', 0, 1, 1, 1),
       (5, 5, 0, 0, NULL, 'report_privmsg', 0, 1, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `bb_reports_reasons`
--

CREATE TABLE IF NOT EXISTS `bb_reports_reasons`
(
    `report_reason_id`    mediumint(8) unsigned NOT NULL auto_increment,
    `report_module_id`    mediumint(8) unsigned NOT NULL,
    `report_reason_order` mediumint(8) unsigned NOT NULL,
    `report_reason_desc`  varchar(255)          NOT NULL,
    PRIMARY KEY (`report_reason_id`),
    KEY `report_type_id` (`report_module_id`),
    KEY `report_reason_order` (`report_reason_order`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_reputation`
--

CREATE TABLE IF NOT EXISTS `bb_reputation`
(
    `id`           mediumint(8) unsigned NOT NULL auto_increment,
    `modification` tinyint(1)            NOT NULL default '0',
    `user_id`      mediumint(8)          NOT NULL default '0',
    `voter_id`     mediumint(8)          NOT NULL default '0',
    `post_id`      mediumint(8)          NOT NULL default '-1',
    `forum_id`     smallint(5)           NOT NULL default '-1',
    `poster_ip`    char(8)               NOT NULL default '',
    `date`         int(11)               NOT NULL default '0',
    `expire`       int(11)               NOT NULL default '0',
    `amount`       smallint(5) unsigned  NOT NULL default '1',
    `edit_time`    int(11)                        default NULL,
    `edit_count`   smallint(5) unsigned  NOT NULL default '0',
    PRIMARY KEY (`id`),
    KEY `voter_id` (`voter_id`),
    KEY `post_id` (`post_id`),
    KEY `date` (`date`),
    KEY `expire` (`expire`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_reputation_text`
--

CREATE TABLE IF NOT EXISTS `bb_reputation_text`
(
    `id`         mediumint(8) unsigned NOT NULL default '0',
    `text`       text,
    `bbcode_uid` varchar(10)           NOT NULL default '',
    PRIMARY KEY (`id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_search_rebuild`
--

CREATE TABLE IF NOT EXISTS `bb_search_rebuild`
(
    `rebuild_session_id`     mediumint(8) unsigned NOT NULL auto_increment,
    `start_post_id`          mediumint(8) unsigned NOT NULL default '0',
    `end_post_id`            mediumint(8) unsigned NOT NULL default '0',
    `start_time`             int(11)               NOT NULL default '0',
    `end_time`               int(11)               NOT NULL default '0',
    `last_cycle_time`        int(11)               NOT NULL default '0',
    `session_time`           int(11)               NOT NULL default '0',
    `session_posts`          mediumint(8) unsigned NOT NULL default '0',
    `session_cycles`         mediumint(8) unsigned NOT NULL default '0',
    `search_size`            int(10) unsigned      NOT NULL default '0',
    `rebuild_session_status` tinyint(1)            NOT NULL default '0',
    PRIMARY KEY (`rebuild_session_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_search_results`
--

CREATE TABLE IF NOT EXISTS `bb_search_results`
(
    `session_id`      char(20) character set utf8 collate utf8_bin    NOT NULL default '',
    `search_type`     tinyint(4)                                      NOT NULL default '0',
    `search_id`       varchar(12) character set utf8 collate utf8_bin NOT NULL default '',
    `search_time`     int(11)                                         NOT NULL default '0',
    `search_settings` text                                            NOT NULL,
    `search_array`    text                                            NOT NULL,
    `search_query`    varchar(100)                                    NOT NULL,
    PRIMARY KEY (`session_id`, `search_type`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_sessions`
--

CREATE TABLE IF NOT EXISTS `bb_sessions`
(
    `session_id`        char(20) character set utf8 collate utf8_bin NOT NULL default '',
    `session_user_id`   mediumint(8)                                 NOT NULL default '0',
    `session_start`     int(11)                                      NOT NULL default '0',
    `session_time`      int(11)                                      NOT NULL default '0',
    `session_ip`        char(32) character set utf8 collate utf8_bin NOT NULL default '',
    `session_logged_in` tinyint(1)                                   NOT NULL default '0',
    `session_admin`     tinyint(2)                                   NOT NULL default '0',
    `session_browser`   TEXT                                         NOT NULL,
    `session_useragent` TEXT                                         NOT NULL,
    PRIMARY KEY (`session_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_shout`
--

CREATE TABLE IF NOT EXISTS `bb_shout`
(
    `shout_id`           mediumint(8) unsigned              NOT NULL AUTO_INCREMENT,
    `shout_username`     varchar(25) CHARACTER SET cp1251   NOT NULL DEFAULT '',
    `shout_user_id`      mediumint(8)                       NOT NULL DEFAULT '0',
    `shout_group_id`     mediumint(8)                       NOT NULL DEFAULT '0',
    `shout_session_time` int(11)                            NOT NULL DEFAULT '0',
    `shout_ip`           char(8) CHARACTER SET cp1251       NOT NULL DEFAULT '',
    `shout_text`         varchar(1000) CHARACTER SET cp1251 NOT NULL,
    `shout_active`       mediumint(8)                       NOT NULL DEFAULT '0',
    `shout_bbcode_uid`   varchar(10)                        NOT NULL DEFAULT '',
    PRIMARY KEY (`shout_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_smilies`
--

CREATE TABLE IF NOT EXISTS `bb_smilies`
(
    `smilies_id` smallint(5) unsigned NOT NULL auto_increment,
    `code`       varchar(50)          NOT NULL default '',
    `smile_url`  varchar(100)         NOT NULL default '',
    `emoticon`   varchar(75)          NOT NULL default '',
    PRIMARY KEY (`smilies_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1769;

--
-- Дамп данных таблицы `bb_smilies`
--

INSERT INTO `bb_smilies` (`smilies_id`, `code`, `smile_url`, `emoticon`)
VALUES (1560, ':D', 'icon_biggrin.gif', 'Very Happy'),
       (1561, ':)', 'icon_smile.gif', 'Smile'),
       (1562, ':(', 'icon_sad.gif', 'Sad'),
       (1563, ':o', 'icon_surprised.gif', 'Surprised'),
       (1564, ':shock:', 'icon_eek.gif', 'Shocked'),
       (1565, ':?', 'icon_confused.gif', 'Confused'),
       (1566, ':cool:', 'icon_cool.gif', 'Cool'),
       (1567, ':lol:', 'icon_lol.gif', 'Laughing'),
       (1568, ':x', 'icon_mad.gif', 'Mad'),
       (1569, ':wow:', 'icon_razz.gif', 'Wow'),
       (1570, ':blush:', 'icon_redface.gif', 'Embarassed'),
       (1571, ':cry:', 'icon_cry.gif', 'Crying or Very sad'),
       (1572, ':evil:', 'icon_evil.gif', 'Evil or Very Mad'),
       (1573, ':twisted:', 'icon_twisted.gif', 'Twisted Evil'),
       (1574, ':roll:', 'icon_rolleyes.gif', 'Rolling Eyes'),
       (1575, ':wink:', 'icon_wink.gif', 'Wink'),
       (1576, ':!:', 'icon_exclaim.gif', 'Exclamation'),
       (1577, ':?:', 'icon_question.gif', 'Question'),
       (1578, ':idea:', 'icon_idea.gif', 'Idea'),
       (1579, ':arrow:', 'icon_arrow.gif', 'Right Arrow'),
       (1580, ':arrow2:', 'icon_arrow2.gif', 'Left Arrow'),
       (1581, ':angry:', 'icon_angry.gif', 'Angry'),
       (1582, ':P', 'be-e.gif', 'bee'),
       (1583, ':mrgreen:', 'icon_mrgreen.gif', 'Mr. Green'),
       (1584, ':boxed:', 'icon_boxed.gif', 'Boxed'),
       (1585, ':furious:', 'icon_furious.gif', 'Furious'),
       (1586, ':greedy:', 'icon_greedy.gif', 'Greedy'),
       (1587, ':in_love:', 'icon_in_love.gif', 'In Love'),
       (1588, ':rant:', 'icon_rant.gif', 'Rant'),
       (1589, ':sick:', 'icon_sick.gif', 'Sick'),
       (1590, ':wall:', 'icon_wall.gif', 'Wall'),
       (1591, ':weep:', 'icon_weep.gif', 'Weep'),
       (1592, ':yawn:', 'icon_yawn.gif', 'Yawn'),
       (1593, ':up:', 'ges_up.gif', 'Up'),
       (1594, ':down:', 'ges_down.gif', 'Down'),
       (1595, ':yes:', 'ges_yes.gif', 'Yes'),
       (1596, ':no:', 'ges_no.gif', 'No'),
       (1597, ':help:', 'ges_help.gif', 'Help'),
       (1598, ':bow:', 'ges_bow.gif', 'Bow'),
       (1599, ':clap:', 'ges_clap.gif', 'Clap'),
       (1600, ':clap2:', 'ges_clap2.gif', 'Clap 2'),
       (1601, ':hmm:', 'ges_hmm.gif', 'Hmm'),
       (1602, ':slap:', 'ges_slap.gif', 'Slap'),
       (1603, ':biker:', 'ppl_biker.gif', 'Biker'),
       (1604, ':chef:', 'ppl_chef.gif', 'Chef'),
       (1605, ':cylon:', 'ppl_cylon.gif', 'Cylon'),
       (1606, ':hannibal:', 'ppl_hannibal.gif', 'Hannibal'),
       (1607, ':santa:', 'santa.gif', 'santa'),
       (1608, ':indian:', 'ppl_indian.gif', 'Indian'),
       (1609, ':king:', 'ppl_king.gif', 'King'),
       (1610, ':mario:', 'ppl_mario.gif', 'Mario'),
       (1611, ':ninja:', 'ppl_ninja.gif', 'Ninja'),
       (1612, ':ninjajig:', 'ppl_ninjajig.gif', 'Ninja Jig'),
       (1613, ':shuriken:', 'ppl_shuriken.gif', 'Ninja Shuriken'),
       (1614, ':oldtimer:', 'ppl_oldtimer.gif', 'Oldtimer'),
       (1615, ':snegurochka:', 'snegurochka.gif', 'snegurochka'),
       (1616, ':pimp:', 'ppl_pimp.gif', 'Pimp'),
       (1617, ':pirat:', 'ppl_pirat.gif', 'Pirate'),
       (1618, ':pirate:', 'ppl_pirate.gif', 'Pirate 2'),
       (1619, ':police:', 'ppl_police.gif', 'Police'),
       (1620, ':pop:', 'ppl_pop.gif', 'Pop'),
       (1621, ':priest:', 'ppl_priest.gif', 'Priest'),
       (1622, ':punk:', 'ppl_punk.gif', 'Punk'),
       (1623, ':rambo:', 'ppl_rambo.gif', 'Rambo'),
       (1624, ':rock:', 'ppl_rock.gif', 'Rocker'),
       (1625, ':newyear:', 'new_year.gif', 'newyear'),
       (1626, ':smurf:', 'ppl_smurf.gif', 'Smurf'),
       (1627, ':spidey:', 'ppl_spidey.gif', 'Spidey'),
       (1628, ':wolverine:', 'ppl_wolverine.gif', 'Wolverine'),
       (1629, ':zorro:', 'ppl_zorro.gif', 'Zorro'),
       (1630, ':artist:', 'ext_artist.gif', 'Artist'),
       (1631, ':argue:', 'ext_argue.gif', 'Argue'),
       (1632, ':baby:', 'ext_baby.gif', 'Baby'),
       (1633, ':beer:', 'ext_beer.gif', 'Beer'),
       (1634, ':beer2:', 'ext_beer2.gif', 'Beer 2'),
       (1635, ':book:', 'ext_book.gif', 'Book'),
       (1636, ':bounce:', 'ext_bounce.gif', 'Bounce'),
       (1637, ':box:', 'ext_box.gif', 'Box'),
       (1638, ':cigar:', 'ext_cigar.gif', 'Cigar'),
       (1639, ':clown:', 'ext_clown.gif', 'Clown'),
       (1640, ':cry_baby:', 'ext_crybaby.gif', 'Cry Baby'),
       (1641, ':crutch:', 'ext_crutch.gif', 'Crutch'),
       (1642, ':doc:', 'ext_doc.gif', 'Doc'),
       (1643, ':drunk:', 'ext_drunk.gif', 'Drunk'),
       (1644, ':flex:', 'ext_flex.gif', 'Flex'),
       (1645, ':jump2:', 'ext_jump2.gif', 'Jump 2'),
       (1646, ':lamo:', 'ext_lame.gif', 'Lamo'),
       (1647, ':komp_cr:', 'ext_komp_cr.gif', 'Comp Crash'),
       (1648, ':hooray:', 'ext_hooray.gif', 'Hooray'),
       (1649, ':hump:', 'ext_hump.gif', 'Hump'),
       (1650, ':icecream:', 'ext_icecream.gif', 'Icecream'),
       (1651, ':kiss:', 'ext_kiss.gif', 'Kiss'),
       (1652, ':lovers:', 'ext_lovers.gif', 'Lovers'),
       (1653, ':mobile:', 'ext_mobile.gif', 'Mobile'),
       (1654, ':music:', 'ext_music.gif', 'Music'),
       (1655, ':secret:', 'ext_secret.gif', 'Secret'),
       (1656, ':shutup:', 'ext_shutup.gif', 'Shut Up'),
       (1657, ':sleep:', 'ext_sleep.gif', 'Sleep'),
       (1658, ':spider:', 'ext_spider.gif', 'Spider'),
       (1659, ':tease:', 'ext_tease.gif', 'Tease'),
       (1660, ':tomato:', 'ext_tomato.gif', 'Tomato'),
       (1661, ':wheelcha:', 'ext_wheelcha.gif', 'Wheel Chair'),
       (1662, ':2guns:', 'gun_2guns.gif', '2guns'),
       (1663, ':axe:', 'gun_axe.gif', 'Axe'),
       (1664, ':bash:', 'gun_bash.gif', 'Bash'),
       (1665, ':chair:', 'gun_chair.gif', 'Chair'),
       (1666, ':gun:', 'gun_gun.gif', 'Gun'),
       (1667, ':alien:', 'non_alien.gif', 'Alien'),
       (1668, ':bananadance:', 'non_banana1.gif', 'Bananadance'),
       (1669, ':bananadance2:', 'non_banana2.gif', 'Bananadance 2'),
       (1670, ':cat:', 'non_cat.gif', 'Cat'),
       (1671, ':clover:', 'non_clover.gif', 'Clover'),
       (1672, ':homestar:', 'non_homestar.gif', 'Homestar'),
       (1673, ':love:', 'non_love.gif', 'Love'),
       (1674, ':nuke:', 'non_nuke.gif', 'Nuke'),
       (1675, ':shaun:', 'non_shaun.gif', 'Shaun'),
       (1676, ':angel:', 'big_angel.gif', 'Angel'),
       (1677, ':band:', 'big_band.gif', 'Band'),
       (1678, ':hang:', 'big_hang.gif', 'Hang'),
       (1679, ':hbd:', 'big_hbd.gif', 'HBD'),
       (1680, ':ban:', 'tr_ban.gif', 'Ban'),
       (1681, ':hi:', 'tr_hi.gif', 'Hi'),
       (1682, ':offtopic:', 'tr_offtopic.gif', 'Off Topic'),
       (1683, ':respect:', 'tr_respect.gif', 'Respect'),
       (1684, ':rip:', 'tr_rip.gif', 'R.I.P.'),
       (1685, ':RTFM:', 'tr_rtfm.gif', 'RTFM!'),
       (1686, ':russ:', 'tr_russ.gif', 'Russia'),
       (1687, ':t_oops:', 'tr_oops.gif', 'Oops'),
       (1688, ':sorry:', 'tr_sorry.gif', 'I\'m Sorry'),
       (1689, ':spam:', 'tr_spam.gif', 'Spam'),
       (1690, ':thankyou:', 'tr_thankyou.gif', 'Thank You'),
       (1691, ':biggrin:', 'icon_biggrin2.gif', 'Very Happy'),
       (1692, ':crazy:', 'crazy0to.gif', 'crazy'),
       (1693, ':hooligan:', 'hooligan.gif', 'hooligan'),
       (1694, ':closetema:', 'closetema.gif', 'zlojmoder'),
       (1695, ':disk:', 'disk.gif', 'Disk'),
       (1696, ':gugli:', 'use_search.gif', 'gugli'),
       (1697, ':jumper:', 'jumper.gif', 'Jumper'),
       (1698, ':P:', 'be-e-e.gif', 'Be-e-e'),
       (1699, ':dancer:', 'dancer.gif', 'Dancer'),
       (1700, ':kiss2:', 'kiss.gif', 'Kiss'),
       (1701, ':girls_dance:', 'girls_dance.gif', 'Girls dance'),
       (1702, ':beautiful:', 'beautiful.gif', 'Im Beautiful'),
       (1703, ':finest:', 'finest.gif', 'Finest'),
       (1704, ':modesty:', 'modesty.gif', 'Modesty'),
       (1705, ':amazement:', 'amazement.gif', 'Amazement'),
       (1706, ':affliction:', 'affliction.gif', 'Affliction'),
       (1707, ':stupid:', 'stupid.gif', 'Im stupid'),
       (1708, ':coolest:', 'coolest.gif', 'Im coolest'),
       (1709, ':bis:', 'bis.gif', 'Bis'),
       (1710, ':rose:', 'in_love2.gif', 'rose'),
       (1711, ':anime_01:', 'anime_01.gif', ''),
       (1712, ':anime_02:', 'anime_02.gif', ''),
       (1713, ':anime_03:', 'anime_03.gif', ''),
       (1714, ':anime_04:', 'anime_04.gif', ''),
       (1715, ':anime_05:', 'anime_05.gif', ''),
       (1716, ':anime_06:', 'anime_06.gif', ''),
       (1717, ':neza4to:', 'ext_dont_ment.gif', 'neza4to'),
       (1718, ':dai5:', 'ext_gimmefive.gif', 'dai5'),
       (1719, ':vzerkale:', 'ext_mirror.gif', 'vzerkale'),
       (1720, ':zlaya:', 'ext_skilletgirl.gif', 'zlaya'),
       (1721, ':good:', 'good.gif', 'good'),
       (1722, ':ne:', 'ne.gif', 'ne'),
       (1723, ':kiss3:', 'kiss3.gif', 'kiss'),
       (1724, ':na_metle:', 'na_metle.gif', 'na metle'),
       (1725, ':lock:', 'lock.gif', 'Lock'),
       (1726, ':boy:', 'cupidboy.gif', 'boy'),
       (1727, ':girl:', 'cupidgirl.gif', 'girl'),
       (1728, ':medved:', 'medved.gif', 'Preved Medved!'),
       (1729, ':bayan:', 'bayan.gif', 'bayan'),
       (1730, ':|', 'icon_neutral.gif', 'Neutral'),
       (1731, ':ngpodarki:', 'ng27.gif', 'ngpodarki'),
       (1732, ':nghorohod:', 'ng33.gif', 'nghorohod'),
       (1733, ':ngolen:', 'ng35.gif', 'ngolen'),
       (1734, ':ngbuhaem:', 'ng37.gif', 'ngbuhaem'),
       (1735, ':ngpodarok:', 'ng38.gif', 'ngpodarok'),
       (1736, ':girlkiss:', 'd40.gif', 'girlkiss'),
       (1737, ':girlclap:', 'd77.gif', 'girlclap'),
       (1738, ':girlboom:', 'd34.gif', 'girlboom'),
       (1739, ':girlwithkido:', 'd25.gif', 'girlwithkido'),
       (1740, ':dancer2:', 'dance3.gif', 'dancer2'),
       (1741, ':download:', 'download.gif', 'download'),
       (1742, ':heat:', 'heat.gif', 'heat'),
       (1743, ':victory:', 'victory.gif', 'victory'),
       (1744, ':party:', 'party.gif', 'party'),
       (1745, ':censored:', 'censored.gif', 'censored'),
       (1746, ':umnik:', 'umnik.gif', 'umnik'),
       (1747, ':smoke:', 'smoke.gif', 'smoke'),
       (1748, ':polling:', 'polling.gif', 'polling'),
       (1749, ':laugh:', 'laugh1.gif', 'laugh'),
       (1750, ':lazy:', 'lazy.gif', 'lazy'),
       (1751, ':read:', 'read.gif', 'read'),
       (1752, ':splun:', 'superstition.gif', 'splun'),
       (1753, ':popcorm:', 'popcorm2.gif', 'popcorm'),
       (1754, ':friends:', 'friends.gif', 'friends'),
       (1755, ':figa:', 'snooks.gif', 'figa'),
       (1756, ':nifigasebe:', 'swoon.gif', 'nifigasebe'),
       (1757, ':unlove:', 'unlove.png', 'unlove'),
       (1758, ':musnote:', 'note.png', 'musnote'),
       (1759, ':redcard:', 'Card_Red.gif', 'redcard'),
       (1760, ':yellowcard:', 'Card_Yellow.gif', 'yellowcard'),
       (1761, ':doctor:', 'Doctor.gif', 'doctor'),
       (1762, ':profi:', 'Prof.gif', 'profi'),
       (1763, ':scream:', 'Scream.gif', 'scream'),
       (1764, ':oldmen:', 'Old.gif', 'oldmen'),
       (1765, ':tired:', 'Tired.gif', 'tired'),
       (1766, ':hypnozed:', 'Hypnotized.gif', 'hypnozed'),
       (1767, ':noidea:', 'No_Idea.gif', 'noidea'),
       (1768, ':3dots:', 'Three_Dots.gif', '3dots');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_topics`
--

CREATE TABLE IF NOT EXISTS `bb_topics`
(
    `topic_id`              mediumint(8) unsigned NOT NULL auto_increment,
    `forum_id`              smallint(8) unsigned  NOT NULL default '0',
    `topic_title`           varchar(250)          NOT NULL default '',
    `topic_poster`          mediumint(8)          NOT NULL default '0',
    `topic_time`            int(11)               NOT NULL default '0',
    `topic_views`           mediumint(8) unsigned NOT NULL default '0',
    `topic_replies`         mediumint(8) unsigned NOT NULL default '0',
    `topic_status`          tinyint(3)            NOT NULL default '0',
    `topic_vote`            tinyint(1)            NOT NULL default '0',
    `topic_type`            tinyint(3)            NOT NULL default '0',
    `topic_first_post_id`   mediumint(8) unsigned NOT NULL default '0',
    `topic_last_post_id`    mediumint(8) unsigned NOT NULL default '0',
    `topic_moved_id`        mediumint(8) unsigned NOT NULL default '0',
    `topic_attachment`      tinyint(1)            NOT NULL default '0',
    `topic_reported`        tinyint(1)            NOT NULL default '0',
    `topic_dl_type`         tinyint(1)            NOT NULL default '0',
    `topic_last_post_time`  int(11)               NOT NULL default '0',
    `topic_show_first_post` tinyint(1) unsigned   NOT NULL default '0',
    PRIMARY KEY (`topic_id`),
    KEY `forum_id` (`forum_id`),
    KEY `topic_last_post_id` (`topic_last_post_id`),
    KEY `topic_last_post_time` (`topic_last_post_time`),
    FULLTEXT KEY `topic_title` (`topic_title`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 2;

--
-- Дамп данных таблицы `bb_topics`
--

INSERT INTO `bb_topics`
VALUES (1, 1, 'Welcome to TorrentPier', 2, 972086460, 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 972086460, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `bb_topics_bookmark`
--

CREATE TABLE IF NOT EXISTS `bb_topics_bookmark`
(
    `topic_id`        mediumint(8) unsigned NOT NULL default '0',
    `user_id`         mediumint(8)          NOT NULL default '0',
    `bookmark_status` tinyint(1)            NOT NULL default '0',
    KEY `topic_id` (`topic_id`),
    KEY `user_id` (`user_id`),
    KEY `bookmark_status` (`bookmark_status`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_topics_watch`
--

CREATE TABLE IF NOT EXISTS `bb_topics_watch`
(
    `topic_id`      mediumint(8) unsigned NOT NULL default '0',
    `user_id`       mediumint(8)          NOT NULL default '0',
    `notify_status` tinyint(1)            NOT NULL default '0',
    KEY `topic_id` (`topic_id`),
    KEY `user_id` (`user_id`),
    KEY `notify_status` (`notify_status`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_textual_confirmation`
--

CREATE TABLE IF NOT EXISTS `bb_textual_confirmation`
(
    `id`       integer NOT NULL AUTO_INCREMENT,
    `question` text    NOT NULL,
    `answers`  text    NOT NULL,
    PRIMARY KEY (id)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 21;

-- --------------------------------------------------------

--
-- Дамп данных таблицы `bb_topic_templates`
--

INSERT INTO `bb_textual_confirmation` (`id`, `question`, `answers`)
VALUES (1, 'Монитор это устройство ввода?', 'нет\r\nno'),
       (2, 'Вы человек?', 'да\r\nyes'),
       (3, 'Солнце это звезда?', 'да\r\nyes'),
       (4, 'На какой планете мы живём?', 'планета земля\r\nземля'),
       (5, 'Скажи привет', 'привет'),
       (6, 'Кто вы по полу?', 'женский\r\nмужской\r\nмужчина\r\nженщина'),
       (7, '2 + 2 = ?', '4'),
       (8, '5 * 3 = ?', '15'),
       (9, '10 / 2 = ?', '5'),
       (10, '5 + 5 = ?', '10'),
       (11, '30 - 10 = ?', '20'),
       (12, 'Клавиатура это устройство ввода?', 'да\r\nyes'),
       (13, 'Как расшифровывается РФ?', 'российская федерация'),
       (14, 'Сахар сладкий?', 'да\r\nyes'),
       (15, 'Какого цвета вода?', 'прозрачная\r\nбесцветная'),
       (16, 'Май какой месяц по счёту?', 'пятый\r\n5'),
       (17, 'Как называется колокол часов Вестминстерского дворца в Лондоне?', 'биг бен'),
       (18, 'Какая самая маленькая планета в нашей Солнечной системе?', 'меркурий'),
       (19, 'Какого цвета была таблетка, которую принимает Нео в фильме "Матрица"?', 'красный\r\nкрасного'),
       (20, 'Какие животные воспитывали Маугли в "Книге джунглей"?', 'волк\r\nволки');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_topic_templates`
--

CREATE TABLE IF NOT EXISTS `bb_topic_templates`
(
    `tpl_id`       smallint(6)  NOT NULL auto_increment,
    `tpl_name`     varchar(20)  NOT NULL default '',
    `tpl_script`   varchar(30)  NOT NULL default '',
    `tpl_template` varchar(30)  NOT NULL default '',
    `tpl_desc`     varchar(255) NOT NULL default '',
    PRIMARY KEY (`tpl_id`),
    UNIQUE KEY `tpl_name` (`tpl_name`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 16;

--
-- Дамп данных таблицы `bb_topic_templates`
--

INSERT INTO `bb_topic_templates`
VALUES (1, 'video', 'video', 'video', 'Video (basic)');
INSERT INTO `bb_topic_templates`
VALUES (2, 'video_home', 'video', 'video_home', 'Video (home)');
INSERT INTO `bb_topic_templates`
VALUES (3, 'video_simple', 'video', 'video_simple', 'Video (simple)');
INSERT INTO `bb_topic_templates`
VALUES (4, 'video_lesson', 'video', 'video_lesson', 'Video (lesson)');
INSERT INTO `bb_topic_templates`
VALUES (5, 'games', 'games', 'games', 'Games');
INSERT INTO `bb_topic_templates`
VALUES (6, 'games_ps', 'games', 'games_ps', 'Games PS/PS2');
INSERT INTO `bb_topic_templates`
VALUES (7, 'games_psp', 'games', 'games_psp', 'Games PSP');
INSERT INTO `bb_topic_templates`
VALUES (8, 'games_xbox', 'games', 'games_xbox', 'Games XBOX');
INSERT INTO `bb_topic_templates`
VALUES (9, 'progs', 'progs', 'progs', 'Programs');
INSERT INTO `bb_topic_templates`
VALUES (10, 'progs_mac', 'progs', 'progs_mac', 'Programs Mac OS');
INSERT INTO `bb_topic_templates`
VALUES (11, 'progs_linux', 'progs', 'progs_linux', 'Programs Linux');
INSERT INTO `bb_topic_templates`
VALUES (12, 'music', 'music', 'music', 'Music');
INSERT INTO `bb_topic_templates`
VALUES (13, 'books', 'books', 'books', 'Books');
INSERT INTO `bb_topic_templates`
VALUES (14, 'audiobooks', 'audiobooks', 'audiobooks', 'Audiobooks');
INSERT INTO `bb_topic_templates`
VALUES (15, 'sport', 'sport', 'sport', 'Sport');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_users`
--

CREATE TABLE IF NOT EXISTS `bb_users`
(
    `user_id`               mediumint(8)                                    NOT NULL auto_increment,
    `user_active`           tinyint(1)                                      NOT NULL default '1',
    `username`              varchar(25)                                     NOT NULL default '',
    `user_password`         varchar(32) character set utf8 collate utf8_bin NOT NULL default '',
    `user_session_time`     int(11)                                         NOT NULL default '0',
    `user_timer`            int(11)                                         NOT NULL DEFAULT '0',
    `user_lastvisit`        int(11)                                         NOT NULL default '0',
    `user_last_ip`          CHAR(32)                                        NOT NULL default '',
    `user_regdate`          int(11)                                         NOT NULL default '0',
    `curpage_topic`         mediumint(8)                                    NOT NULL default '0',
    `curpage_topic_time`    int(11)                                         NOT NULL default '0',
    `user_reg_ip`           CHAR(32)                                        NOT NULL default '',
    `user_level`            tinyint(4)                                      NOT NULL default '0',
    `user_posts`            mediumint(8) unsigned                           NOT NULL default '0',
    `user_timezone`         decimal(5, 2)                                   NOT NULL default '0.00',
    `user_lang`             varchar(255)                                    NOT NULL default '',
    `user_dateformat`       varchar(14)                                     NOT NULL default '',
    `user_new_privmsg`      smallint(5) unsigned                            NOT NULL default '0',
    `user_unread_privmsg`   smallint(5) unsigned                            NOT NULL default '0',
    `user_last_privmsg`     int(11)                                         NOT NULL default '0',
    `user_opt`              int(11)                                         NOT NULL default '0',
    `user_allowavatar`      tinyint(1)                                      NOT NULL default '1',
    `user_allow_pm`         tinyint(1)                                      NOT NULL default '1',
    `user_allow_viewonline` tinyint(1)                                      NOT NULL default '1',
    `user_notify`           tinyint(1)                                      NOT NULL default '1',
    `user_notify_pm`        tinyint(1)                                      NOT NULL default '0',
    `user_rank`             int(11)                                         NOT NULL default '0',
    `user_avatar`           varchar(100)                                    NOT NULL default '',
    `user_avatar_type`      tinyint(4)                                      NOT NULL default '0',
    `user_email`            varchar(255)                                    NOT NULL default '',
    `user_icq`              varchar(15)                                     NOT NULL default '',
    `user_website`          varchar(100)                                    NOT NULL default '',
    `user_gender`           tinyint(1)                                      NOT NULL default '0',
    `user_from`             varchar(100)                                    NOT NULL default '',
    `user_sig`              longtext                                        NOT NULL default '',
    `user_sig_bbcode_uid`   varchar(10)                                     NOT NULL default '',
    `user_aim`              varchar(255)                                    NOT NULL default '',
    `user_yim`              varchar(255)                                    NOT NULL default '',
    `user_msnm`             varchar(255)                                    NOT NULL default '',
    `user_magent`           varchar(255)                                    NOT NULL default '',
    `user_occ`              varchar(100)                                    NOT NULL default '',
    `user_interests`        varchar(255)                                    NOT NULL default '',
    `user_actkey`           varchar(32)                                     NOT NULL default '',
    `user_newpasswd`        varchar(32)                                     NOT NULL default '',
    `user_allow_passkey`    tinyint(1)                                      NOT NULL default '1',
    `user_from_flag`        varchar(3)                                      NOT NULL default '',
    `user_upsp`             tinyint(2)                                      NOT NULL default '0',
    `user_dwsp`             tinyint(2)                                      NOT NULL default '0',
    `ignore_srv_load`       tinyint(1)                                      NOT NULL default '0',
    `autologin_id`          varchar(12) character set utf8 collate utf8_bin NOT NULL default '',
    `user_newest_pm_id`     mediumint(8)                                    NOT NULL default '0',
    `user_reputation`       smallint(5)                                     NOT NULL default '0',
    `user_reputation_plus`  smallint(5)                                     NOT NULL default '0',
    `user_warnings_dem`     tinyint(4) unsigned                             NOT NULL default '0',
    `user_reviews`          smallint(5)                                     NOT NULL default '0',
    `user_warnings_total`   smallint(5)                                     NOT NULL default '0',
    `user_bans_total`       smallint(5)                                     NOT NULL default '0',
    `retracker_local`       tinyint(1)                                      NOT NULL default '1',
    `user_agent`            text                                            NOT NULL default '',
    `user_dbg`              tinyint(1)                                      NOT NULL default '0',
    `tpl_name`              varchar(255)                                    NOT NULL default 'default',
    `user_park_profile`     tinyint(1)                                      NOT NULL default '0',
    `user_birthday`         date                                            NOT NULL DEFAULT '1900-01-01',
    PRIMARY KEY (`user_id`),
    KEY `username` (`username`(10)),
    KEY `user_email` (`user_email`(10)),
    KEY `user_level` (`user_level`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 3;

--
-- Дамп данных таблицы `bb_users`
--

INSERT INTO `bb_users`
VALUES (-1, 0, 'Anonymous', '', 0, 0, 0, 0, 1117103663, 0, 0, 0, 0, 0, 3.00, '', '', 0, 0, 0, 220, 1, 0, 1, 0, 1, 0, '',
        0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, '',
        0, 'default', 0, '1900-01-01');
INSERT INTO `bb_users`
VALUES (2, 1, 'admin', 0x3231323332663239376135376135613734333839346130653461383031666333, 1211472784, 0, 1285876800, 0,
        1285876800, 0, 0, 0, 1, 1, 3.00, '', '', 0, 0, 1211472803, 159, 1, 1, 1, 0, 1, 1, 'noavatar.png', 1,
        'admin@admin.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', 0, 0, 0,
        0x4f5750316d724533314b7335, 0, 0, 0, 0, 0, 0, 0, 1, '', 2, 'default', 0, '1900-01-01');
INSERT INTO `bb_users`
VALUES (-746, 0, 'bot', '', 1117115716, 0, 1117115634, 0, 1117114766, 0, 0, 0, 0, 0, 3.00, '', '', 0, 0, 0, 148, 1, 1,
        1, 0, 0, 0, 'bot.gif', 1, 'bot@bot.bot', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', 1, '', 0, 0,
        0, '', 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 'default', 0, '1900-01-01');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_user_group`
--

CREATE TABLE IF NOT EXISTS `bb_user_group`
(
    `group_id`     mediumint(8) NOT NULL default '0',
    `user_id`      mediumint(8) NOT NULL default '0',
    `user_pending` tinyint(1)   NOT NULL default '0',
    `in_time`      INT(11)      NOT NULL default '0',
    PRIMARY KEY (`group_id`, `user_id`),
    KEY `user_id` (`user_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

--
-- Дамп данных таблицы `bb_user_group`
--

INSERT INTO `bb_user_group` (`group_id`, `user_id`, `user_pending`, `in_time`)
VALUES (1, 2, 0, 1293703085);

-- --------------------------------------------------------

--
-- Структура таблицы `bb_vote_desc`
--

CREATE TABLE IF NOT EXISTS `bb_vote_desc`
(
    `vote_id`     mediumint(8) unsigned NOT NULL auto_increment,
    `topic_id`    mediumint(8) unsigned NOT NULL default '0',
    `vote_text`   text                  NOT NULL,
    `vote_start`  int(11)               NOT NULL default '0',
    `vote_length` int(11)               NOT NULL default '0',
    PRIMARY KEY (`vote_id`),
    KEY `topic_id` (`topic_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_vote_results`
--

CREATE TABLE IF NOT EXISTS `bb_vote_results`
(
    `vote_id`          mediumint(8) unsigned NOT NULL default '0',
    `vote_option_id`   tinyint(4) unsigned   NOT NULL default '0',
    `vote_option_text` varchar(255)          NOT NULL default '',
    `vote_result`      int(11)               NOT NULL default '0',
    KEY `vote_option_id` (`vote_option_id`),
    KEY `vote_id` (`vote_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_vote_voters`
--

CREATE TABLE IF NOT EXISTS `bb_vote_voters`
(
    `vote_id`      mediumint(8) unsigned NOT NULL default '0',
    `vote_user_id` mediumint(8)          NOT NULL default '0',
    `vote_user_ip` char(32)              NOT NULL default '',
    KEY `vote_id` (`vote_id`),
    KEY `vote_user_id` (`vote_user_id`),
    KEY `vote_user_ip` (`vote_user_ip`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_words`
--

CREATE TABLE IF NOT EXISTS `bb_words`
(
    `word_id`     mediumint(8) unsigned NOT NULL auto_increment,
    `word`        char(100)             NOT NULL default '',
    `replacement` char(100)             NOT NULL default '',
    PRIMARY KEY (`word_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `buf_last_seeder`
--

CREATE TABLE IF NOT EXISTS `buf_last_seeder`
(
    `topic_id`         mediumint(8) unsigned NOT NULL default '0',
    `seeder_last_seen` int(11)               NOT NULL default '0',
    PRIMARY KEY (`topic_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `buf_topic_view`
--

CREATE TABLE IF NOT EXISTS `buf_topic_view`
(
    `topic_id`    mediumint(8) unsigned NOT NULL default '0',
    `topic_views` mediumint(8) unsigned NOT NULL default '0',
    PRIMARY KEY (`topic_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;


-- --------------------------------------------------------

--
-- Структура таблицы `bb_untrusted_ips`
--

CREATE TABLE IF NOT EXISTS `bb_untrusted_ips`
(
    `untrusted_ip`       char(8)               NOT NULL,
    `untrusted_reason`   enum ('bruteforce')   NOT NULL,
    `untrusted_attempts` mediumint(8) unsigned NOT NULL default '0',
    `untrusted_pending`  tinyint(1) unsigned   NOT NULL default '0',
    UNIQUE KEY `untrusted_ip` (`untrusted_ip`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `invite_rules`
--

CREATE TABLE IF NOT EXISTS `invite_rules`
(
    `rule_id`       INT(4) unsigned NOT NULL auto_increment,
    `user_rating`   INT(4) unsigned NOT NULL default 0,
    `user_age`      INT(4) unsigned NOT NULL default 0,
    `user_group`    mediumint(8)    NOT NULL,
    `invites_count` INT(4) unsigned NOT NULL default 0,
    PRIMARY KEY (`rule_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `invites`
--

CREATE TABLE IF NOT EXISTS `invites`
(
    `invite_id`       INT(8) unsigned NOT NULL auto_increment,
    `user_id`         MEDIUMINT(8)    NOT NULL default 0,
    `new_user_id`     MEDIUMINT(8)    NOT NULL default 0,
    `invite_code`     VARCHAR(16)     NOT NULL default '',
    `active`          ENUM ('1','0')           default '1',
    `generation_date` INT(10)         NOT NULL default '0',
    `activation_date` INT(10)         NOT NULL default '0',
    PRIMARY KEY (`invite_id`)
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sph_counter`
--

CREATE TABLE IF NOT EXISTS `sph_counter`
(
    `counter_id` int(11) NOT NULL,
    `max_doc_id` int(11) NOT NULL,
    PRIMARY KEY (`counter_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `xbt_announce_log`
--

CREATE TABLE IF NOT EXISTS `xbt_announce_log`
(
    `id`         int(11)          NOT NULL AUTO_INCREMENT,
    `ipa`        int(10) unsigned NOT NULL DEFAULT '0',
    `port`       int(11)          NOT NULL DEFAULT '0',
    `event`      int(11)          NOT NULL DEFAULT '0',
    `info_hash`  blob             NOT NULL,
    `peer_id`    blob             NOT NULL,
    `downloaded` bigint(20)       NOT NULL DEFAULT '0',
    `left0`      bigint(20)       NOT NULL DEFAULT '0',
    `uploaded`   bigint(20)       NOT NULL DEFAULT '0',
    `uid`        int(11)          NOT NULL DEFAULT '0',
    `mtime`      int(11)          NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `xbt_config`
--

CREATE TABLE IF NOT EXISTS `xbt_config`
(
    `name`  varchar(255) NOT NULL DEFAULT '',
    `value` varchar(255) NOT NULL DEFAULT '',
    PRIMARY KEY (`name`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `xbt_deny_from_hosts`
--

CREATE TABLE IF NOT EXISTS `xbt_deny_from_hosts`
(
    `begin` int(11) NOT NULL DEFAULT '0',
    `end`   int(11) NOT NULL DEFAULT '0'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `xbt_files_users`
--

CREATE TABLE IF NOT EXISTS `xbt_files_users`
(
    `fid`        int(11)    NOT NULL DEFAULT '0',
    `uid`        int(11)    NOT NULL DEFAULT '0',
    `active`     tinyint(4) NOT NULL DEFAULT '0',
    `announced`  int(11)    NOT NULL DEFAULT '0',
    `completed`  int(11)    NOT NULL DEFAULT '0',
    `downloaded` bigint(20) NOT NULL DEFAULT '0',
    `left`       bigint(20) NOT NULL DEFAULT '0',
    `uploaded`   bigint(20) NOT NULL DEFAULT '0',
    `mtime`      int(11)    NOT NULL DEFAULT '0',
    UNIQUE KEY `fid` (`fid`, `uid`),
    KEY `uid` (`uid`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `xbt_scrape_log`
--

CREATE TABLE IF NOT EXISTS `xbt_scrape_log`
(
    `id`        int(11) NOT NULL AUTO_INCREMENT,
    `ipa`       int(11) NOT NULL DEFAULT '0',
    `info_hash` blob,
    `uid`       int(11) NOT NULL DEFAULT '0',
    `mtime`     int(11) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  AUTO_INCREMENT = 1;

-- --------------------------------------------------------

--
-- Структура таблицы `bb_medal`
--

CREATE TABLE IF NOT EXISTS `bb_medal`
(
    `medal_id`          mediumint(8) UNSIGNED NOT NULL,
    `cat_id`            mediumint(8) UNSIGNED NOT NULL DEFAULT '1',
    `medal_name`        varchar(40)           NOT NULL,
    `medal_description` varchar(255)          NOT NULL,
    `medal_image`       varchar(40)                    DEFAULT NULL
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

--
-- Дамп данных таблицы `bb_medal`
--

INSERT INTO `bb_medal` (`medal_id`, `cat_id`, `medal_name`, `medal_description`, `medal_image`)
VALUES (156, 16, 'Активный релизер 3', 'Выдается релизерам, создавшим 300 релизов',
        'images/medals/m2.gif'),
       (154, 16, 'Активный релизер 2', 'Выдается релизерам, создавшим 100 релизов',
        'images/medals/m3.gif'),
       (153, 16, 'Активный релизер 1', 'Выдается релизерам, создавшим 50 релизов',
        'images/medals/m1.gif'),
       (157, 16, 'Активный релизер 4', 'Выдается релизерам, создавшим 400 релизов',
        'images/medals/m4.gif'),
       (148, 15, 'Орденоносец 3 степени', 'Даётся за получение 15 или более положительных медалей',
        '/images/medals/post50.gif'),
       (149, 15, 'Почетный орденоносец', 'Даётся за получение 25 или более положительных медалей',
        '/images/medals/post200.gif'),
       (164, 6, '1 место', 'Выдается за победу в конкурсах занявших Призовое 1 Место',
        'images/medals/1-mesto.gif'),
       (158, 16, 'Активный релизер 5', 'Выдается релизерам, создавшим 500 релизов',
        'images/medals/m5.gif'),
       (166, 6, '3 Место', 'Выдается за победу в конкурсах занявших Призовое 3 Место',
        'images/medals/3-mesto.gif'),
       (167, 6, 'Чемпион', 'Вручается с 1 местом за победу в конкурсе', 'images/medals/cb4.gif'),
       (168, 6, 'VIP 1', 'VIP приобретён 1 раз', 'images/medals/VIP.gif'),
       (147, 15, 'Орденоносец 2 степени', 'Даётся за получение 10 или более положительных медалей',
        '/images/medals/345.gif'),
       (140, 13, 'Лайк 200', 'За 200 \"лайков\" в профиле пользователя', '/images/medals/zh2.gif'),
       (143, 13, 'Лайк 500', 'За 500 \"лайков\" в профиле пользователя', '/images/medals/zh6.gif'),
       (141, 13, 'Спасибо 5000', 'За 5000 \"спасибо\" в профиле пользователя', '/images/medals/zh3.gif'),
       (142, 13, 'Лайк 300', 'За 300 \"лайков\" в профиле пользователя', '/images/medals/zh5.gif'),
       (144, 13, 'Спасибо 3000', 'За 3000 \"спасибо\" в профиле пользователя', '/images/medals/zh1.gif'),
       (145, 10, 'Мудрец', 'Выдается за 10000 сообщений на форуме', '/images/medals/mdr.gif'),
       (146, 15, 'Орденоносец 1 степени', 'Даётся за получение 5 или более положительных медалей',
        '/images/medals/post100.gif'),
       (133, 13, 'Знаменитость форума 2', 'Выдается за +300 в репутацию на форуме', '/images/medals/1/300+.gif'),
       (132, 13, 'Знаменитость форума 1', 'Выдается за +150 в репутацию на форуме', '/images/medals/1/150+.gif'),
       (134, 13, 'Знаменитость форума 3', 'Выдается за +500 в репутацию на форуме', '/images/medals/1/500+.gif'),
       (135, 13, 'Знаменитость форума 4', 'Выдается за +750 в репутацию на форуме', '/images/medals/1/750+.gif'),
       (136, 13, 'Знаменитость форума 5', 'Выдается за +1000 в репутацию на форуме',
        '/images/medals/1/1000+.gif'),
       (105, 10, 'Активный Форумчанин 1', 'Выдается за 500 сообщений на форуме', '/images/medals/1/500sms.gif'),
       (106, 10, 'Активный Форумчанин 2', 'Выдается за 1000 сообщений на форуме',
        '/images/medals/1/1000sms.gif'),
       (107, 10, 'Активный Форумчанин 3', 'Выдается за 2000 сообщений на форуме',
        '/images/medals/1/2000sms.gif'),
       (108, 10, 'Активный Форумчанин 4', 'Выдается за 3000 сообщений на форуме',
        '/images/medals/1/3000sms.gif'),
       (109, 10, 'Активный Форумчанин 5', 'Выдается за 5000 сообщений на форуме',
        '/images/medals/1/5000sms.gif'),
       (115, 11, 'Тех. Админ', 'Вручается Тех. Администраторам Трекера', 'images/medals/tech_adm.gif'),
       (126, 12, 'Активный сидер 2', 'Активный сидер, раздал 1 TB', 'images/medals/g2.gif'),
       (119, 11, 'Авторитет', 'Авторитет', 'images/medals/aktivnix.gif'),
       (114, 11, 'Дизайнер', 'Вручается Дизайнерам Трекера', 'images/medals/2000 sms.gif'),
       (127, 12, 'Активный сидер 3', 'Активный сидер, раздал 5 TB', 'images/medals/metal.gif'),
       (129, 12, 'Активный сидер 5', 'Активный сидер, раздал 20 TB', 'images/medals/100-gb.gif'),
       (128, 12, 'Активный сидер 4', 'Активный сидер, раздал 10 TB', 'images/medals/3000 sms.gif'),
       (125, 12, 'Активный сидер 1', 'Активный сидер, раздал 500 GB', 'images/medals/g1.gif'),
       (159, 16, 'Мега релизер', 'Выдается релизерам, создавшим 1000 релизов',
        'images/medals/activ3000.gif'),
       (169, 6, 'VIP 2', 'VIP приобретён 2 раза', 'images/medals/VIP7.gif'),
       (161, 6, 'Кубок Достоинства', 'Вручается достойному трекерчанину', 'images/medals/medal2.gif'),
       (165, 6, '2 место', 'Выдается за победу в конкурсах занявших Призовое 2 Место',
        'images/medals/2-mesto.gif'),
       (170, 6, 'VIP 3', 'VIP приобретен 3 раза и больше', 'images/medals/VIP1.gif'),
       (171, 6, 'Победитель в мини конкурсе', 'За победы в мини конкурсах', 'images/medals/1 (1).gif'),
       (172, 11, 'Легенда', 'Вручается за неоценимый вклад в развитие трекера', 'images/medals/medal8.gif'),
       (175, 17, 'Почетный Репортёр', 'Выдается за развитие раздела новостей', 'images/medals/journal.gif'),
       (174, 17, 'Ни дня без новостей', 'Выдается за активное и регулярное размещение новостей',
        'images/medals/Rep.gif'),
       (176, 18, 'S.T.A.L.K.E.R', 'Опытным Сталкерам знающих \"Зону\"', 'images/medals/Stl.gif'),
       (179, 18, 'Киноман', 'Выдается любителям кино', 'images/medals/400 100.gif'),
       (178, 18, 'Аниме', 'Любителям Аниме', 'images/medals/anime.gif'),
       (180, 18, 'Меломан', 'Любителю музыки', 'images/medals/music.gif'),
       (183, 18, 'Фанат футбола', 'Футбольный фанат', 'images/medals/gol.gif'),
       (182, 18, 'Сериалист', 'Любителю сериалов', 'images/medals/68l.gif'),
       (184, 18, 'Любителям животных', 'Любителям животных', 'images/medals/8da185972668.gif'),
       (185, 18, 'Друг трекера', 'Друг (партнёр)', 'images/medals/0.gif'),
       (186, 18, 'Soft', 'Релизёрам софта', 'images/medals/Soft.gif'),
       (187, 18, 'Speedy', 'За хорошую скорость отдачи', 'images/medals/8.gif'),
       (188, 18, 'Игроман', 'Любителям Игр', 'images/medals/msnt.gif'),
       (189, 18, 'Металлист', 'Pure Fucking Metal', 'images/medals/Mtl.gif'),
       (193, 19, 'Примерный модератор', 'Выдается модераторам, за порядок в разделе',
        'images/medals/5000 sms.gif'),
       (194, 19, 'Активный Модератор', 'Вручается модератору за активность', 'images/medals/100tb.gif'),
       (192, 19, 'Модератор', 'Вручается всем модераторам трекера', 'images/medals/aft.gif'),
       (195, 11, 'Admin', 'Вручается Администраторам Трекера', 'images/medals/Exemplary.gif'),
       (196, 20, 'Lady Butterfly', 'Для творческих девушек', 'images/medals/girl55.gif'),
       (197, 20, 'Активная девушка', 'Active girl', 'images/medals/girl99.gif'),
       (198, 20, 'Бандитка', 'Для девушек хулиганок', 'images/medals/girl44.gif'),
       (199, 20, 'Красотка', 'Красотка', 'images/medals/girl11.gif'),
       (200, 20, 'Мисс Очарование', 'Очаровательным девушкам', 'images/medals/girl66.gif'),
       (201, 20, 'Мисс Элегантность', 'Элегантным девушкам', 'images/medals/girl22.gif'),
       (202, 20, 'Прикольная девчонка', 'Для прикольных девушек', 'images/medals/girl33.gif'),
       (204, 20, 'Рок Леди', 'Rock Lady', 'images/medals/girl88.gif');

-- --------------------------------------------------------

--
-- Структура таблицы `bb_medal_cat`
--

CREATE TABLE IF NOT EXISTS `bb_medal_cat`
(
    `cat_id`    mediumint(8) UNSIGNED NOT NULL,
    `cat_title` varchar(100)          NOT NULL,
    `cat_order` mediumint(8) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

--
-- Дамп данных таблицы `bb_medal_cat`
--

INSERT INTO `bb_medal_cat` (`cat_id`, `cat_title`, `cat_order`)
VALUES (13, 'Знаменитость форума', 90),
       (12, 'Топ сидеры', 50),
       (11, 'Элитные награды', 10),
       (6, 'Победители и VIP', 30),
       (10, 'Активный Форумчанин', 80),
       (15, 'Орденоносец', 40),
       (16, 'Активный релизер', 60),
       (17, 'Репортёрам', 100),
       (18, 'Разные', 110),
       (19, 'Модератор', 20),
       (20, 'Девушкам', 70);

-- --------------------------------------------------------

--
-- Структура таблицы `bb_medal_mod`
--

CREATE TABLE IF NOT EXISTS `bb_medal_mod`
(
    `mod_id`   mediumint(8) UNSIGNED NOT NULL,
    `medal_id` mediumint(8) UNSIGNED NOT NULL,
    `user_id`  mediumint(8) UNSIGNED NOT NULL
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;

--
-- Дамп данных таблицы `bb_medal_mod`
--

INSERT INTO `bb_medal_mod` (`mod_id`, `medal_id`, `user_id`)
VALUES (1, 102, 5056),
       (2, 24, 5056),
       (3, 69, 5056),
       (4, 98, 5056),
       (5, 99, 5056),
       (6, 100, 5056),
       (7, 101, 5056),
       (8, 76, 5056),
       (9, 77, 5056),
       (10, 97, 5056),
       (11, 70, 5056),
       (12, 71, 5056),
       (13, 72, 5056),
       (14, 73, 5056),
       (15, 74, 5056),
       (16, 94, 5056),
       (17, 96, 5056),
       (18, 12, 5056),
       (19, 13, 5056),
       (20, 14, 5056),
       (21, 83, 5056),
       (22, 81, 5056),
       (23, 21, 5056),
       (24, 91, 5056),
       (25, 86, 5056),
       (26, 82, 5056),
       (27, 87, 5056),
       (28, 88, 5056),
       (29, 90, 5056),
       (30, 48, 5056),
       (31, 104, 5056),
       (32, 22, 5056),
       (33, 84, 5056),
       (34, 80, 5056),
       (35, 85, 5056),
       (36, 65, 5056),
       (37, 64, 5056),
       (38, 45, 5056),
       (39, 31, 5056),
       (40, 32, 5056),
       (41, 92, 5056),
       (42, 79, 5056),
       (43, 93, 5056),
       (44, 193, 5055),
       (45, 194, 5055),
       (46, 192, 5055);

-- --------------------------------------------------------

--
-- Структура таблицы `bb_medal_user`
--

CREATE TABLE IF NOT EXISTS `bb_medal_user`
(
    `issue_id`     mediumint(8) UNSIGNED NOT NULL,
    `medal_id`     mediumint(8) UNSIGNED NOT NULL,
    `user_id`      mediumint(8) UNSIGNED NOT NULL,
    `issue_reason` varchar(255)          NOT NULL,
    `issue_time`   int(11)               NOT NULL
) ENGINE = MyISAM
  DEFAULT CHARSET = utf8;
