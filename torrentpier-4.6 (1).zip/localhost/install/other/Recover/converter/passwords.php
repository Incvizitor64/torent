<?php 
$passwords = array();