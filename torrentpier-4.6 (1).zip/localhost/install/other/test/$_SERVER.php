<pre>
<?php echo htmlspecialchars(print_r($_SERVER, true)) ?>
</pre>