<?php
	echo '<pre>';
	print_r(apache_get_modules());
	echo '</pre>';