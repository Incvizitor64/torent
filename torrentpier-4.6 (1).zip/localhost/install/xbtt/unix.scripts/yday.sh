#!/bin/sh

cd /usr/local/rss

PATH=/usr/local/bin:${PATH}

mysql -u <login> -p<pass> -D <database> <yday.sql 1>yday1.log 2>yday2.log