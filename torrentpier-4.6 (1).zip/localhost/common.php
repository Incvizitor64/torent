<?php

/*
	This file is part of TorrentPier

	TorrentPier is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	TorrentPier is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	A copy of the GPL 2.0 should have been included with the program.
	If not, see http://www.gnu.org/licenses/

	Official SVN repository and contact information can be found at
	http://code.google.com/p/torrentpier/
 */

header('X-Frame-Options: SAMEORIGIN');
ignore_user_abort(true);
define('TIMESTART', utime());
define('TIMENOW',   time());

/**
 * Determines if the current version of PHP is equal to or greater than the supplied value
 *
 * @param	string
 * @return	bool	TRUE if the current version is $version or higher
 */
function is_php($version)
{
    static $_is_php;
    $version = (string) $version;

    if ( ! isset($_is_php[$version]))
    {
        $_is_php[$version] = version_compare(PHP_VERSION, $version, '>=');
    }

    return $_is_php[$version];
}

// Version check
if(!is_php('5.3.3')) {
    exit('TorrentPier requires PHP version 5.3.3+. Your PHP version '. PHP_VERSION . "\n");
}
if(is_php('8.0.0')) {
    exit('TorrentPier requires 7.4 >= PHP version. Your PHP version '. PHP_VERSION . "\n");
}

/*
 * ------------------------------------------------------
 * Security procedures
 * ------------------------------------------------------
 */
if ( ! is_php('5.4'))
{
    @set_magic_quotes_runtime(0);
    ini_set('magic_quotes_runtime', 0);

    if ((bool) ini_get('register_globals'))
    {
        $_protected = array(
            '_SERVER',
            '_GET',
            '_POST',
            '_FILES',
            '_REQUEST',
            '_SESSION',
            '_ENV',
            '_COOKIE',
            'GLOBALS',
            'HTTP_RAW_POST_DATA',
            'system_path',
            'application_folder',
            'view_folder',
            '_protected',
            '_registered'
        );

        $_registered = ini_get('variables_order');
        foreach (array('E' => '_ENV', 'G' => '_GET', 'P' => '_POST', 'C' => '_COOKIE', 'S' => '_SERVER') as $key => $superglobal)
        {
            if (strpos($_registered, $key) === FALSE)
            {
                continue;
            }

            foreach (array_keys($$superglobal) as $var)
            {
                if (isset($GLOBALS[$var]) && ! in_array($var, $_protected, TRUE))
                {
                    $GLOBALS[$var] = NULL;
                }
            }
        }
    }
    define('STRIP_SLASHES', get_magic_quotes_gpc());
    if (STRIP_SLASHES) die('set magic_quotes off');
} else {
    define('STRIP_SLASHES', true); // always true!
}

if (isset($_REQUEST['GLOBALS']) || isset($_FILES['GLOBALS'])) die();

if (empty($_SERVER['REMOTE_ADDR'])) {
    $_SERVER['REMOTE_ADDR'] = '127.0.0.1';
}
if (empty($_SERVER['SERVER_NAME'])) {
    $_SERVER['SERVER_NAME'] = '';
}

$rootPath = __DIR__;
if (DIRECTORY_SEPARATOR != '/') $rootPath = str_replace(DIRECTORY_SEPARATOR, '/', $rootPath);
if (!defined('BB_ROOT')) define('BB_ROOT', $rootPath);
if (!defined('PHP_EXT')) define('PHP_EXT', substr(strrchr(__FILE__, '.'), 1));
if (!defined('IN_PHPBB') && !defined('IN_TRACKER')) define('IN_PHPBB', true);
if (!defined('BB_PATH')) define('BB_PATH', realpath(BB_ROOT)); // absolute pathname to the forum root
if (!isset($phpEx)) $phpEx = PHP_EXT;
$phpbb_root_path = BB_ROOT;

function sql_dbg_enabled ()
{
    return (SQL_DEBUG && DBG_USER);
}

// Composer
define('COMPOSER_DIR', BB_PATH .'/vendor/');
if (!file_exists(COMPOSER_DIR . 'autoload.' . PHP_EXT)) {
    exit('Please <a href="https://getcomposer.org/download/" target="_blank" rel="noreferrer" style="color:#0a25bb;">install composer</a> and run <code style="background:#222;color:#00e01f;padding:2px 6px;border-radius:3px;">composer install</code>');
}
require_once (COMPOSER_DIR . 'autoload.' . PHP_EXT); // Include a composer

// Get initial config
define('CFG_DIR', BB_PATH .'/config/');
require(CFG_DIR .'config.'. PHP_EXT);
require(CFG_DIR .'config_mods.'. PHP_EXT);

if (empty($dbcharset)) $dbcharset = 'utf8';

/*
 * ------------------------------------------------------
 * Important charset-related stuff
 * ------------------------------------------------------
 *
 * Configure mbstring and/or iconv if they are enabled
 * and set MB_ENABLED and ICONV_ENABLED constants, so
 * that we don't repeatedly do extension_loaded() or
 * function_exists() calls.
 *
 * Note: UTF-8 class depends on this. It used to be done
 * in it's constructor, but it's _not_ class-specific.
 *
 */
$charset = strtoupper($bb_cfg['system_charset']);
ini_set('default_charset', $charset);

if (extension_loaded('mbstring')) {
    define('MB_ENABLED', TRUE);
    // mbstring.internal_encoding is deprecated starting with PHP 5.6
    // and it's usage triggers E_DEPRECATED messages.
    @ini_set('mbstring.internal_encoding', $charset);
    // This is required for mb_convert_encoding() to strip invalid characters.
    // That's utilized by CI_Utf8, but it's also done for consistency with iconv.
    mb_substitute_character('none');
} else {
    define('MB_ENABLED', FALSE);
}

// There's an ICONV_IMPL constant, but the PHP manual says that using
// iconv's predefined constants is "strongly discouraged".
if (extension_loaded('iconv')) {
    define('ICONV_ENABLED', TRUE);
    // iconv.internal_encoding is deprecated starting with PHP 5.6
    // and it's usage triggers E_DEPRECATED messages.
    @ini_set('iconv.internal_encoding', $charset);
} else {
    define('ICONV_ENABLED', FALSE);
}

if (is_php('5.6')) {
    ini_set('php.internal_encoding', $charset);
}

function bb_log ($msg, $file_name)
{
    if (is_array($msg))
    {
        $msg = join(LOG_LF, $msg);
    }
    $file_name .= (LOG_EXT) ? '.'. LOG_EXT : '';
    return file_write($msg, LOG_DIR . $file_name);
}

function dbg_log ($str, $file)
{
    if (!DBG_LOG) return;

    $dir = LOG_DIR . (defined('IN_PHPBB') ? 'dbg_bb/' : 'dbg_tr/') . date(LOG_DATE_FORMAT) .'/';
    return file_write($str, $dir . $file, false, false);
}

function file_write ($str, $file, $max_size = LOG_MAX_SIZE, $lock = true, $replace_content = false)
{
    $bytes_written = false;

    if ($max_size && @filesize($file) >= $max_size)
    {
        $old_name = $file; $ext = '';
        if (preg_match('#^(.+)(\.[^\\/]+)$#', $file, $matches))
        {
            $old_name = $matches[1]; $ext = $matches[2];
        }
        $new_name = $old_name .'_[old]_'. date('Y-m-d_H-i-s_') . getmypid() . $ext;
        clearstatcache();
        if (@file_exists($file) && @filesize($file) >= $max_size && !@file_exists($new_name))
        {
            @rename($file, $new_name);
        }
    }
    if (!$fp = @fopen($file, 'ab'))
    {
        if ($dir_created = bb_mkdir(dirname($file)))
        {
            $fp = @fopen($file, 'ab');
        }
    }
    if ($fp)
    {
        if ($lock)
        {
            @flock($fp, LOCK_EX);
        }
        if ($replace_content)
        {
            @ftruncate($fp, 0);
            @fseek($fp, 0, SEEK_SET);
        }
        $bytes_written = @fwrite($fp, $str);
        @fclose($fp);
    }

    return $bytes_written;
}

function bb_mkdir ($path, $mode = 0777)
{
    $old_um = umask(0);
    $dir = mkdir_rec($path, $mode);
    umask($old_um);
    return $dir;
}

function mkdir_rec ($path, $mode)
{
    if (is_dir($path))
    {
        return ($path !== '.' && $path !== '..') ? is_writable($path) : false;
    }
    else
    {
        return (mkdir_rec(dirname($path), $mode)) ? @mkdir($path, $mode) : false;
    }
}

/*
 * ------------------------------------------------------
 *  Load compatibility features
 * ------------------------------------------------------
 */
require_once(INC_DIR.'/compat/mbstring.php');
require_once(INC_DIR.'/compat/hash.php');
require_once(INC_DIR.'/compat/password.php');
require_once(INC_DIR.'/compat/standard.php');
require_once(INC_DIR.'/compat/other.php');
require_once(INC_DIR.'/compat/other2.php');
if(is_php('7.0')) {
    require_once(INC_DIR.'/compat/mysqli/autoload.php'); // основной костыль для долгосрочной поддержки... ♻
    if (DBG_LOG) dbg_log('-_-', '__LTS__');
}

// Ported from TorrentPier 2.3
$server_protocol = $bb_cfg['cookie_secure'] ? 'https://' : 'http://';
$server_port = in_array((int)$bb_cfg['server_port'], array(80, 443), true) ? '' : ':' . $bb_cfg['server_port'];
define('FORUM_PATH', $bb_cfg['script_path']);
define('FULL_URL', $server_protocol . $bb_cfg['server_name'] . $server_port . $bb_cfg['script_path']);
unset($server_protocol, $server_port);

// Debug options
define('DBG_USER', (isset($_COOKIE[COOKIE_DBG])));
if (DBG_LOG) dbg_log(' ', '__hits__');

// Board/Tracker shared constants and functions
define('BT_TORRENTS_TABLE',      'bb_bt_torrents');
define('BT_TRACKER_TABLE',       'bb_bt_tracker');
define('BT_TRACKER_SNAP_TABLE',  'bb_bt_tracker_snap');
define('BT_USERS_TABLE',         'bb_bt_users');
define('BT_CHEATER_TABLE',       'bb_bt_cheater');

define('BT_AUTH_KEY_LENGTH', 10);

define('DL_STATUS_RELEASER', -1);
define('DL_STATUS_DOWN',      0);
define('DL_STATUS_COMPLETE',  1);
define('DL_STATUS_CANCEL',    3);
define('DL_STATUS_WILL',      4);

define('TOR_TYPE_GOLD',       1);
define('TOR_TYPE_SILVER',     2);

define('ANONYMOUS', -1);

// Cache
define('PEER_HASH_PREFIX',  'peer_');
define('PEERS_LIST_PREFIX', 'peers_list_');

define('PEER_HASH_EXPIRE',  round($bb_cfg['announce_interval'] * (0.85*$tr_cfg['expire_factor'])));  // sec
define('PEERS_LIST_EXPIRE', round($bb_cfg['announce_interval'] * 0.7));  // sec

if (!function_exists('sqlite_escape_string'))
{
    function sqlite_escape_string($string)
    {
        return SQLite3::escapeString($string);
    }
}

class cache_common
{
	var $used = false;

	/**
	* Returns value of variable
	*/
	function get ($name, $get_miss_key_callback = '', $ttl = 604800)
	{
        if ($get_miss_key_callback) return $get_miss_key_callback($name);
        return is_array($name) ? array() : false;
	}
	/**
	* Store value of variable
	*/
	function set ($name, $value, $ttl = 604800)
	{
		return false;
	}
	/**
	* Remove variable
	*/
	function rm ($name = '')
	{
		return false;
	}
}

/* [Start] Redis cache system */
class cache_redis extends cache_common
{
    var $used       = true;
    var $cfg        = null;
    var $redis      = null;
    var $connected  = false;

    function __construct($cfg)
    {
        global $bb_cfg;

        if (!$this->is_installed())
        {
            die('Error: Redis extension not installed');
        }

        $this->cfg = $cfg;
        $string = ($this->cfg['scheme'] . '://' . $this->cfg['host'] . ':' . $this->cfg['port'] . '/?password=' . $this->cfg['password'] . '&database=' . $this->cfg['database'] . '&timeout=' . $this->cfg['conn_timeout'] . '&read_write_timeout=' . $this->cfg['wr_timeout']);
        $this->redis = new \Predis\Client($string);
    }

    function connect ()
    {
        try {
            $this->redis->connect();
        } catch (Exception $e) {
            $this->connected = false;
            if (DBG_LOG) dbg_log(' ', 'CACHE-connect-FAIL');
        }

        if (@$this->redis->isConnected())
        {
            if (DBG_LOG) dbg_log(' ', 'CACHE-connect');
            $this->connected = true;
        }

        if (!$this->connected && $this->cfg['con_required'])
        {
            die('Could not connect to redis server');
        }
    }

    function get ($name, $get_miss_key_callback = '', $ttl = 0)
    {
        if (!$this->connected) $this->connect();
        return ($this->connected) ? unserialize($this->redis->get($name)) : false;
    }

    function set ($name, $value, $ttl = 0)
    {
        if (!$this->connected) $this->connect();
        if ($this->redis->set($name, serialize($value))) {
            if ($ttl > 0)
            {
                $this->redis->expire($name, $ttl);
            }
            return true;
        } else {
            return false;
        }
    }

    function rm ($name = '')
    {
        if (!$this->connected) $this->connect();
        if($name) {
            return ($this->connected) ? $this->redis->del($name) : false;
        } else {
            return ($this->connected) ? $this->redis->flushdb() : false;
        }
    }

    function is_installed ()
    {
        if(class_exists('\Predis\Client') && extension_loaded('redis')) {
            return true;
        } else {
            return false;
        }
    }
}
/* [End] Redis cache system */

/* [Start] Wincache system */
class cache_wincache extends cache_common
{
    var $used = true;

    function __construct()
    {
        if (!$this->is_installed())
        {
            die('Error: Wincache extension not installed');
        }
    }

    function get ($name, $get_miss_key_callback = '', $ttl = 0)
    {
        $success = FALSE;
        $data = wincache_ucache_get($name, $success);

        // Success returned by reference from wincache_ucache_get()
        return ($success) ? $data : FALSE;
    }

    function set ($name, $value, $ttl = 0)
    {
        return wincache_ucache_set($name, $value, $ttl);
    }

    function rm ($name = '')
    {
        if($name) {
            return wincache_ucache_delete($name);
        } else {
            return wincache_ucache_clear();
        }
    }

    function is_installed ()
    {
        return extension_loaded('wincache');
    }
}
/* [End] Wincache system */

class cache_eaccelerator extends cache_common
{
	var $used = true;

	function __construct()
	{
		if (!$this->is_installed())
		{
			die('Error: eAccelerator function does not exist');
		}
	}

	function get ($name, $get_miss_key_callback = '', $ttl = 0)
	{
		return eaccelerator_get($name);
	}

	function set ($name, $value, $ttl = 0)
	{
		return eaccelerator_put($name, $value, $ttl);
	}

	function rm ($name = '')
	{
		return eaccelerator_rm($name);
	}

	function is_installed ()
	{
		return function_exists('eaccelerator_get');
	}
}

class cache_apc extends cache_common
{
	var $used = true;

	function __construct()
	{
		if (!$this->is_installed())
		{
			die('Error: APC function does not exist');
		}
	}

	function get ($name, $get_miss_key_callback = '', $ttl = 0)
	{
		return apc_fetch($name);
	}

	function set ($name, $value, $ttl = 0)
	{
		return apc_store($name, $value, $ttl);
	}

	function rm ($name = '')
	{
        if ($name) {
            return apc_delete($name);
        } else {
            return apc_clear_cache();
        }
	}

	function is_installed ()
	{
		return function_exists('apc_fetch');
	}
}

class cache_memcached extends cache_common
{
	var $used      = true;
	var $cfg       = null;
	var $memcached  = null;
	var $connected = false;

	function __construct($cfg)
	{
		global $bb_cfg;

		if (!$this->is_installed())
		{
			die('Error: Memcached extension not installed');
		}

		$this->cfg = $cfg;
		$this->memcached = new Memcache;
	}

	function connect ()
	{
		$connect_type = ($this->cfg['pconnect']) ? 'pconnect' : 'connect';

		if (@$this->memcached->$connect_type($this->cfg['host'], $this->cfg['port']))
		{
			$this->connected = true;
		}

		if (DBG_LOG) dbg_log(' ', 'CACHE-connect'. ($this->connected ? '' : '-FAIL'));

		if (!$this->connected && $this->cfg['con_required'])
		{
			die('Could not connect to memcached server');
		}
	}

	function get ($name, $get_miss_key_callback = '', $ttl = 0)
	{
		if (!$this->connected) $this->connect();
		return ($this->connected) ? $this->memcached->get($name) : false;
	}

	function set ($name, $value, $ttl = 0)
	{
		if (!$this->connected) $this->connect();
		return ($this->connected) ? $this->memcached->set($name, $value, false, $ttl) : false;
	}

	function rm ($name = '')
	{
		if (!$this->connected) $this->connect();
        if ($name) {
            return ($this->connected) ? $this->memcached->delete($name, 0) : false;
        } else {
            return ($this->connected) ? $this->memcached->flush() : false;
        }
	}

	function is_installed ()
	{
		return class_exists('Memcache');
	}
}

class cache_xcache extends cache_common
{
	var $used = true;

	function __construct()
	{
		if (!$this->is_installed())
		{
			die('Error: xCache function does not exist');
		}
	}

	function get ($name, $get_miss_key_callback = '', $ttl = 0)
	{
		return xcache_get($name);
	}

	function set ($name, $value, $ttl = 0)
	{
		return xcache_set($name, $value, $ttl);
	}

	function rm ($name = '')
	{
        if ($name) {
            return xcache_unset($name);
        } else {
            xcache_clear_cache(XC_TYPE_PHP, 0);
            xcache_clear_cache(XC_TYPE_VAR, 0);
            return;
        }
	}

	function is_installed ()
	{
		return function_exists('xcache_get');
	}
}

class cache_sqlite extends cache_common
{
	var $used = true;
	var $cfg  = array();
	var $db   = null;

	function __construct($cfg)
	{
        $this->cfg = array_merge($this->cfg, $cfg);
        $this->db = new sqlite_common($cfg);
	}

	function get ($name, $get_miss_key_callback = '', $ttl = 604800)
	{
        if (empty($name))
        {
            return is_array($name) ? array() : false;
        }
        $this->db->shard($name);
        $cached_items = array();
        $name_ary = $name_sql = (array) $name;
        array_deep($name_sql, 'sqlite_escape_string');

        // get available items
        $count_name = is_countable($name) ? count($name) : 0;
        $rowset = $this->db->fetch_rowset("
			SELECT cache_name, cache_value
			FROM ". $this->cfg['table_name'] ."
			WHERE cache_name IN('". join("','", $name_sql) ."') AND cache_expire_time > ". TIMENOW ."
			LIMIT ". $count_name ."
		");

        foreach ($rowset as $row)
        {
            $cached_items[$row['cache_name']] = unserialize($row['cache_value']);
        }

        // get miss items
        if ($get_miss_key_callback AND $miss_key = array_diff($name_ary, array_keys($cached_items)))
        {
            foreach ($get_miss_key_callback($miss_key) as $k => $v)
            {
                $this->set($k, $v, $ttl);
                $cached_items[$k] = $v;
            }
        }
        // return
        if (is_array($name))
        {
            return $cached_items;
        }
        else
        {
            return isset($cached_items[$name]) ? $cached_items[$name] : false;
        }
	}

	function set ($name, $value, $ttl = 604800)
	{
        $this->db->shard($name);
		$name   = sqlite_escape_string($name);
		$expire = TIMENOW + $ttl;
		$value  = sqlite_escape_string(serialize($value));

		$result = $this->db->query("
			REPLACE INTO ". $this->cfg['table_name'] ."
				(cache_name, cache_expire_time, cache_value)
			VALUES
				('$name', '$expire', '$value')
		");

		return (bool) $result;
	}

	function rm ($name = '')
	{
        if ($name) {
            $this->db->shard($name);
            $result = $this->db->query("
			DELETE FROM " . $this->cfg['table_name'] . "
			WHERE cache_name = '" . sqlite_escape_string($name) . "'
		");
        } else {
            $result = $this->db->query("DELETE FROM ". $this->cfg['table_name']);
        }

		return (bool) $result;
	}

	function gc ($expire_time = TIMENOW)
	{
        $result = $this->db->query("DELETE FROM ". $this->cfg['table_name'] ." WHERE cache_expire_time < $expire_time");
        return ($result) ? $this->db->changes() : 0;
	}
}

class cache_file extends cache_common
{
	var $used = true;
	var $dir  = null;

	function __construct($dir)
	{
		$this->dir = $dir;
	}

	function get ($name, $get_miss_key_callback = '', $ttl = 0)
	{
		$filename = $this->dir . clean_filename($name) . '.'. PHP_EXT;
		
		if(file_exists($filename)) 
		{
			require($filename);
		}		

		return (!empty($filecache['value'])) ? $filecache['value'] : false;
	}

	function set ($name, $value, $ttl = 86400)
	{
		if (!\function_exists('var_export'))
		{
			return false;
		}
		
		$filename   = $this->dir . clean_filename($name) . '.'. PHP_EXT;
		$expire     = TIMENOW + $ttl;
		$cache_data = array(
			'expire'  => $expire,
			'value'   => $value,
		);

		$filecache = "<?php\n";
		$filecache .= "if (!defined('BB_ROOT')) die(basename(__FILE__));\n";
		$filecache .= '$filecache = ' . var_export($cache_data, true) . ";\n";
		$filecache .= '?>';		

		return (bool) file_write($filecache, $filename, false, true, true);
	}

	function rm ($name = '')
	{
        $clear = false;
        if ($name) {
            $filename = $this->dir . clean_filename($name) . '.' . PHP_EXT;
            if (file_exists($filename)) {
                $clear = (bool)unlink($filename);
            }
        } else {
            if (is_dir($this->dir)) {
                if ($dh = opendir($this->dir)) {
                    while (($file = readdir($dh)) !== false) {
                        if ($file != "." && $file != ".." && $file != '.htaccess') {
                            $filename = $this->dir . $file;

                            unlink($filename);
                            $clear = true;
                        }
                    }
                    closedir($dh);
                }
            }
        }
        return $clear;
	}

    function gc ($expire_time = TIMENOW)
    {
        $dir = $this->dir;
        $clear = false;

        if (is_dir($dir))
        {
            if ($dh = opendir($dir))
            {
                while (($file = readdir($dh)) !== false)
                {
                    if ($file != "." && $file != ".." && $file != '.htaccess')
                    {
                        $filename = $dir . $file;

                        require($filename);

                        if(!empty($filecache['expire']) && ($filecache['expire'] < $expire_time))
                        {
                            unlink($filename);
                            $clear = true;
                        }
                    }
                }
                closedir($dh);
            }
        }

        return $clear;
    }
}

class sqlite_common extends cache_common
{
    var $cfg = array(
        'db_file_path' => 'sqlite.db',
        'table_name' => 'table_name',
        'table_schema' => 'CREATE TABLE table_name (...)',
        'pconnect' => true,
        'con_required' => true,
        'log_name' => 'SQLite',
        'shard_type' => 'none',     #  none, string, int (тип первичного ключа для шардинга)
        'shard_val' => 0,          #  для string - кол. начальных символов, для int - делитель (будет использован остаток от деления)
    );
	var $dbh       = null;
	var $connected = false;
    var $shard_val = false;

	var $num_queries    = 0;
	var $sql_starttime  = 0;
	var $sql_inittime   = 0;
	var $sql_timetotal  = 0;
	var $cur_query_time = 0;

	var $dbg            = array();
	var $dbg_id         = 0;
	var $dbg_enabled    = false;
	var $cur_query      = null;

	var $table_create_attempts = 0;

	function __construct($cfg)
	{
		$this->cfg = array_merge($this->cfg, $cfg);
		$this->dbg_enabled = sql_dbg_enabled();
	}

	function connect ()
	{
		$this->cur_query = 'connect';
		$this->debug('start');

        if (@$this->dbh = new SQLite3($this->cfg['db_file_path']))
        {
            $this->connected = true;
        }

		if (DBG_LOG) dbg_log(' ', $this->cfg['log_name'] .'-connect'. ($this->connected ? '' : '-FAIL'));

		if (!$this->connected && $this->cfg['con_required'])
		{
			trigger_error('SQLite not connected', E_USER_ERROR);
		}

		$this->debug('stop');
		$this->cur_query = null;
	}

	function create_table ()
	{
		$this->table_create_attempts++;
        return $this->dbh->query($this->cfg['table_schema']);
	}

    function shard ($name)
    {
        $type = $this->cfg['shard_type'];

        if ($type == 'none') return;
        if (is_array($name))  trigger_error('cannot shard: $name is array', E_USER_ERROR);

        // define shard_val
        if ($type == 'string')
        {
            $shard_val = substr($name, 0, $this->cfg['shard_val']);
        }
        else
        {
            $shard_val = $name % $this->cfg['shard_val'];
        }
        // все запросы должны быть к одному и тому же шарду
        if ($this->shard_val !== false)
        {
            if ($shard_val != $this->shard_val)
            {
                trigger_error("shard cannot be reassigned. [{$this->shard_val}, $shard_val, $name]", E_USER_ERROR);
            }
            else
            {
                return;
            }
        }
        $this->shard_val = $shard_val;
        $this->cfg['db_file_path'] = str_replace('*', $shard_val, $this->cfg['db_file_path']);
    }

	function query ($query, $type = 'unbuffered')
	{
		if (!$this->connected) $this->connect();

		$this->cur_query = $query;
		$this->debug('start');

        if (!$result = @$this->dbh->query($query))
        {
            $rowsresult = $this->dbh->query("PRAGMA table_info({$this->cfg['table_name']})");
            $rowscount = 0;
            while ($row = $rowsresult->fetchArray(SQLITE3_ASSOC))
            {
                $rowscount++;
            }
            if (!$this->table_create_attempts && !$rowscount)
            {
                if ($this->create_table())
                {
                    $result = $this->dbh->query($query);
                }
            }
            if (!$result)
            {
                $this->trigger_error($this->get_error_msg());
            }
        }

		$this->debug('stop');
		$this->cur_query = null;

		$this->num_queries++;

		return $result;
	}

	function fetch_row ($query, $type = 'unbuffered')
	{
		$result = $this->query($query, $type);
        return is_resource($result) ? $result->fetchArray(SQLITE3_ASSOC) : false;
	}

	function fetch_rowset ($query, $type = 'unbuffered')
	{
        $result = $this->query($query);
        $rowset = array();
        while ($row = $result->fetchArray(SQLITE3_ASSOC))
        {
            $rowset[] = $row;
        }
        return $rowset;
	}

    function changes ()
    {
        return is_resource($this->dbh) ? $this->dbh->changes() : 0;
    }

	function escape ($str)
	{
		return sqlite_escape_string($str);
	}

	function get_error_msg ()
	{
		return 'SQLite error #'. ($err_code = sqlite_last_error($this->dbh)) .': '. sqlite_error_string($err_code);
	}

    function rm ($name = '')
    {
        if ($name)
        {
            $this->db->shard($name);
            $result = $this->db->query("DELETE FROM ". $this->cfg['table_name'] ." WHERE cache_name = '". sqlite_escape_string($name) ."'");
        }
        else
        {
            $result = $this->db->query("DELETE FROM ". $this->cfg['table_name']);
        }
        return (bool) $result;
    }

    function gc ($expire_time = TIMENOW)
    {
        $result = $this->db->query("DELETE FROM ". $this->cfg['table_name'] ." WHERE cache_expire_time < $expire_time");
        return ($result) ? sqlite_changes($this->db->dbh) : 0;
    }

	function trigger_error ($msg = 'DB Error')
	{
		if (error_reporting()) trigger_error($msg, E_USER_ERROR);
	}

	function debug ($mode)
	{
		if (!$this->dbg_enabled) return;

		$id  =& $this->dbg_id;
		$dbg =& $this->dbg[$id];

		if ($mode == 'start')
		{
			$this->sql_starttime = utime();

			$dbg['sql']  = $this->cur_query;
			$dbg['src']  = $this->debug_find_source();
			$dbg['file'] = $this->debug_find_source('file');
			$dbg['line'] = $this->debug_find_source('line');
			$dbg['time'] = '';
		}
		else if ($mode == 'stop')
		{
			$this->cur_query_time = utime() - $this->sql_starttime;
			$this->sql_timetotal += $this->cur_query_time;
			$dbg['time'] = $this->cur_query_time;
			$id++;
		}
	}

	function debug_find_source ($mode = '')
	{
		foreach (debug_backtrace() as $trace)
		{
			if ($trace['file'] !== __FILE__)
			{
				switch ($mode)
				{
					case 'file': return $trace['file'];
					case 'line': return $trace['line'];
					default: return hide_bb_path($trace['file']) .'('. $trace['line'] .')';
				}
			}
		}
		return null;
	}
}

switch ($bb_cfg['tr_cache_type'])
{
    /* [Start] Redis cache system */
    case 'redis':
        $tr_cache = new cache_redis($bb_cfg['tr_cache']['redis']);
        break;
    /* [End] Redis cache system */

    /* [Start] Wincache system */
    case 'wincache':
        $tr_cache = new cache_wincache();
        break;
    /* [End] Wincache system */

	case 'eaccelerator':
		$tr_cache = new cache_eaccelerator();
		break;

	case 'APC':
		$tr_cache = new cache_apc();
		break;

	case 'memcached':
		$tr_cache = new cache_memcached($bb_cfg['tr_cache']['memcached']);
		break;

	case 'xcache':
		$tr_cache = new cache_xcache();
		break;

	case 'sqlite':
		$tr_cache = new cache_sqlite($bb_cfg['tr_cache']['sqlite']);
		break;
		
	case 'filecache':
		$tr_cache = new cache_file(CACHE_DIR . $bb_cfg['tr_cache']['filecache']['path']);
		break;

	default:
		$tr_cache = new cache_common();
}

switch ($bb_cfg['bb_cache_type'])
{
	case 'same_as_tracker':
		$bb_cache =& $tr_cache;
		break;

    /* [Start] Redis cache system */
    case 'redis':
        $bb_cache = new cache_redis($bb_cfg['bb_cache']['redis']);
        break;
    /* [End] Redis cache system */

    /* [Start] Wincache system */
    case 'wincache':
        $bb_cache = new cache_wincache();
        break;
    /* [End] Wincache system */

	case 'eaccelerator':
		$bb_cache = new cache_eaccelerator();
		break;

	case 'APC':
		$bb_cache = new cache_apc();
		break;

	case 'memcached':
		$bb_cache = new cache_memcached($bb_cfg['bb_cache']['memcached']);
		break;

	case 'xcache':
		$bb_cache = new cache_xcache();
		break;

	case 'sqlite':
		$bb_cache = new cache_sqlite($bb_cfg['bb_cache']['sqlite']);
		break;
		
	case 'filecache':
		$bb_cache = new cache_file(CACHE_DIR . $bb_cfg['bb_cache']['filecache']['path']);
		break;

	default:
		$bb_cache = new cache_common();
}

// Functions
function utime ()
{
	return array_sum(explode(' ', microtime()));
}

function verify_id ($id, $length)
{
	return (preg_match('#^[a-zA-Z0-9]{'. $length .'}$#', $id) && is_string($id));
}

function clean_filename ($fname)
{
	static $s = array('\\', '/', ':', '*', '?', '"', '<', '>', '|', ' ');
	return str_replace($s, '_', str_compact($fname));
}

function encode_ip ($dotquad_ip)
{
	$ip_sep = explode('.', $dotquad_ip);
	if (count($ip_sep) == 4)
	{
		return sprintf('%02x%02x%02x%02x', $ip_sep[0], $ip_sep[1], $ip_sep[2], $ip_sep[3]);
	}

	$ip_sep = explode(':', preg_replace('/(^:)|(:$)/', '', $dotquad_ip));
	$res = '';
	foreach ($ip_sep as $x)
	{
		$res .= sprintf('%0'. ($x == '' ? (9 - count($ip_sep)) * 4 : 4) .'s', $x);
	}
	return $res;
}

function decode_ip ($int_ip)
{
	$int_ip = trim($int_ip);
	
	if (strlen($int_ip) == 32) 
	{
		$int_ip = substr(chunk_split($int_ip, 4, ':'), 0, 39);
		$int_ip = ':'. implode(':', array_map("hexhex", explode(':',$int_ip))) .':';
		preg_match_all("/(:0)+/", $int_ip, $zeros);
		if (count($zeros[0]) > 0) 
		{
			$match = '';
			foreach($zeros[0] as $zero)
				if (strlen($zero) > strlen($match))
					$match = $zero;
			$int_ip = preg_replace('/'. $match .'/', ':', $int_ip, 1);
		}
		return preg_replace('/(^:([^:]))|(([^:]):$)/', '$2$4', $int_ip);
	}
	if (strlen($int_ip) !== 8) $int_ip = '00000000';
	$hexipbang = explode('.', chunk_split($int_ip, 2, '.'));
	return hexdec($hexipbang[0]). '.' . hexdec($hexipbang[1]) . '.' . hexdec($hexipbang[2]) . '.' . hexdec($hexipbang[3]);
}

function hexhex ($value)
{
	return dechex(hexdec($value));
}

function verify_ip ($ip)
{
	return preg_match('#^(\d{1,3}\.){3}\d{1,3}$#', $ip);
}

function str_compact ($str)
{
	return preg_replace('#\s+#', ' ', trim($str));
}

/* From TorrentPier 2.3 Fix */
function make_rand_str($len = 10)
{
    $str = '';
    while (strlen($str) < $len) {
        $str .= str_shuffle(preg_replace('#[^0-9a-zA-Z]#', '', password_hash(uniqid(mt_rand(), true), PASSWORD_BCRYPT)));
    }
    return substr($str, 0, $len);
}

// bencode: based on OpenTracker [http://whitsoftdev.com/opentracker]
function bencode ($var)
{
	if (is_string($var))
	{
		return strlen($var) .':'. $var;
	}
	else if (is_int($var))
	{
		return 'i'. $var .'e';
	}
	else if (is_float($var))
	{
		return 'i'. sprintf('%.0f', $var) .'e';
	}
	else if (is_array($var))
	{
		if (count($var) == 0)
		{
			return 'de';
		}
		else
		{
			$assoc = false;

			foreach ($var as $key => $val)
			{
				if (!is_int($key))
				{
					$assoc = true;
					break;
				}
			}

			if ($assoc)
			{
				ksort($var, SORT_REGULAR);
				$ret = 'd';

				foreach ($var as $key => $val)
				{
					$ret .= bencode($key) . bencode($val);
				}
				return $ret .'e';
			}
			else
			{
				$ret = 'l';

				foreach ($var as $val)
				{
					$ret .= bencode($val);
				}
				return $ret .'e';
			}
		}
	}
	else
	{
		trigger_error('bencode error: wrong data type', E_USER_ERROR);
	}
}

function array_deep (&$var, $fn, $one_dimensional = false, $array_only = false)
{
	if (is_array($var))
	{
		foreach ($var as $k => $v)
		{
			if (is_array($v))
			{
				if ($one_dimensional)
				{
					unset($var[$k]);
				}
				else if ($array_only)
				{
					$var[$k] = $fn($v);
				}
				else
				{
					array_deep($var[$k], $fn);
				}
			}
			else if (!$array_only)
			{
				$var[$k] = $fn($v);
			}
		}
	}
	else if (!$array_only)
	{
		$var = $fn($var);
	}
}

function hide_bb_path ($path)
{
	return substr(str_replace(BB_PATH, '', $path), 1);
}

function tr_drop_request ($drop_type)
{
	if (DBG_LOG) dbg_log(' ', "request-dropped-$drop_type");
	dummy_exit(mt_rand(300, 900));
}

function get_loadavg ()
{
	if (is_callable('sys_getloadavg'))
	{
		$loadavg = join(' ', sys_getloadavg());
	}
	else if (strpos(PHP_OS, 'Linux') !== false)
	{
		$loadavg = @file_get_contents('/proc/loadavg');
	}

	return !empty($loadavg) ? $loadavg : 0;
}

// Board init
if (defined('IN_PHPBB'))
{
	require(INC_DIR .'init_bb.'. PHP_EXT);
}
// Tracker init
else if (defined('IN_TRACKER'))
{
	define('DUMMY_PEER', pack('Nn', ip2long($_SERVER['REMOTE_ADDR']), !empty($_GET['port']) ? intval($_GET['port']) : mt_rand(1000, 65000)));
	
	function dummy_exit ($interval = 1800)
	{
		$output = bencode(array(
			'interval'     => (int)    $interval,
			'min interval' => (int)    $interval,
			'peers'        => (string) DUMMY_PEER,
		));

		die($output);
	}
	
	header('Content-Type: text/plain');
	header('Pragma: no-cache');

	if (STRIP_SLASHES)
	{
		array_deep($_GET, 'stripslashes');
		array_deep($_POST, 'stripslashes');
	}

	if (!defined('IN_ADMIN'))
	{
		// Exit if tracker is disabled via ON/OFF trigger
		if (file_exists(BB_DISABLED))
		{
			dummy_exit(mt_rand(1200, 2400));  #  die('d14:failure reason20:temporarily disablede');
		}

		// Limit server load
		if ($bb_cfg['max_srv_load'] || $bb_cfg['tr_working_second'])
		{
			if ((!empty($_GET['uploaded']) || !empty($_GET['downloaded'])) && (!isset($_GET['event']) || $_GET['event'] === 'started'))
			{
				if ($bb_cfg['tr_working_second'] && (TIMENOW % $bb_cfg['tr_working_second']))
				{
					tr_drop_request('wrk_sec');
				}
				else if ($bb_cfg['max_srv_load'] && LOADAVG)
				{
					if (LOADAVG > $bb_cfg['max_srv_load'])
					{
						tr_drop_request('load');
					}
				}
			}
		}
	}
}