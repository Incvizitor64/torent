<?php

/*
	This file is part of TorrentPier

	TorrentPier is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	TorrentPier is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	A copy of the GPL 2.0 should have been included with the program.
	If not, see http://www.gnu.org/licenses/

	Official SVN repository and contact information can be found at
	http://code.google.com/p/torrentpier/
 */
 
define('IN_PHPBB', true);
define('BB_SCRIPT', 'memberlist');
define('BB_ROOT', './');
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require(BB_ROOT ."common.$phpEx");

$page_cfg['use_tablesorter'] = true;

$user->session_start(array('req_login' => true));

$start = abs(intval(request_var('start', 0)));
$mode  = (string) request_var('mode', 'joined');
$sort_order = (request_var('order', 'ASC') == 'ASC') ? 'ASC' : 'DESC';
$username   = request_var('username', '');
$paginationusername = $username;

//
// Memberlist sorting
//
$mode_types_text = array(
	$lang['Sort_Joined'],
	$lang['Sort_Username'],
	$lang['Sort_Location'],
	$lang['Sort_Posts'],
	$lang['Sort_Email'],
	$lang['Sort_Website'],
	$lang['Sort_Top_Ten']
);

$mode_types = array(
	'joined',
	'username',
	'location',
	'posts',
	'email',
	'website',
	'topten'
);

// Democracy Mod 0.21 adapted [START]
if ($bb_cfg['reputation_enabled'] || $bb_cfg['warnings_enabled'])
{
	include($phpbb_root_path . 'includes/functions_reputation.' . $phpEx);

	// to avoid create_function()
	function democracy_col_reputation($userdata) { return reputation_display($userdata, REPUTATION_SUM, false); }
	function democracy_col_warnings($userdata) { return reputation_warnings($userdata, user_banned($userdata['user_id'], true), 'text', false); }

	$democracy_cols = array(
		array('title' => $lang['Reputation'], 'mode' => 'reputation', 'mode_text' => $lang['Sort_Reputation'], 'auth_key' => 'auth_view_rep', 'applicability' => 'no_rep', 'call' => 'democracy_col_reputation'),
		array('title' => $lang['Warnings'], 'mode' => 'warnings', 'mode_text' => $lang['Sort_Warnings'], 'auth_key' => 'auth_view_warns', 'applicability' => 'no_warn', 'call' => 'democracy_col_warnings'),
	);

	$is_auth = reputation_auth(NO_ID, $userdata);

	for ($i = 0, $len = strlen($bb_cfg['reputation_memberlist']); $i < $len; ++$i)
	{
		if (!$bb_cfg['reputation_memberlist'][$i] || !$is_auth[$democracy_cols[$i]['auth_key']])
		{
			$democracy_cols[$i] = false;
		}
	}
	$democracy_cols = array_filter($democracy_cols);

	foreach ($democracy_cols as $col)
	{
		$mode_types[] = $col['mode'];
		$mode_types_text[] = $col['mode_text'];
		$template->assign_block_vars('democracy', array('L_TITLE' => $col['title']));
	}
}
else
{
	$democracy_cols = array();
}
$template->assign_var('S_COLSPAN', 9 + count($democracy_cols));
// Democracy Mod 0.21 adapted [END]

// <select> mode
$select_sort_mode = '<select name="mode">';

for ($i=0, $cnt=count($mode_types_text); $i < $cnt; $i++)
{
	$selected = ( $mode == $mode_types[$i] ) ? ' selected="selected"' : '';
	$select_sort_mode .= '<option value="' . $mode_types[$i] . '"' . $selected . '>' . $mode_types_text[$i] . '</option>';
}
$select_sort_mode .= '</select>';

// <select> order
$select_sort_order = '<select name="order">';

if ($sort_order == 'ASC')
{
	$select_sort_order .= '<option value="ASC" selected="selected">' . $lang['ASC'] . '</option><option value="DESC">' . $lang['DESC'] . '</option>';
}
else
{
	$select_sort_order .= '<option value="ASC">' . $lang['ASC'] . '</option><option value="DESC" selected="selected">' . $lang['DESC'] . '</option>';
}
$select_sort_order .= '</select>';

//
// Generate page
//
$template->assign_vars(array(
	'S_MODE_SELECT' => $select_sort_mode,
	'S_ORDER_SELECT' => $select_sort_order,
	'S_MODE_ACTION' => append_sid("memberlist.$phpEx"),
	'S_USERNAME' => $paginationusername,
));

switch( $mode )
{
	case 'joined':
		$order_by = "user_id $sort_order LIMIT $start, " . $board_config['topics_per_page'];
		break;
	case 'username':
		$order_by = "username $sort_order LIMIT $start, " . $board_config['topics_per_page'];
		break;
	case 'location':
		$order_by = "user_from $sort_order LIMIT $start, " . $board_config['topics_per_page'];
		break;
	case 'posts':
		$order_by = "user_posts $sort_order LIMIT $start, " . $board_config['topics_per_page'];
		break;
	case 'email':
		$order_by = "user_email $sort_order LIMIT $start, " . $board_config['topics_per_page'];
		break;
	case 'website':
		$order_by = "user_website $sort_order LIMIT $start, " . $board_config['topics_per_page'];
		break;
	case 'topten':
		$order_by = "user_posts $sort_order LIMIT 10";
		break;
	case 'reputation':
		$order_by = "user_reputation $sort_order, user_regdate LIMIT $start, " . $bb_cfg['topics_per_page'];
		break;
	case 'warnings':
		$order_by = "user_warnings_dem $sort_order, user_regdate LIMIT $start, " . $bb_cfg['topics_per_page'];
		break;
	default:
		$order_by = "user_regdate $sort_order LIMIT $start, " . $board_config['topics_per_page'];
		$mode = 'joined';
		break;
}

// per-letter selection
$by_letter = 'all';
//$letters_range = 'a-zа-я';
$letters_range = 'a-z';
$letters_range .= iconv('windows-1251', 'UTF-8', chr(224));
$letters_range .= '-';
$letters_range .= iconv('windows-1251', 'UTF-8', chr(255));
$select_letter = $letter_sql = '';

$by_letter_req = (@$_REQUEST['letter']) ? strtolower(trim($_REQUEST['letter'])) : false;

if ($by_letter_req)
{
	if ($by_letter_req === 'all')
	{
		$by_letter = 'all';
		$letter_sql = '';
	}
	else if ($by_letter_req === 'others')
	{
		$by_letter = 'others';
		$letter_sql = "username REGEXP '^[!-@\\[-`].*$'";
	}
	// else if ($letter_req = preg_replace("#[^$letters_range]#", '', $by_letter_req[0]))
	else if ($letter_req = preg_replace("#[^$letters_range]#ui", '', iconv('windows-1251', 'UTF-8', $by_letter_req[0])))
	{
		$by_letter = $db->escape($letter_req);
		$letter_sql = "LOWER(username) LIKE '$by_letter%'";
	}
}

// ENG
for ($i=ord('A'), $cnt=ord('Z'); $i <= $cnt; $i++)
{
	$select_letter .= ($by_letter == chr($i)) ? '<b>'. chr($i) .'</b>&nbsp;' : '<a class="genmed" href="'. append_sid("memberlist.$phpEx?letter=". chr($i) ."&amp;mode=$mode&amp;order=$sort_order") .'">'. chr($i) .'</a>&nbsp;';
}
// RUS
$select_letter .= ': ';
// for ($i=ord('а'), $cnt=ord('я'); $i <= $cnt; $i++)
for ($i=224, $cnt=255; $i <= $cnt; $i++)
{
   // $select_letter .= ($by_letter == chr($i)) ? '<b>'. chr($i-32) .'</b>&nbsp;' : '<a class="genmed" href="'. append_sid("memberlist.$phpEx?letter=". chr($i) ."&amp;mode=$mode&amp;order=$sort_order") .'">'. chr($i-32) .'</a>&nbsp;';
   $select_letter .= ($by_letter == iconv('windows-1251', 'UTF-8', chr($i))) ? '<b>'. iconv('windows-1251', 'UTF-8', chr($i-32)) .'</b>&nbsp;' : '<a class="genmed" href="'. append_sid("memberlist.$phpEx?letter=%". strtoupper(base_convert($i, 10, 16)) ."&amp;mode=$mode&amp;order=$sort_order") .'">'. iconv('windows-1251', 'UTF-8', chr($i-32)) .'</a>&nbsp;';
}

$select_letter .= ':&nbsp;';
$select_letter .= ($by_letter == 'others') ? '<b>'. $lang['Others'] .'</b>&nbsp;' : '<a class="genmed" href="'. append_sid("memberlist.$phpEx?letter=others&amp;mode=$mode&amp;order=$sort_order") .'">'. $lang['Others'] .'</a>&nbsp;';
$select_letter .= ':&nbsp;';
$select_letter .= ($by_letter == 'all') ? '<b>'. $lang['All'] .'</b>' : '<a class="genmed" href="'. append_sid("memberlist.$phpEx?letter=all&amp;mode=$mode&amp;order=$sort_order") .'">'. $lang['All'] .'</a>';

$template->assign_vars(array(
	'L_SORT_PER_LETTER' => $lang['Sort_per_letter'],
	'S_LETTER_SELECT'   => $select_letter,
	'S_LETTER_HIDDEN'   => '<input type="hidden" name="letter" value="'. $by_letter .'">',
));

// per-letter selection end
$sql = "SELECT username, user_id, user_opt, user_posts, user_regdate, user_from, user_from_flag, user_website, user_email, user_rank, user_icq, user_aim, user_yim, user_msnm, user_magent, user_avatar, user_avatar_type, user_allowavatar, user_allow_viewonline, user_timer, user_level, user_warnings_dem, " . reputation_get_sql('ext') . "
         FROM ". USERS_TABLE ."
		 WHERE user_id NOT IN(". EXCLUDED_USERS_CSV .")";
if ( $username )
{
	$username = preg_replace('/\*/', '%', phpbb_clean_username($username));
	$letter_sql = "username LIKE '". str_replace("\'", "''", $username) ."'";
}
$sql .= ($letter_sql) ? " AND $letter_sql" : '';
$sql .= " ORDER BY $order_by";

$result = $db->sql_query($sql) OR message_die(GENERAL_ERROR, 'Could not query users', '', __LINE__, __FILE__, $sql);

// [start] Show user rank in memberlist
$sql = "SELECT *
	FROM " . RANKS_TABLE . "
	ORDER BY rank_special, rank_min";
if ( !($rresult = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, "Could not obtain ranks information.", '', __LINE__, __FILE__, $sql);
}
$ranksrow = array();
while ( $rank_table_row = $db->sql_fetchrow($rresult) )
{
	$ranksrow[] = $rank_table_row;
}
$db->sql_freeresult($rresult);
// [end] Show user rank in memberlist

if ( $row = $db->sql_fetchrow($result) )
{
	$i = 0;
	do
	{
		$username = $row['username'];
		$user_id = $row['user_id'];
		$from = $row['user_from'];
// FLAGHACK-start
		$flag = ($row['user_from_flag'] && $row['user_from_flag'] != 'blank.gif') ? make_user_flag($row['user_from_flag']) : '';
// FLAGHACK-end

		$joined = create_date($lang['DATE_FORMAT'], $row['user_regdate'], $board_config['board_timezone']);
		$posts = $row['user_posts'];
		$poster_avatar = false;

		if ($row['user_avatar_type'] && $user_id != ANONYMOUS && $row['user_allowavatar'])
		{
			switch ($row['user_avatar_type'])
			{
				case USER_AVATAR_UPLOAD:
					$poster_avatar = ($board_config['allow_avatar_upload']) ? '<img src="'. $board_config['avatar_path'] .'/'. $row['user_avatar'] .'" alt="" border="0" />' : false;
					break;
				case USER_AVATAR_REMOTE:
					$poster_avatar = ($board_config['allow_avatar_remote']) ? '<img src="'. $row['user_avatar'] .'" alt="" border="0" />' : false;
					break;
				case USER_AVATAR_GALLERY:
					$poster_avatar = ($board_config['allow_avatar_local']) ? '<img src="'. $board_config['avatar_gallery_path'] .'/'. $row['user_avatar'] .'" alt="" border="0" />' : false;
					break;
			}
		}

		if ( bf($row['user_opt'], 'user_opt', 'viewemail') || IS_ADMIN )
		{
			$email_uri = ( $bb_cfg['board_email_form'] ) ? "profile.$phpEx?mode=email&amp;u={$row['user_id']}" : 'mailto:' . $row['user_email'];
			$email_img = '<a href="' . $email_uri . '"><img src="' . $images['icon_email'] . '" alt="' . $lang['Send_email'] . '" title="' . $lang['Send_email'] . '" border="0" /></a>';
			$email = '<a class="txtb" href="' . $email_uri . '">' . $lang['Send_email_txtb'] . '</a>';
		}
		else
		{
			$email_img = '&nbsp;';
			$email = '&nbsp;';
		}

		$pm_img = '<a href="' . append_sid("privmsg.$phpEx?mode=post&amp;". POST_USERS_URL ."=$user_id") .'"><img src="' . $images['icon_pm'] . '" alt="' . $lang['Send_private_message'] . '" title="' . $lang['Send_private_message'] . '" border="0" /></a>';
		$pm = '<a class="txtb" href="'. append_sid("privmsg.$phpEx?mode=post&amp;". POST_USERS_URL ."=$user_id") .'">'. $lang['Send_pm_txtb'] .'</a>';
		// $email = ($bb_cfg['board_email_form']) ? '<a class="txtb" href="'. append_sid("profile.$phpEx?mode=email&amp;". POST_USERS_URL ."=$user_id") .'">'. $lang['Send_email_txtb'] .'</a>' : false;
		$temp_url = append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=$user_id");
		$profile = '<a href="' . $temp_url . '">' . $lang['Read_profile'] . '</a>';
		$www_img = ($row['user_website']) ? '<a href="'. $row['user_website'] .'" target="_userwww"><img src="' . $images['icon_www'] . '" alt="' . $lang['Visit_website'] . '" title="' . $lang['Visit_website'] . '" border="0" /></a>' : false;
		$www = ($row['user_website']) ? '<a class="txtb" href="'. $row['user_website'] .'" target="_userwww">'. $lang['Visit_website_txtb'] .'</a>' : false;

		$temp_url = append_sid("search.$phpEx?search_author=1&amp;uid=$user_id");
		$search_img = '<a href="' . $temp_url . '"><img src="' . $images['icon_search'] . '" alt="' . $lang['Search_user_posts'] . '" title="' . $lang['Search_user_posts'] . '" border="0" /></a>';
		$search = '<a href="' . $temp_url . '">' . $lang['Search_user_posts'] . '</a>';

		$row_class = !($i % 2) ? 'row1' : 'row2';

		// [start] Show user rank in memberlist
		//
		// Generate ranks, set them to empty string initially.
		//
		$rank = '';
		$rank_image = '';
		if ( $row['user_rank'] )
		{
			for($j = 0; $j < count($ranksrow); $j++)
			{
				if ( $row['user_rank'] == $ranksrow[$j]['rank_id'] && $ranksrow[$j]['rank_special'] )
				{
					$rank = $ranksrow[$j]['rank_title'];
					$rank_image = ( $ranksrow[$j]['rank_image'] ) ? '<br /><img src="' . $ranksrow[$j]['rank_image'] . '" alt="' . $rank . '" title="' . $rank . '" border="0" /><br />' : '<br />';
				}
			}
		}
		else
		{
			for($j = 0; $j < count($ranksrow); $j++)
			{
				if ( $row['user_posts'] >= $ranksrow[$j]['rank_min'] && !$ranksrow[$j]['rank_special'] )
				{
					$rank = $ranksrow[$j]['rank_title'];
					$rank_image = ( $ranksrow[$j]['rank_image'] ) ? '<br /><img src="' . $ranksrow[$j]['rank_image'] . '" alt="' . $rank . '" title="' . $rank . '" border="0" /><br />' : '<br />';
				}
			}
		}
		// [end] Show user rank in memberlist 

		//Online/Offline
		if (($row['user_timer'] >= ( time() - 300 )) && ($row['user_allow_viewonline']))
		{
			$on_off_hidden = ($bb_cfg['text_buttons']) ? $lang['Icon_online_txtb']      : '<img src="' . $images['icon_online'] . '" alt="' . $lang['Online'] . '" title="' . $lang['Online'] . '" border="0" />';
		}
		else if ($row['user_allow_viewonline'] == 0)
		{
			$on_off_hidden = ($bb_cfg['text_buttons']) ? $lang['Icon_hidden_txtb']      :'<img src="' . $images['icon_hidden'] . '" alt="' . $lang['Hidden'] . '" title="' . $lang['Hidden'] . '" border="0" />';
		}
		else
		{
			$on_off_hidden = ($bb_cfg['text_buttons']) ? $lang['Icon_offline_txtb']     : '<img src="' . $images['icon_offline'] . '" alt="' . $lang['Offline'] . '" title="' . $lang['Offline'] . '" border="0" />';
		}
		//Online/Offline

		$template->assign_block_vars('memberrow', array(
			'ROW_NUMBER'    => $i + ( $start + 1 ),
			'ROW_CLASS'     => $row_class,
			'USERNAME'      => $username,
			'FROM'          => $from,
			'FLAG'          => $flag,
			'JOINED_RAW'    => $row['user_regdate'],
			'JOINED'        => $joined,
			'POSTS'         => $posts,
			'AVATAR_IMG'    => $poster_avatar,
			'SEARCH'        => $search,
			'PM_IMG'        => $pm_img,
			'PM'            => $pm,
			'USER_ONLINE'   => $on_off_hidden,
			'U_SEARCH_USER' => append_sid("search.$phpEx?mode=searchuser"),
			'EMAIL_IMG'     => $email_img,
			'EMAIL'         => $email,
			'WWW_IMG'       => $www_img,
			'WWW'           => $www,
			'U_VIEWPROFILE' => append_sid("profile.$phpEx?mode=viewprofile&amp;". POST_USERS_URL ."=$user_id"),
			'RANK'          => $rank,
			'RANK_IMAGE'    => $rank_image,
		));
		// Democracy Mod 0.21 adapted [START]
		foreach ($democracy_cols as $col)
		{
			$template->assign_block_vars('memberrow.democracy', array(
				'VALUE' => reputation_not_applicable($row, $col['applicability']) ? '&mdash;' : $col['call']($row),
			));
		}
		// Democracy Mod 0.21 adapted [END]
		$i++;
	}
	while ( $row = $db->sql_fetchrow($result) );
	$db->sql_freeresult($result);
}
else
{
  	 $template->assign_block_vars('no_username', array(
       'NO_USER_ID_SPECIFIED' => $lang['No_user_id_specified']   )
 	 );
}
$paginationurl = "memberlist.$phpEx?mode=$mode&amp;order=$sort_order&amp;letter=$by_letter";
if ($paginationusername) $paginationurl .= "&amp;username=$paginationusername";
if ( $mode != 'topten' || $board_config['topics_per_page'] < 10 )
{
	$sql = "SELECT COUNT(*) AS total FROM ". USERS_TABLE;
	$sql .=	($letter_sql) ? " WHERE $letter_sql" : '';
	if (!$result = $db->sql_query($sql))
	{
		message_die(GENERAL_ERROR, 'Error getting total users', '', __LINE__, __FILE__, $sql);
	}
	if ($total = $db->sql_fetchrow($result))
	{
		$total_members = $total['total'];
		$pagination = generate_pagination($paginationurl, $total_members, $board_config['topics_per_page'], $start). '&nbsp;';
	}
	$db->sql_freeresult($result);
}
else
{
	$pagination = '&nbsp;';
	$total_members = 10;
}
$template->assign_vars(array(
	'PAGE_TITLE' => $lang['MEMBERLIST'],
	'PAGINATION' => $pagination,
	'PAGE_NUMBER' => sprintf($lang['Page_of'], ( floor( $start / $board_config['topics_per_page'] ) + 1 ), ceil( $total_members / $board_config['topics_per_page'] )),
	'L_ON_OFF_STATUS' => $lang['On_off_status'],
	'URL'         => $paginationurl,
	'PER_PAGE' => $board_config['topics_per_page'],
));

print_page('memberlist.tpl');
