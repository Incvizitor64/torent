<?php
/***************************************************************************
 *                                order.php
 *                            -------------------
 *   copyright            : (C) 2009 Wertos
 *   email                : admin@supporttp.ru
 *
 *   $Id: order.php,v 1.0.0 2009/12/10 10:16:30 ngoctu Exp $
 *
 ***************************************************************************/

define('IN_PHPBB', true);
define('BB_SCRIPT', 'order');
define('BB_ROOT', './');
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include(BB_ROOT . 'common.'.$phpEx);

// Start session management
$user->session_start();
// End session management
if( !$userdata['session_logged_in'] ) { 
  header("Location: " . append_sid(BB_ROOT . "login." . $phpEx . "?redirect=order." . $phpEx)); 
  exit; 
}

$i = 0;
$number_of_order = 20;
$start  = isset($_GET['start']) ? abs(intval($_GET['start'])) : 0;
$my  = isset($_GET['my']) ? abs(intval($_GET['my'])) : 0;
$hide_yes = isset($_GET['hide_yes']) ? abs(intval($_GET['hide_yes'])) : 0;
$show_abuse = isset($_GET['abuse']) ? abs(intval($_GET['abuse'])) : 0;
$forum = isset($_GET['f']) ? abs(intval($_GET['f'])) : 0;
$search_string = isset($_GET['st']) ? $db->escape($_GET['st']) : '';

$query_url = !empty($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';
$where_sql = '';
$where_sql_1 = '';
if ($my == 1 ) {
  $where_sql = "WHERE o.order_user_id = ".$userdata['user_id'];
  $where_sql_1 = "WHERE order_user_id = ".$userdata['user_id'];
}
if ($hide_yes == 1 ) {
  $where_sql = ($where_sql == '') ? "WHERE o.order_yes = 0" : $where_sql." AND o.order_yes = 0";
  $where_sql_1 = ($where_sql_1 == '') ? "WHERE order_yes = 0" : $where_sql_1." AND order_yes = 0";
}
if ($show_abuse == 1 ) {
  $where_sql = ($where_sql == '') ? "WHERE o.order_abuse = 1" : $where_sql." AND o.order_abuse = 1";
  $where_sql_1 = ($where_sql_1 == '') ? "WHERE order_abuse = 0" : $where_sql_1." AND order_abuse = 0";
}
if ($forum) {
  $where_sql = ($where_sql == '') ? "WHERE o.order_forum_id = $forum" : $where_sql." AND o.order_forum_id = $forum";
  $where_sql_1 = ($where_sql_1 == '') ? "WHERE order_forum_id = $forum" : $where_sql_1." AND order_forum_id = $forum";
}
if($search_string != '') {
  $where_sql = ($where_sql == '') ? "WHERE o.order_name LIKE '%$search_string%'" : $where_sql." AND o.order_name LIKE '%$search_string%'";
  $where_sql_1 = ($where_sql_1 == '') ? "WHERE order_name LIKE '%$search_string%'" : $where_sql_1." AND order_name LIKE '%$search_string%'";
}

//echo preg_replace('/\&start=.*/i', '', $query_url);
$pg_url = $query_url ? '?'.preg_replace('/\&start=.*/i', '', $query_url) : '?go=1';
$sql = "SELECT COUNT(order_id) AS c_order FROM bb_order $where_sql_1";

if( !$result = $db->sql_query($sql) )
{
 message_die(GENERAL_ERROR, 'Could not obtain order information from the database', '', __LINE__, __FILE__, $sql);
}
$row = $db->sql_fetchrow($result);

$order_sql = $db->query("SELECT o.*, u.username AS username_add, u.user_id AS user_id_add, uu.username AS username_performed, uu.user_id AS user_id_performed, f.forum_name
                         FROM bb_order AS o
                         LEFT JOIN bb_users AS u ON(u.user_id = o.order_user_id)
                         LEFT JOIN bb_users AS uu ON(uu.user_id = o.order_user_performed_id)
                         LEFT JOIN bb_forums AS f ON(f.forum_id = o.order_forum_id)
                         $where_sql
                         ORDER BY o.order_time DESC
                         LIMIT $start, $number_of_order");
while ($order = $db->sql_fetchrow($order_sql))
 {     
  $i++;
  $img_abuse = ($order['order_abuse'] == 1) ? '<img src="'.BB_ROOT.'images/order_abuse.png" />' : '<img src="'.BB_ROOT.'images/order_normal.png" />';
  $row_class = !($i % 2) ? 'row2' : 'row1';
  $row_class = ($order['order_abuse'] == 1) ? 'hl-selected-post' : $row_class;
  $template->assign_block_vars('orderrow', array(
    'ROW_CLASS'  => $row_class,
    'ORDER_ID'   => $order['order_id'],
    'ORDER_FORUM_NAME'=> $order['order_forum_id'] ? '<a href="viewforum.php?f='.$order['order_forum_id'].'">'.$order['forum_name'].'</a>' : '----',
    'ORDER_NAME' => $order['order_name'],
    'ORDER_DESC' => $order['order_desc'],
    'ORDER_USERNAME_ADD' => $order['username_add'] ? '<a href="profile.php?mode=viewprofile&u='.$order['user_id_add'].'" target="_blank">'.$order['username_add'].'</a>' : '----',
    'USERNAME_ORDER_PERFORMED' => $order['username_performed'] ? '<a href="profile.php?mode=viewprofile&u='.$order['user_id_performed'].'" target="_blank">'.$order['username_performed'].'</a>' : '----',
    'ORDER_TIME' => create_date($bb_cfg['default_dateformat'], $order['order_time'], $bb_cfg['board_timezone']),
    'ORDER_YES'  => ($order['order_yes'] == 1) ? '<a class="seed bold" href="viewtopic.php?t='.$order['order_topic_id'].'" />'.$lang['YES'].'</a>' : '<span id="order_yes" class="clickable" name="'.$order['order_id'].'">'.$lang['NO'].'</span>',
    'ORDER_VOTE' => ($order['order_yes'] == 1) ? $order['order_vote'] : '<a href="#" name="'.$order['order_id'].'">'.$order['order_vote'].'</a>',
    'ORDER_ABUSE'=> (($order['order_user_id'] == $userdata['user_id']) && (!$order['order_abuse']) && ($order['order_yes'])) ? '<span id="abuse_'.$order['order_id'].'" class="clickable" onclick="ajax.order_abuse('.$order['order_id'].'); return false;">'.$img_abuse.'</span>' : '<span>'.$img_abuse.'</span>',
  ));
 }
$template->assign_vars(array(
   'ADD_USENAME' => $userdata['username'],
   'PAGINATION'  => generate_pagination($pg_url, $row['c_order'], $number_of_order, $start),
   'PAGE_NUMBER' => sprintf($lang['Page_of'], (floor($start / $number_of_order) + 1), ceil($row['c_order'] / $number_of_order)),
   'SHOW_JUMPBOX'=> true,
   'BUILD_FORUM' => get_forum_select ('user', POST_FORUM_URL, null, 40, null, '', null),
   'U_ORDER'     => 'order.php',
));

print_page('order.tpl');