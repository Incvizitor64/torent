<?php

//
// Module information
//
$lang['Module_title'] = 'Report PM';
$lang['Module_explain'] = 'This module allows the users to report PM they receive.';

//
// Language variables
//
$lang['Report_list_title'] = 'Private messages';
$lang['Report_type'] = 'Private message';
$lang['Message_id'] = 'ID';
$lang['Message_title'] = 'Title';
$lang['Message_text'] = 'Message text';
$lang['Message_from'] = 'By';

$lang['Write_report'] = '[Report PM]';
$lang['Duplicate_report'] = '[PM has already been reported]';
$lang['Write_report_explain'] = 'Use this form to report the selected PM. Reporting should generally be used only if the PM breaks forum rules.';
$lang['Write_report_error'] = 'The selected PM doesn\'t exist.';
$lang['Auth_write_error'] = 'You don\'t have the permission to report PM.';
$lang['Duplicate_error'] = 'The PM has already been reported.';
$lang['Deleted_error'] = 'The reported PM was deleted.';

$lang['Click_return'] = '%sClick here%s to return to the PM.';