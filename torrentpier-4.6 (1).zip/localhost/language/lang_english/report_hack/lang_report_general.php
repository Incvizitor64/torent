<?php

//
// Module information
//
$lang['Module_title'] = 'General reports';
$lang['Module_explain'] = 'This module allows the users to send general reports to the team.';

//
// Language variables
//
$lang['Report_list_title'] = 'General reports';
$lang['Report_type'] = 'General report';

$lang['Write_report'] = 'Write report';
$lang['Write_report_explain'] = 'Use this form to send a message to the team.';
$lang['Auth_write_error'] = 'You don\'t have the permission to write reports.';