<?php

/**
   Gallery RoadTrain
   Russian language for TorrentPier SVN
*/

$lang['gallery_your_image'] = 'Your image';
$lang['gallery_failure'] = 'Failure';
$lang['gallery_link_url'] = 'Link to image';
$lang['gallery_screenshots'] = 'Screenshots';
$lang['gallery_upload_image'] = 'Upload';
$lang['gallery_max_file_size'] = 'Upload an image can be in formats GiF, JPG, PNG. The volume of one image should not exceed';
$lang['gallery_tag_spoiler'] = 'Tag spoiler';
$lang['gallery_tag_screen'] = 'Tag insert screenshot';
$lang['gallery_tag_screen_thumb'] = 'Tag insert screenshot with thumbs';
$lang['gallery_tag_poster_right'] = 'Tag insert poster right';
$lang['gallery_image_overload'] = 'Image size exceeds the maximum image size.';
$lang['gallery_file_exist'] = 'Such an image exists.';
$lang['gallery_upload_failed'] = 'Upload failed. Repeat.';
$lang['gallery_upload_successful'] = 'Upload was successful.';
$lang['gallery_del_link'] = 'URL to delete the file';
$lang['gallery_file_delete'] = 'Your file is deleted';
$lang['gallery_back'] = 'Back to gallery';
$lang['gallery_file_not_upload'] = 'The file doensn\'t uploaded.';
$lang['gallery_file_not_exist'] = 'The file is not exist.';
$lang['gallery_invalid_type'] = 'Invalid file type.';
$lang['gallery_create_thumb'] = 'Create thumbnail';
$lang['gallery_more_link'] = 'more...';