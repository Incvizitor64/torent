<?php
/***************************************************************************
 *                          lang_tc.php [Russian]
 *                            -------------------
 *   begin                : Thursday, Oct 19, 2006
 *   copyright            : (C) 2006 bbAntiSpam
 *   email                : support@bbantispam.com
 *
 *   $Id: lang_tc.php 1374 2006-11-18 06:28:06Z olpa $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['tc_bad_answer']         = 'Incorrect answer to the Text Confirmation question.';
$lang['tc_explain']            = 'To show that you are not a spambot, answer the Text Confirmation question.';
$lang['tc_mail_subject']       = 'Spam registration on phpBB';
$lang['Textual_Confirmation']  = 'Text Confirmation';
$lang['tc_admin_dup_question'] = "<p>The question has already been: '%s'.</p>\n";
$lang['tc_admin_cant_parse']   = "<p>Error parsing text with question and answers: '%s'.</p>\n";
$lang['tc_admin_question_saved']   = "<p>Question saved: '%s'.</p>\n";
$lang['tc_admin_question_deleted'] = "<p>Old questions removed: %s</p>\n";
$lang['tc_admin_database_updated'] = "<p>The database has been updated.</p>\n";
$lang['tc_admin_explanation']      = "<p>Question blocks are separated by an empty line. First line of each block&#xa0;&#x2014; it's a question, everything else&#xa0;&#x2014; right answers. The question must be valid HTML. The response is case insensitive (unless, of course, your Russian phpBB is configured correctly).</p>\n";