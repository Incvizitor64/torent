<?php

$lang['log_action']['log_type'] = array(
	'mod_topic_delete'   => 'Topic:<br /> <b>deleted</b>',
	'mod_topic_move'     => 'Topic:<br /> <b>moved</b>',
	'mod_topic_lock'     => 'Topic:<br /> <b>closed</b>',
	'mod_topic_unlock'   => 'Topic:<br /> <b>opened</b>',
	'mod_topic_split'    => 'Topic:<br /> <b>split</b>',
	'mod_post_delete'    => 'Post:<br /> <b>deleted</b>',
	'adm_user_delete'    => 'User:<br /> <b>deleted</b>',
	'adm_user_ban'       => 'User:<br /> <b>ban</b>',
	'adm_user_unban'     => 'User:<br /> <b>unban</b>',
	'tor_status_changed' => 'Status:<br /> <b>changed</b>',
	'tor_unreg'          => 'Torrent:<br /> <b>unreged</b>',
	'att_delete'         => 'File:<br /> <b>deleted</b>',
	'ban_ip'             => 'Ban:<br /> <b>IP</b>',
	'ban_email'          => 'Ban:<br /> <b>email</b>',
	'ban_name'           => 'Ban:<br /> <b>name</b>',
	'groupmember_add'    => 'Group:<br /> <b>added</b>',
	'groupmember_del'    => 'Group:<br /> <b>deleted</b>',
);

    $lang['acts_log_all_actions']  = 'All actions';
    $lang['acts_log_search_options'] = 'Actions Log: Search options';
    $lang['acts_log_forum'] = 'Forum';
    $lang['acts_log_action'] = 'Action';
    $lang['acts_log_user'] = 'User';
    $lang['acts_log_logs_from'] = 'Logs from ';
    $lang['acts_log_first'] = 'first ';
    $lang['acts_log_days_back'] = 'days back';
    $lang['acts_log_topic_match'] = 'Topic title match';
    $lang['acts_log_sort_by'] = 'Sort by';
    $lang['acts_log_logs_action'] = 'Action';
    $lang['acts_log_username'] = 'Username';
    $lang['acts_log_time'] = 'Time';
    $lang['acts_log_info'] = 'Info';
