<?php
/*************************************************************************************
 *                           lang_democracy.php
 * Part of Democracy MOD by Carbofos < carbofos@mail.ru > and ETZel < etzel@mail.ru >
 *************************************************************************************/

/*************************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *************************************************************************************/

$lang += array(
	// general & misc
	'Reputation' => 'Reputation',
	'Warnings' => 'Warnings',
	'Warning' => 'Warning',
	'reputation_display' => 'Display',
	'reputation_banned_note' => '(Banned)',
	'reputation_banned_permanently' => 'Banned permanently',

	// reputation types
	'reputation_including' => 'This includes',
	'reputation_base' => 'Base reputation',
	'reputation_base_exp' => 'Reputation given to this user by other users',
	'reputation_rep_start' => 'Starting reputation',
	'reputation_rep_start_exp' => 'Bonus reputation given to this user for registering',
	'reputation_for_regdays' => 'Experience reputation',
	'reputation_for_regdays_exp' => 'Bonus reputation given to this user for a time since present on board',
	'reputation_for_posts' => 'Posting reputation',
	'reputation_for_posts_exp' => 'Bonus reputation given to this user for posting messages',
	'reputation_for_reviews' => 'Reviewing reputation',
	'reputation_for_reviews_exp' => 'Bonus reputation given to a user for for giving away reputation',
	'reputation_for_rep' => 'Reputation bonus',
	'reputation_for_rep_exp' => 'Bonus reputation given to a user for receiving reputation points',
	'reputation_for_warns' => 'Warnings penalty',
	'reputation_for_warns_exp' => 'Reputation fine for received warnings',
	'reputation_for_bans' => 'Bans penalty',
	'reputation_for_bans_exp' => 'Reputation fine for being banned',
	'reputation_positive_reviews' => 'Positive reviews',
	'reputation_negative_reviews' => 'Negative reviews',

	// index page
	'reputation_reported_posts' => 'Posts reported by users: %s',
	'reputation_most_respected_user' => 'Our most respected user is ',
	'reputation_most_respected_users' => 'Our most respected users are ',
	'reputation_least_respected_user' => 'Our least respected user is ',
	'reputation_least_respected_users' => 'Our least respected users are ',

	// viewing reviews
	'New_warning' => 'New warning',
	'New_review' => 'New review',
	'Post_Reports' => 'Post Reports',
	'Review' => 'Review',
	'Official' => 'Review', // i.e. Moderator
	'reputation_of' => 'Reputation of %s',
	'reputation_warnings_to' => 'Warnings given to %s',
	'reputation_warnings_expired' =>  'Expired warnings given to %s',
	'reputation_display_expired' => 'Show expired warnings',
	'reputation_post_ref' => 'Post reference',
	'reputation_post_reviews' => 'Post reviews',
	'reputation_post_deleted' => 'Deleted',
	'reputation_total' => 'Total',
	'reputation_issued' => 'Issued',
	'Edit' => 'Edit',
	'reputation_edit_review' => 'Edit review',
	'reputation_delete_review' => 'Delete review',

	// viewing reports
	'reputation_actions' => 'Actions',
	'reputation_order_by' => 'Order by',
	'reputation_post_peports_exp' => 'Using the form below you can check out posts and reviews reported by users and perform actions on them.<br />Hint: After you resolve the report delete it to prevent other moderators from taking same actions as you did once more :)',
	'reputation_report_date' => 'Report date',
	'reputation_reports_number' => 'Reports number',
	'reputation_first_reported' => 'First reported by',
	'reputation_confirm_report' => 'Are you sure you want to report this post to moderator(s)?',
	'reputation_confirm_report2' => 'Are you sure you want to report this review to moderator(s)?',
	'reputation_report_deleted' => 'The report has been deleted.',
	'reputation_report_success' => 'The officials have been informed',
	'reputation_reviewed' => 'Reviewed', // TODO: replace

	// viewing profile
	'reputation_search_given' => 'Find all reviews written by %s',
	'reputation_search_reputation' => 'Find all reviews given to %s',
	'reputation_search_warnings' => 'Find all warnings given to %s',
	'reputation_search_expired' => 'Find expired warnings and bans',
	'reputation_expired_details' => '%s expired warnings, %s expired bans',
	'reputation_giving_power' => 'Reputation power of %s',

	// viewing posts (+some general buttons)
	'Reviews' => 'Reviews',
	'reputation_view_reviews' => 'This post has %s review(s)',
	'reputation_post_warning' => 'Warned by %s on %s. Expires: %s',
	'reputation_post_ban' => 'Banned by %s at %s. Expires: %s',
	'reputation_approve' => 'Approve',
	'reputation_disapprove' => 'Disapprove',
	'reputation_reason' => 'Reason',
	'reputation_warn' => 'Warn',
	'reputation_ban' => 'Ban',
	'reputation_warn_user' => 'Give this user a warning',
	'reputation_ban_user' => 'Ban this user',
	'reputation_report_post' => 'Report this post to moderator(s)',
	'reputation_report' => 'Report',

	// expiration
	'reputation_expire' => 'Expire',
	'reputation_expired' => 'Expired',
	'reputation_expire_never' => 'Never',

	// adding/editing reviews
	'reputation_modify' => 'Modify user\'s reputation',
	'reputation_mail_warning' => 'You have recieved a warning',
	'reputation_mail_ban' => 'You have been banned',

	'reputation_expire_fixed' => 'After %s days.',
	'reputation_expire_limited_bottom' => 'Minimum value is %d day(s)',
	'reputation_expire_limited' => 'Possible values are %d to %d days',
	'reputation_note_cant_edit' => 'Please note that you won\'t be able to edit your review later',
	'reputation_note_can_edit' => 'Please note that you\'ll be able to edit only your review text',
	'reputation_for_days' => 'for %d day(s)',
	'reputation_forever' => '(no expiration date set)',

	'reputation_confirm_delete' => 'Are you sure you want to delete this review?',
	'reputation_update_successfull' => 'You have successfully voted for this user\'s reputation',
	'reputation_warning_successfull' => 'The user has been warned successfully',
	'reputation_delete_success' => 'Review was deleted successfully. User\'s reputation has been updated.',

	// notification templates
	'reputation_notify_reputation' => "You have received a review from %s.\nAs a result, your reputation has changed by %s points and now totals to %s.\n\nComment:\n%s\n\nLink to review: %s",
	'reputation_notify_warning' => "%s has given you a warning %s.\n\nComment:\n%s\n\nLink to review: %s",
	'reputation_subj_reputation' => 'Your reputation has changed',
	'reputation_subj_warning' => 'You have received a warning',

	// input errors
	'reputation_no_comments_entered' => 'You didn\'t enter any comment!',
	'reputation_no_post_spec' => 'No post specified!',
	'reputation_no_user_spec' => 'No user specified!',
	'reputation_no_review_spec' => 'No review specified!',
	'reputation_no_expire_entered' => 'You didn\'t enter an expire date for this warning',

	// procedural errors
	'reputation_deleted_no_edit' => 'The review you try to edit referres to deleted post',
	'reputation_last_warning_issued' => 'The user has already got last warning',
	'reputation_already_warned' => 'This user has been already warned for this post',
	'reputation_already_banned' => 'This user is already banned',
	'reputation_already_voted' => 'You have already referred to this post!',

	// auth_personal errors
	'reputation_not_applicable' => 'This user can\'t have reputation.',
	'reputation_cant_warn_mods' => 'Moderators and administrators cannot be given warnings',
	'reputation_self_no_modify' => 'You can\'t modify your own reputation!',
	'reputation_others_no_edit' => 'You can\'t edit others\' reviews',
	'reputation_other_mods_no_edit' => 'You can\'t edit warnings or bans given by other moderators/admins.',
	'reputation_anonymous_no_reputation' => 'Anonymous users don\'t have reputation!',
	'reputation_anonymous_no_reviews' => 'Anonymous posts don\'t have reviews!',
	'reputation_limits_apply' => 'To change reputation you should met requirements on the number of posts, reputation points and active warnings.',
	'reputation_time_limit' => 'You can\'t change reputation of the same member more than once in %d minutes.',
	'reputation_rotation_limit' => 'You mush change reputation of %d different member to be able to change reputation of the same member twice.',

	// emptiness errors
	'reputation_no_reviews' => 'This post hasn\'t got any reviews',
	'reputation_no_details' => 'This user hasn\'t got any reputation details',
	'reputation_no_warnings' => 'This user hasn\'t got any warnings',
	'reputation_no_reports' => 'There is no post reports',

	// backlinks
	'reputation_msg_view_warning' => '%sView this warning%s',
	'reputation_msg_delete_report' => '%sDelete report%s',
	'reputation_msg_view_profile' => '%sView this user\'s profile%s',
	'reputation_msg_back_to_topic' => '%sGo back to topic%s',
	'reputation_msg_back_to_reviews' => '%sGo back to reviews%s',
	'reputation_msg_view_your_review' => '%sView your review%s',
	'reputation_msg_back_to_reports' => '%sBack to the Reports page%s',

	// sorting
	'Sort_Reputation' => 'Reputation',
	'Sort_Warnings' => 'Warnings',

	// posting
	'Post_locked' => 'Sorry, you are not allowed edit or delete this post any more.',
	'reputation_lock_post' => 'Lock this post',
);