<?php
/*************************************************************************************
 *                           lang_admin_democracy.php
 * Part of Democracy MOD by Carbofos < carbofos@mail.ru > and ETZel < etzel@mail.ru >
 *************************************************************************************/

/*************************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *************************************************************************************/

$lang += array(
	'reputation_democracy' => 'Democracy',
	'reputation_democracy_exp' => 'Democracy combines the features of warnings system, ban manager, karma (reputation) and post reports.',
	'reputation_democracy_users' => 'Warned &amp; Banned users',
	'reputation_democracy_users_exp' => 'This page contains users that have warnings or have been banned via the Democracy system.',
	'reputation_enable' => 'Enable reputation',
	'reputation_enable_warnings' => 'Enable warnings and bans',
	'reports_enabled' => 'Enable Report Post button',
	'reputation_positive_only' => 'Positive reviews only',
	'reputation_positive_only_exp' => 'Make only positive reviews possible. Hide (not delete!) negative reviews and do not count them when summing reputation points.',
	'reputation_empty_reviews' => 'Allow reviews without comments (make comment field optional)',
	'reputation_reputation_options' => 'Reputation options',
	'reputation_warnings_options' => 'Warnings options',
	'reputation_reports_options' => 'Post report options',
	'reputation_common_options' => 'Common options',
	'Click_return_reputation_index' => 'Click %sHere%s to return to Democracy configuration',

	'reputation_access_rights' => 'Access rights',
	'reputation_view_rep' => 'View reputation',
	'reputation_add_rep' => 'Change reputation',
	'reputation_add_rep_nonpost' => 'Change reputation without referring to a specific post',
	'reputation_edit_rep' => 'Edit reputation reviews',
	'reputation_delete_rep' => 'Delete reputation reviews',
	'reputation_no_limits' => 'Requirements do not apply',
	'reputation_view_warns' => 'View warnings and bans',
	'reputation_warn' => 'Give warnings',
	'reputation_warn_nonpost' => 'Give warnings without referring to a specific post',
	'reputation_ban_nonpost' => 'Ban users without referring to a specific post',
	'reputation_edit_warns' => 'Edit warnings and bans',
	'reputation_delete_warns' => 'Delete warnings and bans',
	'reputation_not_applicable' => 'Don\'t have reputation at all',
	'reputation_perms_notes' => '(*) only his/her own<br />(**) only in the forums where he/she is moderator.',
	'reputation_warn_perms_notes' => '(*) user can always see his/her own warnings.<br />(**) only in the forums where he/she is moderator.',

	'reputation_auto_reputation' => 'Modifiers applied to a user reputation',
	'reputation_start' => 'Give to a user %s reputation points upon registration.',
	'reputation_for_days' => 'Add one reputation point for every %s days of registration.',
	'reputation_for_posts' => 'Add one reputation point for every %s messages poster by user.',
	'reputation_for_reviews' => 'Add one reputation point for every %s reviews made by user.',
	'reputation_for_rep' => 'Bonus of one reputation point for every %s reputation points given to a user by other users.',
	'reputation_for_warns' => 'Penalty of %s reputation points for every warning given to a user.',
	'reputation_for_bans' => 'Penalty of %s reputation points for every time user gets banned.',

	'reputation_giving_scale' => 'Reputation power',
	'reputation_giving_scale_exp' => 'Initially each user have reputation power of 1, i.e. they can change other\'s reputation by 1 at a time.',
	'reputation_giving_for_days' => 'Power is increased by 1 every %s days of registration.',
	'reputation_giving_for_posts' => 'Power is increased by 1 for every %s messages poster by user.',
	'reputation_giving_for_rep' => 'Power is increased by one for every %s reputation points user have.',
	'reputation_giving_max' => 'Limit maximum reputation power to %s.',
	'reputation_giving_slowdown' => 'Slowdown coefficient: %s.',
	'reputation_giving_slowdown_exp' => 'Please enter a value between 0 (no slowdown) and 100 (maximal slowdown).<br />Sample (what will be changed to what): <span id="giving_slowdown_sample"></span>',

	'reputation_days_req' => 'At least %s days of registration.',
	'reputation_posts_req' => 'At least %s posts.',
	'reputation_warnings_req' => 'At most %s unexpired warnings.',
	'reputation_points_req' => 'At least %s reputation points.',
	'reputation_time_limit' => 'User cannot change reputation of the same member more than once in %s minutes.',
	'reputation_rotation_limit' => 'Reputation user spread: %s users.',
	'reputation_rotation_limit_exp' => 'This setting dictates how many unique members that a user must rate before they are able to rate the same member twice.',
	'reputation_most_respected' => 'Show %s most respected users.',
	'reputation_least_respected' => 'Show %s least respected users.',
	'reputation_respected_exp' => 'Users having equal reputation are counted as a single position. So the actual number of displayed users may be bigger.',
	'reputation_show_values' => 'Show reputation values in the above lists.',
	'reputation_display' => 'Reputation display',
	'reputation_display_sum' => 'Single number (sum)',
	'reputation_display_plusminus' => 'Positive and negative separated (+2/-3)',
	'reputation_warnings_display' => 'Warnings display',
	'reputation_warnings_display_img' => 'Graphical ("yellow cards")',
	'reputation_warnings_display_text' => 'Textual',

	'reputation_infinite' => 'Infinite',
	'reputation_infinite_exp' => 'Moderators should expire or delete warnings manually.',
	'reputation_infinite_ban_exp' => 'Moderators should expire or delete bans manually.',
	'reputation_fixed' => 'Fixed: %s days.',
	'reputation_modifiable' => 'Can be chosen by moderator between %s and %s days.',
	'reputation_modifiable_exp' => 'Leave the fields blank not to put restrictions.',
	'reputation_store' => 'Mark as expired and store',
	'reputation_delete_days' => 'Mark as expired and delete after %s days.',
	'reputation_ban_warnings' => 'Users will get banned after receiving %s active warnings.',
	'reputation_ban_warnings_exp' => 'When this option is enabled, the last warning will just turn into ban.',
	'reputation_check_rate' => 'Expired warnings and bans check rate: %s minutes.',
	'reputation_check_rate_exp' => 'Manipulate delay between checkups to reduce the workload.',

	'reputation_memberlist' => 'Memberlist', // NOTE: $lang['Memberlist'] in russian phpBB says "Users", so we need this
	'reputation_memberlist_reputation' => 'Show reputation',
	'reputation_memberlist_warnings' => 'Show warnings',

	'reputation_default_order' => 'Default reviews order',

	'reputation_notify' => 'Notification',
	'reputation_ban' => 'Ban',

	'reputation_check_confirm' => 'Please confirm your intention to change settings by checking the appropriate checkbox!',

	'reputation_reports_color' => 'Color used to distinguish the link to reports page:',
	'reputation_reports_color_exp' => 'If there are any reports. Leave blank if you don\'t want the link to have different color.',

	'reputation_warning_expiry' => 'Warnings expiration',
	'reputation_ban_expiry' => 'Bans expiration',
	'reputation_expired_warnings' => 'Expired warnings and bans',
	'reputation_index_page' => 'Index page',
	'reputation_prerequirements' => 'Requirements to the user changing reputation',
	'reputation_limits' => 'Other requirements',

	'reputation_maintenance' => 'Maintenance',
	'reputation_resync' => 'Ensure data integrity between users, posts and reputation table.',
	'reputation_resync_exp' => 'Use this when user\'s reputation or warnings don\'t match actual number of reviews.',
	'reputation_success' => 'Operation completed successfully.',

	/*
	'reputation_reports_per_page' => 'Reports per page',
	'reputation_reviews_per_page' => 'Reputation reviews per page',
	'reputation_allow_empty_warns' => 'Allow warnings without the reason specified.',
	*/
);