<?php

$translit_table = array(
#	'from' => 'to',
);

