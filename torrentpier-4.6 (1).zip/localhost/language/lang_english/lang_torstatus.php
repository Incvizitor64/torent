<?php

$lang['Torstatus_subj'] = 'In your release the moderator changed the status';
$lang['Torstatus_text'] = 'Hello!<br><br>In your release <p><a href="viewtopic.php?t=%s" target=_blank>%s :: %s</a></p> the moderator <p><a href="profile.php?mode=viewprofile&u=%s" target=_blank><b>%s</b></a></p> changed the status of the torrent on "%s"';
$lang['Torstatus_mod_subj'] = 'In the release of your responsibility poster has make changes';
$lang['Torstatus_mod_text'] = 'In the release <p><a href="viewtopic.php?t=%s" target=_blank>%s</a></p> poster has make changes. Please check it again';
