<?php

$lang['CRON__LIST'] = 'Cron list';
$lang['CRON__ID'] = 'Id';
$lang['CRON__ACTIVE'] = 'Active';
$lang['CRON__TITLE'] = 'Title';
$lang['CRON__SCRIPT'] = 'Script';
$lang['CRON__SCHEDULE'] = 'Schedule';
$lang['CRON__LAST_RUN'] = 'Last Run';
$lang['CRON__NEXT_RUN'] = 'Next Run';
$lang['CRON__RUN_COUNT'] = 'Runs';
$lang['CRON__MANAGE'] = 'Manage';
$lang['CRON__OPTIONS'] = 'Cron options';

$lang['CRON_ENABLED'] = 'Cron enabled';
$lang['CRON_CHECK_INTERVAL'] = 'Cron check interval (sec)';

$lang['WITH_SELECTED'] = 'With selected';
$lang['NOTHING'] = 'do nothing';
$lang['CRON_RUN'] = 'Run';
$lang['CRON_DEL'] = 'Delete';
$lang['CRON_DISABLE'] = 'Disable';
$lang['CRON_ENABLE'] = 'Enable';

$lang['RUN_MAIN_CRON'] = '[Run cron]';
$lang['ADD_JOB'] = '[Add job]';
$lang['CRON_WORKS'] = 'Cron is now works or is broken -> ';
$lang['REPAIR_CRON'] = '[Repair Cron]';

$lang['CRON_EDIT_HEAD_EDIT'] = 'Edit job';
$lang['CRON_EDIT_HEAD_ADD'] = 'Add job';
$lang['cron_id'] = 'Cron id';
$lang['cron_active'] = 'Cron active';
$lang['cron_active_expl'] = 'this job is active?';
$lang['cron_title'] = 'Cron title';
$lang['cron_script'] = 'Cron script';
$lang['cron_script_expl'] = 'name of the script from "includes/cron/jobs/"';
$lang['SCHEDULE'] = 'Schedule';
//schedule
$lang['hourly'] = 'hourly';
$lang['daily'] = 'daily';
$lang['weekly'] = 'weekly';
$lang['monthly'] = 'monthly';
$lang['interval'] = 'interval';
//
$lang['RUN_DAY'] = 'Run day';
$lang['RUN_DAY_EXPL'] = 'the day when this job run';
$lang['run_time'] = 'Run time';
$lang['run_time_expl'] = 'the time when this job run (e.g. 05:00:00)';
$lang['run_order'] = 'Run order';
$lang['last_run'] = 'Last Run';
$lang['next_run'] = 'Next Run';
$lang['run_interval'] = 'Run interval';
$lang['run_interval_expl'] = 'e.g. 00:10:00';
$lang['log_enabled'] = 'Log enabled';
$lang['log_file'] = 'Log file';
$lang['log_file_expl'] = 'the file for save the log';
$lang['log_sql_queries'] = 'Log SQL queries';
$lang['disable_board'] = 'Disable board';
$lang['disable_board_expl'] = 'disable board when this job is run';
$lang['run_counter'] = 'Run counter';

