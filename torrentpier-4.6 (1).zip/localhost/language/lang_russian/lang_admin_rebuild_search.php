<?php

/***************************************************************************
 *                       lang_admin_rebuild_search.php [Russia]
 *                       ---------------------------------------
 *     begin                : Mon Aug 22 2005
 *     copyright            : (C) 2001 The phpBB Group
 *     email                : support@phpbb.com
 *
 *     $Id: lang_admin_rebuild_search.php,v 2.2.2.0 2006/02/04 18:38:17 chatasos Exp $
 *
 ****************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

$lang['Rebuild_search'] = 'Индексировать';
$lang['Rebuild_search_desc'] = 'Эта функция индексирует таблицы поиска. Индексация может занять некоторое время.<br />
Пожалуйста, не закрывайте эту страницу до окончания индексации';

//
// Input screen
//
$lang['Starting_post_id'] = 'Начальный ID сообщения';
$lang['Starting_post_id_explain'] = 'Первый пост, с которого начнется обработка<br />Вы можете начать с самого начала или с последнего поста, который вы остановили.';

$lang['Start_option_beginning'] = 'начать с начала';
$lang['Start_option_continue'] = 'продолжить с последней остановки';

$lang['Clear_search_tables'] = 'Очистить таблицы поиска';
$lang['Clear_search_tables_explain'] = '';
$lang['Clear_search_no'] = 'НЕТ';
$lang['Clear_search_delete'] = 'УДАЛИТЬ';
$lang['Clear_search_truncate'] = 'Обрезать';

$lang['Num_of_posts'] = 'Количество сообщений';
$lang['Num_of_posts_explain'] = 'Общее количество постов для обработки<br />Он автоматически заполняется количеством общих/оставшихся сообщений, найденных в базе данных.';

$lang['Posts_per_cycle'] = 'Посты за цикл';
$lang['Posts_per_cycle_explain'] = 'Количество сообщений для обработки за цикл<br />Держите его низким, чтобы избежать тайм-аутов php/webserver.';

$lang['Refresh_rate'] = 'Период обновления';
$lang['Refresh_rate_explain'] = 'Сколько времени (в секундах) бездействовать перед переходом к следующему циклу обработки<br />Обычно вам не нужно это менять';

$lang['Time_limit'] = 'Ограничение времени';
$lang['Time_limit_explain'] = 'Сколько времени (сек) может длиться постобработка перед переходом к следующему циклу';
$lang['Time_limit_explain_safe'] = '<i>Ваш php (безопасный режим) настроен на тайм-аут %s секунд, поэтому держитесь ниже этого значения.</i>';
$lang['Time_limit_explain_webserver'] = '<i>На вашем веб-сервере настроено время ожидания %s сек., поэтому держитесь ниже этого значения.</i>';

$lang['Disable_board'] = 'Отключение форума';
$lang['Disable_board_explain'] = 'Нужно ли отключать ваш форум во время обработки';
$lang['Disable_board_explain_enabled'] = 'Он будет включен автоматически после окончания обработки';
$lang['Disable_board_explain_already'] = '<i>Ваш форум уже отключен</i>';

//
// Information strings
//
$lang['Info_processing_stopped'] = 'Последний раз вы останавливали обработку на post_id %s (%s обработано постов) на %s';
$lang['Info_processing_aborted'] = 'В последний раз вы прервали обработку на post_id %s (%s обработано постов) на %s';
$lang['Info_processing_aborted_soon'] = 'Пожалуйста, подождите несколько минут, прежде чем продолжить...';
$lang['Info_processing_finished'] = 'Вы успешно завершили обработку (%s обработано постов) на %s';
$lang['Info_processing_finished_new'] = 'Вы успешно завершили обработку на post_id %s (%s обработано постов) на %s,<br />но были %s новый пост(-ы) после этой даты';

//
// Progress screen
//
$lang['Rebuild_search_progress'] = 'Восстановить ход поиска';

$lang['Processed_post_ids'] = 'Идентификаторы обработанных постов: %s - %s';
$lang['Timer_expired'] = 'Таймер истек в %s сек. ';
$lang['Cleared_search_tables'] = 'Очищены таблицы поиска. ';
$lang['Deleted_posts'] = '%s пост(-ы) были удалены вашими пользователями во время обработки. ';
$lang['Processing_next_posts'] = 'Обрабатываем следующий %s пост(-ы). Пожалуйста, подождите...';
$lang['All_session_posts_processed'] = 'Обработаны все посты в текущей сессии.';
$lang['All_posts_processed'] = 'Все посты были успешно обработаны.';
$lang['All_tables_optimized'] = 'Все поисковые таблицы были успешно оптимизированы.';

$lang['Processing_post_details'] = 'Обработка поста';
$lang['Processed_posts'] = 'Обработанные посты';
$lang['Percent'] = 'Процентов';
$lang['Current_session'] = 'Текущая сессия';
$lang['Total'] = 'Всего';

$lang['Process_details'] = 'от <b>%s</b> до <b>%s</b> (из общего числа <b>%s</b>)';
$lang['Percent_completed'] = '%s %% завершено';

$lang['Processing_time_details'] = 'Детали текущей сессии';
$lang['Processing_time'] = 'Время выполнения';
$lang['Time_last_posts'] = 'Последние %s сообщений';
$lang['Time_from_the_beginning'] = 'С самого начала';
$lang['Time_average'] = 'Среднее значение за цикл';
$lang['Time_estimated'] = 'Рассчитано до финиша';

$lang['days'] = 'дней';
$lang['hours'] = 'часов';
$lang['minutes'] = 'минут';
$lang['seconds'] = 'секунд';

$lang['Database_size_details'] = 'Детали размера БД';
$lang['Size_current'] = 'Текущий';
$lang['Size_estimated'] = 'Оценка после финиша';
$lang['Size_search_tables'] = 'Размер таблицы поиска';
$lang['Size_database'] = 'Размер ДБ';

$lang['Bytes'] = 'Байт';

$lang['Active_parameters'] = 'Активные параметры';
$lang['Posts_last_cycle'] = 'Обработанный пост(-ы) в последнем цикле';
$lang['Board_status'] = 'Статус форума';
$lang['Board_disabled'] = 'Отключен';
$lang['Board_enabled'] = 'Включен';

$lang['Info_estimated_values'] = '(*) Все оценочные значения рассчитаны приблизительно<br />
			на основе текущего процента выполнения и может не отражать фактические окончательные значения.<br />
			По мере увеличения процента выполненных расчетные значения будут приближаться к фактическим.';

$lang['Click_return_rebuild_search'] = 'Нажмите %sздесь%s чтобы вернутся в Индексацию';
$lang['Rebuild_search_aborted'] = 'Восстановление поиска прервано на post_id %s.<br /><br />Если вы прервали поиск во время обработки, вам придется подождать несколько минут, пока вы снова не запустите Индексацию, чтобы последний цикл мог завершиться.';
$lang['Wrong_input'] = 'Вы ввели несколько неверных значений. Проверьте введенные данные и повторите попытку.';

// Buttons
$lang['Next'] = 'Далее';
$lang['Processing'] = 'Загрузка...';
$lang['Finished'] = 'Закончить';