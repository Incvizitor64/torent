<?php
/*************************************************************************************
 *                           lang_democracy.php [Russian]
 * Part of Democracy MOD by Carbofos < carbofos@mail.ru > and ETZel < etzel@mail.ru >
 *************************************************************************************/

/*************************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *************************************************************************************/

$lang += array(
	// general & misc
	'Reputation' => 'Репутация',
	'Warnings' => 'Предупреждения',
	'Warning' => 'Предупреждение',
	'reputation_display' => 'Показывать',
	'reputation_banned_note' => '(Бан)',
	'reputation_banned_permanently' => 'Бессрочный бан',

	// reputation types
	'reputation_including' => 'В том числе',
	'reputation_base' => 'Базовая репутация',
	'reputation_base_exp' => 'Репутация полученная по отзывам других пользователей',
	'reputation_rep_start' => 'Начальная репутация',
	'reputation_rep_start_exp' => 'Репутация начисленная за регистрацию на форуме',
	'reputation_for_regdays' => 'Репутация за опыт',
	'reputation_for_regdays_exp' => 'Репутация начисленная за время пребывания на форуме',
	'reputation_for_posts' => 'Репутация за сообщения',
	'reputation_for_posts_exp' => 'Репутация начисленная за активность на форуме',
	'reputation_for_reviews' => 'Репутация за обзоры',
	'reputation_for_reviews_exp' => 'Репутация начисленная за активность в написании обзоров',
	'reputation_for_rep' => 'Бонусная репутация',
	'reputation_for_rep_exp' => 'Репутация начисленная за получение репутации от других пользователей',
	'reputation_for_warns' => 'Штраф за предупреждения',
	'reputation_for_warns_exp' => 'Репутация отчисленная за получение предупреждений',
	'reputation_for_bans' => 'Штраф за баны',
	'reputation_for_bans_exp' => 'Репутация отчисленная за баны',
	'reputation_positive_reviews' => 'Положительные отзывы',
	'reputation_negative_reviews' => 'Отрицательные отзывы',

	// index page
	'reputation_reported_posts' => 'Сообщений с уведомлениями от пользователей: %s',
	'reputation_most_respected_user' => 'Наш самый уважаемый пользователь: ',
	'reputation_most_respected_users' => 'Наши самые уважаемые пользователи: ',
	'reputation_least_respected_user' => 'Наш самый неуважаемый пользователь: ',
	'reputation_least_respected_users' => 'Наши самые неуважаемые пользователи: ',

	// viewing reviews
	'New_warning' => 'Новое предупреждение',
	'New_review' => 'Новый отзыв',
	'Post_Reports' => 'Сообщения модераторам',
	'Review' => 'Отзыв',
	'Official' => 'Выдал', // i.e. Moderator
	'reputation_of' => 'Репутация пользователя %s',
	'reputation_warnings_to' => 'Предупреждения, выданные пользователю %s',
	'reputation_warnings_expired' =>  'Прошлые предупреждения, выданные пользователю %s',
	'reputation_display_expired' => 'Показать истекшие предупреждения',
	'reputation_post_ref' => 'Сообщение',
	'reputation_post_reviews' => 'Отзывы сообщения',
	'reputation_post_deleted' => 'Удалено',
	'reputation_total' => 'Всего',
	'reputation_issued' => 'Выдано',
	'Edit' => 'Редактировать',
	'reputation_edit_review' => 'Редактировать отзыв',
	'reputation_delete_review' => 'Удалить отзыв',

	// viewing reports
	'reputation_actions' => 'Действия',
	'reputation_order_by' => 'Упорядочить по',
	'reputation_post_peports_exp' => 'Используя эту страницу Вы можете проверить сообщения и отзывы, на которые обратили Ваше внимание пользователи, а также принять необходимые меры.<br />Подсказка: После того, как Вы рассмотрите \'жалобу\' и примете меры, удалите ее, чтобы другие модераторы не продублировали Ваши действия :)',
	'reputation_report_date' => 'Время сообщения',
	'reputation_reports_number' => 'Количество сообщений',
	'reputation_first_reported' => 'Первый(ая)',
	'reputation_confirm_report' => 'Вы уверены, что хотите сообщить модераторам об этом сообщении?',
	'reputation_confirm_report2' => 'Вы уверены, что хотите сообщить модераторам об этом отзыве?',
	'reputation_report_deleted' => 'Уведомление было удалено',
	'reputation_report_success' => 'Официальные лица были уведомлены',
	'reputation_reviewed' => 'Отзыв получен', // TODO: replace

	// viewing profile
	'reputation_search_given' => 'Найти все отзывы пользователя',
	'reputation_search_reputation' => 'Найти все отзывы на сообщения пользователя',
	'reputation_search_warnings' => 'Найти все предупреждения, выданные пользователю',
	'reputation_search_expired' => 'Найти истекшие предупреждения',
	'reputation_expired_details' => '%s истекших предупреждений, %s истекших банов',
	'reputation_giving_power' => 'Может менять репутацию на %s',

	// viewing posts (+some general buttons)
	'Reviews' => 'Отзывы',
	'reputation_view_reviews' => 'Всего отзывов: %s',
	'reputation_post_warning' => 'Предупреждение выдано %s (%s, действует до: %s)',
	'reputation_post_ban' => 'Бан выдан %s (%s, действует до: %s)',
	'reputation_approve' => 'Согласиться',
	'reputation_disapprove' => 'Не согласиться',
	'reputation_reason' => 'Пояснение',
	'reputation_warn' => 'Предупредить',
	'reputation_ban' => 'Забанить',
	'reputation_warn_user' => 'Выдать предупреждение',
	'reputation_ban_user' => 'Забанить пользователя',
	'reputation_report_post' => 'Сообщить модератору(ам)',
	'reputation_report' => 'Сообщить',

	// expiration
	'reputation_expire' => 'Срок действия',
	'reputation_expired' => 'окончен',
	'reputation_expire_never' => 'не ограничен',

	// adding/editing reviews
	'reputation_modify' => 'Изменить репутацию',
	'reputation_mail_warning' => 'Вы получили предупреждение',
	'reputation_mail_ban' => 'Вам был закрыт доступ к форуму',

	'reputation_expire_fixed' => 'выдается на %s дней.', // do not change %s to %d !
	'reputation_expire_limited_bottom' => 'Укажите значение от %d дней.',
	'reputation_expire_limited' => 'Укажите значение от %d до %d дней',
	'reputation_note_cant_edit' => 'Обратите внимание, что Вы не сможете позже отредактировать свой отзыв',
	'reputation_note_can_edit' => 'Обратите внимание, что Вы сможете позже отредактировать только текст своего отзыва',
	'reputation_for_days' => 'на %d дней',
	'reputation_forever' => 'на неограниченный срок',

	'reputation_confirm_delete' => 'Вы уверены, что хотите удалить этот отзыв?',
	'reputation_update_successfull' => 'Ваш отзыв был добавлен',
	'reputation_warning_successfull' => 'Пользователь был предупрежден',
	'reputation_delete_success' => 'Отзыв был удален. Репутация пользователя была обновлена.',

	// notification templates
	'reputation_notify_reputation' => "Вы получили отзыв от пользователя %s.\nВаша репутация изменилась на %s и теперь составляет %s.\n\nКомментарий:\n%s\n\nСсылка на отзыв: %s",
	'reputation_notify_warning' => "%s выдал вам предупреждение %s.\n\nКомментарий:\n%s\n\nСсылка на отзыв: %s",
	'reputation_subj_reputation' => 'Ваша репутация изменилась',
	'reputation_subj_warning' => 'Вы получили предупреждение',

	// input errors
	'reputation_no_comments_entered' => 'Вы не ввели свой комментарий!',
	'reputation_no_post_spec' => 'Не указано сообщение!',
	'reputation_no_user_spec' => 'Не указан пользователь!',
	'reputation_no_review_spec' => 'Не указан отзыв!',
	'reputation_no_expire_entered' => 'Вы не ввели срок действия этого предупреждения',

	// procedural errors
	'reputation_deleted_no_edit' => 'Отзыв, который Вы хотите отредактировать, ссылается на сообщение, которое было удалено',
	'reputation_last_warning_issued' => 'Пользователь уже получил последнее предупреждение',
	'reputation_already_warned' => 'Пользователь уже был предупрежден за это сообщение',
	'reputation_already_banned' => 'Этот пользователь уже забанен',
	'reputation_already_voted' => 'Вы уже ссылались на это сообщение!',

	// auth_personal errors
	'reputation_cant_warn_mods' => 'Модераторы и администраторы не могут получать предупреждения',
	'reputation_self_no_modify' => 'Нельзя изменять свою репутацию!',
	'reputation_others_no_edit' => 'Вы можете редактировать только свои собственные отзывы.',
	'reputation_not_applicable' => 'Этот пользователь не имеет репутации',
	'reputation_other_mods_no_edit' => 'Вы не можете редактировать отзывы, оставленные другими модераторами.',
	'reputation_anonymous_no_reputation' => 'Безымянные пользователи не могут иметь репутацию!',
	'reputation_anonymous_no_reviews' => 'Сообщения гостей не могут иметь отзывы!',
	'reputation_limits_apply' => 'Менять репутацию могут только пользователи, достигшие определенного количества постов и баллов репутации.',
	'reputation_time_limit' => 'Нельзя менять репутацию одного и того же пользователя чаще чем раз в %d минут',
	'reputation_rotation_limit' => 'Надо изменить репутацию не менее чем %d разных пользователей, чтобы можно было два раза поменять репутацию одному и тому же пользователю.',

	// emptiness errors
	'reputation_no_reviews' => 'Это сообщение не имеет отзывов',
	'reputation_no_details' => 'Этот пользователь не имеет репутации',
	'reputation_no_warnings' => 'Этот пользователь не имеет предупреждений',
	'reputation_no_reports' => 'Нет сообщений модераторам',

	// backlinks
	'reputation_msg_view_warning' => '%sПосмотреть предупреждение%s',
	'reputation_msg_delete_report' => '%sУдалить сообщение%s',
	'reputation_msg_view_profile' => '%sПосмотреть профиль%s',
	'reputation_msg_back_to_topic' => '%sВернуться в тему%s',
	'reputation_msg_back_to_reviews' => '%sВернуться к отзывам%s',
	'reputation_msg_view_your_review' => '%sПосмотреть Ваш отзыв%s',
	'reputation_msg_back_to_reports' => '%sВернуться на страницу уведомлений%s',

	// sorting
	'Sort_Reputation' => 'репутации',
	'Sort_Warnings' => 'количеству предупреждений',

	// posting
	'Post_locked' => 'Извините, вы больше не можете редактировать или удалить это сообщение.',
	'reputation_lock_post' => 'Заморозить это сообщение',
);
