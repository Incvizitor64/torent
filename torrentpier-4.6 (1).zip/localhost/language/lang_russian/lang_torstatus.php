<?php

$lang['Torstatus_subj'] = 'В вашей раздаче модератор изменил статус';
$lang['Torstatus_text'] = 'Здравствуйте!<br><br>В вашей раздаче <p><a href="viewtopic.php?t=%s" target=_blank>%s :: %s</a></p> модератор <p><a href="profile.php?mode=viewprofile&u=%s" target=_blank><b>%s</b></a></p> изменил статус торрента на "%s"';
$lang['Torstatus_mod_subj'] = 'В под ответственной раздаче релизер внёс изменения';
$lang['Torstatus_mod_text'] = 'В раздаче <p><a href="viewtopic.php?t=%s" target=_blank>%s</a></p> релизер внёс изменения. Просьба проверить её заново';
