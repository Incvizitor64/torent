<?php

//
// Module information
//
$lang['Module_title'] = 'Общие нарушения';
$lang['Module_explain'] = 'Этот модуль позволяет отправлять команде администраторов и модераторов сообщения о нарушениях в свободной форме.';

//
// Language variables
//
$lang['Report_list_title'] = 'Общие нарушения';
$lang['Report_type'] = 'Общие нарушения';

$lang['Write_report'] = 'Сообщить о нарушении';
$lang['Write_report_explain'] = 'Используйте эту форму для отправки сообщения команде администраторов и модераторов.';
$lang['Auth_write_error'] = 'У вас нет прав для отправки сообщений о нарушениях.';