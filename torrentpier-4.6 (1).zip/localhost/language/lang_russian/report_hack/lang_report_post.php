<?php

//
// Module information
//
$lang['Module_title'] = 'Нарушения в сообщениях пользоваталей';
$lang['Module_explain'] = 'Этот модуль позволяет сообщать о нарушениях в сообщениях темы.';

//
// Language variables
//
$lang['Report_list_title'] = 'Нарушения в сообщениях';
$lang['Report_type'] = 'Нарушения в сообщениях';

$lang['Write_report'] = 'Сообщить о нарушении';
$lang['Duplicate_report'] = 'О нарушении сообщено';
$lang['Write_report_explain'] = 'Используйте эту форму для отправки сообщения о нарушении. Делайте это только, если вы заметили нарушение Правил трекера.';
$lang['Write_report_error'] = 'Выбранное сообщение не существует.';
$lang['Auth_write_error'] = 'У вас нет прав для отправки сообщения.';
$lang['Duplicate_error'] = 'О нарушениях в выбранных сообщениях уже сообщено.';
$lang['Deleted_error'] = 'Сообщение с нарушением удалено.';

$lang['Click_return'] = '%sНажмите%s для возврата к сообщению в теме.';