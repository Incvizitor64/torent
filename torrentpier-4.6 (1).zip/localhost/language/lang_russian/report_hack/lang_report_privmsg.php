<?php

//
// Module information
//
$lang['Module_title'] = 'Нарушения в ЛС пользоваталей';
$lang['Module_explain'] = 'Этот модуль позволяет сообщать о нарушениях в ЛС.';

//
// Language variables
//
$lang['Report_list_title'] = 'Нарушения в ЛС';
$lang['Report_type'] = 'Нарушения в ЛС';
$lang['Message_id'] = 'ID';
$lang['Message_title'] = 'Заголовок';
$lang['Message_text'] = 'Текст';
$lang['Message_from'] = 'От';

$lang['Write_report'] = '[Сообщить о нарушении в ЛС]';
$lang['Duplicate_report'] = '[О нарушении уже сообщено]';
$lang['Write_report_explain'] = 'Используйте эту форму для отправки сообщения о нарушении. Делайте это только, если вы заметили нарушение Правил трекера.';
$lang['Write_report_error'] = 'Выбранное ЛС не существует.';
$lang['Auth_write_error'] = 'У вас нет прав для отправки сообщения.';
$lang['Duplicate_error'] = 'О нарушении уже сообщено.';
$lang['Deleted_error'] = 'ЛС с нарушением удалено.';

$lang['Click_return'] = '%sНажмите%s для возврата к ЛС.';