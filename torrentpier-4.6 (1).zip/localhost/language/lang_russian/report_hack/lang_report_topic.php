<?php

//
// Module information
//
$lang['Module_title'] = 'Нарушения в темах';
$lang['Module_explain'] = 'Этот модуль позволяет сообщать о нарушающих Правила темах.';

//
// Language variables
//
$lang['Report_list_title'] = 'Нарушения в темах';
$lang['Report_type'] = 'Нарушения в темах';

$lang['Write_report'] = 'Сообщить о нарушении в теме';
$lang['Duplicate_report'] = 'О нарушении уже сообщено';
$lang['Write_report_explain'] = 'Используйте эту форму для отправки сообщения о нарушении. Делайте это только, если вы заметили нарушение Правил трекера.';
$lang['Write_report_error'] = 'Выбранная тема не существует.';
$lang['Auth_write_error'] = 'У вас нет прав для отправки сообщения.';
$lang['Duplicate_error'] = 'О нарушении уже сообщено.';
$lang['Deleted_error'] = 'Тема с нарушением удалена.';

$lang['Click_return'] = '%sНажмите%s для возврата в тему.';