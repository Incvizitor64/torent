<?php

$lang['Bot_topic_moved_from_to'] = 'Топик был перенесен из форума <b>%s</b> в форум <b>%s</b><br /><br />%s';
$lang['Bot_mess_splits'] = 'Сообщения из этой темы были выделены в отдельный топик <b>%s</b><br /><br />%s';
$lang['Bot_topic_splits'] = 'Тема была выделена из <b>%s</b><br /><br />%s';