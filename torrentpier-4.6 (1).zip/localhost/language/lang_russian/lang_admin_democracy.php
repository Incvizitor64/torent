<?php
/*************************************************************************************
 *                           lang_admin_democracy.php [Russian]
 * Part of Democracy MOD by Carbofos < carbofos@mail.ru > and ETZel < etzel@mail.ru >
 *************************************************************************************/

/*************************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *************************************************************************************/

$lang += array(
	'reputation_democracy' => 'Демократия',
	'reputation_democracy_exp' => '"Демократия" объединяет возможности системы предупреждений, управления банами, кармы (репутации) и сообщений модераторам.',
	'reputation_democracy_users' => 'Предупреждения и баны',
	'reputation_democracy_users_exp' => 'На этой странице находится список пользователей, которые имеют предупреждения или были забанены через систему Демократии.',
	'reputation_enable' => 'Включить систему репутации',
	'reputation_enable_warnings' => 'Включить систему предупреждений',
	'reports_enabled' => 'Сообщения модератору',
	'reputation_positive_only' => 'Только положительные отзывы',
	'reputation_positive_only_exp' => 'Пользователи не смогут давать негативные отзывы. Опция действует на новые отзывы и отображение репутации. Если до ее включения уже были отрицательные отзывы, они останутся на месте.',
	'reputation_empty_reviews' => 'Разрешить отзывы без комментариев',
	'reputation_reputation_options' => 'Настройки репутации',
	'reputation_warnings_options' => 'Настройки предупреждений',
	'reputation_reports_options' => 'Настройки сообщений модераторам',
	'reputation_common_options' => 'Общие настройки',
	'Click_return_reputation_index' => '%sВернуться к настройкам Демократии%s',

	'reputation_access_rights' => 'Права доступа',
	'reputation_view_rep' => 'Видеть репутацию и страницы с отзывами',
	'reputation_add_rep' => 'Добавлять репутацию',
	'reputation_add_rep_nonpost' => 'Добавлять репутацию (без указания поста)',
	'reputation_edit_rep' => 'Редактировать отзывы',
	'reputation_delete_rep' => 'Удалять отзывы',
	'reputation_no_limits' => 'Игнорировать ограничения на изменение',
	'reputation_view_warns' => 'Видеть предупреждения и баны',
	'reputation_warn' => 'Выдавать предупреждения',
	'reputation_warn_nonpost' => 'Выдавать предупреждения (без указания поста)',
	'reputation_ban_nonpost' => 'Банить (без указания поста)',
	'reputation_edit_warns' => 'Редактировать предупреждения и баны',
	'reputation_delete_warns' => 'Удалять предупреждения и баны',
	'reputation_not_applicable' => 'Не имеют репутации',
	'reputation_perms_notes' => '(*) только свои<br />(**) только в тех форумах, где он/она является модератором',
	'reputation_warn_perms_notes' => '(*) пользователь всегда может видеть предупреждения, выданные ему<br />(**) только в тех форумах, где он/она является модератором',

	'reputation_auto_reputation' => 'Модификаторы репутации',
	'reputation_start' => 'Давать пользователю %s очков репутации при регистрации.',
	'reputation_for_days' => 'Добавлять одно очко репутации за каждых %s дней регистрации.',
	'reputation_for_posts' => 'Добавлять одно очко репутации за каждых %s сообщений, оставленных пользователем.',
	'reputation_for_reviews' => 'Добавлять одно очко репутации за каждых %s обзоров, написанных пользователем.',
	'reputation_for_rep' => 'Бонусное очко репутации за каждых %s очков репутации полученных от других пользователей.',
	'reputation_for_warns' => 'Штраф %s очков репутации за каждое предупреждение.',
	'reputation_for_bans' => 'Штраф %s очков репутации за каждый бан.',

	'reputation_giving_scale' => 'Влиятельность',
	'reputation_giving_scale_exp' => 'Изначально каждый пользователь имеет влиятельность 1 балл. т.е. может меняет репутацию других пользователей на 1 балл.',
	'reputation_giving_for_days' => 'Влиятельность увеличивается на 1 каждые %s дней регистрации.',
	'reputation_giving_for_posts' => 'Влиятельность увеличивается на 1 за каждые %s сообщений пользователя.',
	'reputation_giving_for_rep' => 'Влиятельность увеличивается на 1 за каждые %s баллов репутации пользователя.',
	'reputation_giving_max' => 'Максимальная влиятельность ограничена %s баллами',
	'reputation_giving_slowdown' => 'Коэффициент уменьшения влиятельности: %s.',
	'reputation_giving_slowdown_exp' => 'Укажите значение между 0 (нет замедления) и 100 (максимальное замедление).<br />Пример (что на что изменится): <span id="giving_slowdown_sample"></span>.',

	'reputation_days_req' => 'Не менее %s дней регистрации.',
	'reputation_posts_req' => 'Не менее %s сообщений на форуме.',
	'reputation_warnings_req' => 'Не более %s активных предупреждений.',
	'reputation_points_req' => 'Репутация не менее %s баллов.',
	'reputation_time_limit' => 'Один пользователь может менять репутацию другого не чаще одного раза за %s минут.',
	'reputation_rotation_limit' => 'Ротация изменений: %s пользователей.',
	'reputation_rotation_limit_exp' => 'Скольким разным пользователям нужно изменить репутацию, перед тем как можно будет дважды менять репутацию одному и тому же пользователю.',
	'reputation_most_respected' => 'Показывать %s наиболее уважаемых пользователей.',
	'reputation_least_respected' => 'Показывать %s наименее уважаемых пользователей.',
	'reputation_respected_exp' => 'Обратите внимание, что точное число отображаемых пользователей моет быть больше, если часть из них имеет одинаковое значение репутации (все они считаются за одну позицию в рейтинге)',
	'reputation_show_values' => 'Показывать значение репутации в перечисленных списках.',
	'reputation_display' => 'Отображение репутации',
	'reputation_display_sum' => 'Одно число (сумма)',
	'reputation_display_plusminus' => 'Положительная и отрицательная раздельно (+2/-3)',
	'reputation_warnings_display' => 'Отображение предупреждений',
	'reputation_warnings_display_img' => 'Графически ("карточки")',
	'reputation_warnings_display_text' => 'Текстом',

	'reputation_infinite' => 'Бесконечный',
	'reputation_infinite_exp' => 'В этом режиме модераторы (администраторы) должны вручную удалять выданные предупреждения, когда сочтут нужным.',
	'reputation_infinite_ban_exp' => 'В этом режиме модераторы (администраторы) должны вручную разбанивать пользователей, когда сочтут нужным.',
	'reputation_fixed' => 'Фиксированный: %s дней.',
	'reputation_modifiable' => 'Можно менять в диапазоне от %s до %s дней.',
	'reputation_modifiable_exp' => 'Вы можете оставить одно или даже оба поля пустыми, чтобы не накладывать ограничения.',
	'reputation_store' => 'Хранить',
	'reputation_delete_days' => 'Удалять по прошествии %s дней.',
	'reputation_ban_warnings' => 'Автоматически банить пользователя, получившего %s предупреждений.',
	'reputation_ban_warnings_exp' => 'Последнее предупреждение автоматически превратится в бан.',
	'reputation_check_rate' => 'Проверять сроки действия предупреждений каждые %s минут',
	'reputation_check_rate_exp' => 'Установите этот параметр так, чтобы проверки не сказывались на нагрузке',

	'reputation_memberlist' => 'Список пользователей', // NOTE: $lang['Memberlist'] in russian phpBB says "Users", so we need this
	'reputation_memberlist_reputation' => 'Показывать репутацию',
	'reputation_memberlist_warnings' => 'Показывать предупреждения',

	'reputation_default_order' => 'Порядок отзывов по умолчанию',

	'reputation_notify' => 'Уведомления',
	'reputation_ban' => 'Бан',

	'reputation_check_confirm' => 'Подтвердите намеренность изменений, установив соответствующую галочку!',

	'reputation_reports_color' => 'Цвет для выделения ссылки на страницу уведомлений:',
	'reputation_reports_color_exp' => 'Оставьте поле пустым, чтобы не выделять ссылку цветом.',

	'reputation_warning_expiry' => 'Срок действия предупреждения',
	'reputation_ban_expiry' => 'Срок действия бана',
	'reputation_expired_warnings' => 'Истекшие предупреждения и баны',
	'reputation_index_page' => 'Главная страница',
	'reputation_prerequirements' => 'Ограничения на пользователя, меняющего репутацию',
	'reputation_limits' => 'Дополнительные ограничения',

	'reputation_maintenance' => 'Утилиты',
	'reputation_resync' => 'Восстановить целостность данных',
	'reputation_resync_exp' => 'Используйте, если число предупреждений или баллов репутации<br />в профиле отличается от действительного.',
	'reputation_success' => 'Операция была выполнена успешно.',

	/*
	'reputation_reports_per_page' => 'Количество сообщений модераторам на страницу',
	'reputation_reviews_per_page' => 'Количество отзывов на страницу',
	'reputation_allow_empty_warns' => 'Разрешить предупреждения без указания причины',
	*/
);
