<?php

/**
   Gallery RoadTrain
   Russian language for TorrentPier SVN
*/

$lang['gallery_your_image'] = 'Ваше изображение';
$lang['gallery_failure'] = 'Неудача';
$lang['gallery_link_url'] = 'Ссылка на изображение';
$lang['gallery_screenshots'] = 'Скриншоты';
$lang['gallery_upload_image'] = 'Загрузить';
$lang['gallery_max_file_size'] = 'Загружать можно изображения в форматах GiF, JPG, PNG. Объем одного изображения не должен превышать';
$lang['gallery_tag_spoiler'] = 'Тэг cпойлера';
$lang['gallery_tag_screen'] = 'Тэг вставки cкриншота';
$lang['gallery_tag_screen_thumb'] = 'Тэг вставки cкриншота с превью';
$lang['gallery_tag_poster_right'] = 'Тэг вставки постера справа';
$lang['gallery_image_overload'] = 'Размер изображения превышает максимально установленный.';
$lang['gallery_file_exist'] = 'Такое изображение уже существует.';
$lang['gallery_upload_failed'] = 'Загрузка потерпела неудачу. Повторите.';
$lang['gallery_upload_successful'] = 'Загрузка прошла успешно.';
$lang['gallery_del_link'] = 'Ссылка на удаление файла';
$lang['gallery_file_delete'] = 'Ваш Файл удален';
$lang['gallery_back'] = 'Вернуться в галерею';
$lang['gallery_file_not_uploaded'] = 'Файл не загружен.';
$lang['gallery_file_not_exist'] = 'Файл не найден.';
$lang['gallery_invalid_type'] = 'Недопустимый тип файла.';
$lang['gallery_create_thumb'] = 'Создать превью';
$lang['gallery_more_link'] = 'ещё...';