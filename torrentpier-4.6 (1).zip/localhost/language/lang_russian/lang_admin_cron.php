<?php

$lang['CRON__LIST'] = 'Список задач';
$lang['CRON__ID'] = 'Id';
$lang['CRON__ACTIVE'] = 'Вкл.';
$lang['CRON__TITLE'] = 'Название';
$lang['CRON__SCRIPT'] = 'Скрипт';
$lang['CRON__SCHEDULE'] = 'Запуск';
$lang['CRON__LAST_RUN'] = 'Посл. запуск';
$lang['CRON__NEXT_RUN'] = 'След. запуск';
$lang['CRON__RUN_COUNT'] = 'Запусков';
$lang['CRON__MANAGE'] = 'Управление';
$lang['CRON__OPTIONS'] = 'Настройки крона';

$lang['CRON_ENABLED'] = 'Крон включён';
$lang['CRON_CHECK_INTERVAL'] = 'Интервал проверки крона (в секундах)';

$lang['WITH_SELECTED'] = 'С выделенными';
$lang['NOTHING'] = 'ничего не делать';
$lang['CRON_RUN'] = 'запустить';
$lang['CRON_DEL'] = 'удалить';
$lang['CRON_DISABLE'] = 'отключить';
$lang['CRON_ENABLE'] = 'включить';

$lang['RUN_MAIN_CRON'] = '[Запустить крон]';
$lang['ADD_JOB'] = '[Добавить задачу]';
$lang['CRON_WORKS'] = 'Крон в данный момент запущен или завис -> ';
$lang['REPAIR_CRON'] = '[Восстановить]';

$lang['CRON_EDIT_HEAD_EDIT'] = 'Редактировать задачу';
$lang['CRON_EDIT_HEAD_ADD'] = 'Добавить задачу';
$lang['cron_id'] = 'ID';
$lang['cron_active'] = 'Активность';
$lang['cron_active_expl'] = 'эта задача включена?';
$lang['cron_title'] = 'Название задачи';
$lang['cron_script'] = 'Скрипт';
$lang['cron_script_expl'] = 'название в папке "includes/cron/jobs/"';
$lang['SCHEDULE'] = 'Запуск';
//schedule
$lang['hourly'] = 'ежечасно';
$lang['daily'] = 'ежедневно';
$lang['weekly'] = 'еженедельно';
$lang['monthly'] = 'ежемесячно';
$lang['interval'] = 'интервал';
//
$lang['RUN_DAY'] = 'День запуска';
$lang['RUN_DAY_EXPL'] = 'день месяца/недели, когда эта задача будет выполняться';
$lang['run_time'] = 'Время запуска';
$lang['run_time_expl'] = 'время запуска этой задачи (напр. 05:00:00)';
$lang['run_order'] = 'Порядок запуска';
$lang['last_run'] = 'Последний запуск';
$lang['next_run'] = 'Следующий запуск';
$lang['run_interval'] = 'Интервал запуска';
$lang['run_interval_expl'] = 'напр. 00:10:00';
$lang['log_enabled'] = 'Логирование включено';
$lang['log_file'] = 'Файл лога';
$lang['log_file_expl'] = 'файл, куда будут сохраняться логи';
$lang['log_sql_queries'] = 'Логировать SQL запросы';
$lang['disable_board'] = 'Отключать форум';
$lang['disable_board_expl'] = 'отключать форум, когда задача выполняется?';
$lang['run_counter'] = 'Кол-во запусков';

