<?php

//
// Original translation performed by Alexey V. Borzov (borz_off)
// borz_off@cs.msu.su
//

setlocale(LC_ALL, 'ru_RU.UTF-8');
$lang['CONTENT_ENCODING'] = 'UTF-8';
$lang['CONTENT_DIRECTION'] = 'ltr';
$lang['DATE_FORMAT'] = 'Y-m-d'; //'d.m.Y'; // This should be changed to the default date format for your language, php date() format
$lang['TRANSLATION_INFO'] = '';
$lang['MODULE_OFF'] = 'Модуль отключен!';

//
// Common, these terms are used
// extensively on several pages
//
$lang['FORUM'] = 'Форум';
$lang['CATEGORY'] = 'Категория';
$lang['TOPIC'] = 'Тема';
$lang['TOPICS'] = 'Темы';
$lang['TOPICS_SHORT'] = 'Тем';
$lang['REPLIES'] = 'Ответов';
$lang['REPLIES_SHORT'] = 'Отв.';
$lang['VIEWS'] = 'Просм.';
$lang['Post'] = 'Сообщение';
$lang['POSTS'] = 'Сообщений';
$lang['POSTS_SHORT'] = 'Сообщ.';
$lang['POSTED'] = 'Добавлено';
$lang['USERNAME'] = 'Имя';
$lang['PASSWORD'] = 'Пароль';
$lang['EMAIL'] = 'Email';
$lang['Poster'] = 'Автор';
$lang['AUTHOR'] = 'Автор';
$lang['Time'] = 'Время';
$lang['Hours'] = 'Часы';
$lang['MESSAGE'] = 'Сообщение';
$lang['TORRENT'] = 'Торрент';
$lang['MANAGE'] = 'Профиль';
$lang['PERMISSIONS'] = 'Права доступа';
$lang['USER'] = 'Пользователь';
$lang['ID_USER'] = 'ID пользователя';

// Whois looking topic [START]
$lang['WHOIS_LOOKING'] = 'Кто просматривает тему';
// Whois looking topic [END]

//Thanks mod
$lang['USER_THANKS'] = 'Спасибы пользователя' ;
$lang['USER_THANKS_'] = 'Пользователь сказал спасибо:' ;
$lang['USER_THANKED'] = 'Пользователю сказали спасибо:' ;
$lang['THANKED'] = 'Поблагодарили';
$lang['THANK'] = 'Поблагодарил(a)';
$lang['Thanks'] = 'Спасибо';
$lang['Thank_List'] = 'Список';
//
$lang['Rating'] = 'Оценка';
$lang['Rating_Votes'] = 'Голосов';
$lang['Your_Vote'] = 'Ваша оценка';
$lang['Vote_Counted'] = 'засчитана';
//
$lang['Rating_1'] = 'Отстой';
$lang['Rating_2'] = 'Так себе';
$lang['Rating_3'] = 'Средне';
$lang['Rating_4'] = 'Хорошо';
$lang['Rating_5'] = 'Супер';
//End thanks mod

$lang['1_Day'] = 'за последний день';
$lang['7_Days'] = 'за последние 7 дней';
$lang['2_Weeks'] = 'за последние 2 недели';
$lang['1_Month'] = 'за последний месяц';
$lang['3_Months'] = 'за последние 3 месяца';
$lang['6_Months'] = 'за последние 6 месяцев';
$lang['1_Year'] = 'за последний год';

$lang['GO'] = 'Перейти';
$lang['Jump_to'] = 'Перейти';
$lang['SUBMIT'] = 'Отправить';
$lang['DO_SUBMIT'] = 'Отправить';
$lang['RESET'] = 'Вернуть';
$lang['CANCEL'] = 'Отмена';
$lang['PREVIEW'] = 'Предв. просмотр';
$lang['CONFIRM'] = 'Подтвердите';
$lang['Spellcheck'] = 'Орфография';
$lang['YES'] = 'Да';
$lang['NO'] = 'Нет';
$lang['Enabled'] = 'Включено';
$lang['Disabled'] = 'Выключено';
$lang['Error'] = 'Ошибка';
$lang['SELECT_ACTION'] = 'Выберите действие';

$lang['Next'] = 'След.';
$lang['Previous'] = 'Пред.';
$lang['GOTO_PAGE'] = 'Страницы';
$lang['GOTO_SHORT'] = 'Стр.';
$lang['JOINED'] = 'Зарегистрирован';
$lang['LONGEVITY'] = 'Стаж';
$lang['IP_Address'] = 'Адрес IP';
$lang['POSTED_AFTER'] = 'спустя';
$lang['Edit_delete_post'] = 'Изменить/удалить это сообщение';

$lang['Select_forum'] = 'Выберите форум';
$lang['View_latest_post'] = 'Посмотреть последнее сообщение';
$lang['View_newest_post'] = 'Перейти к первому непрочитанному сообщению';
$lang['Page_of'] = 'Страница <b>%d</b> из <b>%s</b>';

$lang['ICQ'] = 'ICQ Номер';
$lang['AIM'] = 'AIM Адрес';
$lang['MSNM'] = 'MSN Мессенджер';
$lang['MAGENT'] = 'Агент Mail.ru';
$lang['YIM'] = 'Yahoo Мессенджер';

$lang['Forum_Index'] = 'Список форумов %s';

$lang['Post_new_topic'] = 'Начать новую тему';
$lang['Post_regular_topic'] = 'Создать обычную тему';
$lang['Reply_to_topic'] = 'Ответить на тему';
$lang['Reply_with_quote'] = 'Ответить с цитатой';

$lang['Click_return_topic'] = '%sВернуться в тему%s';
$lang['Click_return_login'] = '%sПопробовать ещё раз%s';
$lang['Click_return_forum'] = '%sВернуться в форум%s';
$lang['Click_view_message'] = '%sПросмотреть ваше сообщение%s';
$lang['Click_return_modcp'] = '%sВернуться к панели модерации%s';
$lang['Click_return_group'] = '%sВернуться к информации о группах%s';

$lang['Admin_panel'] = 'Перейти в администраторский раздел';

$lang['Board_disable'] = 'Извините, эти форумы отключены. Попробуйте зайти попозже';

$lang['LOADING'] = 'Загружается...';
$lang['JUMPBOX_TITLE'] = 'Выберите форум для перехода';
$lang['DISPLAYING_OPTIONS'] = 'Опции показа';

//
// Global Header strings
//
$lang['Registered_users'] = 'Зарегистрированные пользователи:';
$lang['Browsing_forum'] = 'Сейчас этот форум просматривают:';
$lang['Online_users'] = 'Сейчас на форуме <b>%1$d</b> посетителей: %2$d зарегистрированных и %3$d гостей';
$lang['Record_online_users'] = 'Больше всего посетителей (<b>%s</b>) здесь было %s'; // first %s = number of users, second %s is the date.
$lang['Users'] = 'юзеров';

$lang['ONLINE_ADMIN'] = 'Администратор';
$lang['ONLINE_MOD'] = 'Модератор';
$lang['ONLINE_GROUP_MEMBER'] = 'Участник групп';

$lang['You_last_visit'] = 'Ваш последний визит: <span class="tz_time">%s</span>';
$lang['Current_time'] = 'Текущее время: <span class="tz_time">%s</span>';

$lang['SEARCH_NEW'] = 'Новые сообщения';
$lang['SEARCH_SELF'] = 'Мои сообщения';
$lang['SEARCH_SELF_BY_LAST'] = 'времени последнего сообщения';
$lang['SEARCH_SELF_BY_MY'] = 'времени моего сообщения';
$lang['SEARCH_UNANSWERED'] = 'Сообщения без ответов';
$lang['SEARCH_UNANSWERED_SHORT'] = 'без ответов';
$lang['SEARCH_LATEST'] = 'Последние';

$lang['REGISTER'] = 'Регистрация';
$lang['PROFILE'] = 'Профиль';
$lang['Edit_profile'] = 'Редактирование вашего профиля';
$lang['SEARCH'] = 'Поиск';
$lang['MEMBERLIST'] = 'Пользователи';
$lang['FAQ'] = 'FAQ';
$lang['BBCode_guide'] = 'Руководство по BBCode';
$lang['USERGROUPS'] = 'Группы';
$lang['LASTPOST'] = 'Посл. сообщение';
$lang['Moderator'] = 'Модератор';
$lang['MODERATORS'] = 'Модераторы';
$lang['TERMS'] = 'Правила';

//
// Stats block text
//
$lang['Posted_topics_total'] = 'Наши пользователи создали тем: <b>%s</b>'; // Number of topics
$lang['Posted_articles_zero_total'] = 'Наши пользователи не оставили ни одного сообщения'; // Number of posts
$lang['Posted_articles_total'] = 'Наши пользователи оставили сообщений: <b>%s</b>'; // Number of posts
$lang['Registered_users_zero_total'] = 'У нас нет зарегистрированных пользователей'; // # registered users
$lang['Registered_users_total'] = 'Всего зарегистрированных пользователей: <b>%s</b>'; // # registered users
$lang['Newest_user'] = 'Последний зарегистрированный пользователь: <b>%s%s%s</b>'; // username

// Tracker stats
$lang['Torrents_stat'] = 'Раздач: <b style="color: blue;">%s</b>,&nbsp; общий размер: <b>%s</b>'; // first %s = number of torrents, second %s is the total size.
$lang['Peers_stat'] = 'Пиров: <b>%s</b>,&nbsp; сидеров: <b class="seedmed">%s</b>,&nbsp; личеров: <b class="leechmed">%s</b>'; // first %s = number of peers, second %s = number of seeders,  third %s = number of leechers.
$lang['Speed_stat'] = 'Скорость обмена: <b>%s</b>&nbsp;'; // %s = total speed.

$lang['No_new_posts_last_visit'] = 'Нет новых сообщений с последнего посещения';
$lang['NO_NEW_POSTS'] = 'Нет новых сообщений';
$lang['NEW_POSTS'] = 'Новые сообщения';
$lang['New_post'] = 'Новое сообщение';
$lang['No_new_posts_hot'] = 'Нет новых сообщений [ Популярная тема ]';
$lang['New_posts_hot'] = 'Новые сообщения [ Популярная тема ]';
$lang['NO_NEW_POSTS_LOCKED'] = 'Тема закрыта';
$lang['NEW_POSTS_LOCKED'] = 'Новые сообщения [ Тема закрыта ]';
$lang['FORUM_LOCKED'] = 'Форум закрыт';

//
// Login
//
$lang['Enter_password'] = 'Введите ваше имя и пароль для входа в систему';
$lang['LOGIN'] = 'Вход';
$lang['LOGOUT'] = 'Выход';
$lang['CONFIRM_LOGOUT'] = 'Вы уверены, что хотите выйти?';

$lang['FORGOTTEN_PASSWORD'] = 'Забыли пароль?';
$lang['AUTO_LOGIN'] = 'Автоматически входить при каждом посещении';
$lang['Error_login'] = 'Вы ввели неверное/неактивное имя пользователя или неверный пароль.';
$lang['REMEMBER'] = 'Запомнить';
$lang['USER_WELCOME'] = 'Вы зашли как: ';

//
// Index page
//
$lang['Index'] = 'Главная';
$lang['HOME'] = 'Главная';
$lang['NO_POSTS'] = 'Нет сообщений';
$lang['NO_FORUMS'] = 'На этом сайте нет форумов';

$lang['PRIVATE_MESSAGE'] = 'Личное сообщение';
$lang['PRIVATE_MESSAGES'] = 'Личные сообщения';
$lang['WHOSONLINE'] = 'Кто сейчас на форуме';

$lang['MARK_ALL_FORUMS_READ'] = 'Отметить все форумы как прочтённые';
$lang['Forums_marked_read'] = 'Все форумы были отмечены как прочтённые';

$lang['LATEST_NEWS'] = 'Последние новости';
$lang['SUBFORUMS'] = 'Подфорумы';

//
// Viewforum
//
$lang['View_forum'] = 'Просмотр форума';

$lang['Forum_not_exist'] = 'Форума, который вы выбрали, не существует';
$lang['Reached_on_error'] = 'Вы попали на эту страницу из-за ошибки';

$lang['DISPLAY_TOPICS'] = 'Показать';
$lang['All_Topics'] = 'все темы';
$lang['TOPICS_PER_PAGE'] = 'тем на страницу';
$lang['MODERATE_FORUM'] = 'Модерировать этот форум';
$lang['TITLE_SEARCH_HINT'] = 'поиск по названию...';

$lang['Topic_Announcement'] = 'Объявление:';
$lang['Topic_Sticky'] = 'Прилеплена:';
$lang['Topic_Moved'] = 'Перемещена:';
$lang['Topic_Poll'] = '[ Опрос ]';

$lang['MARK_TOPICS_READ'] = 'Отметить все темы как прочтённые';
$lang['Topics_marked_read'] = 'Все темы в этом форуме были отмечены как прочтённые';

$lang['Rules_post_can'] = 'Вы <b>можете</b> начинать темы';
$lang['Rules_post_cannot'] = 'Вы <b>не можете</b> начинать темы';
$lang['Rules_reply_can'] = 'Вы <b>можете</b> отвечать на сообщения';
$lang['Rules_reply_cannot'] = 'Вы <b>не можете</b> отвечать на сообщения';
$lang['Rules_edit_can'] = 'Вы <b>можете</b> редактировать свои сообщения';
$lang['Rules_edit_cannot'] = 'Вы <b>не можете</b> редактировать свои сообщения';
$lang['Rules_delete_can'] = 'Вы <b>можете</b> удалять свои сообщения';
$lang['Rules_delete_cannot'] = 'Вы <b>не можете</b> удалять свои сообщения';
$lang['Rules_vote_can'] = 'Вы <b>можете</b> голосовать в опросах';
$lang['Rules_vote_cannot'] = 'Вы <b>не можете</b> голосовать в опросах';
$lang['Rules_moderate'] = 'Вы <b>можете</b> модерировать этот форум';

$lang['No_topics_post_one'] = 'В этом форуме пока нет сообщений<br />Щёлкните <b>Начать новую тему</b>, и ваше сообщение станет первым.';


//
// Viewtopic
//
$lang['View_topic'] = 'Просмотр темы';

$lang['Guest'] = 'Гость';
$lang['POST_SUBJECT'] = 'Заголовок сообщения';
$lang['VIEW_NEXT_TOPIC'] = 'Следующая тема';
$lang['VIEW_PREVIOUS_TOPIC'] = 'Предыдущая тема';
$lang['SUBMIT_VOTE'] = 'Проголосовать';
$lang['VIEW_RESULTS'] = 'Результаты';

$lang['No_newer_topics'] = 'В этом форуме нет более новых тем';
$lang['No_older_topics'] = 'В этом форуме нет более старых тем';
$lang['Topic_post_not_exist'] = 'Темы, которую вы запросили, не существует.';
$lang['No_posts_topic'] = 'В этой теме нет сообщений';

$lang['DISPLAY_POSTS'] = 'Показать сообщения';
$lang['All_Posts'] = 'все сообщения';
$lang['Newest_First'] = 'Начиная с новых';
$lang['Oldest_First'] = 'Начиная со старых';

$lang['BACK_TO_TOP'] = 'Вернуться к началу';

$lang['Read_profile'] = 'Посмотреть профиль'; // Followed by username of poster
$lang['Visit_website'] = 'Посетить сайт автора';
$lang['ICQ_status'] = 'Статус ICQ';
$lang['View_IP'] = 'Показать IP адрес автора';
$lang['Moderate_post'] = 'Модерировать сообщения';
$lang['Delete_post'] = 'Удалить это сообщение';

$lang['wrote'] = 'писал(а)'; // proceeds the username and is followed by the quoted text
$lang['Quote'] = 'Цитата'; // comes before bbcode quote output.
$lang['Code'] = 'Код'; // comes before bbcode code output.
$lang['CODE_COPIED'] = 'Код скопирован в буфер обмена';
$lang['CODE_COPY'] = 'скопировать в буфер обмена';
$lang['Spoiler_head'] = 'скрытый текст';
$lang['SKETCH'] = 'Эскиз';
$lang['SKETCH_TITLE'] = 'Эскиз изображения (Ctrl+T)';

$lang['Edited_time_total'] = 'Последний раз редактировалось: %s (%s), всего редактировалось %d раз'; // Last edited by me on 12 Oct 2001, edited 1 time in total
$lang['Edited_times_total'] = 'Последний раз редактировалось: %s (%s), всего редактировалось %d раз(а)'; // Last edited by me on 12 Oct 2001, edited 2 times in total

$lang['LOCK_TOPIC'] = 'Закрыть тему';
$lang['UNLOCK_TOPIC'] = 'Вновь открыть тему';
$lang['MOVE_TOPIC'] = 'Перенести тему';
$lang['DELETE_TOPIC'] = 'Удалить тему';
$lang['SPLIT_TOPIC'] = 'Разделить тему';

// User topic list
$lang['EDIT_LIST'] = 'Редактировать список';
$lang['MARK_INVERT'] = 'отметить/инвертировать';
$lang['DEL_TOPIC_LIST'] = 'Удалить выбранные темы из списка';
$lang['EXPLAIN_TOPIC_LIST'] = 'Для удаления тем из списка нажмите на иконку слева от названия любого раздела';
// User topic list [END]

// Bookmarks
$lang['Stop_bookmark_topic'] = 'Удалить из закладок';
$lang['Start_bookmark_topic'] = 'Добавить в закладки';
$lang['Bookmarks'] = 'Закладки';
$lang['Bookmark_added'] = 'Тема успешно добавлена в закладки';
$lang['Bookmark_removed'] = 'Тема успешно удалена из закладок';
$lang['No_bookmarks'] = 'У вас нет закладок';
// Bookmarks [END]

// Watched topic
$lang['Watched_topics'] = 'Отслеживаемые темы';
$lang['No_watched_topics'] = 'Вы не отслеживаете ни на одну из тем';
// Watched topic [END]

$lang['Stop_watching_topic'] = 'Перестать следить за ответами';
$lang['Start_watching_topic'] = 'Следить за ответами в теме';
$lang['No_longer_watching'] = 'Вы больше не следите за ответами в этой теме';
$lang['You_are_watching'] = 'Теперь вы следите за ответами в этой теме';

$lang['TOTAL_VOTES'] = 'Всего проголосовало';
$lang['SEARCH_IN_TOPIC'] = 'искать в теме...';
$lang['HIDE_IN_TOPIC'] = 'Не показывать';

$lang['FLAGS'] = 'флаги';
$lang['AVATARS'] = 'аватары';
$lang['RANK_IMAGES'] = 'картинки званий';
$lang['POST_IMAGES'] = 'картинки в сообщениях';
$lang['SMILIES'] = 'смайлики';
$lang['SIGNATURES'] = 'подписи';
$lang['SPOILER'] = 'Спойлер';
$lang['SHOW_OPENED'] = 'показывать открытым';

$lang['MODERATE_TOPIC'] = 'Модерировать этот топик';
$lang['Select_posts_per_page'] = 'сообщ. на страницу';


//
// Posting/Replying (Not private messaging!)
//
$lang['Message_body'] = 'Сообщение';
$lang['Topic_review'] = 'Обзор темы';

$lang['No_post_mode'] = 'Не указан режим сообщения';

$lang['Post_a_new_topic'] = 'Начать новую тему';
$lang['Post_a_reply'] = 'Ответить';
$lang['Post_topic_as'] = 'Статус создаваемой темы';
$lang['Edit_post'] = 'Редактировать сообщение';
$lang['OPTIONS'] = 'Настройки';

$lang['POST_ANNOUNCEMENT'] = 'Объявление';
$lang['POST_STICKY'] = 'Прилепленная';
$lang['POST_NORMAL'] = 'Обычная';
$lang['POST_DOWNLOAD'] = 'Download';

$lang['Confirm_delete'] = 'Вы уверены, что хотите удалить это сообщение?';
$lang['Confirm_delete_poll'] = 'Вы уверены, что хотите удалить этот опрос?';

$lang['Flood_Error'] = 'Вы не можете отправить следующее сообщение сразу после предыдущего. Пожалуйста, попробуйте чуть попозже.';
$lang['Empty_subject'] = 'Вы должны указать заголовок сообщения, когда начинаете новую тему';
$lang['Empty_message'] = 'Вы должны ввести текст сообщения';
$lang['Forum_locked'] = 'Этот форум закрыт, вы не можете писать новые сообщения и редактировать старые.';
$lang['Topic_locked'] = 'Эта тема закрыта, вы не можете писать ответы и редактировать сообщения.';
$lang['Topic_locked_short'] = 'Тема закрыта';
$lang['No_post_id'] = 'Вы должны выбрать сообщение для редактирования';
$lang['No_topic_id'] = 'Вы должны выбрать тему для ответа';
$lang['No_valid_mode'] = 'Вы можете только создавать темы, отвечать и редактировать сообщения. Вернитесь и попробуйте ещё раз.';
$lang['No_such_post'] = 'Сообщение отсутствует. Вернитесь и попробуйте ещё раз.';
$lang['Edit_own_posts'] = 'Извините, вы можете редактировать только ваши собственные сообщения';
$lang['Delete_own_posts'] = 'Извините, вы можете удалять только ваши собственные сообщения';
$lang['Cannot_delete_replied'] = 'Извините, вы не можете удалить сообщение, на которое были получены ответы';
$lang['Cannot_delete_poll'] = 'Извините, вы не можете удалить активный опрос';
$lang['Empty_poll_title'] = 'Вы должны ввести заголовок для опроса';
$lang['To_few_poll_options'] = 'Вы должны ввести не менее двух вариантов ответа';
$lang['To_many_poll_options'] = 'Вы попытались ввести слишком много вариантов ответа';
$lang['Post_has_no_poll'] = 'В этом сообщении нет опроса';
$lang['Already_voted'] = 'Вы уже голосовали в этом опросе';
$lang['No_vote_option'] = 'Вы должны указать вариант ответа при голосовании';
$lang['locked_warn'] = 'Вы отправили сообщение в закрытый топик!';

$lang['Add_poll'] = 'Добавить опрос';
$lang['Add_poll_explain'] = 'Если вы не хотите добавлять опрос к вашему сообщению, оставьте поля пустыми';
$lang['Poll_question'] = 'Вопрос';
$lang['Poll_option'] = 'Вариант ответа';
$lang['Add_option'] = 'Добавить ещё вариант';
$lang['UPDATE'] = 'Обновить';
$lang['Poll_for'] = 'Опрос должен идти';
$lang['Days'] = 'Дней';
$lang['Poll_for_explain'] = '[ оставьте поле пустым, чтобы опрос не кончался ]';
$lang['Delete_poll'] = 'Удалить опрос';

$lang['Disable_BBCode_post'] = 'Отключить BBCode';
$lang['Disable_Smilies_post'] = 'Отключить смайлики';

$lang['BBCode_is_ON'] = '%sBBCode%s <u>ВКЛЮЧЁН</u>';
$lang['BBCode_is_OFF'] = '%sBBCode%s <u>ВЫКЛЮЧЕН</u>';
$lang['Smilies_are_ON'] = 'Смайлики <u>ВКЛЮЧЕНЫ</u>';
$lang['Smilies_are_OFF'] = 'Смайлики <u>ВЫКЛЮЧЕНЫ</u>';

$lang['ATTACH_SIGNATURE'] = 'Присоединить подпись (можно изменять в профиле)';
$lang['Notify'] = 'Сообщать мне о получении ответа';

$lang['Stored'] = 'Ваше сообщение было успешно добавлено';
$lang['Deleted'] = 'Ваше сообщение было успешно удалено';
$lang['Poll_delete'] = 'Ваш опрос был успешно удалён';
$lang['Vote_cast'] = 'Ваш голос был учтён';

$lang['Topic_reply_notification'] = 'Уведомление об ответе в теме';

$lang['bbcode_b_help'] = 'Жирный текст: [b]текст[/b]  (alt+b)';
$lang['bbcode_i_help'] = 'Наклонный текст: [i]текст[/i]  (alt+i)';
$lang['bbcode_u_help'] = 'Подчёркнутый текст: [u]текст[/u]  (alt+u)';
$lang['bbcode_q_help'] = 'Цитата: [quote]текст[/quote]  (alt+q)';
$lang['bbcode_c_help'] = 'Код (программа): [code]код[/code]  (alt+c)';
$lang['bbcode_l_help'] = 'Список: [list]текст[/list] (alt+l)';
$lang['bbcode_o_help'] = 'Нумерованный список: [list=]текст[/list]  (alt+o)';
$lang['bbcode_p_help'] = 'Вставить картинку: [img]http://image_url[/img]  (alt+p)';
$lang['bbcode_w_help'] = 'Вставить ссылку: [url]http://url[/url] или [url=http://url]текст ссылки[/url]  (alt+w)';
$lang['bbcode_a_help'] = 'Закрыть все открытые теги bbCode';
$lang['bbcode_s_help'] = 'Цвет шрифта: [color=red]текст[/color]  Подсказка: можно использовать color=#FF0000';
$lang['bbcode_f_help'] = 'Размер шрифта: [size=x-small]маленький текст[/size]';

$lang['Emoticons'] = 'Смайлики';
$lang['More_emoticons'] = 'Дополнительные смайлики';

$lang['Font_color'] = 'Цвет';
$lang['color_default'] = 'По умолчанию';
$lang['color_dark_red'] = 'Тёмно-красный';
$lang['color_red'] = 'Красный';
$lang['color_orange'] = 'Оранжевый';
$lang['color_brown'] = 'Коричневый';
$lang['color_yellow'] = 'Жёлтый';
$lang['color_green'] = 'Зелёный';
$lang['color_olive'] = 'Оливковый';
$lang['color_cyan'] = 'Голубой';
$lang['color_blue'] = 'Синий';
$lang['color_dark_blue'] = 'Тёмно-синий';
$lang['color_indigo'] = 'Индиго';
$lang['color_violet'] = 'Фиолетовый';
$lang['color_white'] = 'Белый';
$lang['color_black'] = 'Чёрный';

$lang['Font_size'] = 'Размер';
$lang['font_tiny'] = 'Очень маленький';
$lang['font_small'] = 'Маленький';
$lang['font_normal'] = 'Обычный';
$lang['font_large'] = 'Большой';
$lang['font_huge'] = 'Огромный';

$lang['Close_Tags'] = 'Закрыть теги';
$lang['Styles_tip'] = 'Подсказка: Можно быстро применить стили к выделенному тексту';

$lang['NEW_POSTS_PREVIEW'] = 'В топике есть новые, измененные или непрочитанные сообщения';

//
// Private Messaging
//
$lang['Private_Messaging'] = 'ЛС';

$lang['No_new_pm'] = 'новых нет';

$lang['New_pms_format'] = '<b>%1$s</b> %2$s'; // 1 новое сообщ.
$lang['New_pms_declension'] = array('новое сообщение', 'новых сообщений');

$lang['Unread_pms_format'] = '<b>%1$s</b> %2$s'; // 1 непрочитанное
$lang['Unread_pms_declension'] = array('непрочитанное', 'непрочитанных');

$lang['Unread_message'] = 'Непрочитанное сообщение';
$lang['Read_message'] = 'Прочитанное сообщение';

$lang['Read_pm'] = 'Прочитать сообщение';
$lang['Post_new_pm'] = 'Написать новое сообщение';
$lang['Post_reply_pm'] = 'Ответить на сообщение';
$lang['Post_quote_pm'] = '[Цитировать]';
$lang['Edit_pm'] = '[Редактировать]';

$lang['Inbox'] = 'Входящие';
$lang['Outbox'] = 'Исходящие';
$lang['Savebox'] = 'Сохранённые';
$lang['Sentbox'] = 'Отправленные';
$lang['Flag'] = 'Флаг';
$lang['Subject'] = 'Тема';
$lang['FROM'] = 'От';
$lang['TO'] = 'Кому';
$lang['Date'] = 'Дата';
$lang['Mark'] = 'Отметка';
$lang['Sent'] = 'Отправлено';
$lang['Saved'] = 'Сохранено';
$lang['Delete_marked'] = 'Удалить отмеченное';
$lang['Delete_all'] = 'Удалить все';
$lang['Save_marked'] = 'Сохранить отмеченное';
$lang['Save_message'] = 'Сохранить сообщение';
$lang['Delete_message'] = 'Удалить сообщение';

$lang['Display_messages'] = 'Показать сообщения'; // Followed by number of days/weeks/months
$lang['All_Messages'] = 'Все сообщения';

$lang['No_messages_folder'] = 'В этой папке нет сообщений';

$lang['PM_disabled'] = 'Возможность отправки ЛС на этих форумах была отключена';
$lang['Cannot_send_privmsg'] = 'Извините, вам не разрешено отправлять ЛС';
$lang['No_to_user'] = 'Вы должны указать имя получателя этого сообщения';
$lang['No_such_user'] = 'Извините, но такого пользователя не существует';

$lang['Gallery_disabled'] = 'Галерея отключена';

$lang['Disable_BBCode_pm'] = 'Отключить BBCode';
$lang['Disable_Smilies_pm'] = 'Отключить смайлики';

$lang['Message_sent'] = '<b>Ваше сообщение было отправлено</b>';

$lang['Click_return_inbox'] = 'Перейти в папку:<br /><br /> %s<b>Входящие</b>%s';
$lang['Click_return_sentbox'] = '&nbsp;&nbsp; %s<b>Отправленные</b>%s';
$lang['Click_return_outbox'] = '&nbsp;&nbsp; %s<b>Исходящие</b>%s';
$lang['Click_return_savebox'] = '&nbsp;&nbsp; %s<b>Сохраненные</b>%s';
$lang['Click_return_index'] = '%sВернуться к списку форумов%s';

$lang['Send_a_new_message'] = 'Отправить ЛС';
$lang['Send_a_reply'] = 'Ответить на ЛС';
$lang['Edit_message'] = 'Редактировать ЛС';

$lang['Notification_subject'] = 'Вам пришло новое ЛС';

$lang['FIND_USERNAME'] = 'Найти пользователя';
$lang['SELECT_USERNAME'] = 'Выберите пользователя';
$lang['Find'] = 'Найти';
$lang['No_match'] = 'Не найдено';

$lang['No_post_id'] = 'Не указан ID';
$lang['No_such_folder'] = 'Такой папки нет';
$lang['No_folder'] = 'Не указана папка';

$lang['Mark_all'] = 'Выделить все';
$lang['Unmark_all'] = 'Снять выделение';

$lang['Confirm_delete_pm'] = 'Вы уверены, что хотите удалить это сообщение?';
$lang['Confirm_delete_pms'] = 'Вы уверены, что хотите удалить эти сообщения?';

$lang['Inbox_size'] = 'Ваша папка &laquo;Входящие&raquo;<br />заполнена на <b>%d%%</b>'; // eg. Your Inbox is 50% full
$lang['Sentbox_size'] = 'Ваша папка &laquo;Отправленные&raquo;<br />заполнена на <b>%d%%</b>';
$lang['Savebox_size'] = 'Ваша папка &laquo;Сохранённые&raquo;<br />заполнена на <b>%d%%</b>';

$lang['Click_view_privmsg'] = '%sПерейти в папку &laquo;Входящие&raquo;%s';

$lang['Outbox_expl'] = 'В папке <b>Исходящие</b> находятся отправленные, но еще не прочтённые получателем сообщения. В <b>Отправленные</b> они попадают только после того, как получатель их прочтет. Сообщения, находящиеся в папке <b>Исходящие</b>, можно отредактировать или удалить.';

//
// Profiles/Registration
//
$lang['Viewing_user_profile'] = 'Профиль пользователя %s'; // %s is username
$lang['About_user'] = 'О пользователе %s'; // слово 'пользователь' - чтобы не заморачиваться с мужским/женским родом

$lang['Preferences'] = 'Личные настройки';
$lang['Items_required'] = 'Поля отмеченные * обязательны к заполнению, если не указано обратное';
$lang['Registration_info'] = 'Регистрационная информация';
$lang['Profile_info'] = 'Профиль';
$lang['Profile_info_warn'] = 'Эта информация будет в открытом доступе';
$lang['Avatar_panel'] = 'Управление аватарой';
$lang['Avatar_gallery'] = 'Галерея аватар';

$lang['WEBSITE'] = 'Сайт';
$lang['LOCATION'] = 'Откуда';
$lang['Contact'] = 'Контакты'; // Как связаться с Vasya_Poopkin
$lang['Email_address'] = 'Адрес e-mail';
$lang['Send_private_message'] = 'Отправить ЛС';
$lang['Hidden_email'] = '[ скрыт ]';
$lang['Interests'] = 'Интересы';
$lang['Occupation'] = 'Род занятий';
$lang['Poster_rank'] = 'Звание';

$lang['Group_member'] = 'Членство в группах';

$lang['Total_posts'] = 'Всего сообщений';
$lang['User_post_pct_stats'] = '%.2f%% от общего числа'; // 15% of total
$lang['User_post_day_stats'] = '%.2f сообщений в день'; // 1.5 posts per day
$lang['Search_user_posts'] = 'Найти сообщения пользователя %s'; // Find all posts by username
$lang['Search_user_posts_short'] = 'Найти сообщения пользователя';
$lang['Search_user_topics'] = 'Начатые темы'; // Find all topics by username

$lang['No_user_id_specified'] = 'Извините, такого пользователя не существует';
$lang['Wrong_Profile'] = 'Вы не можете редактировать чужой профиль.';

$lang['Only_one_avatar'] = 'Может быть указан только один тип аватары';
$lang['File_no_data'] = 'Файл по указанному вами URL не содержит данных';
$lang['No_connection_URL'] = 'Невозможно установить соединения с указанным вами URL';
$lang['Incomplete_URL'] = 'Вы указали неполный URL';
$lang['Wrong_remote_avatar_format'] = 'Неверный URL удалённой аватары';
$lang['No_send_account_inactive'] = 'Извините, но пароль не может быть выслан (учетная запись неактивна)';
$lang['No_send_account'] = 'Извините, но пароль для этого пользователя не может быть выслан. Обратитесь к администраторам форума за дополнительной информацией';

$lang['Always_add_sig'] = 'Всегда присоединять мою подпись';
$lang['HIDE_PORN_FORUMS'] = 'Скрыть pron форумы';
$lang['Always_notify'] = 'Всегда сообщать мне об ответах';
$lang['Always_notify_explain'] = 'Когда кто-нибудь ответит на тему, в которую вы писали, вам высылается e-mail. Это можно также настроить при размещении сообщения.';

$lang['Board_style'] = 'Внешний вид форумов';
$lang['Board_lang'] = 'Язык';
$lang['No_themes'] = 'В базе нет цветовых схем';
$lang['Timezone'] = 'Часовой пояс';
$lang['Date_format'] = 'Формат даты';
$lang['Date_format_explain'] = 'Синтаксис идентичен функции <a href="http://www.php.net/date" target="_other">date()</a> языка PHP';
$lang['Signature'] = 'Подпись';
$lang['Signature_explain'] = 'Это текст, который можно добавлять к размещаемым вами сообщениям. Длина его ограничена %d символами.';
$lang['Public_view_email'] = 'Всегда показывать мой адрес e-mail';

$lang['GenRandomPass'] = 'Сгенерировать случайный пароль';
$lang['Current_password'] = 'Текущий пароль';
$lang['NEW_PASSWORD'] = 'Новый пароль';
$lang['Confirm_password'] = 'Подтвердите пароль';
$lang['Confirm_password_explain'] = 'Вы должны указать ваш текущий пароль, если хотите изменить его или поменять свой email.';
$lang['password_if_changed'] = 'Указывайте пароль только если вы хотите его поменять';
$lang['password_confirm_if_changed'] = 'Подтверждать пароль нужно в том случае, если вы изменили его выше.';

$lang['Autologin'] = 'Автовход';
$lang['Reset_autologin'] = 'Удалить ключ автоматического входа на форум';
$lang['Reset_autologin_expl'] = 'включая все места, где вы заходили на форум со включенным автовходом';

$lang['Avatar'] = 'Аватара';
$lang['Avatar_explain'] = 'Показывает небольшое изображение под информацией о вас в сообщениях. Может быть показано только одно изображение, шириной не более %d пикселов, высотой не более %d пикселов и объёмом не более %d кб.';
$lang['Upload_Avatar_file'] = 'Загрузить аватарку с вашего компьютера';
$lang['Upload_Avatar_URL'] = 'Загрузить аватарку с URL';
$lang['Upload_Avatar_URL_explain'] = 'Введите URL по которому находится файл с изображением, он будет скопирован на этот сайт.';
$lang['Pick_local_Avatar'] = 'Выбрать аватарку из галереи';
$lang['Link_remote_Avatar'] = 'Показывать аватарку с другого сервера';
$lang['Link_remote_Avatar_explain'] = 'Введите URL изображения, на которое вы хотите сослаться.';
$lang['Avatar_URL'] = 'URL изображения аватары';
$lang['Select_from_gallery'] = 'Выбрать аватарку из галереи';
$lang['View_avatar_gallery'] = 'Показать галерею';

$lang['Select_avatar'] = 'Выберите аватарку';
$lang['Return_profile'] = 'Вернуться к профилю';
$lang['SELECT_CATEGORY'] = 'Выберите категорию';

$lang['Delete_Image'] = 'Удалить изображение';
$lang['Current_Image'] = 'Текущее изображение';

$lang['Notify_on_privmsg'] = 'Уведомлять о новых ЛС';
$lang['Hide_user'] = 'Скрывать ваше пребывание на форуме';

$lang['Profile_updated'] = 'Ваш профиль был изменён';
$lang['Profile_updated_inactive'] = 'Ваш профиль был изменён, но вы изменили важные данные, так что теперь ваша учётная запись неактивна. Проверьте ваш почтовый ящик, чтобы узнать как вновь активизировать учётную запись или, если требуется одобрение администратора, подождите пока это сделает администратор.';

$lang['Password_mismatch'] = 'Введённые пароли не совпадают';
$lang['Current_password_mismatch'] = 'Введённый вами пароль не совпадает с паролем из базы';
$lang['Password_long'] = 'Ваш пароль должен быть не длиннее 32 символов';
$lang['Too_many_registers'] = 'Вы сделали слишком много попыток зарегистрироваться. Пожалуйста, повторите попытку позднее.';
$lang['Username_taken'] = 'Извините, пользователь с таким именем уже существует';
$lang['Username_invalid'] = 'Извините, это имя содержит неподходящие символы, (например ")';
$lang['Username_disallowed'] = 'Извините, это имя было запрещено к использованию';
$lang['Email_taken'] = 'Извините, этот адрес e-mail уже занят другим пользователем';
$lang['Email_banned'] = 'Извините, адрес <b>%s</b> находится в чёрном списке';
$lang['Email_invalid'] = 'Извините, этот адрес e-mail неправилен';
$lang['Signature_too_long'] = 'Слишком длинная подпись';
$lang['Fields_empty'] = 'Вы должны заполнить обязательные поля';
$lang['Avatar_filetype'] = 'Файл аватары должен быть .jpg, .gif или .png';
$lang['Avatar_filesize'] = 'Объём файла аватары должен быть не более %d кб';
$lang['Avatar_imagesize'] = 'Аватара должна быть не больше %d пикселов в ширину и %d пикселов в высоту';
$lang['Username_min_length'] = 'Извините, длина имени должна быть не менее %s символов';
$lang['Username_max_length'] = 'Извините, длина имени должна быть не более %s символов';

$lang['Welcome_subject'] = 'Добро пожаловать на форумы %s';
$lang['New_account_subject'] = 'Новый пользователь';
$lang['Account_activated_subject'] = 'Учётная запись активизирована';

$lang['Account_added'] = 'Спасибо за регистрацию, учётная запись была создана. Вы можете войти в систему, используя ваше имя и пароль.';
$lang['Account_inactive'] = 'Учётная запись была создана. На этом форуме требуется активизация учётной записи, ключ для активизации был выслан на введённый вами адрес. Проверьте свою почту для более подробной информации.';
$lang['Account_inactive_admin'] = 'Учётная запись была создана. На этом форуме требуется активизация новой учётной записи администраторами. Им был отправлен e-mail, и, как только они активизируют вашу учётную запись, вы получите уведомление.';
$lang['Account_active'] = 'Ваша учётная запись была активизирована. Спасибо за регистрацию.';
$lang['Account_active_admin'] = 'Ваша учётная запись была активизирована.';
$lang['Reactivate'] = 'Вновь активизировать учётную запись';
$lang['Already_activated'] = 'Вы уже активизировали свою учётную запись';
$lang['COPPA'] = 'Ваша учётная запись была создана, но теперь она должна быть одобрена, более подробная информация была выслана вам по e-mail.';

$lang['Registration'] = 'Условия регистрации';

$lang['Agree_over_13'] = 'Я <b>согласен</b> с этими условиями';
$lang['Agree_not'] = 'Я <b>не согласен</b> с этими условиями';

$lang['Wrong_activation'] = 'Введённый вами ключ активизации не совпадает с хранящимся в базе';
$lang['Send_password'] = 'Прислать новый пароль';
$lang['Password_updated'] = 'Новый пароль был создан, проверьте почтовый ящик, чтобы узнать как его активизировать';
$lang['No_email_match'] = 'Введённый вами адрес e-mail не совпадает с записанным на этого пользователя';
$lang['New_password_activation'] = 'Активизация нового пароля';
$lang['Password_activated'] = 'Ваша учётная запись была вновь активизирована. Для входа в систему используйте пароль из присланного вам письма.';

$lang['Send_email_msg'] = 'Отправить e-mail';
$lang['No_user_specified'] = 'Пользователь не был выбран';
$lang['User_prevent_email'] = 'Пользователь не желает получать e-mail. Попробуйте отправить ему/ей ЛС';
$lang['User_not_exist'] = 'Пользователя не существует';
$lang['CC_email'] = 'Отправить копию сообщения самому себе';
$lang['Email_message_desc'] = 'Сообщение будет отправлено в виде простого текста, не включайте в него HTML или BBCode. В качестве обратного адреса будет показываться ваш адрес e-mail.';
$lang['Flood_email_limit'] = 'Вы не можете отправить ещё один e-mail сразу после предыдущего, попробуйте сделать это попозже.';
$lang['Recipient'] = 'Получатель';
$lang['Email_sent'] = 'Сообщение было отправлено';
$lang['Send_email'] = 'Отправить e-mail';
$lang['Empty_subject_email'] = 'Вы должны указать тему сообщения';
$lang['Empty_message_email'] = 'Вы должны указать текст сообщения для отправки';

$lang['USER_AGREEMENT'] = 'Пользовательское Соглашение';
$lang['USER_AGREEMENT_HEAD'] = 'Для продолжения регистрации Вы должны принять наше ПОЛЬЗОВАТЕЛЬСКОЕ СОГЛАШЕНИЕ';
$lang['USER_AGREEMENT_AGREE'] = 'Я прочел ПОЛЬЗОВАТЕЛЬСКОЕ СОГЛАШЕНИЕ и обязуюсь его не нарушать';

$lang['COPYRIGHT_HOLDERS'] = 'Для правообладателей';
$lang['ADVERT'] = 'Реклама на сайте';

//
// Visual confirmation system strings
//
$lang['Confirm_code_empty'] = 'Введите код подтверждения';
$lang['Confirm_code_wrong'] = 'Вы ввели неверный код подтверждения';
$lang['Too_many_registers'] = 'Вы исчерпали предельное количество попыток регистрации для данной сессии. Повторите попытку позднее.';
$lang['Confirm_code_impaired'] = 'Если у вас плохое зрение или вы не можете прочесть этот код по какой-то другой причине, то обратитесь за помощью к %sАдминистратору%s.';
$lang['Confirm_code'] = 'Код подтверждения';
$lang['Confirm_code_explain'] = 'Введите код в точности так, как вы его видите. Код является регистро-зависимым, а символ нуля имеет косую линию внутри цифры.';

//
// Memberslist
//
$lang['SORT'] = 'Упорядочить';
$lang['Sort_Top_Ten'] = 'десять самых активных участников';
$lang['Sort_Joined'] = 'дате регистрации';
$lang['Sort_Username'] = 'имени пользователя';
$lang['Sort_Location'] = 'местонахождению';
$lang['Sort_Posts'] = 'количеству сообщений';
$lang['Sort_Email'] = 'адресу e-mail';
$lang['Sort_Website'] = 'адресу сайта';
$lang['ASC'] = 'по возрастанию';
$lang['DESC'] = 'по убыванию';
$lang['ORDER'] = ''; // не нужно, в английском используется в контексте 'Order ascending';


//
// Group control panel
//
$lang['Group_Control_Panel'] = 'Группы';
$lang['MEMBERSHIP_DETAILS'] = 'Информация о членстве в группах';
$lang['JOIN_A_GROUP'] = 'Вступить в группу';

$lang['GROUP_INFORMATION'] = 'Информация о группе';
$lang['GROUP_NAME'] = 'Название группы';
$lang['GROUP_DESCRIPTION'] = 'Описание группы';
$lang['GROUP_MEMBERSHIP'] = 'Членство в группе';
$lang['GROUP_MEMBERS'] = 'Члены группы';
$lang['GROUP_MODERATOR'] = 'Модератор группы';
$lang['PENDING_MEMBERS'] = 'Кандидаты в члены группы';

$lang['GROUP_TYPE'] = 'Тип группы';
$lang['GROUP_OPEN'] = 'Группа с открытым членством';
$lang['GROUP_CLOSED'] = 'Группа с закрытым членством';
$lang['GROUP_HIDDEN'] = 'Скрытая группа';

$lang["Group_member_mod"] = 'Являетесь модератором групп';
$lang["Group_member_member"] = 'Являетесь членом групп';
$lang["Group_member_pending"] = 'Кандидат в члены групп';
$lang["Group_member_open"] = 'Группы с открытым членством';
$lang["Group_member_closed"] = 'Группы с закрытым членством';
$lang["Group_member_hidden"] = 'Скрытые группы';

$lang['No_groups_exist'] = 'Нет ни одной группы';
$lang['Group_not_exist'] = 'Такой группы не существует';

$lang['NO_GROUP_MEMBERS'] = 'В этой группе нет ни одного члена';
$lang['HIDDEN_GROUP_MEMBERS'] = 'Эта группа скрыта, вы не можете посмотреть её состав';
$lang['No_pending_group_members'] = 'В этой группе нет кандидатов в члены';
$lang['Group_joined'] = 'Вы попросили о вступлении в группу. Когда вашу просьбу одобрит модератор группы, вам будет прислано уведомление.';
$lang['Group_request'] = 'Было подана просьба о вступлении в группу.';
$lang['Group_approved'] = 'Ваша просьба была удовлетворена.';
$lang['Group_added'] = 'Вы были включены в группу';
$lang['Already_member_group'] = 'Вы уже являетесь членом этой группы';
$lang['User_is_member_group'] = 'Пользователь уже является членом этой группы';
$lang['Group_type_updated'] = 'Тип группы успешно изменён';

$lang['Could_not_add_user'] = 'Выбранного пользователя не существует';
$lang['Could_not_anon_user'] = 'Вы не можете сделать анонимного пользователя членом группы';

$lang['Confirm_unsub'] = 'Вы уверены, что хотите выйти из этой группы?';
$lang['Confirm_unsub_pending'] = 'Вы уверены, что хотите отказаться от участия в этой группе? Ваша просьба о вступлении не была ни удовлетворена, ни отклонена!';

$lang['Unsub_success'] = 'Вы успешно покинули эту группу.';

$lang['APPROVE_SELECTED'] = 'Одобрить выделенное';
$lang['DENY_SELECTED'] = 'Отклонить выделенное';
$lang['Not_logged_in'] = 'Вы должны войти в систему, прежде чем вступать в группу.';
$lang['REMOVE_SELECTED'] = 'Удалить выделенное';
$lang['ADD_MEMBER'] = 'Добавить члена группы';
$lang['Not_group_moderator'] = 'Вы не являетесь модератором группы и не можете выполнить данное действие';

$lang['Login_to_join'] = 'Войдите в систему, чтобы менять своё членство в группах';
$lang['This_open_group'] = 'Это группа с открытым членством, вы можете подать просьбу о вступлении';
$lang['This_closed_group'] = 'Это группа с закрытым членством, новые пользователи не принимаются';
$lang['This_hidden_group'] = 'Это скрытая группа, автоматическое добавление пользователей не разрешается';
$lang['Member_this_group'] = 'Вы член этой группы';
$lang['Pending_this_group'] = 'Вы кандидат в члены этой группы';
$lang['Are_group_moderator'] = 'Вы модератор этой группы';
$lang['None'] = 'Нет';

$lang['SUBSCRIBE'] = 'Записаться в группу';
$lang['UNSUBSCRIBE_GROUP'] = 'Выйти из группы';
$lang['VIEW_INFORMATION'] = 'Просмотреть информацию';


//
// Search
//
$lang['Search_query'] = 'Запрос';
$lang['SEARCH_OPTIONS'] = 'Параметры запроса';

$lang['SEARCH_WORDS'] = 'Ключевые слова';
$lang['SEARCH_WORDS_EXPL'] = 'Вы можете использовать <b>+</b> (знак "плюс" написанный слитно перед словом: "+слово") чтобы определить слова, которые должны быть в результатах и <b>-</b> (знак "минус") для слов, которых не должно быть. Используйте <b>*</b> в качестве шаблона для частичного совпадения.';
$lang['SEARCH_AUTHOR'] = 'Поиск по автору';
$lang['SEARCH_AUTHOR_EXPL'] = 'Используйте * в качестве шаблона';

$lang['Search_titles_only'] = 'Искать только в названиях тем';
$lang['Search_all_words'] = 'искать все слова';
$lang['Search_my_msg_only'] = 'Искать только в моих сообщениях';
$lang['IN_MY_POSTS']  = 'В моих сообщениях';
$lang['Search_my_topics'] = 'в моих темах';
$lang['New_topics'] = 'Новые темы';

$lang['Return_first'] = 'Показывать первые'; // followed by xxx characters
$lang['characters_posts'] = 'символов сообщений';

$lang['SEARCH_PREVIOUS'] = 'Время размещения'; // followed by days, weeks, months, year, all

$lang['SORT_BY'] = 'Упорядочить по';
$lang['Sort_Time'] = 'Время размещения';
$lang['Sort_Post_Subject'] = 'Заголовок сообщения';
$lang['Sort_Topic_Title'] = 'Название темы';
$lang['Sort_Author'] = 'Автор';
$lang['Sort_Forum'] = 'Форум';

$lang['DISPLAY_RESULTS_AS'] = 'Показывать результаты как';
$lang['All_available'] = 'Все имеющиеся';
$lang['Briefly'] = 'Кратко';
$lang['No_searchable_forums'] = 'У вас нет доступа к поиску ни в одном из форумов на сайте';

$lang['No_search_match'] = 'Подходящих тем или сообщений не найдено';
$lang['Found_search_match'] = 'Результатов поиска: %d'; // eg. Search found 1 match
$lang['Found_search_matches'] = 'Результатов поиска: %d'; // eg. Search found 24 matches
$lang['Too_many_search_results'] = 'По вашему запросу может быть найдено слишком много сообщений. Постарайтесь более точно сформулировать то, что вы хотите найти.';

$lang['CLOSE_WINDOW'] = 'Закрыть окно';
$lang['CLOSE'] = 'закрыть';
$lang['HIDE'] = 'спрятать';
$lang['SEARCH_TERMS'] = 'Поисковый запрос';


//
// Auth related entries
//
// Note the %s will be replaced with one of the following 'user' arrays
$lang['Sorry_auth_view'] = 'Извините, только %s могут видеть этот форум';
$lang['Sorry_auth_read'] = 'Извините, только %s могут читать сообщения в этом форуме';
$lang['Sorry_auth_post'] = 'Извините, только %s могут начинать темы в этом форуме';
$lang['Sorry_auth_reply'] = 'Извините, только %s могут отвечать на сообщения в этом форуме';
$lang['Sorry_auth_edit'] = 'Извините, только %s могут редактировать сообщения в этом форуме';
$lang['Sorry_auth_delete'] = 'Извините, только %s могут удалять сообщения в этом форуме';
$lang['Sorry_auth_vote'] = 'Извините, только %s могут голосовать в опросах этого форума';
$lang['Sorry_auth_sticky'] = 'Извините, только %s могут прилеплять темы в этом форуме';
$lang['Sorry_auth_announce'] = 'Извините, только %s могут размещать объявления в этом форуме';

// These replace the %s in the above strings
$lang['Auth_Anonymous_Users'] = '<b>гости</b>';
$lang['Auth_Registered_Users'] = '<b>зарегистрированные пользователи</b>';
$lang['Auth_Users_granted_access'] = '<b>пользователи со специальными правами доступа</b>';
//$lang['Auth_Users_granted_access'] = 'пользователи, состоящие <a class="gen" href="http://torrents.ru/forum/groupcp.php"><b>в группax</b></a>';
$lang['Auth_Moderators'] = '<b>модераторы</b>';
$lang['Auth_Administrators'] = '<b>администраторы</b>';

$lang['Not_Moderator'] = 'Вы не являетесь модератором этого форума';
$lang['Not_Authorised'] = 'Нет доступа';

$lang['You_been_banned'] = 'Вам был закрыт доступ к форуму<br />Обратитесь к вебмастеру или администратору форумов за дополнительной информацией';


//
// Online/Offline
//
$lang['Offline'] = 'Вне форума';
$lang['Online'] = 'На форуме';
$lang['Hidden'] = 'Скрыт';
$lang['On_off_status'] = 'Статус';

//
// Viewonline
//
$lang['Reg_users_zero_online'] = 'Сейчас на форуме зарегистрированных пользователей: 0 и '; // There ae 5 Registered and
$lang['Reg_users_online'] = 'Сейчас на форуме зарегистрированных пользователей: %d и '; // There ae 5 Registered and
$lang['Reg_user_online'] = 'Сейчас на форуме зарегистрированных пользователей: %d и ';
$lang['Hidden_users_zero_online'] = 'скрытых пользователей: 0'; // 6 Hidden users online
$lang['Hidden_users_online'] = 'скрытых пользователей: %d';
$lang['Hidden_user_online'] = 'скрытых пользователей: %d'; // 6 Hidden users online
$lang['Guest_users_online'] = 'Сейчас на форуме гостей: %d';
$lang['Guest_users_zero_online'] = 'Сейчас на форуме гостей: 0'; // There are 10 Guest users online
$lang['Guest_user_online'] = 'Сейчас на форуме гостей: %d';
$lang['No_users_browsing'] = 'Этот форум сейчас никто не просматривает';

$lang['ONLINE_EXPLAIN'] = 'данные за последние пять минут';

$lang['Last_updated'] = 'Последнее изменение';

$lang['Viewing_profile'] = 'Просмотр профиля';

//
// Moderator Control Panel
//
$lang['Mod_CP'] = 'Панель модерации';
$lang['Mod_CP_explain'] = 'Здесь вы можете проводить массовую модерацию этого форума. Вы можете закрывать, открывать, перемещать или удалять любое количество тем.';

$lang['SELECT'] = 'Выбрать';
$lang['DELETE'] = 'Удалить';
$lang['MOVE'] = 'Переместить';
$lang['LOCK'] = 'Закрыть';
$lang['UNLOCK'] = 'Открыть';

$lang['Topics_Removed'] = 'Выбранные темы были успешно удалены из базы данных';
$lang['Topics_Locked'] = 'Выбранные темы были закрыты';
$lang['Topics_Moved'] = 'Выбранные темы были перемещены';
$lang['Topics_Unlocked'] = 'Выбранные темы были открыты';
$lang['No_Topics_Moved'] = 'Не было перенесено ни одной темы';

$lang['Confirm_delete_topic'] = 'Вы действительно хотите удалить выбранные темы?';
$lang['Confirm_lock_topic'] = 'Вы действительно хотите закрыть выбранные темы?';
$lang['Confirm_unlock_topic'] = 'Вы действительно хотите открыть выбранные темы?';
$lang['Confirm_move_topic'] = 'Вы действительно хотите переместить выбранные темы?';

$lang['Move_to_forum'] = 'Переместить в форум';
$lang['Leave_shadow_topic'] = 'Оставить ссылку в старом форуме';

$lang['Split_Topic'] = 'Разделение темы';
$lang['Split_Topic_explain'] = 'С использованием этой формы вы можете разделить тему на две либо выбирая сообщения по одному, либо разбив по выбранному сообщению';
$lang['NEW_TOPIC_TITLE'] = 'Заголовок новой темы';
$lang['FORUM_FOR_NEW_TOPIC'] = 'Форум для новой темы';
$lang['SPLIT_POSTS'] = 'Отделить выбранные сообщения';
$lang['SPLIT_AFTER'] = 'Отделить все сообщения после выбранного';
$lang['Topic_split'] = 'Выбранная тема была успешно отделена';

$lang['Too_many_error'] = 'Вы выбрали слишком много сообщений. Вы можете выбрать только одно сообщение, чтобы отделить все сообщения после него.';

$lang['None_selected'] = 'Вы ничего не выбрали для совершения этой операции. Вернитесь назад и выберите.';
$lang['New_forum'] = 'Новый форум';

$lang['This_posts_IP'] = 'IP адрес для этого сообщения';
$lang['Other_IP_this_user'] = 'Другие IP адреса с которых писал этот пользователь';
$lang['Users_this_IP'] = 'Пользователи, писавшие с этого IP';
$lang['IP_info'] = 'Информация об IP адресе';
$lang['Lookup_IP'] = 'Посмотреть хост для IP';


//
// Timezones ... for display on each page
//
$lang['All_times'] = 'Часовой пояс: <span class="tz_time">%s</span>'; // This is followed by GMT and the timezone offset

$lang['-12'] = 'GMT - 12';
$lang['-11'] = 'GMT - 11';
$lang['-10'] = 'GMT - 10';
$lang['-9'] = 'GMT - 9';
$lang['-8'] = 'GMT - 8';
$lang['-7'] = 'GMT - 7';
$lang['-6'] = 'GMT - 6';
$lang['-5'] = 'GMT - 5';
$lang['-4'] = 'GMT - 4';
$lang['-3.5'] = 'GMT - 3:30';
$lang['-3'] = 'GMT - 3';
$lang['-2'] = 'GMT - 2';
$lang['-1'] = 'GMT - 1';
$lang['0'] = 'GMT';
$lang['1'] = 'GMT + 1';
$lang['2'] = 'GMT + 2';
$lang['3'] = 'GMT + 3';
$lang['3.5'] = 'GMT + 3:30';
$lang['4'] = 'GMT + 4';
$lang['4.5'] = 'GMT + 4:30';
$lang['5'] = 'GMT + 5';
$lang['5.5'] = 'GMT + 5:30';
$lang['6'] = 'GMT + 6';
$lang['6.5'] = 'GMT + 6:30';
$lang['7'] = 'GMT + 7';
$lang['8'] = 'GMT + 8';
$lang['9'] = 'GMT + 9';
$lang['9.5'] = 'GMT + 9:30';
$lang['10'] = 'GMT + 10';
$lang['11'] = 'GMT + 11';
$lang['12'] = 'GMT + 12';
$lang['13'] = 'GMT + 13';

// это для выпадающего меню, раньше тут ещё были города
$lang['tz']['-12'] = 'GMT - 12';
$lang['tz']['-11'] = 'GMT - 11';
$lang['tz']['-10'] = 'GMT - 10';
$lang['tz']['-9'] = 'GMT - 9';
$lang['tz']['-8'] = 'GMT - 8';
$lang['tz']['-7'] = 'GMT - 7';
$lang['tz']['-6'] = 'GMT - 6';
$lang['tz']['-5'] = 'GMT - 5';
$lang['tz']['-4'] = 'GMT - 4';
$lang['tz']['-3.5'] = 'GMT - 3:30';
$lang['tz']['-3'] = 'GMT - 3';
$lang['tz']['-2'] = 'GMT - 2';
$lang['tz']['-1'] = 'GMT - 1';
$lang['tz']['0'] = 'GMT (время по Гринвичу)';
$lang['tz']['1'] = 'GMT + 1';
$lang['tz']['2'] = 'GMT + 2';
$lang['tz']['3'] = 'GMT + 3 (зимнее московское время)';
$lang['tz']['3.5'] = 'GMT + 3:30';
$lang['tz']['4'] = 'GMT + 4 (летнее московское время)';
$lang['tz']['4.5'] = 'GMT + 4:30';
$lang['tz']['5'] = 'GMT + 5';
$lang['tz']['5.5'] = 'GMT + 5:30';
$lang['tz']['6'] = 'GMT + 6';
$lang['tz']['6.5'] = 'GMT + 6:30';
$lang['tz']['7'] = 'GMT + 7';
$lang['tz']['8'] = 'GMT + 8';
$lang['tz']['9'] = 'GMT + 9';
$lang['tz']['9.5'] = 'GMT + 9:30';
$lang['tz']['10'] = 'GMT + 10';
$lang['tz']['11'] = 'GMT + 11';
$lang['tz']['12'] = 'GMT + 12';
$lang['tz']['13'] = 'GMT + 13';

$lang['datetime']['Sunday'] = 'Воскресенье';
$lang['datetime']['Monday'] = 'Понедельник';
$lang['datetime']['Tuesday'] = 'Вторник';
$lang['datetime']['Wednesday'] = 'Среда';
$lang['datetime']['Thursday'] = 'Четверг';
$lang['datetime']['Friday'] = 'Пятница';
$lang['datetime']['Saturday'] = 'Суббота';
$lang['datetime']['Sun'] = 'Вс';
$lang['datetime']['Mon'] = 'Пн';
$lang['datetime']['Tue'] = 'Вт';
$lang['datetime']['Wed'] = 'Ср';
$lang['datetime']['Thu'] = 'Чт';
$lang['datetime']['Fri'] = 'Пт';
$lang['datetime']['Sat'] = 'Сб';
$lang['datetime']['January'] = 'Январь';
$lang['datetime']['February'] = 'Февраль';
$lang['datetime']['March'] = 'Март';
$lang['datetime']['April'] = 'Апрель';
$lang['datetime']['May'] = 'Май';
$lang['datetime']['June'] = 'Июнь';
$lang['datetime']['July'] = 'Июль';
$lang['datetime']['August'] = 'Август';
$lang['datetime']['September'] = 'Сентябрь';
$lang['datetime']['October'] = 'Октябрь';
$lang['datetime']['November'] = 'Ноябрь';
$lang['datetime']['December'] = 'Декабрь';
$lang['datetime']['Jan'] = 'Янв';
$lang['datetime']['Feb'] = 'Фев';
$lang['datetime']['Mar'] = 'Мар';
$lang['datetime']['Apr'] = 'Апр';
$lang['datetime']['May'] = 'Май';
$lang['datetime']['Jun'] = 'Июн';
$lang['datetime']['Jul'] = 'Июл';
$lang['datetime']['Aug'] = 'Авг';
$lang['datetime']['Sep'] = 'Сен';
$lang['datetime']['Oct'] = 'Окт';
$lang['datetime']['Nov'] = 'Ноя';
$lang['datetime']['Dec'] = 'Дек';

//
// Errors (not related to a
// specific failure on a page)
//
$lang['INFORMATION'] = 'Информация';
$lang['Critical_Information'] = 'Критическая информация';

$lang['General_Error'] = 'Ошибка';
$lang['Critical_Error'] = 'Критическая ошибка';
$lang['An_error_occured'] = 'Произошла ошибка';
$lang['A_critical_error'] = 'Произошла критическая ошибка';

$lang['Admin_reauthenticate'] = 'Чтобы получить доступ к админ/мод панели, Вам необходимо еще раз ввести пароль.';
$lang['Login_attempts_exceeded'] = 'The maximum number of %s login attempts has been exceeded. You are not allowed to login for the next %s minutes.';
$lang['Please_remove_install_contrib'] = 'Please ensure both the install/ and contrib/ directories are deleted';

//
// Attachment Mod Main Language Variables
//

// Auth Related Entries
$lang['Rules_attach_can'] = 'Вы <b>можете</b> прикреплять файлы к сообщениям';
$lang['Rules_attach_cannot'] = 'Вы <b>не можете</b> прикреплять файлы к сообщениям';
$lang['Rules_download_can'] = 'Вы <b>можете</b> скачивать файлы';
$lang['Rules_download_cannot'] = 'Вы <b>не можете</b> скачивать файлы';
$lang['Sorry_auth_view_attach'] = 'Вы <b>не можете</b> просматривать или скачивать файлы';

// Viewtopic -> Display of Attachments
$lang['Description'] = 'Описание'; // used in Administration Panel too...
$lang['Download'] = 'Скачать'; // this Language Variable is defined in lang_admin.php too, but we are unable to access it from the main Language File
$lang['FILELIST'] = 'Список файлов';
$lang['COLLAPSE'] = 'Свернуть директории';
$lang['EXPAND'] = 'Развернуть';
$lang['SWITCH'] = 'Переключить';
$lang['Filesize'] = 'Размер';
$lang['VIEWED'] = 'Просмотров';
$lang['Download_number'] = '%d раз'; // replace %d with count
$lang['Extension_disabled_after_posting'] = 'Расширение \'%s\' было деактивировано администратором форума, поэтому это вложение не отображается.'; // used in Posts and PM's, replace %s with mime type

// Posting/PM -> Posting Attachments
$lang['Add_attachment'] = 'Прикрепить файл';
$lang['Add_attachment_title'] = 'Прикрепить файл';
$lang['Add_attachment_explain'] = 'Если вы не хотите прикреплять файл, оставьте это поле пустым';
$lang['File_name'] = 'Имя файла';
$lang['File_comment'] = 'Комментарий';

// Posting/PM -> Posted Attachments
$lang['Posted_attachments'] = 'Прикрепленные файлы';
$lang['Update_comment'] = 'Обновить комментарий';
$lang['Delete_attachments'] = 'Удалить файлы';
$lang['Delete_attachment'] = 'Удалить файл';
$lang['Delete_thumbnail'] = 'Удалить пиктограмму';
$lang['Upload_new_version'] = 'Загрузить новую версию';

// Errors -> Posting Attachments
$lang['Invalid_filename'] = '%s - неправильное имя файла'; // replace %s with given filename
$lang['Attachment_php_size_na'] = 'Вложение слишком велико.<br />Невозможно превышать ограничение установленное в PHP.<br />Attachment Mod не может определить максимальный размер закачиваемых файлов, определенный в php.ini.';
$lang['Attachment_php_size_overrun'] = 'Вложение слишком велико.<br />Максимальный размер закачиваемого файла: %d MB.<br />Отметьте, что эта величина определена в php.ini и Attachment Mod не может изменить это значение в большую сторону.'; // replace %d with ini_get('upload_max_filesize')
$lang['Disallowed_extension'] = 'Расширение %s запрещено администратором'; // replace %s with extension (e.g. .php)
$lang['Disallowed_extension_within_forum'] = 'Вы не можете публиковать файлы с расширением %s в этом форуме'; // replace %s with the Extension
$lang['Attachment_too_big'] = 'Вложение слишком велико.<br/>Максимальный размер: %d %s'; // replace %d with maximum file size, %s with size var
$lang['Attach_quota_reached'] = 'Достигнут максимальный общий размер ваших вложений. Пожалуйста, обратитесь к администратору по интересующим вас вопросам.';
$lang['Too_many_attachments'] = 'Вложение невозможно, так как максимальное количество (%d) вложений в этом сообщении достигнуто.'; // replace %d with maximum number of attachments
$lang['Error_imagesize'] = 'Изображение должно быть меньше, чем %d пикселей в ширину и %d пикселей в высоту.';
$lang['General_upload_error'] = 'Ошибка закачки: Невозможно закачать вложение в %s.'; // replace %s with local path

$lang['Error_empty_add_attachbox'] = 'Вы должны указать "Имя Файла" в форме "Прикрепить файл"';
$lang['Error_missing_old_entry'] = 'Невозможно обновить вложение, старое вложение не обнаружено';

// Errors -> PM Related
$lang['Attach_quota_sender_pm_reached'] = 'К сожалению, вы достигли максимального общего объема закачанных файлов в папке ЛС. Пожалуйста, удалите часть принятых/отправленных вложений.';
$lang['Attach_quota_receiver_pm_reached'] = 'К сожалению, \'%s\' достиг(ла) максимального общего объема закачанных файлов в папке ЛС. Пожалуйста, сообщите ему(ей) или подождите удаления некоторых из вложений.';

// Errors -> Download
$lang['No_attachment_selected'] = 'Вы не выделили вложений для скачивания или просмотра.';
$lang['Error_no_attachment'] = 'Выделенных вложений больше не существует.';

// Delete Attachments
$lang['Confirm_delete_attachments'] = 'Вы уверены, что хотите удалить выделенные вложения?';
$lang['Deleted_attachments'] = 'Выделенные вложения удалены.';
$lang['Error_deleted_attachments'] = 'Невозможно удалить вложения.';
$lang['Confirm_delete_pm_attachments'] = 'Вы уверены, что хотите удалить все вложения в этом ЛС?';

// General Error Messages
$lang['Attachment_feature_disabled'] = 'Функция вложений выключена.';

$lang['Directory_does_not_exist'] = 'Директория \'%s\' не существует или не может быть найдена.'; // replace %s with directory
$lang['Directory_is_not_a_dir'] = 'Пожалуйста, проверьте является ли \'%s\' директорией.'; // replace %s with directory
$lang['Directory_not_writeable'] = 'Директория \'%s\' недоступна для записи. Вам нужно создать директорию для закачек и выполнить chmod 777 (или изменить владельца httpd-servers) для закачки фалов на сервер.<br />Если у вас только FTP доступ к серверу измените \'Атрибуты\' директории на rwxrwxrwx.'; // replace %s with directory

$lang['Ftp_error_connect'] = 'Невозможно соединиться с FTP сервером: \'%s\'. Пожалуйста, проверьте ваши настройки FTP.';
$lang['Ftp_error_login'] = 'Невозможно зайти на FTP сервер. Имя пользователя \'%s\' иои пароль неверны. Пожалуйста, проверьте ваши настройки FTP.';
$lang['Ftp_error_path'] = 'Нет доступа к директории: \'%s\'. Пожалуйста, проверьте ваши настройки FTP.';
$lang['Ftp_error_upload'] = 'Невозможно записать файлы в директорию: \'%s\'. Пожалуйста, проверьте ваши настройки FTP.';
$lang['Ftp_error_delete'] = 'Невозможно удалить файлы в директории: \'%s\'. Пожалуйста, проверьте ваши настройки FTP.<br />Другой причиной этой ошибки может быть отсутствие файла, проверьте сначала скрытые вложения.';
$lang['Ftp_error_pasv_mode'] = 'Невозможно включить/отключить пассивный режим';

// Attach Rules Window
$lang['Rules_page'] = 'Правила вложений';
$lang['Attach_rules_title'] = 'Разрешенные группы расширений и их размер';
$lang['Group_rule_header'] = '%s -> Максимальный общий размер: %s'; // Replace first %s with Extension Group, second one with the Size STRING
$lang['Allowed_extensions_and_sizes'] = 'Разрешенные расширения и их размер';
$lang['Note_user_empty_group_permissions'] = 'ВНИМАНИЕ:<br />Вы можете отправлять вложения в этот форум, <br />но так как ни одной группе расширений не разрешено быть вложенной здесь, <br />вы не можете ничего отправить. Если вы попытаетесь, <br />то получите сообщение об ошибке.<br />';

// Quota Variables
$lang['UPLOAD_QUOTA'] = 'Квота';
$lang['PM_QUOTA'] = 'Квота ЛС';
$lang['User_upload_quota_reached'] = 'К сожалению, вы достигли максимального общего объема закачанных файлов - %d %s'; // replace %d with Size, %s with Size Lang (MB for example)

// User Attachment Control Panel
$lang['User_acp_title'] = 'Управление вложениями';//'Панель управления вложениями пользователя';
$lang['UACP'] = 'Управление вложениями';
$lang['User_uploaded_profile'] = 'Закачано: %s';
$lang['User_quota_profile'] = 'Квота: %s';
$lang['Upload_percent_profile'] = '%d%% от общего';

// Common Variables
$lang['Bytes'] = 'Байт';
$lang['KB'] = 'KB';
$lang['MB'] = 'MB';
$lang['Attach_search_query'] = 'Поиск вложений';
$lang['Test_settings'] = 'Проверить настройки';
$lang['Not_assigned'] = 'Не назначено';
$lang['No_file_comment_available'] = 'Комментарий недоступен';
$lang['Attachbox_limit'] = 'Ваш ящик вложений заполнен на %d%%';
$lang['No_quota_limit'] = 'Квота отсутствует';
$lang['Unlimited'] = 'Без ограничений';

//bt
$lang['Bt_Reg_YES'] = 'Зарегистрирован';
$lang['Bt_Reg_NO'] = 'Не зарегистрирован';
$lang['Bt_Added'] = 'Добавлен';
$lang['Bt_Reg_on_tracker'] = 'Зарегистрировать торрент';
$lang['Bt_Reg_fail'] = 'Не удалось зарегистрировать торент на трекере';
$lang['Bt_Reg_fail_same_hash'] = 'Другой торент с таким же info_hash уже <a href="%s"><b>зарегистрирован</b></a>';
$lang['Bt_Unreg_from_tracker'] = 'Разрегистрировать торрент';
$lang['Bt_Deleted'] = 'Торрент разрегистрирован';
$lang['Bt_Registered'] = 'Торент зарегистрирован на трекере<br /><br />Теперь вам <a href="%s"><b>нужно его скачать</b></a> и поставить на закачку у самого себя в ту же директорию, где лежат оригинальные файлы';
$lang['Invalid_ann_url'] = 'Неправильный Аnnounce URL [%s]<br /><br />должен быть <b>%s</b>';
$lang['Passkey_err_tor_not_reg'] = 'Невозможно добавить passkey<br /><br />Торрент не зарегистрирован на трекере';
$lang['Passkey_err_empty'] = 'Невозможно добавить passkey<br /><br />Вам необходимо <a href="%s" target="_blank"><b>зайти в ваш форумный профиль</b></a> и сгенерировать passkey';
$lang['Bt_Gen_Passkey'] = 'Passkey';
$lang['Bt_Gen_Passkey_Url'] = 'Создать или изменить Passkey';
$lang['Bt_Gen_Passkey_Explain'] = 'Сгенерировать ваш личный id, который будет добавляться в торент-файлы во время скачивания и затем использоваться трекером в качестве вашего аутентификатора.';
$lang['Bt_Gen_Passkey_Explain_2'] = '<b>Внимание!</b> После изменения или создания нового id вам будет необходимо <b>заново скачать все активные торенты!</b>';
$lang['Bt_Gen_Passkey_OK'] = 'Новый персональный идентификатор сгенерирован';
$lang['Bt_No_searchable_forums'] = 'Доступных для поиска форумов не найдено';

$lang['SEEDERS'] = 'Сидов';
$lang['LEECHERS'] = 'Личеров';
$lang['Releasing'] = 'Свои';
$lang['Seeding'] = 'Раздает';
$lang['Leeching'] = 'Качает';
$lang['IS_REGISTERED'] = 'Зарегистрирован';
$lang['MAGNET'] = 'Magnet';
$lang['CALLSEED'] = 'Позвать скачавших';

//torrent status mod
$lang['TOR_STATUS'] = 'Статус';
$lang['TOR_STATUS_SELECT_ACTION'] = 'Выберите статус';
$lang['TOR_STATUS_CHECKED'] = 'проверено'; // 2
$lang['TOR_STATUS_NOT_CHECKED'] = 'не проверено';//0
$lang['TOR_STATUS_CLOSED'] = 'закрыто';//1
$lang['TOR_STATUS_D'] = 'повтор';//3
$lang['TOR_STATUS_NOT_PERFECT'] = 'неоформлено';//4
$lang['TOR_STATUS_PART_PERFECT'] = 'недооформлено';//5
$lang['TOR_STATUS_FISHILY'] = 'сомнительно';//6
$lang['TOR_STATUS_COPY'] = 'закрыто правообладателем';//7
//end torrent status mod

$lang['Bt_Topic_Title'] = 'Название темы';
$lang['Bt_Seeder_last_seen'] = 'Последний seeder';
$lang['Bt_Sort_Forum'] = 'Форум';
$lang['SIZE'] = 'Размер';
$lang['PIECE_LENGTH'] = 'Размер блока';
$lang['COMPLETED'] = 'Скачан';
$lang['ADDED'] = 'Добавлен';
$lang['DELETE_TORRENT'] = 'Удалить торент';
$lang['DEL_MOVE_TORRENT'] = 'Удалить и перенести топик';
$lang['DL_TORRENT'] = 'Скачать .torrent';
$lang['Bt_Last_post'] = 'Посл. сообщение';
$lang['Bt_Created'] = 'Время создания топика';
$lang['Bt_Replies'] = 'Сообщения';
$lang['Bt_Views'] = 'Просмотры';
$lang['FREEZE_TORRENT'] = 'Запретить скачивание';
$lang['UNFREEZE_TORRENT'] = 'Разрешить скачивание';

// Gold/Silver releases
$lang['GOLD'] = 'Золото';
$lang['SILVER'] = 'Серебро';
$lang['SET_GOLD_TORRENT'] = 'Сделать золотым';
$lang['UNSET_GOLD_TORRENT'] = 'Снять золото';
$lang['SET_SILVER_TORRENT'] = 'Сделать серебряным';
$lang['UNSET_SILVER_TORRENT'] = 'Снять серебро';
$lang['GOLD_STATUS'] = 'ЗОЛОТАЯ РАЗДАЧА! СКАЧАННОЕ НЕ ЗАСЧИТЫВАЕТСЯ!';
$lang['SILVER_STATUS'] = 'СЕРЕБРЯНАЯ РАЗДАЧА! СКАЧАННОЕ ЗАСЧИТЫВАЕТСЯ ТОЛЬКО НАПОЛОВИНУ!';
// End - Gold/Silver releases

$lang['SEARCH_IN_FORUMS'] = 'Искать в форумах';
$lang['SELECT_CAT']    = 'Выбрать категорию...';
$lang['GO_TO_SECTION'] = 'перейти к разделу';
$lang['TORRENTS_FROM'] = 'Торенты за';
$lang['SHOW_ONLY'] = 'Показывать только';
$lang['SHOW_COLUMN'] = 'Показывать колонку';

$lang['Bt_Only_Active'] = 'Активные (есть seeder или leecher)';
$lang['Bt_Only_My'] = 'Мои раздачи';
$lang['Bt_Seed_exist'] = 'Есть seeder (полный источник)';
$lang['Bt_Only_New'] = 'Новые с последнего посещения';
$lang['Bt_Show_Cat'] = 'Категория';
$lang['Bt_Show_Forum'] = 'Форум';
$lang['Bt_Show_Author'] = 'Автор';
$lang['Bt_Show_Speed'] = 'Скорость';
$lang['SEED_NOT_SEEN'] = 'Источника не было';
$lang['TITLE_MATCH'] = 'Название содержит';
$lang['Bt_User_not_found'] = 'не найден';
$lang['DL_SPEED'] = 'Общая скорость скачивания';

$lang['Bt_Disregard'] = 'не учитывать';
$lang['Bt_Never'] = 'никогда';
$lang['Bt_All_Days_for'] = 'за все время';
$lang['Bt_1_Day_for']    = 'за сегодня';
$lang['Bt_3_Day_for']    = 'последние 3 дня';
$lang['Bt_7_Days_for']   = 'посл. неделю';
$lang['Bt_2_Weeks_for']  = 'посл. 2 недели';
$lang['Bt_1_Month_for']  = 'последний месяц';
$lang['Bt_1_Day']    = 'день';
$lang['Bt_3_Days']    = '3 дня';
$lang['Bt_7_Days']   = 'неделю';
$lang['Bt_2_Weeks']  = '2 недели';
$lang['Bt_1_Month']  = 'месяц';

$lang['DL_LIST_AND_TORRENT_ACTIVITY'] = 'Статистика раздачи';
$lang['DL_WILL'] = 'Буду качать';
$lang['DL_DOWN'] = 'Качаю';
$lang['DL_COMPLETE'] = 'Скачал';
$lang['DL_CANCEL'] = 'Отмена';

$lang['dlWill_2'] = 'Будут качать';
$lang['dlDown_2'] = 'Качают';
$lang['dlComplete_2'] = 'Скачали';
$lang['dlCancel_2'] = 'Отмена';

$lang['DL_List_Del'] = 'Очистить DL-List';
$lang['DL_List_Del_Confirm'] = 'Вы уверены, что хотите удалить DL-List для этого топика?';
$lang['SHOW_DL_LIST'] = 'Список скачавших';
$lang['Set_DL_Status'] = 'Download';
$lang['Unset_DL_Status'] = 'Not Download';
$lang['Topics_Down_Sets'] = 'Выбранные темы изменили статус на: <b>Download</b>';
$lang['Topics_Down_Unsets'] = 'Выбранные темы перестали быть <b>Download</b>';

$lang['Topic_DL'] = 'DL';

$lang['MY_DOWNLOADS'] = 'Мои закачки';
$lang['SEARCH_DL_WILL'] = 'Будущие';
$lang['SEARCH_DL_WILL_DOWNLOADS'] = 'Будущие закачки';
$lang['SEARCH_DL_DOWN'] = 'Текущие';
$lang['SEARCH_DL_COMPLETE'] = 'Прошлые';
$lang['SEARCH_DL_COMPLETE_DOWNLOADS']   = 'Прошлые закачки';
$lang['SEARCH_DL_CANCEL'] = 'Отмененные';
$lang['CUR_DOWNLOADS'] = 'Текущие закачки';
$lang['CUR_UPLOADS']   = 'Текущие раздачи';
$lang['Search_user_releases'] = 'Найти все текущие раздачи';
$lang['TOR_SEARCH_TITLE'] = 'Опции показа торентов';
$lang['OPEN_TOPIC'] = 'Открыть топик';

$lang['Allowed_only_1st_post_attach'] = 'Вы можете прикреплять торрент-файлы только к первому сообщению в теме';
$lang['Allowed_only_1st_post_reg'] = 'Вы можете регистрировать торрент-файлы на трекере только из первого сообщения в теме';
$lang['Reg_not_allowed_in_this_forum'] = 'В этом форуме регистрация торрентов на трекере запрещена';
$lang['Already_reg'] = 'Торрент уже зарегистрирован';
$lang['Not_torrent'] = 'Это не торрент-файл';
$lang['Only_1_tor_per_post'] = 'Вы не можете зарегистрировать еще один торрент для этого сообщения';
$lang['Only_1_tor_per_topic'] = 'Вы не можете зарегистрировать еще один торрент для этого топика';
$lang['Viewing_user_bt_profile'] = 'Torrent-профиль пользователя %s'; // %s is username
$lang['Cur_active_dls'] = 'Текущие активные torrent\'ы';
$lang['View_torrent_profile'] = 'Torrent-профиль';
$lang['RATIO_FAQ'] = 'FAQ по рейтингу';

$lang['Profile_up_total'] = 'Всего отдано';
$lang['Profile_down_total'] = 'Всего скачано';
$lang['Profile_Bonus'] = 'Бонус';
$lang['Profile_released'] = 'Отдано на своих раздачах';
$lang['Profile_Ratio'] = 'Рейтинг';
$lang['Profile_max_speed'] = 'Скорость';
$lang['Profile_it_will_be_downloaded'] = 'начнет учитываться после того как будет скачано';

$lang['SPMODE_FULL'] = 'Подробная статистика пиров';
$lang['Curr_passkey'] = 'Текущий passkey:';

$lang['BT_RATIO'] = 'Рейтинг';
$lang['YOUR_RATIO'] = 'Ваш рейтинг';
$lang['DOWNLOADED'] = 'Скачано';
$lang['UPLOADED'] = 'Отдано';
$lang['RELEASED'] = 'на своих';
$lang['BT_BONUS_UP'] = 'бонус';
$lang['BT_LAST_UPDATE'] = 'Посл.обновл.';
$lang['BT_TODAY'] = 'Сегодня';
$lang['BT_YESTERDAY'] = 'Вчера';
$lang['BT_COUNTED'] = 'Всего учтено';

$lang['TRACKER'] = 'Трекер';
$lang['GALLERY'] = 'Галерея';
$lang['OPEN_TOPICS'] = 'Открывать топики';
$lang['OPEN_IN_SAME_WINDOW'] = 'открывать в этом же окне';

$lang['Bt_Low_ratio_func'] = 'У Вас слишком низкий рейтинг для того, чтобы воспользоваться этой функцией';
$lang['Bt_Low_ratio_for_dl'] = 'Рейтинг <b>%s</b> уже не позволяет Вам скачивать новые торренты.<br /><br />Для поднятия рейтинга, Вы можете что-либо раздать из <a href="%s"><b>Ваших прошлых закачек</b></a>, либо организовать новую раздачу.<br /><br /><b>Пожалуйста, помните о том, что Ваше участие в системе BitTorrent не может ограничиваться только скачиванием!</b>';
$lang['bt_ratio_warning_msg'] = 'Если ваш рейтинг упадёт ниже %s, Вы не сможете скачивать торренты ! <a href="%s"><b>Подробнее о рейтинге.</b></a>';

$lang['Seeder_last_seen'] = 'Полного источника не было: <b>%s</b>';

//
// MAIL.RU Keyboard
//
$lang['kb_title'] = 'Русская клавиатура';
$lang['kb_rus_keylayout'] = 'Раскладка: ';
$lang['kb_none'] = 'Отсутствует';
$lang['kb_translit'] = 'Транслит';
$lang['kb_traditional'] = 'Традиционная';
$lang['kb_rules'] = 'Правила набора';
$lang['kb_show'] = 'Показать клавиатуру';
$lang['kb_about'] = 'О клавиатуре';
$lang['kb_close'] = 'Закрыть';
$lang['kb_translit_mozilla'] = 'Выберите текст, который вы хотите для перевода в транслит, и нажмите кнопку \'Транслит\'.';
$lang['kb_translit_opera7'] = 'Нажмите здесь для перевода вашего сообщения в транслит.';

$lang['Need_to_login_first'] = 'Вы должны авторизоваться на форуме';
$lang['Only_for_mod'] = 'Эта опция доступна только модераторам';
$lang['Only_for_admin'] = 'Эта опция доступна только администраторам';
$lang['Only_for_super_admin'] = 'Эта опция доступна только супер администраторам';

$lang['Access'] = 'Доступ';
$lang['Access_srv_load'] = 'Зависит от загрузки сервера';

$lang['last_ip'] = 'Последний IP:';
$lang['reg_ip']  = 'IP регистрации:';
$lang['last_ip_users'] = 'Другие пользователи, зашедшие с этого IP:';
$lang['reg_ip_users']  = 'Другие пользователи, зарегистрировавшиеся с этого IP:';
$lang['already_reg']   = 'С вашего IP-адреса уже зарегистрирован пользователь %s. Если Вы ранее не регистрировались на нашем трекере, обратитесь к <a href="mailto:%s">Администрации</a>';

//
// That's all, Folks!
// -------------------------------------------------

// from lang_admin
$lang['Not_admin'] = 'У вас нет прав на администрирование';

$lang['COOKIES_REQUIRED'] = 'Куки должны быть включены!';
$lang['Session_Expired'] = 'Сессия устарела';

// FLAGHACK-start
$lang['Country_Flag'] = 'Флаг страны';
$lang['Select_Country'] = 'ВЫБЕРИТЕ СТРАНУ' ;
// FLAGHACK-end

// Sort memberlist per letter
$lang['Sort_per_letter'] = 'Имя начинается с буквы';
$lang['Others'] = 'другие';
$lang['All'] = 'все';

$lang['POST_LINK'] = 'Линк на это сообщение';
$lang['LAST_VISITED'] = 'Последний визит';
$lang['LAST_ACTIVITY'] = 'Последняя активность';
$lang['Never'] = 'Никогда';

//mpd
$lang['DELETE_POSTS'] = 'Удалить сообщения';
$lang['Delete_posts_succesfully'] = 'Выбранные сообщения были успешно удалены';
//mpd end

//ts
$lang['Topics_Announcement'] = 'Объявления';
$lang['Topics_Sticky'] = 'Прилеплены';
$lang['Topics_Normal'] = 'Топики';
//ts end

//dpc
$lang['Double_Post_Error'] = 'Вы не можете отправить подряд два одинаковых сообщения';
//dpc end

//upt
$lang['Update_post_time'] = 'Обновить время сообщения';
//upt end

$lang['Topic_split_new'] = 'Новая тема';
$lang['Topic_split_old'] = 'Старая тема';
$lang['Bot_leave_msg_moved'] = 'Оставить сообщение о переносе';
$lang['BOT_AFTER_SPLIT_TO_OLD'] = 'Оставить сообщение о разделении <b>в старой теме</b>';
$lang['BOT_AFTER_SPLIT_TO_NEW'] = 'Добавить сообщение о разделении <b>в новую тему</b>';
//qr
$lang['QUICK_REPLY'] = 'Быстрый ответ';
$lang['INS_NAME_TIP'] = 'Вставить имя или выделенный кусок сообщения.';
$lang['QUOTE_SELECTED'] = 'Цитировать выделенный текст';
$lang['TRANSLIT_RULES'] = 'Правила транслита';
$lang['QR_ATTACHSIG'] = 'Присоединить подпись';
$lang['QR_NOTIFY'] = 'Уведомлять об ответах';
$lang['QR_DISABLE'] = 'Отключить';
$lang['QR_USERNAME'] = 'Имя';
$lang['No_Text_Sel'] = 'Нет выделенного текста';
$lang['QR_Font_sel'] = 'Шрифт';
$lang['QR_Color_sel'] = 'Цвет шрифта';
$lang['QR_Size_sel'] = 'Размер шрифта';
$lang['color_steel_blue'] = 'Тёмно-Голубой';
$lang['color_gray'] = 'Серый';
$lang['color_dark_green'] = 'Тёмно-Зелёный';
//qr end

//Online/Offline
$lang['Icon_offline_txtb'] = '[OFF]';
$lang['Icon_hidden_txtb'] = '[HID]';
$lang['Icon_online_txtb'] = '[ON]';
//Online/Offline end

//txtb
$lang['ICQ_txtb'] = '[ICQ]';
$lang['AIM_txtb'] = '[AIM]';
$lang['MSNM_txtb'] = '[MSN]';
$lang['MAGENT_txtb'] = '[Агент Mail.ru]';
$lang['YIM_txtb'] = '[Yahoo]';
$lang['Reply_with_quote_txtb'] = '[Цитировать]';
$lang['Read_profile_txtb'] = '[Профиль]';
$lang['Send_email_txtb'] = '[E-mail]';
$lang['Visit_website_txtb'] = '[www]';
$lang['Edit_delete_post_txtb'] = '[Изменить]';
$lang['Search_user_posts_txtb'] = '[Поиск]';
$lang['View_IP_txtb'] = '[ip]';
$lang['Delete_post_txtb'] = '[x]';
$lang['Moderate_post_txtb'] = '[m]';
$lang['Send_pm_txtb'] = '[ЛС]';
//txtb end

$lang['declension']['replies'] = array('ответ', 'ответа', 'ответов');
$lang['declension']['times'] = array('раз', 'раза', 'раз');

$lang['delta_time']['intervals'] = array(
	'seconds' => array('секунда', 'секунды', 'секунд'),
	'minutes' => array('минута',  'минуты',  'минут'),
	'hours'   => array('час',     'часа',    'часов'),
	'mday'    => array('день',    'дня',     'дней'),
	'mon'     => array('месяц',   'месяца',  'месяцев'),
	'year'    => array('год',     'года',    'лет'),
);
$lang['delta_time']['format'] = '%1$s %2$s';  // 5(%1) минут(%2)

$lang['auth_types'][AUTH_ALL]   = $lang['Auth_Anonymous_Users'];
$lang['auth_types'][AUTH_REG]   = $lang['Auth_Registered_Users'];
$lang['auth_types'][AUTH_ACL]   = $lang['Auth_Users_granted_access'];
$lang['auth_types'][AUTH_MOD]   = $lang['Auth_Moderators'];
$lang['auth_types'][AUTH_ADMIN] = $lang['Auth_Administrators'];

$lang['new_user_reg_disabled'] = 'Регистрация новых пользователей временно отключена';
$lang['ONLY_NEW_POSTS'] = 'только новые сообщения';
$lang['ONLY_NEW_TOPICS'] = 'только новые темы';

$lang['TORHELP_TITLE'] = 'Этим раздачам необходима ваша помощь!';

$lang['LAST_ADDED'] = 'Новые торренты';
$lang['TOP_DOWNLOADED'] = 'Самые скачиваемые';
$lang['TOP_SEEDERS'] = "Топ {$bb_cfg['t_top_uploaders']} сидеров";
$lang['TOP_LEECHERS'] = "Топ {$bb_cfg['t_top_downloaders']} личеров";
$lang['LAST_TIMES'] = ' раз';

//
// Reports
//
$lang['Reports'] = 'Нарушения';
$lang['New_report'] = ': одно открыто';
$lang['New_reports'] = ': %d открыто';
$lang['No_new_reports'] = ': нет открытых';
$lang['Report_index'] = 'Полный список нарушений';
$lang['Statistics'] = 'Статистика';
$lang['Statistic'] = 'Параметр';
$lang['Value'] = 'Значение';
$lang['Report_count'] = 'Текущее число сообщений';
$lang['Report_modules_count'] = 'Число модулей';
$lang['Report_hack_count'] = 'Общее число сообщений';
$lang['Deleted_reports'] = 'Сообщения, отмеченные для удаления';
$lang['Report_type'] = 'Тип сообщения';
$lang['Report_by'] = 'от';
$lang['No_reports'] = 'Нет сообщений';
$lang['Invert_select'] = 'Обратить выделение';
$lang['Reported_by'] = 'Сообщение от';
$lang['Reported_time'] = 'Дата сообщения';
$lang['Status'] = 'Статус';
$lang['Last_changed_by'] = 'Последнее изменение';
$lang['Changes'] = 'Изменения';
$lang['Report_change_text'] = 'Отмечено как "%1$s" пользователем %2$s в %3$s.';
$lang['Report_change_text_comment'] = 'Отмечено как "%1$s" пользователем %2$s в %3$s:<br />%4$s';
$lang['Report_change_delete_text'] = 'Отмечено для удаления пользователем %1$s в %2$s.';
$lang['Action'] = 'Действие';
$lang['Report_mark'] = 'Отметить как';
$lang['Open_reports'] = 'открытые сообщения';
$lang['No_reports_found'] = 'Подходящих сообщений не найдено.';
$lang['No_reports_selected'] = 'Не было выделено ни одного сообщения.';
$lang['Report_not_exists'] = 'Выбранное сообщение не существует.';
$lang['Report_not_supported'] = 'Данная опция не поддерживается.';
$lang['Click_return_report'] = '%sНажмите%s для возврата к сообщению.';
$lang['Click_return_report_list'] = '%sНажмите%s для возврата к списку сообщений.';

$lang['Report_status'] = array(
	REPORT_NEW => 'Новое',
	REPORT_OPEN => 'Открыто',
	REPORT_IN_PROCESS => 'В обработке',
	REPORT_CLEARED => 'Закрыто',
	REPORT_DELETE => 'Отмечено для удаления');

$lang['Reason'] = 'Причина';
$lang['Report_subject'] = 'Тема';
$lang['Report_title_empty'] = 'Необходимо ввести заголовок сообщения.';
$lang['Report_desc_empty'] = 'Необходимо ввести сообщение.';
$lang['Report_inserted'] = 'Сообщение было отправлено администрации.';

$lang['Change_report'] = 'Изменить сообщение';
$lang['Change_reports'] = 'Изменить сообщения';
$lang['Change_report_explain'] = 'Вы уверены, что хотите изменить статус выбранного сообщения?';
$lang['Change_reports_explain'] = 'Вы уверены, что хотите изменить статус выбранных сообщений?';
$lang['Comment'] = 'Комментарий';
$lang['Report_changed'] = 'Статус выбранного сообщения был изменен.';
$lang['Reports_changed'] = 'Статус выбранных сообщений был изменен.';

$lang['Delete_report'] = 'Удалить сообщение';
$lang['Delete_reports'] = 'Удалить сообщения';
$lang['Delete_report_explain'] = 'Вы уверены, что хотите удалить выбранное сообщение?';
$lang['Delete_reports_explain'] = 'Вы уверены, что хотите удалить выбранные сообщения?';
$lang['Report_deleted'] = 'Выбранное сообщение удалено.';
$lang['Reports_deleted'] = 'Выбранные сообщения удалены.';
//
// Reports [END]
//

// Medal [BEGIN]
$lang['MEDAL'] = 'Доска почета';
$lang['TOP_10'] = 'Десятка лучших';
$lang['TOP_10_RATIO'] = 'по Upload/Download Ratio';
$lang['TOP_10_SIZE_DOWNLOAD'] = 'по объему загруженного';
$lang['BEST_RELIZER'] = 'Десятка лучших';
$lang['BEST_RELEASES'] = 'Лучшие раздачи';
$lang['DOWNLOAD_MONTH'] = 'Скачивания релизов за месяц';
$lang['THANKS_MONTH'] = 'Благодарности релизов за месяц';
$lang['BEST_RELEASES_MONTH'] = 'Лучшие релизы за месяц';
$lang['BEST_RELEASES_WEEK'] = 'Лучшие релизы за неделю';
$lang['THANKS'] = 'Спасибо';
$lang['RELEASES'] = 'Релизов';
$lang['AVERAGE_RATING'] = 'Ср. оценка';
$lang['BEST_COUNT_DOWNLOAD'] = 'по сумме скачиваний';
$lang['BEST_COUNT_THANKS'] = 'по числу благодарностей';
$lang['DOWNLOADS'] = 'Скачиваний';
$lang['ON_AVERAGE'] = 'В среднем';
// Medal [END]

// search
$lang['SEARCH_S'] = 'Поиск...';
$lang['FORUM_S'] = 'по форуму';
$lang['TRACKER_S'] = 'по трекеру';
$lang['HASH_S'] = 'по info_hash';

// copyright
$lang['NOTICE'] = '!ВНИМАНИЕ!';
$lang['POWERED'] = 'Работает на <b>TorrentPier</b> &copy; <strong>Meithar</strong>, RoadTrain, Pandora<br /> Сборка движка, исправления и установка модов: <a href="http://rutracker.org/forum/viewtopic.php?t=1904777">fly_indiz</a>, форкнул <a href="https://kelesidis.ru">corew</a> &copy;';
$lang['DIVE'] = 'Форум представлен на базе <a href="http://www.phpbb.com">phpBB</a> &copy; phpBB Group';
$lang['COPY'] = 'Сайт не предоставляет электронные версии произведений, а занимается лишь коллекционированием и каталогизацией ссылок, присылаемых и публикуемых на форуме нашими читателями. Если вы являетесь правообладателем какого-либо представленного материала и не желаете чтобы ссылка на него находилась в нашем каталоге, свяжитесь с нами и мы незамедлительно удалим её. Файлы для обмена на трекере предоставлены пользователями сайта, и администрация не несёт ответственности за их содержание. Просьба не заливать файлы, защищенные авторскими правами, а также файлы нелегального содержания!';
$lang['SITE_WORKS'] = 'Сайт был запущен в';

// ajax register
$lang['NO_INPUT_NAME'] = 'Поле для ввода имени не должно быть пустым';
$lang['NO_INPUT_EMAIL'] = 'Поле для ввода email не должно быть пустым';
$lang['EMAIL_EXISTS'] = 'Этот email уже занят';
$lang['NAME_EXISTS'] = 'Это имя уже занято';
$lang['PASS_INDEFINITE'] = 'Поля для ввода пароля не должны быть пустыми !';
$lang['PASS_NOT_CONFIRM'] = 'Введённые пароли не совпадают';
$lang['PASS_CONFIRM'] = 'Пароли совпадают, можете продолжить регистрацию.';
$lang['EMAIL_NOT_VALID'] = 'Скорее всего Вы ошиблись при вводе email\'а.';
// ajax register

// Show map
$lang['FORUM_MAP'] = 'Карта форумов';
$lang['FILTER_BY_NAME'] = '<i>Фильтр по названию</i>';
$lang['MAP_TITLE'] = 'Карта форумов';
$lang['SITEMAP_TITLE'] = 'Карта сайта';
// Show map [END]

// double_post eliminate start
$lang['ADDED_LATER'] = 'Добавлено спустя';
// double_post eliminate end

// Invites mod [START]
$lang['INVITE_FAIL'] = 'Такого кода инвайта не существует или он уже активирован';
$lang['INVITE'] = 'Выдать инвайт';
$lang['INVITE_CODE'] = 'Код инвайта';
$lang['INVITE_DENY'] = 'Внимание!<br />На данный момент регистрация разрешена только по инвайтам.<br />Если вы не введете код инвайта, вы не сможете зарегистрироваться.';
$lang['INVITE_FREE'] = 'На данный момент разрешена регистрация без инвайтов.';
$lang['INVITE_USER'] = 'пригласил на трекер';
$lang['INVITE_USER2'] = 'отображаются последние 10 приглашенных';
$lang['INVITE_ACTIVE'] = 'Активность';
$lang['NO_INVITES'] = 'Инвайтов не выдавалось';
$lang['INVITE_NOT_ISSUE'] = 'Инвайтов не выдавалось';
$lang['INVITE_PRESS'] = 'Нажмите %sздесь%s, чтобы перейти к списку инвайтов';
$lang['INVITE_ISSUED'] = 'Инвайт успешно выдан';
$lang['INVITE_CANNOT_ISSUE'] = 'Инвайт не может быть выдан';
$lang['INVITES'] = 'Инвайты';
$lang['YOUR_INVITES'] = 'Ваши инвайты';
$lang['INVITES_DATE'] = 'Дата выдачи';
$lang['INVITED_USER'] = 'Привлеченный пользователь';
$lang['INVITES_ACTIVATED_DATE'] = 'Дата активации';
$lang['ALL_INVITES'] = 'За всё время вами выдано инвайтов';
$lang['WEEK_INVITES'] = 'За последнюю неделю вами выдано инвайтов';
$lang['INVITE_NOTIFY'] = '<ul><li>вы уже выдали разрешенное вам максимальное кол-во инвайтов в неделю;</li><li>ваш рейтинг не позволяет выдавать вам инвайты;</li><li>кол-во прошедших месяцев со дня вашей регистрации не позволяет вам выдавать инвайты.</li></ul>';
$lang['INVITE_MONTH_NOTIFY'] = 'Кол-во месяцев, прошедших со дня вашей регистрации';
$lang['INVITE_RULES'] = 'Текущие правила для получения инвайтов';
$lang['INVITE_MINRATING'] = 'Минимальный рейтинг';
$lang['INVITE_MINSTAGE'] = 'Минимальный стаж в месяцах';
$lang['INVITE_COUNT'] = 'Кол-во инвайтов в неделю';
$lang['NO_INVITE_CODE'] = 'Вы не указали код инвайта';
$lang['INVITE_NOTIFY2'] = 'Это может быть связано с тем, что';
$lang['YOU_BEEN_INVITED'] = 'Приглашен пользователем';
$lang['INVITE_GROUP'] = 'Вы состоите в следующих группах';
$lang['INVITE_GROUP2'] = 'Группа';
$lang['INVITE_ANYGROUP'] = 'ЛЮБАЯ';
$lang['INVITE_NOTIFY3'] = 'Количество инвайтов, доступных Вам для генерации - равно наибольшему количеству среди подходящих для Вас правил.';
$lang['NO_GROUP_MEMBER'] = 'Не является членом групп';
// Invites mod [END]

// Similar Topics [START]
$lang['SIMILAR'] = 'Похожие темы';
// Similar Topics [END]

$lang['browser'] = 'Браузер';

$lang['PER_PAGE'] = 'К странице...';

$lang['GROUP_IN'] = 'Вступление';

$lang['CHEATERS'] = 'Читеры';
$lang['CHEATERS_SPEEDLIMIT'] = 'Действующий лимит скорости';
$lang['CHEATERS_NO'] = 'Читеров нет';

$lang['FREELEECH'] = 'Сегодня идет свободное скачивание без начисления Download';

$lang['BETTER_RELEASE'] = 'У вас есть неоформленный релиз, прежде чем создавать новый исправьте свой неоформленный';

$lang['TOP_UP'] = 'Наверх страницы';

// ReadOnly [START]
$lang['ADD_READONLY'] = '+';
$lang['USER_ALREADY_READONLY'] = 'Пользователь уже имеет статус "только чтение" в этом форуме';
$lang['DEL_READONLY'] = '-';
$lang['READONLY'] = 'Только чтение';
$lang['RO_IN_ALL'] = 'Во всех форумах';
// ReadOnly [END]

$lang['ADD_RETACKER'] = 'Присоединять retracker.local';

$lang['SHOW_FIRST_POST'] = 'Закрепленное сообщение';

$lang['USERDBG'] = 'Показывать отладочную информацию';
$lang['USERDBGSQL'] = 'Вместе с SQL';

// Hide category
$lang['HIDE_CATEGORY'] = 'Скрыть категории';
$lang['HIDE_CATEGORY_OPT'] = 'Опции скрытия разделов';
$lang['HIDE_CATEGORY_SELECT'] = 'Выбор категорий для скрытия';
$lang['HIDE_CATEGORY_ALL_MESSAGE'] = 'Часть категорий скрыта, воспользуйтесь меню "<span style="color: darkred;">Скрыть категории</span>"';
$lang['HIDE_CATEGORY_RESET'] = 'Сбросить скр. категорий';
$lang['SHOW_HIDE_CATEGORY'] = 'Показать скрытые';

$lang['Rank_title'] = 'Лычка';

$lang['TOPIC_MOVED_TEXT'] = 'Топик<br/>%s<br/>был перемещён из форума<br/>%s<br/>в форум<br/>%s<br/>модератором %s';

$lang['MODERATOR_LOGS'] = 'Лог модераторских действий';

$lang['MODERATOR_SELF_LOGS'] = 'Лог собственных действий';

$lang['TOPIC_DELETED'] = 'Топик удалён';

$lang['TOPIC_DELETED_TEXT'] = 'Топик<br/>%s<br/>в форуме<br/>%s<br/>был удален модератором %s';

// Internet Speed
$lang['upsp'] = "Скорость отдачи";
$lang['dwsp'] = "Скорость скачки";
$lang['your_speed'] = "Скорость интернета";

// Youtube Link
$lang['youtube_link'] = 'Ссылка YouTube';

// Chat AJAX
$lang['shoutbox_insert_name'] = 'Мини-Чат';
$lang['shoutbox_err'] = 'Нужно ввести сообщение';
$lang['shoutbox_message'] = 'Введите ваше сообщение';

// Users Today
$lang['users_today'] = 'Пользователи, посетившие ресурс сегодня: ';

// Show Who Voted
$lang['NAMES_TOTAL_VOTES'] = 'Кто голосовал';

// Friends
$lang['FRIENDS_COUNT'] = 'Друзей';
$lang['FRIENDS_LIST'] = 'Список друзей';
$lang['REMOVE_FRIEND'] = 'Удалить из друзей';
$lang['ADD_FRIEND'] = 'Добавить в друзья';

// Post number
$lang['Copy_message'] = 'Скопируйте прямую ссылку этого сообщения';

// Block posting for new accounts
$lang['REG_BLOCK'] = 'Внимание! Вы не можете создавать новые темы, отвечать и цитировать еще %s';

// Start add - Gender MOD
$lang['Gender'] = "Пол";
$lang['Male'] = "Муж";
$lang['Female']="Жен";
$lang['No_gender_specify'] = "Не указан";
$lang['USERS_TOTAL_GENDER'] = 'Парней: <b>%d</b>, Девушек: <b>%d</b>, Не указали: <b>%d</b>';
// End add - Gender MOD

// Select logo [Mod]
$lang['Logo_settings'] = 'Настройки логотипа';
$lang['Logo_path'] = 'Папка где находятся логотипы';
$lang['Logo_path_explain'] = 'Путь к корневой папке, например: images/logo';
$lang['Logo'] = 'Выберите логотип';
$lang['Logo_dimensions'] = 'Размеры логотипа';
$lang['Logo_dimensions_explain'] = '(высота х ширина в пикселях) ';

// Improved log
$lang['Debug_on'] = 'Дебаг включен';
$lang['Debug_off'] = 'Дебаг выключен';
$lang['Execution_time'] = 'Время выполнения: ';
$lang['Sec'] = ' секунд ';
$lang['Queries'] = ' запросы';
$lang['In'] = ' в ';
$lang['Memory'] = 'Память: ';
$lang['Load'] = 'Загрузка:';
$lang['wrap_log'] = 'развернуть';
$lang['max_log'] = 'макс.';
$lang['show_log'] = 'смотреть лог';
$lang['show_log_compact'] = 'лог в новом стиле';

// Off PM
$lang['OFF_PM'] ='Отключить входящие ЛС';
$lang['OFF_PM_MESSAGE'] ='Пользователь отключил входящие ЛС';

// Парковка аккаунта
$lang['PARK_CONTROL'] ='Парковка аккаунта';
$lang['PARK_WARNING'] ='Припарковав аккаунт Вы не сможете скачивать!';
$lang['PARK_PROFILE_STATUS'] ='Аккаунт припаркован';
$lang['PARK_PROFILE_STATUS_WHOTE'] = ''; // OG - "<h5>Что такое "Парковка Аккаунта"?</h5>"
$lang['PARK_PROFILE_STATUS_WHOTE_LINK'] = ''; // OG - "viewtopic.php?t=123"
$lang['PARK_PROFILE_POST_DISALLOWED'] ='Вы не сможете писать сообщения пока аккаунт припаркован';
$lang['PARK_PROFILE_PM_DISALLOWED'] ='Вы не сможете использовать Личные сообщения пока аккаунт припаркован';

// Misc
$lang['online_users'] = 'Показать пользователей онлайн';
$lang['UserAgent'] = 'Подробнее о браузере';
$lang['INDEX_RETURN'] = 'Вернуться на главную';
$lang['NAVIGATION'] = "Навигация";
$lang['TOR_HASH'] = "Хэш";

// Medal MOD
$lang['Medal_Control_Panel'] = 'Панель управления наградой';
$lang['Medals'] = 'Награды';
$lang['Medals'] = 'Уникальные награды';
$lang['Medals_all'] = 'Всего наград';
$lang['View_More'] = 'Смотреть ещё';
$lang['Medal_amount'] = 'Количество: ';
$lang['Medal_Information'] = 'Информация о награде';
$lang['Medal_name'] = 'Название';
$lang['Medal_description'] = 'Описание награды';
$lang['Medal_image'] = 'Изображение';
$lang['Medal_details'] = 'Подробнее';
$lang['Medal_reason'] = 'Причина награждения';
$lang['Medal_reason_explain'] = 'Вы можете написать причину награждения<br />Это поле не обязательно для заполнения';
$lang['Medal_no_reason'] = '<i>Не указана</i>';
$lang['Medal_time'] = 'Время награждения';
$lang['Medal_moderator'] = 'Модератор награды';
$lang['No_medal_mod'] = 'Модератор еще не назначен';
$lang['Medal_userlist'] = 'У кого есть?';
$lang['Medal_Members'] = 'Награжденные пользователи';
$lang['Medal_Members_explain'] = 'Нажмите на никнейм, чтобы отредактировать причину вручения';
$lang['No_medal_members'] = 'Никто еще не награжден';
$lang['No_medals_exist'] = 'Нет Медалей';
$lang['Medal_not_exist'] = 'Это медаль не существует';
$lang['No_username_specified'] = 'Не задано имя пользователя';
$lang['No_medal_id_specified'] = 'Медаль не указана';
$lang['Medal_user_username'] = 'Наградить пользователя';
$lang['Medal_unmedal_username'] = 'Удалить эту награду у одного или нескольких пользователей';
$lang['Medal_unmedal_username_explain'] = 'Выделите пользователей у которых нужно убрать награду';
$lang['Medal_added'] = 'Вы были награждены этой медалью.';
$lang['Medal_update_sucessful'] = 'Изменения внесены успешно';
$lang['Could_not_anonymous_user'] = 'Нельзя давать награду Anonymous';
$lang['Not_medal_moderator'] = 'Вы не модератор этой награды';
$lang['Link_to_cp'] = 'Управление наградой';
$lang['Click_return_medal'] = '%sВернуться к управлению наградой%s';
$lang['No_medal'] = 'Нет медали в наличии';
//Medal MOD [END]

// Latest news in sidebar
$lang['LAST_ADD_POST'] = 'Последние сообщения';
$lang['AUTHOR_NEW_POST'] = 'Последнее сообщение от';

// Moderate panel
$lang['MODERATE_PANEL'] = 'Модераторская панель';
$lang['MODERATE_PANEL_EXPLAIN'] = 'Панель управления раздачами пользователей';
$lang['MODERATE_PANEL_STATUS'] = 'Статус раздач(и) изменён на %s<br /><br /> %sвернуться к управлению%s';
$lang['MODERATE_PANEL_TYPE'] = 'Тип раздач(и) изменён на %s<br /><br /> %sвернуться к управлению%s';
$lang['MODERATE_PANEL_TOR_DEL'] = 'В выбранных темах торренты успешно удалены<br /><br /> %sвернуться к управлению%s';
$lang['MODERATE_PANEL_TEXT'] = '%s <br /><br /> %sвернуться к управлению%s';
$lang['NORMAL'] = 'Обычный';
$lang['CHECK_ALL'] = 'Отметить всё';
$lang['UNCHECK_ALL'] = 'Снять выделение';
// Moderate panel [END]

// Start order mod
$lang['ORDER_SECTION'] = 'Секция запросов';
$lang['ORDER'] = 'Запрос';
$lang['ORDER_ADDED'] = 'Добавлен';
$lang['USER_ORDERED_ADD'] = 'Запросил';
$lang['ORDER_YES'] = 'Выполнен ?';
$lang['USER_ORDER_PERFORMED'] = 'Выполнил';
$lang['ORDER_VOTE'] = 'Голосов';
$lang['ORDER_ADD'] = 'Сделать запрос';
$lang['ORDER_MY'] = 'Мои запросы';
$lang['ORDER_ALL'] = 'Все запросы';
$lang['ORDER_HIDE_YES'] = 'Спрятать выполненные';
$lang['INPUT_ORDER_HEAD'] = 'Введите заголовок запроса';
$lang['INPUT_ORDER_DESC'] = 'Введите краткое описание';
$lang['ORDER_ARE_VOTE'] = 'Извините, но Вы уже голосовали за данный запрос сегодня !\n Голосовать можно раз в сутки !';
$lang['SET_ORDER_TOPIC_ID'] = 'В этом поле укажите ID топика';
$lang['ORDER_TOPIC_ID_NOT_SET'] = 'ID топика не указан !!!';
$lang['ORDER_ABUSE'] = 'Нарушение';
$lang['ORDER_SHOW_ABUSE'] = 'C нарушениями';
$lang['SELECT_ORDER_FORUM'] = '<b>Выберите форум.</b><br />В котором, по Вашему мнению должна располагаться раздача';
$lang['ADD_COMMENT_ORDER'] = 'Добавить комментарий';
$lang['COMMENT_ORDER'] = 'Комментарий<br /><span class="small">Использование <b>BBCode</b> и <b>HTML</b> запрещено</span>';
$lang['NO_COMMENT_ORDER'] = 'Вы не ввели комментарий';
// End order mod

//+MOD: DHTML Collapsible Forum Index MOD
$lang['CFI_options'] = "C.F.I.";
$lang['CFI_options_ex'] = "Параметры сворачиваемого указателя форума";
$lang['CFI_close'] = "Закрыть";
$lang['CFI_delete'] = "Удалить сохраненное состояние";
$lang['CFI_restore'] = "Восстановить сохраненное состояние";
$lang['CFI_save'] = "Сохранить состояние";
$lang['CFI_Expand_all'] = "Расширить все";
$lang['CFI_Collapse_all'] = "Свернуть все";
//-MOD: DHTML Collapsible Forum Index MOD

/* [MOD] Spoilers [START] */
$lang['SPOILERS_SELECT'] = array (
    'Простой спойлер',
    'Осторожно, спойлер!!!',
    '18+',
    'Картинки',
    'Видео',
    'Текст',
    'Ссылки',
);
/* [MOD] Spoilers [END] */

// Birthday
$lang['BIRTHDAY'] = 'День рождения';
$lang['HAPPY_BIRTHDAY'] = 'С Днем Рождения!';
$lang['WRONG_BIRTHDAY_FORMAT'] = 'Дата рождения указана неверно';
$lang['AGE'] = 'Возраст';
$lang['BIRTHDAY_TO_HIGH'] = 'Извините, сайт запрещено посещать пользователям старше %d лет';
$lang['BIRTHDAY_TO_LOW'] = 'Извините, сайт запрещено посещать детям младше %d лет';
$lang['BIRTHDAY_TODAY'] = 'Пользователи, празднующие День Рождения сегодня: ';
$lang['BIRTHDAY_WEEK'] = 'Пользователи, празднующие День Рождения в ближайшие %d дней: %s';
$lang['NOBIRTHDAY_WEEK'] = 'В ближайшие %d дней никто не празднует День Рождения.'; // %d is substitude with the number of days
$lang['NOBIRTHDAY_TODAY'] = 'Сегодня никто не празднует День Рождения.';

// MultiTracker 1.0.2
$lang['TR_FORCE_UPDATE'] = 'ПРИНУДИТЕЛЬНОЕ ОБНОВЛЕНИЕ';
$lang['TR_EX_SEEDS_LEECHERS'] = 'Внешних Сидов / Личеров:';

$lang['ALIGN_SELECT'] = array (
    'align' => 'Выравнивание',
    'left' => 'Влево',
    'right' => 'Вправо',
    'center' => 'По центру',
    'justify' => 'По ширине',
);

$lang['HASH_INVALID'] = 'Хэш %s некорректен';
$lang['HASH_NOT_FOUND'] = 'Раздача с хэшем %s не найдена';
$lang['FILE_UPLOAD_ERROR'] = 'Ошибка загрузки файла на сервер';
$lang['FILE_SIZE_UPLOAD_ERROR'] = 'Не удаётся получить размер файла';
$lang['FILE_ATTACH_UPLOAD_ERROR'] = 'Не удаётся получить вложения';
$lang['FILE_ATTACH_CREATE_UPLOAD_ERROR'] = 'Не удаётся создать вложение';
$lang['FILE_EXT_UPLOAD_ERROR'] = 'Не удаётся получить расширение';
$lang['FILE_EMPTY_UPLOAD_ERROR'] = 'Файл пустой';
$lang['FILE_UPD_COMM_UPLOAD_ERROR'] = 'Не удалось обновить комментарий к файлу';
$lang['FILE_UPD_ATTACH_UPLOAD_ERROR'] = 'Не удалось обновить вложение';
$lang['FILE_GET_QUOTA_LIMIT_UPLOAD_ERROR'] = 'Не получается получить лимит квоты';
$lang['FILE_GET_QUOTA_USER_UPLOAD_ERROR'] = 'Не получается получить квоту пользователя';
$lang['FILE_GET_QUOTA_GROUP_UPLOAD_ERROR'] = 'Не получается получить квоту группы';
$lang['FILE_GET_QUOTA_GROUP_USER_UPLOAD_ERROR'] = 'Не получается получить квоту групп пользователей';
