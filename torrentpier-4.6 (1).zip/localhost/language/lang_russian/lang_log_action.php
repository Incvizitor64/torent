<?php

$lang['log_action']['log_type'] = array(
	'mod_topic_delete'   => 'Топик:<br /> <b>удален</b>',
	'mod_topic_move'     => 'Топик:<br /> <b>перенесен</b>',
	'mod_topic_lock'     => 'Топик:<br /> <b>закрыт</b>',
	'mod_topic_unlock'   => 'Топик:<br /> <b>открыт</b>',
	'mod_topic_split'    => 'Топик:<br /> <b>разделен</b>',
	'mod_post_delete'    => 'Пост:<br /> <b>удален</b>',
	'adm_user_delete'    => 'Юзер:<br /> <b>удален</b>',
	'adm_user_ban'       => 'Юзер:<br /> <b>забанен</b>',
	'adm_user_unban'     => 'Юзер:<br /> <b>разбанен</b>',
	'tor_status_changed' => 'Статус:<br /> <b>изменён</b>',
	'tor_unreg'          => 'Торрент:<br /> <b>разрегистр.</b>',
	'att_delete'         => 'Файл:<br /> <b>удален</b>',
	'ban_ip'             => 'Бан:<br /> <b>IP</b>',
	'ban_email'          => 'Бан:<br /> <b>email</b>',
	'ban_name'           => 'Бан:<br /> <b>имя</b>',
	'groupmember_add'    => 'Группа:<br /> <b>добавлен</b>',
	'groupmember_del'    => 'Группа:<br /> <b>удалён</b>',
);

    $lang['acts_log_all_actions']  = 'Все действия';
    $lang['acts_log_search_options'] = 'Настройки отчета по действиям';
    $lang['acts_log_forum'] = 'Форум';
    $lang['acts_log_action'] = 'Действие';
    $lang['acts_log_user'] = 'Юзер';
    $lang['acts_log_logs_from'] = 'Логи с ';
    $lang['acts_log_first'] = 'сначала ';
    $lang['acts_log_days_back'] = 'дней назад';
    $lang['acts_log_topic_match'] = 'Совпадение с названием темы';
    $lang['acts_log_sort_by'] = 'Сортировать по';
    $lang['acts_log_logs_action'] = 'Действие';
    $lang['acts_log_username'] = 'Имя пользователя';
    $lang['acts_log_time'] = 'Время';
    $lang['acts_log_info'] = 'Инфо';
