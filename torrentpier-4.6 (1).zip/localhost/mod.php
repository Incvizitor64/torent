<?php

// Версия 1.05

define('IN_PHPBB', true);
define('BB_ROOT', './');
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require(BB_ROOT ."common.$phpEx");

$page_cfg['load_tpl_vars'] = array(
	'post_icons',
);

$user->session_start(array('req_login' => true));

// Сортировка в таблицах
$page_cfg['use_tablesorter'] = true;
// Предпросмотр на ajax'е
$page_cfg['include_bbcode_js'] = true;

$tracking_topics = get_tracks('topic');

// Кол-во тем на странице
$tor_topics_per_page = $bb_cfg['posts_per_page'];
if ($req_tpp = abs(intval(@$_REQUEST['tpp'])) AND in_array($req_tpp, $bb_cfg['allowed_posts_per_page']))
{
	$tor_topics_per_page = $req_tpp;
}
$select_tpp = '';
foreach ($bb_cfg['allowed_posts_per_page'] as $tpp)
{
	$select_tpp[$tpp] = $tpp;
}

$start  = isset($_GET['start']) ? abs(intval($_GET['start'])) : '0';
$status = isset($_GET['st']) ? $_GET['st'] : '0';
$user_id = $userdata['user_id'];

if ($status == 'gold')
{
	$where_status = "AND tor.tor_type = 1";
}
elseif ($status == 'silver')
{
	$where_status = "AND tor.tor_type = 2";
}
elseif ($status == 'bronz')
{
	$where_status = "AND tor.tor_type = 3";
}
elseif (preg_match("/^[0-9]+$/", $status))
{
	$where_status = "AND tor.tor_status = $status";
}
else
{
	bb_die(':(');
}

if($userdata['user_level'] == USER)
{
	meta_refresh('./', '3');
	bb_die($lang['Not_Moderator']);
}

if($userdata['user_level'] == GROUP_MEMBER)
{
	meta_refresh('./', '3');
	bb_die($lang['Not_Moderator']);
}

// Исключаем вывод с ненужных форумов
$trash_forums = $bb_cfg['trash_forum_id'] ? $bb_cfg['trash_forum_id'] : '0';

//
$url = append_sid("mod.$phpEx?st=$status");

// Основная ф-ция обновления статуса и типа раздачи
if ( isset($HTTP_POST_VARS['topic_id']) )
{
    $topic_ids = implode(",", $HTTP_POST_VARS['topic_id']);
    $status = $HTTP_POST_VARS['status'];

    switch($status)
    {
    	case 'set_gold':
    	case 'set_silver':
		
    	case 'unset_gold_silver_bronz':
		   	if($status == 'set_gold')
		   	{
    		    $type = '1';
    		    $type_text = '<b style="color: yellow;">'. $lang['GOLD'] .'</b>';
		   	}
		   	elseif($status == 'set_silver')
		   	{
    		    $type = '2';
    		    $type_text = '<b style="color: silver;">'. $lang['SILVER'] .'</b>';
		   	}
		
		   	elseif($status == 'unset_gold_silver_bronz')
		   	{
    		    $type = '0';
    		    $type_text = '<b>'. $lang['NORMAL'] .'</b>';
		   	}

	        $sql = "UPDATE ". BT_TORRENTS_TABLE ." SET tor_type = $type WHERE topic_id IN ($topic_ids)";
		    if ( !($result = $db->sql_query($sql)) )
		    {
		        message_die(GENERAL_ERROR, "Could not update torrent type", '', __LINE__, __FILE__, $sql);
		    }

			meta_refresh($url, '2');
		    $message = sprintf($lang['MODERATE_PANEL_TYPE'], $type_text, '<a class="gen" href="'. $url .'">', '</a>');
			message_die(GENERAL_MESSAGE, $message);
		  break;
		case 'lock':
		case 'unlock':
			$lock = ($status == 'lock');
			$new_topic_status = ($lock) ? TOPIC_LOCKED : TOPIC_UNLOCKED;

		    $sql = "UPDATE ". TOPICS_TABLE ." SET topic_status = $new_topic_status WHERE topic_id IN ($topic_ids)";
		    if ( !($result = $db->sql_query($sql)) )
		    {
		        message_die(GENERAL_ERROR, "Could not update topic LOCK-status", '', __LINE__, __FILE__, $sql);
		    }

			$status_text = ($lock) ? $lang['Topics_Locked'] : $lang['Topics_Unlocked'];
			meta_refresh($url, '2');
		    $message = sprintf($lang['MODERATE_PANEL_TEXT'], $status_text, '<a class="gen" href="'. $url .'">', '</a>');
			message_die(GENERAL_MESSAGE, $message);
		  break;
		case 'down':
		case 'undown':
			$set_download = ($status == 'down');
			$new_dl_type  = ($set_download) ? TOPIC_DL_TYPE_DL : TOPIC_DL_TYPE_NORMAL;

			$sql = "UPDATE ". TOPICS_TABLE ." SET topic_dl_type = $new_dl_type WHERE topic_id IN ($topic_ids)";
		    if ( !($result = $db->sql_query($sql)) )
		    {
		        message_die(GENERAL_ERROR, "Could not update topic DL-status", '', __LINE__, __FILE__, $sql);
		    }

			$status_text = ($lock) ? $lang['Topics_Down_Sets'] : $lang['Topics_Down_Unsets'];
			meta_refresh($url, '2');
		    $message = sprintf($lang['MODERATE_PANEL_TEXT'], $status_text, '<a class="gen" href="'. $url .'">', '</a>');
			message_die(GENERAL_MESSAGE, $message);
		  break;
		case 'delete':
			require_once(INC_DIR .'functions_admin.'. PHP_EXT);

			topic_delete($topic_ids);

			meta_refresh($url, '2');
		    $message = sprintf($lang['MODERATE_PANEL_TEXT'], $lang['Topics_Removed'], '<a class="gen" href="'. $url .'">', '</a>');
			message_die(GENERAL_MESSAGE, $message);
		  break;
		 case 'tor_delete':
			require_once(INC_DIR .'functions_torrent.'. PHP_EXT);

			$sql = "SELECT attach_id FROM ". TORRENTS_TABLE ." WHERE topic_id IN ($topic_ids)";
		    if ( !($result = $db->sql_query($sql)) )
		    {
		        message_die(GENERAL_ERROR, "Could not update torrent type", '', __LINE__, __FILE__, $sql);
		    }
			while ( $row = $db->sql_fetchrow($result) )
			{
				tracker_unregister($row['attach_id']);
			}

			meta_refresh($url, '2');
		    $message = sprintf($lang['MODERATE_PANEL_TOR_DEL'], $lang['Topics_Removed'], '<a class="gen" href="'. $url .'">', '</a>');
			message_die(GENERAL_MESSAGE, $message);
		  break;


		default:
			$sql = "UPDATE ". BT_TORRENTS_TABLE ." SET tor_status = $status, checked_time = ". time() .", checked_user_id = $user_id WHERE topic_id IN ($topic_ids)";
		    if ( !($result = $db->sql_query($sql)) )
		    {
		        message_die(GENERAL_ERROR, "Could not update torrent status", '', __LINE__, __FILE__, $sql);
		    }

			switch($status)
			{
				case 0:
					$status_text = '<span class="tor-not-approved">'. $lang['TOR_STATUS_NOT_CHECKED'] .'</span>';
				  break;
		    	case 1:
					$status_text = '<span class="tor-closed">'. $lang['TOR_STATUS_CLOSED'] .'</span>';
				  break;
		    	case 2:
					$status_text = '<span class="tor-approved">'. $lang['TOR_STATUS_CHECKED'] .'</span>';
				  break;
		    	case 3:
					$status_text = '<span class="tor-dup">'. $lang['TOR_STATUS_D'] .'</span>';
				  break;
		    	case 4:
					$status_text = '<span class="tor-no-desc">'. $lang['TOR_STATUS_NOT_PERFECT'] .'</span>';
				  break;
		    	case 5:
					$status_text = '<span class="tor-need-edit">'. $lang['TOR_STATUS_PART_PERFECT'] .'</span>';
				  break;
		    	case 6:
					$status_text = '<span class="tor-consumed">'. $lang['TOR_STATUS_FISHILY'] .'</span>';
				  break;
		    	case 7:
					$status_text = '<span class="tor-closed-cp">'. $lang['TOR_STATUS_COPY'] .'</span>';
			      break;

			}

			meta_refresh($url, '2');
		    $message = sprintf($lang['MODERATE_PANEL_TYPE'], $status_text, '<a class="gen" href="'. $url .'">', '</a>');
			message_die(GENERAL_MESSAGE, $message);
		  break;
    }
}

$auth_table = ($userdata['user_level'] == ADMIN) ? "" : ", ". AUTH_ACCESS_SNAP_TABLE ." aa";
$auth_access = ($userdata['user_level'] == ADMIN) ? "" : "AND aa.user_id = $user_id AND tor.forum_id = aa.forum_id AND aa.forum_perm = 8";

//
$sql = "SELECT COUNT(tor.topic_id) as tor_count
	FROM ". BT_TORRENTS_TABLE ." tor $auth_table
	WHERE tor.forum_id != ($trash_forums)
		$auth_access
		$where_status";
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not obtain count topic', '', __LINE__, __FILE__, $sql);
}
$row = $db->sql_fetchrow($result);
$tor_count = ( $row['tor_count'] ) ? $row['tor_count'] : 0;
$db->sql_freeresult($result);

if ($tor_count)
{
    $sql = "SELECT tor.*, t.*, f.forum_name,f.forum_parent, u.username, u.user_level
        FROM ". BT_TORRENTS_TABLE ." tor, ". TOPICS_TABLE ." t, ". FORUMS_TABLE ." f, ". USERS_TABLE ." u $auth_table
        WHERE t.topic_id = tor.topic_id
            AND t.topic_poster = u.user_id
            AND f.forum_id = t.forum_id
            AND f.forum_id != ($trash_forums)
            $auth_access
            $where_status
        GROUP BY tor.topic_id
        ORDER BY tor.reg_time DESC
      LIMIT $start, $tor_topics_per_page";
    if ( !($result = $db->sql_query($sql)) )
    {
		message_die(GENERAL_ERROR, 'Could not obtain topic information', '', __LINE__, __FILE__, $sql);
    }
    $tor = $db->sql_fetchrowset($result);

    if ($tor)
    {
        $template->assign_block_vars('tor_topics', array());
        for ($i = 0; $i < count($tor); $i++)
        {
            //$username =  colornick_level($tor[$i]['username'], $tor[$i]['user_level']);
			$username =  $tor[$i]['username'];
			$topic_poster = ($tor[$i]['topic_poster'] == ANONYMOUS ) ? ( ($username != '' ) ? $username . ' ' : $lang['Guest'] . ' ' ) : '<a class="genmed" href="' . append_sid(BB_ROOT . "profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . '='  . $tor[$i]['topic_poster']) . '">' . $username . '</a>';

            // Gold/Silver releases mod
			$is_gold = '';
			if ($bb_cfg['gold_silver_enabled'])
			{
				if ($tor[$i]['tor_type'] == TOR_TYPE_GOLD)
				{
					$is_gold = '<img src="images/tor_gold.gif" width="16" height="15" title="'.$lang['GOLD'].'" />&nbsp;';
				}
				elseif ($tor[$i]['tor_type'] == TOR_TYPE_SILVER)
				{
					$is_gold = '<img src="images/tor_silver.gif" width="16" height="15" title="'.$lang['SILVER'].'" />&nbsp;';
				}
				
			}
			// END Gold/Silver releases mod

            // Иконка темы
            $is_unread = is_unread($tor[$i]['topic_last_post_time'], $tor[$i]['topic_id'], $tor[$i]['forum_id']);

            $row_class = (!($i % 2)) ? 'row2' : 'row1';
                            if (@$parent_id = $tor[$i]['forum_parent'])
                {
                    if (!$forums = $datastore->get('cat_forums'))
                    {
                         $datastore->update('cat_forums');
                         $forums = $datastore->get('cat_forums');
                    }
                } 

            $template->assign_block_vars('tor', array(
                'PARENT_FORUM_HREF'    => ($parent_id) ? FORUM_URL . $parent_id : '',
                'PARENT_FORUM_NAME' => ($parent_id) ? htmlCHR($forums['f'][$parent_id]['forum_name']) : '', 
                'ROW_CLASS'     => $row_class,

                'POST_ID'       => $tor[$i]['post_id'],
                'TOPIC_ID'      => $tor[$i]['topic_id'],
                'TOPIC_TITLE'   => wbr($tor[$i]['topic_title']),
                'TOPIC_REPLIES' => $tor[$i]['topic_replies'],
                'REG_TIME'      => create_date($bb_cfg['default_dateformat'], $tor[$i]['reg_time'], $bb_cfg['board_timezone']),
                'REG_TIME_BACK' => delta_time($tor[$i]['reg_time']),

                'FORUM_TITLE'   => wbr($tor[$i]['forum_name']),

                'TOPIC_POSTER'  => $topic_poster,

                'U_FORUM'       => append_sid(BB_ROOT . "viewforum.$phpEx?" . POST_FORUM_URL . '=' . $tor[$i]['forum_id']),
                'U_TOPIC'       => append_sid(BB_ROOT . "viewtopic.$phpEx?"  . POST_TOPIC_URL . '=' . $tor[$i]['topic_id']),

                'TOR_STATUS'    => $tor[$i]['tor_status'],
                'TOR_TYPE'      => $is_gold,
                'TOR_FROZEN'    => ($tor[$i]['tor_status'] == TOR_STATUS_FROZEN || $tor[$i]['tor_status'] == 3 || $tor[$i]['tor_status'] == 4 || $tor[$i]['tor_status'] == 7),
                'DL_CLASS'      => isset($tor[$i]['dl_status']) ? $dl_link_css[$tor[$i]['dl_status']] : 'genmed',

                'IS_UNREAD'     => $is_unread,
				'TOPIC_ICON'    => get_topic_icon($tor[$i], $is_unread),
				'PAGINATION'    => ($tor[$i]['topic_status'] == TOPIC_MOVED) ? '' : build_topic_pagination(TOPIC_URL . $tor[$i]['topic_id'], $tor[$i]['topic_replies'], $bb_cfg['posts_per_page']),
            ));
        unset($forums);
        }

        $pagination = generate_pagination($url, $tor_count, $tor_topics_per_page, $start);

		$template->assign_vars(array(
			'PAGINATION'  => $pagination,
			'PAGE_NUMBER' => sprintf($lang['Page_of'], ( floor( $start / $tor_topics_per_page ) + 1 ), ceil( $tor_count / $tor_topics_per_page )),
		    'U_PER_PAGE'  => $url,
		    'PER_PAGE'    => $tor_topics_per_page,
		));
    }
    $db->sql_freeresult($result);
}
else
{
    $template->assign_block_vars('no_tor_topics', array());
}

$template->assign_vars(array(
    'PAGE_TITLE'     => $lang['MODERATE_PANEL'],

    'SELECT_TPP'     => ($select_tpp) ? build_select('tpp', $select_tpp, $tor_topics_per_page, null, null, 'onchange="$(\'#tpp\').submit();"') : '',
    'L_NO_MATCH'     => $lang['No_match'],
    'L_DOWN'         => $lang['Set_DL_Status'],
	'L_UNDOWN'       => $lang['Unset_DL_Status'],
	'L_TOR_DELETE'   => $lang['Bt_Unreg_from_tracker'],

    'ST_0'           => ($status == 0) ? 'selected="selected"' : '',
    'ST_1'           => ($status == 1) ? 'selected="selected"' : '',
    'ST_2'           => ($status == 2) ? 'selected="selected"' : '',
    'ST_3'           => ($status == 3) ? 'selected="selected"' : '',
    'ST_4'           => ($status == 4) ? 'selected="selected"' : '',
    'ST_5'           => ($status == 5) ? 'selected="selected"' : '',
    'ST_6'           => ($status == 6) ? 'selected="selected"' : '',
    'ST_7'           => ($status == 7) ? 'selected="selected"' : '',

    'ST_G'           => ($status == 'gold') ? 'selected="selected"' : '',
    'ST_S'           => ($status == 'silver') ? 'selected="selected"' : '',


    'SHOW_JUMPBOX'   => true,
));

print_page('mod.tpl');