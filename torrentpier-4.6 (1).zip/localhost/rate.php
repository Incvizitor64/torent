<?php
define('IN_PHPBB', true);
define('BB_SCRIPT', 'rate');
define('BB_ROOT', './');
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require(BB_ROOT ."common.$phpEx");

// Start session management
$user->session_start();

$attach_id = $_GET['a'];
$rating = $_GET['v'];

if( $userdata['user_id'] != ANONYMOUS && is_numeric($attach_id) && is_numeric($rating) && $rating>=1 && $rating<=5 ) {

	$sql = "insert into ". ATTACHMENTS_RATING_TABLE ."(attach_id,user_id,rating)values("
		. $attach_id .",". $userdata['user_id'] .",". $rating .")on duplicate key update rating=values(rating)";

	if( $db->sql_query($sql) ) {
		echo 'var vd=document.getElementById("VD'. $attach_id .'");vd.innerHTML="'. $lang['Your_Vote'] .' '. $rating .' '. $lang['Vote_Counted'] .'";';
	}

	$sql = "select sum(rating) as r, count(*) as c from ". ATTACHMENTS_RATING_TABLE ." where rating>0 and attach_id=". $attach_id;

	if( $result = $db->sql_query($sql) ) {
		if ($row = $db->sql_fetchrow($result)) {
			echo 'var vr=document.getElementById("VR'. $attach_id .'");vr.innerHTML="'. round($row['r']/$row['c'],1) .'";';
			echo 'var vc=document.getElementById("VC'. $attach_id .'");vc.innerHTML="'. $row['c'] .'";';
			$sql = "update ". ATTACHMENTS_DESC_TABLE ." set rating_sum=". $row['r'] .", rating_count=". $row['c'] ." where attach_id=". $attach_id;
			$db->sql_query($sql);
		}
	}
}