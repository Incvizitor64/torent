<?php

define('IN_PHPBB', true);
define('BB_ROOT', './');
include(BB_ROOT .'common.php');

//
// Start session management
//
$user->session_start();

$user_id = $userdata['user_id'];
//
// End session management
//

if ( isset($_GET[POST_USERS_URL]) || isset($_POST[POST_USERS_URL]) )
{
	$user_id = ( isset($_POST[POST_USERS_URL]) ) ? intval($_POST[POST_USERS_URL]) : intval($_GET[POST_USERS_URL]);
}
else
{
	$user_id = '';
}
$profiledata = get_userdata($user_id);

if ( isset($_GET[POST_MEDAL_URL]) || isset($_POST[POST_MEDAL_URL]) )
{
	$medal_id = ( isset($_POST[POST_MEDAL_URL]) ) ? intval($_POST[POST_MEDAL_URL]) : intval($_GET[POST_MEDAL_URL]);
}
else
{
	$medal_id = '';
}

// session id check
if (!empty($_POST['sid']) || !empty($_GET['sid']))
{
	$sid = (!empty($_POST['sid'])) ? $_POST['sid'] : $_GET['sid'];
}
else
{
	$sid = '';
}

// session id check
if ($sid == '' || $sid != $userdata['session_id'])
{
	$message = $lang['Not_Authorised'] . '<br /><br />' . sprintf($lang['Click_return_index'], '<a href="index.php">', '</a>');

	message_die(GENERAL_ERROR, $message);
}

$is_moderator = FALSE;

$is_moderator = ($userdata['user_level'] != ADMIN) ? check_medal_mod($medal_id) : TRUE;

// Start auth check
if ( !$is_moderator )
{
	$message = $lang['Not_medal_moderator'] . '<br /><br />' . sprintf($lang['Click_return_index'], '<a href="index.php">', '</a>');

	message_die(GENERAL_MESSAGE, $message);
}
// End Auth Check

if ( empty($user_id) )
{
	message_die(GENERAL_MESSAGE, $lang['No_user_id_specified'] );
}

if ( empty($medal_id) )
{
	message_die(GENERAL_MESSAGE, $lang['No_medal_id_specified']);
}

$sql = "SELECT *
	FROM " . BB_MEDAL_USER . "
	WHERE medal_id = $medal_id
	AND user_id = '" . $profiledata['user_id'] . "'
	ORDER BY issue_id";

if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Error getting user medal information', '', __LINE__, __FILE__, $sql);
}
else
{
	$row = array();
	$issue = array();
	$default_config = array();
	$row = $db->sql_fetchrowset($result);
	$rows = count($row);

	for($i = 0; $i < $rows; $i++)
	{
		$issue[$i]['issue_id'] = $row[$i]['issue_id'];
		$issue[$i]['issue_time'] = $row[$i]['issue_time'];
		$issue_reason = $row[$i]['issue_reason'];
		$default_config[$i] = str_replace("'", "\'", $issue_reason);

		$issue[$i]['issue_reason'] = ( isset($_POST['issue_reason'.$row[$i]['issue_id']]) ) ? trim($_POST['issue_reason'.$row[$i]['issue_id']]) : $default_config[$i];

		if( isset($_POST['submit']) )
		{
			$sql = "UPDATE " . BB_MEDAL_USER . "
				SET issue_reason = '" . str_replace("\'", "''", $issue[$i]['issue_reason']) . "'
				WHERE issue_id =" . $row[$i]['issue_id'];

			if ( !$db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, 'Could not update medal info', '', __LINE__, __FILE__, $sql);
			}
		}

	}

	if( isset($_POST['submit']) )
	{
		$message = $lang['Medal_update_sucessful'] . '<br /><br />' . sprintf($lang['Click_return_medal'], '<a href="medalcp.php?'. POST_MEDAL_URL .'='.$medal_id.'&amp;sid='.$userdata['session_id'] .'">', '</a>') . '<br /><br />'. sprintf($lang['Click_return_index'], '<a href="index.php">', '</a>');

		message_die(GENERAL_MESSAGE, $message);
	}
}

$s_hidden_fields = '<input type="hidden" name="sid" value="' . $userdata['session_id'] . '" />';
$s_hidden_fields .= '<input type="hidden" name="' . POST_USERS_URL . '" value="' . $profiledata['user_id'] . '" />';
$s_hidden_fields .= '<input type="hidden" name="' . POST_MEDAL_URL . '" value="' . $medal_id . '" />';

$page_title = $lang['Medal_Control_Panel'];

$sql = "SELECT *
	FROM " . BB_MEDAL . "
	WHERE medal_id =" . $medal_id;
if ( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not obtain medal information', '', __LINE__, __FILE__, $sql);
}
$medal_info = $db->sql_fetchrow($result);

$template->assign_vars(array(
	'L_MEDAL_INFORMATION' => $lang['Medal_Information'] . ' :: ' . $profiledata['username'],

	"MEDAL_NAME" => $medal_info['medal_name'],
	"MEDAL_DESCRIPTION" => $medal_info['medal_description'],

	"S_MEDAL_ACTION" => 'medalcp_edit.php',
	'S_HIDDEN_FIELDS' => $s_hidden_fields)
);

for($i = 0; $i < $rows; $i++)
{
	$template->assign_block_vars("medaledit", array(
		'L_MEDAL_TIME' => $lang['Medal_time'],
		'L_MEDAL_REASON' => $lang['Medal_reason'],
		'L_MEDAL_REASON_EXPLAIN' => $lang['Medal_reason_explain'],
		'L_ISSUE_REASON' => 'issue_reason'. $issue[$i]['issue_id'],

		"ISSUE_REASON" => $issue[$i]['issue_reason'],
		"ISSUE_TIME" => bb_date($issue[$i]['issue_time'])
		)
	);
}

print_page('medalcp_edit_body.tpl');

