<?php

/*
	This file is part of TorrentPier

	TorrentPier is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	TorrentPier is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	A copy of the GPL 2.0 should have been included with the program.
	If not, see http://www.gnu.org/licenses/

	Official SVN repository and contact information can be found at
	http://code.google.com/p/torrentpier/
 */

define('IN_PHPBB',   true);
define('BB_SCRIPT', 'login');
define('IN_LOGIN', true);
define('BB_ROOT', './');
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require(BB_ROOT ."common.$phpEx");

array_deep($_POST, 'trim');

$user->session_start();

// logout
if (!empty($_GET['logout']))
{
    if (!IS_GUEST)
    {
        $user->session_end();
    }
    redirect("index.$phpEx");
}

$redirect_url = "index.$phpEx";
$login_errors = array();

// dj_maxx: add visual confirmation to login form
if (!empty($_POST['login']) && !empty($_POST['cookie_test']))
{
    if (empty($_COOKIE[COOKIE_TEST]) || $_COOKIE[COOKIE_TEST] !== $_POST['cookie_test'])
    {
        $login_errors[] = $lang['Session_Expired'];
    }
}
// end of

// Requested redirect
if (preg_match('/^redirect=([a-z0-9\.#\/\?&=\+\-_]+)/si', $_SERVER['QUERY_STRING'], $matches))
{
	$redirect_url = $matches[1];

	if (!strstr($redirect_url, '?') && $first_amp = strpos($redirect_url, '&'))
	{
		$redirect_url[$first_amp] = '?';
	}
}
else if (!empty($_POST['redirect']))
{
	$redirect_url = str_replace('&amp;', '&', htmlspecialchars($_POST['redirect']));
}
else if (!empty($_SERVER['HTTP_REFERER']) && ($parts = @parse_url($_SERVER['HTTP_REFERER'])))
{
	$redirect_url = (isset($parts['path']) ? $parts['path'] : "index.$phpEx") . (isset($parts['query']) ? '?'. $parts['query'] : '');
}

$redirect_url = str_replace('&admin=1', '', $redirect_url);
$redirect_url = str_replace('?admin=1', '', $redirect_url);

if (!$redirect_url || strstr(urldecode($redirect_url), "\n") || strstr(urldecode($redirect_url), "\r") || strstr(urldecode($redirect_url), ';url'))
{
	$redirect_url = "index.$phpEx";
}

$redirect_url = str_replace("&sid={$user->data['session_id']}", '', $redirect_url);
if (isset($_REQUEST['admin']) && !(IS_MOD || IS_ADMIN))
{
	bb_die($lang['Not_admin']);
}

if ($bb_cfg['board_disable'] && $user->data['user_level'] != ADMIN)
{
    redirect("index.$phpEx");
}

$mod_admin_login = ((IS_MOD || IS_ADMIN) && !$user->data['session_admin']);

// login username & password
$login_username = ($mod_admin_login) ? $userdata['username'] : (string) @$_POST['login_username'];
$login_password = (string) @$_POST['login_password'];

// dj_maxx: add visual confirmation to login form
$need_captcha = false;
if(!$mod_admin_login) {
    $sql = "SELECT * FROM ". UNTRUSTED_IPS_TABLE ." WHERE untrusted_ip = '".USER_IP."'";
    if ( $row = $db->fetch_row($sql) )  // record in banlist table exists
    {
        if ($row['untrusted_attempts'] >= $bb_cfg['untrusted_attempts_count']) $need_captcha = true;
    }
}
// end of

if (isset($_POST['login']))
{
    if (!$mod_admin_login)
    {
        if (!IS_GUEST)
        {
            redirect('index.php');
        }
        if ($login_username == '' || $login_password == '')
        {
            $login_errors[] = $lang['Enter_password'];
        }
	}

	if (!$login_errors)
	{
        // dj_maxx: add visual confirmation to login form
        if ($user->login($_POST, $mod_admin_login))
        {
            $redirect_url = (defined('FIRST_LOGON')) ? $bb_cfg['first_logon_redirect_url'] : $redirect_url;
            $sql = "SELECT * FROM ". UNTRUSTED_IPS_TABLE ." WHERE untrusted_ip = '".USER_IP."'";
            if ( $row = $db->fetch_row($sql) )  // record in banlist table exists
            {
                // Обнуление при введении правильно комбинации логин/пароль
                if($row['untrusted_attempts'] > 0) {
                    $db->query("DELETE FROM ". UNTRUSTED_IPS_TABLE ." WHERE untrusted_ip = '".USER_IP."'");
                }
            }
            if ($redirect_url == '/' . LOGIN_URL || $redirect_url == LOGIN_URL) $redirect_url = 'index.php';
            redirect($redirect_url);
        }

        $login_errors[] = $lang['Error_login'];

        if (!$mod_admin_login)
        {
            $sql = "SELECT * FROM ". UNTRUSTED_IPS_TABLE ." WHERE untrusted_ip = '".USER_IP."'";
            if ( $row = $db->fetch_row($sql) )  // record in banlist table exists
            {
                if ($row['untrusted_attempts'] >= $bb_cfg['untrusted_attempts_count']) $need_captcha = true;
            }
            /* treat all as untrusted, cron will sort who is who in bb_manage_untrusted.php :) */
            $sql = "INSERT INTO ". UNTRUSTED_IPS_TABLE ."
		        (untrusted_ip,  untrusted_reason, untrusted_attempts, untrusted_pending) VALUES
		        ('".USER_IP."', 'bruteforce', 1, 1)
		        ON DUPLICATE KEY UPDATE
		        untrusted_attempts = untrusted_attempts + 1";
            if ( !$db->sql_query($sql) )
            {
                message_die(GENERAL_ERROR, "Could not update anti-attack table.", '', __LINE__, __FILE__, $sql);
            }
        }
        else $need_captcha = false;

        if ($need_captcha)
        {
            if (!empty($_POST['confirm_id']))
            {
                $sid = (isset($_POST['sid'])) ? $_POST['sid'] : 0;
                $confirm_id = htmlspecialchars($_POST['confirm_id']);
                $confirm_code = trim(htmlspecialchars($_POST['cfmcd']));

                if (empty($confirm_code))
                {
                    $login_errors[] = $lang['Confirm_code_empty'];
                }
                else {
                    if (!preg_match('/^[A-Za-z0-9]+$/', $confirm_id))
                    {
                        $confirm_id = '';
                    }

                    $sql = 'SELECT code
				        FROM ' . CONFIRM_TABLE . "
				        WHERE confirm_id = '$confirm_id'
					    AND session_id = '" . $sid . "'";
                    if (!($result = $db->sql_query($sql)))
                    {
                        message_die(GENERAL_ERROR, 'Could not obtain confirmation code', '', __LINE__, __FILE__, $sql);
                    }

                    if ($row = $db->sql_fetchrow($result))
                    {
                        // Only compare one char if the zlib-extension is not loaded
                        if (!@extension_loaded('zlib'))
                        {
                            $row['code'] = substr($row['code'], -1);
                        }

                        if (strtolower($row['code']) != strtolower($confirm_code))
                        {
                            $login_errors[] = $lang['Confirm_code_wrong'];
                        }
                        else
                        {
                            $sql = 'DELETE FROM ' . CONFIRM_TABLE . "
						WHERE confirm_id = '$confirm_id'
						AND session_id = '" . $sid . "'";
                            if (!$db->sql_query($sql))
                            {
                                message_die(GENERAL_ERROR, 'Could not delete confirmation code', '', __LINE__, __FILE__, $sql);
                            }
                        }
                    }
                    else
                    {
                        $login_errors[] = $lang['Confirm_code_wrong'];
                    }
                    $db->sql_freeresult($result);
                }
            }
        }
	}
    // end of
}

// Login page
if (IS_GUEST || $mod_admin_login)
{
    // dj_maxx: add visual confirmation to login form
	$confirm_image = '';
	$s_hidden_fields = '';

	if ($need_captcha)
	{
        $db->query("
			DELETE cfm
			FROM ". CONFIRM_TABLE ." cfm
			LEFT JOIN ". SESSIONS_TABLE ." s USING(session_id)
			WHERE s.session_id IS NULL
		");

        $row = $db->fetch_row("
			SELECT COUNT(session_id) AS attempts
			FROM ". CONFIRM_TABLE ."
			WHERE session_id = '{$userdata['session_id']}'
		");

        if (isset($row['attempts']) && $row['attempts'] >= $bb_cfg['attempts_enter_code_count'])
        {
            message_die(GENERAL_MESSAGE, $lang['Too_many_registers']);
        }

        $confirm_chars = array('1', '2', '3', '4', '5', '6', '7', '8', '9');

        $max_chars = count($confirm_chars) - 1;
        $confirm_code = '';
        for ($i = 0; $i < 3; $i++)
        {
            $confirm_code .= $confirm_chars[mt_rand(0, $max_chars)];
        }

        $confirm_id = make_rand_str(12);

        $db->query("
			INSERT INTO ". CONFIRM_TABLE ." (confirm_id, session_id, code)
			VALUES ('$confirm_id', '{$userdata['session_id']}', '$confirm_code')
		");

        $confirm_image = (extension_loaded('zlib')) ? '
			<img src="'. append_sid("profile.$phpEx?mode=confirm&amp;id=$confirm_id") .'" alt="" title="" />
		' : '
			<img src="'. append_sid("profile.$phpEx?mode=confirm&amp;id=$confirm_id&amp;c=1") .'" alt="" title="" />
			<img src="'. append_sid("profile.$phpEx?mode=confirm&amp;id=$confirm_id&amp;c=2") .'" alt="" title="" />
			<img src="'. append_sid("profile.$phpEx?mode=confirm&amp;id=$confirm_id&amp;c=3") .'" alt="" title="" />
			<img src="'. append_sid("profile.$phpEx?mode=confirm&amp;id=$confirm_id&amp;c=4") .'" alt="" title="" />
		';
        $s_hidden_fields .= '<input type="hidden" name="confirm_id" value="'. $confirm_id .'" />';
        $s_hidden_fields .= '<input type="hidden" name="sid" value="'. $userdata['session_id'] .'" />';

        $template->assign_block_vars('switch_confirm', array());
	}

    $cookie_test_val = mt_rand();
    bb_setcookie(COOKIE_TEST, $cookie_test_val, COOKIE_SESSION);
    // end of

	$template->assign_vars(array(
		'USERNAME'         => htmlCHR($login_username),
        'PASSWORD'         => htmlCHR($login_password),

		'ERR_MSG'          => join('<br />', $login_errors),
		'T_ENTER_PASSWORD' => ($mod_admin_login) ? $lang['Admin_reauthenticate'] : $lang['Enter_password'],

		'U_SEND_PASSWORD'  => "profile.$phpEx?mode=sendpassword",
		'ADMIN_LOGIN'      => $mod_admin_login,

        // dj_maxx: add visual confirmation to login form
		'COOKIE_TEST_VAL'  => $cookie_test_val,
		'L_CONFIRM_CODE'   => $lang['Confirm_code'],
		'CONFIRM_IMG' 	   => $confirm_image,
		'S_HIDDEN_FIELDS'  => $s_hidden_fields,
		// end of

		'REDIRECT_URL'     => htmlCHR($redirect_url),
	));

	print_page('login.tpl');
}

redirect("index.$phpEx");

