<?php

/*
	This file is part of TorrentPier

	TorrentPier is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	TorrentPier is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	A copy of the GPL 2.0 should have been included with the program.
	If not, see http://www.gnu.org/licenses/

	Official SVN repository and contact information can be found at
	http://code.google.com/p/torrentpier/
 */

define('IN_AJAX', true);
$ajax = new ajax_common();

require('./common.php');

$ajax->init();

// Handle "board disabled via ON/OFF trigger"
if (file_exists(BB_DISABLED))
{
	$ajax->ajax_die($bb_cfg['board_disabled_msg']);
}

// Load actions required modules
switch ($ajax->action)
{
	case 'view_post':
		require(INC_DIR .'bbcode.'. PHP_EXT);
	break;

	case 'chat_message': // ajax chat
		require(INC_DIR .'functions_post.'. PHP_EXT);
		require(INC_DIR .'bbcode.'. PHP_EXT);
	break;

	case 'check_name': // Mod cool register Check Name
		require_once(INC_DIR .'functions_validate.'. PHP_EXT);
	break;

	case 'check_email': // Mod cool register Check Email
		require_once(INC_DIR .'functions_validate.'. PHP_EXT);
	break;
}

// position in $ajax->valid_actions['xxx']
define('AJAX_AUTH', 0);  //  'guest', 'user', 'mod', 'admin'

$user->session_start();
$ajax->exec();

//
// Ajax
//
class ajax_common
{
	var $request  = array();
	var $response = array();

	var $valid_actions = array(
	    //   ACTION NAME             AJAX_AUTH
		'edit_user_profile' => array('admin'),
		'view_post'         => array('guest'),
        'force_update'		=> array('admin'),
		'chat_message'      => array('user'),
		'check_name'        => array('guest'),
		'check_email'       => array('guest'),
		'check_pass'        => array('guest'),
		'friends'           => array('user'),
        'order_vote'          => array('user'),
        'order_delete'        => array('admin'),
        'order_add'           => array('user'),
        'order_yes'           => array('user'),
        'order_abuse'         => array('user'),
        'view_comment'      => array('user'),
        'o_comment_add'     => array('user'),
        'birthday_list'     => array('user'),
        'gen_rand_pass'     => array('guest'),
	);

	var $action = null;

	/**
	*  Constructor
	*/
	function __construct()
	{
		ob_start(array(&$this, 'ob_handler'));
		header('Content-Type: text/plain');
	}

	/**
	*  Perform action
	*/
	function exec ()
	{
		global $lang;

		// Exit if we already have errors
		if (!empty($this->response['error_code']))
		{
			$this->send();
		}

		// Check that requested action is valid
		$action = $this->action;

		if (!$action || !is_string($action))
		{
			$this->ajax_die('no action specified');
		}
		else if (!$action_params =& $this->valid_actions[$action])
		{
			$this->ajax_die('invalid action: '. $action);
		}

		// Auth check
		switch ($action_params[AJAX_AUTH])
		{
			// GUEST
			case 'guest':
				break;

			// USER
			case 'user':
				if (IS_GUEST)
				{
					$this->ajax_die($lang['Need_to_login_first']);
				}
				break;

			// MOD
			case 'mod':
				if (!(IS_MOD || IS_ADMIN))
				{
					$this->ajax_die($lang['Only_for_mod']);
				}
				$this->check_admin_session();
				break;

			// ADMIN
			case 'admin':
				if (!IS_ADMIN)
				{
					$this->ajax_die($lang['Only_for_admin']);
				}
				$this->check_admin_session();
				break;

			default:
				trigger_error("invalid auth type for $action", E_USER_ERROR);
		}

		// Run action
		$this->$action();

		// Send output
		$this->send();
	}

	/**
	*  Exit on error
	*/
	function ajax_die ($error_msg, $error_code = E_AJAX_GENERAL_ERROR)
	{
		$this->response['error_code'] = $error_code;
		$this->response['error_msg'] = $error_msg;

		$this->send();
	}

	/**
	*  Initialization
	*/
	function init ()
	{
		$this->request = $_POST;

		$this->action  =& $this->request['action'];
	}

	/**
	*  Send data
	*/
	function send ()
	{
		$this->response['action'] = $this->action;

		if (sql_dbg_enabled())
		{
			$this->response['sql_log'] = get_sql_log();
		}

		// sending output will be handled by $this->ob_handler()
		exit();
	}

	/**
	*  OB Handler
	*/
	function ob_handler ($contents)
	{
		if (DBG_USER)
		{
			if ($contents)
			{
				$this->response['raw_output'] = $contents;
			}
		}

		$response_js = bb_json_encode($this->response);

		if (GZIP_OUTPUT_ALLOWED && !defined('NO_GZIP'))
		{
			if (UA_GZIP_SUPPORTED && strlen($response_js) > 2000)
			{
				header('Content-Encoding: gzip');
				$response_js = gzencode($response_js, 1);
			}
		}

		return $response_js;
	}

	/**
	*  Admin session
	*/
	function check_admin_session ()
	{
		global $user;

		if (!$user->data['session_admin'])
		{
			if (empty($this->request['user_password']))
			{
				$this->prompt_for_password();
			}
			else
			{
				$login_args = array(
					'login_username' => $user->data['username'],
					'login_password' => $_POST['user_password'],
				);
				if (!$user->login($login_args, true))
				{
					$this->ajax_die('Wrong password');
				}
			}
		}
	}

	/**
	*  Prompt for password
	*/
	function prompt_for_password ()
	{
		$this->response['prompt_password'] = 1;
		$this->send();
	}

	/**
	*  Edit user profile
	*/
	function edit_user_profile ()
	{
		global $db, $bb_cfg, $lang;

		if (!$user_id = intval($this->request['user_id']) OR !$profiledata = get_userdata($user_id))
		{
			$this->ajax_die('invalid user_id');
		}
		if (!$field = (string) $this->request['field'])
		{
			$this->ajax_die('invalid profile field');
		}

		$table = USERS_TABLE;
		$value = (string) $this->request['value'];

		switch ($field)
		{
			case 'user_regdate':
			case 'user_lastvisit':
				$tz = TIMENOW + (3600 * $bb_cfg['board_timezone']);
				if (($value = strtotime($value, $tz)) < $bb_cfg['board_startdate'] OR $value > TIMENOW)
				{
					$this->ajax_die('invalid date: '. $this->request['value']);
				}
				$this->response['new_value'] = bb_date($value);
				break;

			case 'ignore_srv_load':
				$value = ($this->request['value']) ? 0 : 1;
				$this->response['new_value'] = ($profiledata['user_level'] != USER || $value) ? $lang['NO'] : $lang['YES'];
				break;

			case 'u_up_total':
			case 'u_down_total':
			case 'u_up_release':
			case 'u_up_bonus':
				if (!IS_SUPER_ADMIN)
				{
					$this->ajax_die($lang['Only_for_super_admin']);
				}

				$table = BT_USERS_TABLE;
				$value = (float) str_replace(',', '.', $this->request['value']);

				foreach (array('KB'=>1,'MB'=>2,'GB'=>3,'TB'=>4) as $s => $m)
				{
					if (strpos($this->request['value'], $s) !== false)
					{
						$value *= pow(1024, $m);
						break;
					}
				}
				$value = sprintf('%.0f', $value);
				$this->response['new_value'] = humn_size($value, null, null, ' ');

				if (!$btu = get_bt_userdata($user_id))
				{
					require(INC_DIR .'functions_torrent.'. PHP_EXT);
					generate_passkey($user_id, true);
					$btu = get_bt_userdata($user_id);
				}
				$btu[$field] = $value;
				$this->response['update_ids']['u_ratio'] = (string) get_bt_ratio($btu);
				break;

			default:
				$this->ajax_die("invalid profile field: $field");
		}

		$value_sql = $db->escape($value, true);
		$db->query("UPDATE $table SET $field = $value_sql WHERE user_id = $user_id LIMIT 1");

		$this->response['edit_id'] = $this->request['edit_id'];
	}

	/**
	*  View post
	*/
	function view_post ()
	{
		global $user, $db, $lang, $bb_cfg, $userdata;

		$post_id = (int) $this->request['post_id'];

		$sql = "
			SELECT
			  p.*,
			  h.post_html, IF(h.post_html IS NULL, pt.post_text, NULL) AS post_text,
			  pt.post_subject, pt.bbcode_uid,
			  f.auth_read
			FROM       ". POSTS_TABLE      ." p
			INNER JOIN ". POSTS_TEXT_TABLE ." pt ON(pt.post_id = p.post_id)
			 LEFT JOIN ". POSTS_HTML_TABLE ." h  ON(h.post_id = pt.post_id)
			INNER JOIN ". FORUMS_TABLE     ." f  ON(f.forum_id = p.forum_id)
			WHERE
			  p.post_id = $post_id
			LIMIT 1
		";

		if (!$post_data = $db->fetch_row($sql))
		{
			$this->ajax_die($lang['Topic_post_not_exist']);
		}

		// Auth check
		if ($post_data['auth_read'] == AUTH_REG)
		{
			if (IS_GUEST)
			{
				$this->ajax_die($lang['Need_to_login_first']);
			}
		}
		else if ($post_data['auth_read'] != AUTH_ALL)
		{
			$is_auth = auth(AUTH_READ, $post_data['forum_id'], $user->data, $post_data);
			if (!$is_auth['auth_read'])
			{
				$this->ajax_die($lang['Topic_post_not_exist']);
			}
		}

		if($bb_cfg['reg_block']) {
            if ($userdata['user_regdate'] + $bb_cfg['reg_block_time'] > TIMENOW)
            {
                $time_left = bb_date_v2((($userdata['user_regdate'] + $bb_cfg['reg_block_time']) - TIMENOW), 'H:i:s', '0');
                $this->ajax_die(sprintf($lang['REG_BLOCK'], $time_left));
            }
        }

        if($bb_cfg['parking_no_post']) {
            if ($userdata['user_park_profile']) {
                $this->ajax_die($lang['PARK_PROFILE_POST_DISALLOWED']);
            }
        }

		$this->response['post_id']   = $post_id;
		$this->response['post_html'] = get_parsed_post($post_data);
	}

	// ajax cool register mod start
	function check_name()
	{
		global $db, $lang;
		$username = (string) $this->request['username'];
		if ($username == '')
		{
			$this->response['html'] = '<img src="images/aff_cross.gif"><span class="leechmed bold">&nbsp;'.$lang['NO_INPUT_NAME'].'</span>';
		}
		else
		{
			$validate_username_check = validate_username($username);
			if ($validate_username_check['error'])
			{
				$this->response['html'] = '<img src="images/aff_cross.gif"><span class="leechmed bold">&nbsp;'.$validate_username_check['error_msg'].'</span>';
			}
			else
			{
				$this->response['html'] = '<img src="images/aff_tick.gif">';
			}
		}
	}

	function check_email()
	{
		global $db, $lang;
		$email = (string) $this->request['email'];
		if ($email == '')
		{
			$this->response['html'] = '<img src="images/aff_cross.gif"><span class="leechmed bold">&nbsp;'.$lang['NO_INPUT_EMAIL'].'</span>';
		}
		else
		{
			$validate_email_check = validate_email($email);
			if ($validate_email_check['error'])
			{
				$this->response['html'] = '<img src="images/aff_cross.gif"><span class="leechmed bold">&nbsp;'.$validate_email_check['error_msg'].'</span>';
			}
			else
			{
				$this->response['html'] = '<img src="images/aff_tick.gif">';
			}
		}
	}

	function check_pass()
	{
		global $lang;
		$pass = (string) $this->request['pass'];
		$pass_confirm = (string) $this->request['pass_confirm'];
		if (($pass == '') || ($pass_confirm == ''))
		{
			$this->response['html'] = '<img src="images/aff_cross.gif"><span class="leechmed bold">&nbsp;'.$lang['PASS_INDEFINITE'].'</span>';
		}
		else
		{
		if ( $pass != $pass_confirm)
		{
			$this->response['html'] = '<img src="images/aff_cross.gif"><span class="leechmed bold">&nbsp;'.$lang['PASS_NOT_CONFIRM'].'</span>';
		}
		else
		{
			$this->response['html'] = '<img src="images/aff_tick.gif"><span class="seedmed bold">&nbsp;'.$lang['PASS_CONFIRM'].'</span>';   }
		}
	}
	// ajax cool register mod end

	// ajax chat
	function chat_message()
	{
		global $db, $bb_cache, $userdata, $bb_cfg, $lang;
		$mode = (int) $this->request['mode'];
		$message = (string) $this->request['message'];
		$shoutbox_date = 'H:i:s';

        if(!$bb_cfg['ajax_chat']) $this->ajax_die($lang['MODULE_OFF']);

		if($mode==1)
		{
			if(!$message) ajax_die($lang['shoutbox_err']);
			$bbcode_on = $bb_cfg['allow_bbcode'];
			$smilies_on = $bb_cfg['allow_smilies'];
			if(!IS_ADMIN)
			{
				$chk = $db->fetch_row('SELECT MAX(shout_session_time) AS last_post_time FROM bb_shout WHERE shout_user_id = '.$userdata['user_id']);
				if ( $chk['last_post_time'] > 0 && ( time() - $chk['last_post_time'] ) < $bb_cfg['flood_interval'] ) ajax_die($lang['Flood_Error']);
			}
			if (!empty($message))
			{
				$bbcode_uid = ( $bbcode_on ) ? make_bbcode_uid() : '';
				$html_entities_match = array('#&(?!(\#[0-9]+;))#', '#<#', '#>#', '#"#');
				$html_entities_replace = array('&amp;', '&lt;', '&gt;', '&quot;');
				$message = str_replace("\r", '', trim($message));
				$message = preg_replace("#\n{3,}#", "\n\n", $message);
				$message = preg_replace($html_entities_match, $html_entities_replace, $message);
				$message = stripslashes(prepare_message(addslashes(unprepare_message($message)), $bbcode_on, $smilies_on, $bbcode_uid));
				$message = bbencode_first_pass($message, $bbcode_uid);
				$message = bbencode_second_pass($message, $bbcode_uid);
				$message = make_clickable($message);
				$message = smilies_pass($message);
				$message = nl2br($message);
				$db->query('INSERT INTO bb_shout (shout_text, shout_session_time, shout_user_id, shout_ip, shout_username, shout_bbcode_uid) VALUES ("'.$db->escape($message).'", '.time().', '.$userdata['user_id'].', "'.USER_IP.'", "'.$db->escape($userdata['username']).'", "'.$bbcode_uid.'")');
				$bb_cache->rm('shout_data');
			}
		}
		if(!$shout_data = $bb_cache->get('shout_data'))
		{
			$shout_rows = $db->fetch_rowset("SELECT s.*, u.username, u.user_level, u.user_rank, u.user_avatar, u.user_avatar_type, u.user_allowavatar
				FROM bb_shout s, ".USERS_TABLE." u
				WHERE s.shout_user_id=u.user_id AND u.user_id = u.user_id
				ORDER BY s.shout_session_time DESC LIMIT 50");
			$i=0;
			$shout_data = '';
			foreach ($shout_rows AS $shout_row)
			{
				$row_class = !($i % 2) ? 'row1' : 'row2';
				$user_level =  $shout_row['user_level'];
				if($user_level == ADMIN) $username = '<span class="colorAdmin">'.$shout_row['username'].'</span>' ;
				else if($user_level == MOD) $username = '<span class="colorMod">'.$shout_row['username'].'</span>';
				else if($user_level == GROUP_MEMBER) $username = '<span class="colorGroup">'.$shout_row['username'].'</span>';
				else $username = '<span class="colorNick">'.$shout_row['username'].'</span>';

				$avatar_img = '';
				if ($shout_row['user_avatar_type'] && $shout_row['user_allowavatar'] )
				{
					switch($shout_row['user_avatar_type'] )
					{
						case USER_AVATAR_UPLOAD:
							$avatar_img = ( $bb_cfg['allow_avatar_upload'] ) ? '<img align="left" style="max-height:35px;max-width:35px;padding-right: 3px;" src="' . $bb_cfg['avatar_path'] . '/' . $shout_row['user_avatar'] . '" alt="" border="0" />' : '';
							break;
						case USER_AVATAR_REMOTE:
							$avatar_img = ( $bb_cfg['allow_avatar_remote'] ) ? '<img align="left" style="max-height:35px;max-width:35px;padding-right: 3px;" src="' . $shout_row['user_avatar'] . '" alt="" border="0" />' : '';
							break;
						case USER_AVATAR_GALLERY:
							$avatar_img = ( $bb_cfg['allow_avatar_local'] ) ? '<img align="left" style="max-height:35px;max-width:35px;padding-right: 3px;" src="' . $bb_cfg['avatar_gallery_path'] . '/' . $shout_row['user_avatar'] . '" alt="" border="0" />' : '';
							break;
					}
				}

				$shout = (!$shout_row['shout_active']) ? $shout_row['shout_text'] : $lang['Shout_censor'];
				//if ( $bb_cfg['allow_smilies'] != 0 ) $shout = smilies_pass($shout);
				$shout_new = bbencode_second_pass($shout, $shout_row['shout_bbcode_uid']);
				$shout = str_replace("\n", "\n<br />\n", $shout);
				$shout = ($user_level == ADMIN) ? '<span class="colorAdmin">'.$shout.'</span>' : $shout;

				$shout_avatar = '';
				if(isset($avatar_img) && !empty($avatar_img)) {
				    $shout_avatar = '<a href="profile.php?mode=viewprofile&u='.$shout_row['shout_user_id'].'">'.$avatar_img.'&nbsp;</a>&nbsp;';
                }
				$shout_data .= '<div id="shout_'.$shout_row['shout_id'].'" class="chat-comment '.$row_class.'"><div style="min-height: 32px;">' . $shout_avatar . '<a class="bold" title="'.$lang['shoutbox_insert_name'].'" style="text-decoration: none;" href="javascript:add_nick(\'[b]'.addslashes($shout_row['shout_username']).'[/b],\')">'.$username.'</a><div class="small">'.create_date($shoutbox_date, $shout_row['shout_session_time'], $bb_cfg['board_timezone']).'</div></div><div class="spacer_2"></div><span style="font-size: 11px;">'.$shout.'</span></div>';
				++$i;
			}
			$bb_cache->set('shout_data', $shout_data);
		}
		$this->response['message'] = $shout_data;
	}

	// friends
	function friends()
    {
        global $db, $bb_cfg, $lang, $userdata, $datastore;

        $mode = (string) $this->request['mode'];
        $user_id = (int) $this->request['user_id'];
        $html = '';

        if(!$bb_cfg['friends']) $this->ajax_die($lang['MODULE_OFF']);
        if(!$user_id) $this->ajax_die($lang['NO_SUCH_USER']);

        switch($mode)
        {
            case 'list':
                $sql = $db->fetch_rowset("SELECT uf.*, u.username, u.user_id, u.user_rank, u.user_avatar, u.user_avatar_type, u.user_allowavatar, u.user_posts
		    FROM bb_friends uf, ". USERS_TABLE ." u
			WHERE uf.user_id = $user_id
			    AND uf.friends_id = u.user_id
			ORDER BY u.username ASC");
                $count = $db->fetch_row("SELECT COUNT(friends_id) AS friends FROM bb_friends WHERE user_id = $user_id");

                $ranks = $datastore->get('ranks');
                $datastore->enqueue(array(
                    'ranks',
                ));

                $html = '<div class="xenOverlay" style="z-index: 1000; top: 91.1px; left: 286.5px; display: block; position: fixed"><div class="section">';
                $html .= '<h2 class="heading h1">Список друзей пользователя '. get_username($user_id) .'</h2><div>';
                $html .= '<dl class="subHeading pairsInline"><dt>Найдено друзей: </dt><dd>'. $count['friends'] .'</dd></dl>';
                $html .= (!$sql) ? '<ol class="overlayScroll"><li class="primaryContent memberListItem"><div class="member"><div class="userInfo"><div class="userBlurb dimmed"><span class="userTitle">У '. get_username($user_id) .' еще нет друзей</span></div></div></div></li></ol>' : '';

                foreach($sql as $row)
                {
                    $my_friends = $db->fetch_row("SELECT * FROM bb_friends WHERE user_id = ". $userdata['user_id'] ." AND friends_id = ". $row['user_id']);
                    $user_rank  = $row['user_rank'];

                    $friend_avatar_img = '';
                    if ($row['user_avatar_type'] && $row['user_allowavatar'] )
                    {
                        switch($row['user_avatar_type'])
                        {
                            case USER_AVATAR_UPLOAD:
                                $friend_avatar_img = ( $bb_cfg['allow_avatar_upload'] ) ? $bb_cfg['avatar_path'] . '/' . $row['user_avatar'] : '';
                                break;
                            case USER_AVATAR_REMOTE:
                                $friend_avatar_img = ( $bb_cfg['allow_avatar_remote'] ) ? $row['user_avatar'] : '';
                                break;
                            case USER_AVATAR_GALLERY:
                                $friend_avatar_img = ( $bb_cfg['allow_avatar_local'] ) ? $bb_cfg['avatar_gallery_path'] . '/' . $row['user_avatar'] : '';
                                break;
                        }
                    }

                    $rank_title = isset($ranks[$user_rank]) ? $ranks[$user_rank]['rank_title'] : $lang['USER'];

                    $friend_avatar = '';
                    if(isset($friend_avatar_img) && !empty($friend_avatar_img)) {
                        $friend_avatar = '<a href="'. PROFILE_URL . $row['user_id'] .'" class="avatars decoration_none" alt=""><img class="img" align="left" src="' . $friend_avatar_img . '"></a>';
                    }

                    $html .= '<ol class="overlayScroll" id="fr_'.$row['friends_id'].'"><li class="primaryContent memberListItem">' . $friend_avatar .'';
                    $html .= '<div class="extra"><abbr class="DateTime">';
                    $html .= ($user_id == $userdata['user_id']) ? '<a href="#" onclick="ajax.exec({action : \'friends\', mode: \'del\', user_id : \''.$row['user_id'] .'\'}); $(\'#fr_\'+ '.$row['friends_id'].').hide(\'slow\'); return false;" title="Удалить из списка друзей" ><img src="images/delfrends.png"></a>' : '';
                    $html .= (!$my_friends && $row['user_id'] != $userdata['user_id']) ? '<a href="#" onclick="ajax.exec({action : \'friends\', mode: \'add\', user_id : \''. $row['user_id'] .'\'}); return false;" title="Добавить в список друзей" ><img src="images/addfrends.png"></a>' : '';
                    $html .= '</abbr></div>';
                    $html .= '<div class="member"><h3 class="username"><a href="'. PROFILE_URL.$row['user_id'] .'" class="username">'. profile_url($row) .'</a></h3>';
                    $html .= '<div class="userInfo">';
                    $html .= '<div class="userBlurb dimmed"><span>'. $rank_title .'</span></div>';
                    $html .= '<dl class="userStats pairsInline"><dt title="Всего сообщений, опубликованных '. $row['username'] .'">Сообщений: </dt><dd>'. $row['user_posts'] .'</dd></dl></div></div></li></ol>';
                }

                $html .= '</div><div class="sectionFooter overlayOnly"><a href="#" class="button primary OverlayCloser" onclick="$(\'.xenOverlay\').hide(\'slow\'); return false;" title="Закрыть список" ><img src="images/closefrends.png"></a></a></div></div></div>';

                break;

            case 'add':
                $sql = $db->fetch_row("SELECT * FROM bb_friends WHERE user_id = ". $userdata['user_id']." AND friends_id = $user_id");
                if($sql) $this->ajax_die(get_username($user_id) .' уже добавлен в список Ваших друзей');
                if($userdata['user_id'] == $user_id) $this->ajax_die('Вы не можете добавить себя в свой список друзей!');

                $db->query("INSERT INTO bb_friends (user_id, friends_id) VALUES (". $userdata['user_id'].", $user_id)");

                $message = 'Здравствуйте, '. get_username($user_id) .'.[br][br]
		    '. $userdata['username'] .' добавил Вас в список своих друзей. [br][br]
			Для подтверждения ваших дружеских отношений, перейдите в профиль [url='. make_url(PROFILE_URL . $userdata['user_id']) .']'. $userdata['username'] .'[/url] и добавьте его в список своих друзей.[br][br]
            Это автоматическое сообщение! Вам не нужно на него отвечать!';
                $subject = $userdata['username'] .' добавил Вас в список друзей';

                send_pm_v2($user_id, $subject, $message, ANONYMOUS);
                cache_rm_user_sessions ($user_id);

                $html = $this->ajax_die(get_username($user_id) .' добавлен в список ваших друзей');
                break;

            case 'del':
                $sql = $db->fetch_row("SELECT * FROM bb_friends WHERE user_id = ". $userdata['user_id']." AND friends_id = $user_id");
                if(!$sql) $this->ajax_die($lang['User_not_exist']);
                if($userdata['user_id'] == $user_id) $this->ajax_die('Вы не можете удалить себя из списка друзей!');

                $db->query("DELETE FROM bb_friends WHERE user_id = ". $userdata['user_id']." AND friends_id = $user_id");

                $message = 'Здравствуйте, '. get_username($user_id) .'.[br][br]
		    [url='. make_url(PROFILE_URL . $userdata['user_id']) .']'. $userdata['username'] .'[/url] удалил Вас в списка своих друзей. [br][br]
            Это автоматическое сообщение! Вам не нужно на него отвечать!';
                $subject = $userdata['username'] .' удалил Вас в списка друзей';

                send_pm_v2($user_id, $subject, $message, ANONYMOUS);
                cache_rm_user_sessions ($user_id);

                $html = $this->ajax_die(get_username($user_id) .' удален из списка ваших друзей');
                break;
        }

        $this->response['html']	= $html;
        $this->response['mode']	= $mode;
	}

    function order_vote()
    {
        global $db;
        $id = (int) $this->request['id'];
        $db->query("UPDATE bb_order SET order_vote = order_vote+1 WHERE  order_id = $id");
        $vote_summ = $db->sql_query("SELECT order_vote FROM bb_order WHERE order_id = $id LIMIT 1");
        while ($votes = $db->sql_fetchrow($vote_summ))
        {
            $votes_summ = $votes['order_vote'];
        }
        $this->response['vote'] = $votes_summ;
        $this->response['id'] = $id;
    }

    function order_delete()
    {
        global $db;
        $id = (int) $this->request['id'];
        $db->query("DELETE FROM bb_order WHERE order_id = $id");
        $this->response['id'] = $id;
    }

    function order_add()
    {
        global $db, $userdata, $bb_cfg, $lang;
        $name = (string) $this->request['name'];
        $desc = (string) $this->request['desc'];
        $f_id = (int) $this->request['forum'];
        if (($name == '') || ($desc == '')) ajax_die('Error');
        $time = TIMENOW;
        $user_id = $userdata['user_id'];
        $name = $db->escape($name);
        $desc = $db->escape($desc);
        $vote = 0;
        $html = '';
        $row = $db->fetch_row("SELECT forum_name FROM ". FORUMS_TABLE ." WHERE forum_id = ".$f_id);
        $db->query("INSERT bb_order SET
               order_forum_id = $f_id,
               order_name = '$name',
               order_desc = '$desc',
               order_time = $time,
               order_yes  = 0,
               order_user_id = $user_id,
               order_vote = $vote
             ");
        $html .= '<td class="small bold w10 tCenter"><a href="viewforum.php?f='.$f_id.'">'.$row['forum_name'].'</a></td>';
        $html .= '<td class="bold w30" name="hilite">'.$name.'</td>';
        $html .= '<td class="w10 tCenter">'.create_date($bb_cfg['default_dateformat'], $time, $bb_cfg['board_timezone']).'</td>';
        $html .= '<td class="bold w10 tCenter"><a href="profile.php?mode=viewprofile&u='.$user_id.'">'.$userdata['username'].'</a></td>';
        $html .= '<td class="w10 tCenter">'.$lang['NO'].'</td>';
        $html .= '<td class="bold w10 tCenter">----</td>';
        $html .= '<td class="w10 tCenter bold">0</td>';
        $html .= '<td class="w10 tCenter bold"><img src="'.BB_ROOT.'images/order_normal.png" /></td>';
        if ($userdata['user_level'] == ADMIN) {
            $html .= '<td class="w10 bold tCenter leech">X</td>';
        }
        $this->response['html'] = $html;
    }

    function order_yes()
    {
        global $db, $userdata, $lang;
        $id = (int) $this->request['id'];
        $topic_id = (int) $this->request['topic_id'];
        $user_id = $userdata['user_id'];
        $db->query("UPDATE bb_order SET order_yes = 1, order_user_performed_id = $user_id, order_topic_id = $topic_id WHERE order_id = $id");
        $this->response['id'] = $id;
        $this->response['username'] = '<a href="profile.php?mode=viewprofile&u='.$user_id.'">'.$userdata['username'].'</a>';
        $this->response['html'] = '<a href="viewtopic.php?t='.$topic_id.'" class="seed bold" />'.$lang['YES'].'</b>';
    }

    function order_abuse()
    {
        global $db;
        $id = (int) $this->request['id'];
        $db->query("UPDATE bb_order SET order_abuse = 1 WHERE order_id = $id");
        $this->response['id'] = $id;
    }

    function view_comment()
    {
        global $db, $userdata, $lang, $bb_cfg;
        $order_id = (int) $this->request['or_id'];
        $user_id = $userdata['user_id'];
        $i = 0;
        $comments = $db->query("SELECT c.*, u.username
              FROM bb_order_comment AS c
              LEFT JOIN bb_users AS u ON(u.user_id = c.comment_user_id)
              WHERE order_id = $order_id
              ORDER BY comment_time
             ");
        $html = '<table class="forumline w100">';
        while ($com = $db->sql_fetchrow($comments))
        {
            $i++;
            $row_class = !($i % 2) ? 'row2' : 'row1';
            $html .= '<tr class="'.$row_class.'">';
            $html .= '<td width="10%" class="tCenter bold"><a href="profile.php?mode=viewprofile&u='.$user_id.'">'.$com['username'].'</a><br />'.create_date($bb_cfg['default_dateformat'], $com['comment_time'], $bb_cfg['board_timezone']).'</td>';
            $html .= '<td width="90%">'.htmlspecialchars($com['comment']).'</td>';
            $html .= '</tr>';
        }
        $html .= '<tr class="row3">';
        $html .= '<td class="w100 bold tCenter" colspan="2">'. $lang['ADD_COMMENT_ORDER'] .'</td>';
        $html .= '</tr>';
        $html .= '<tr class="row1">';
        $html .= '<td width="20%" class="bold">'. $lang['COMMENT_ORDER'] .'</td>';
        $html .= '<td width="80%" class="bold tCenter"><textarea id="ctext_'.$order_id.'" style="width: 90%; height: 100px;"></textarea></td>';
        $html .= '</tr>';
        $html .= '<tr>';
        $html .= '<td colspan="2" class="tCenter"><input type="button" onclick="ajax.o_comment_add('.$order_id.');" value="'. $lang['SUBMIT'] .'" /></td>';
        $html .= '</tr>';
        $html .= '</table>';

        $this->response['html']  = $html;
        $this->response['or_id'] = $order_id;
    }

    function o_comment_add()
    {
        global $db, $userdata, $lang, $bb_cfg;
        $order_id = (int) $this->request['id'];
        $text = $this->request['text'];
        if (!$text) ajax_die(''. $lang['NO_COMMENT_ORDER'] .'');
        //  $text = htmlentities($text);
        $user_id = $userdata['user_id'];
        $time = TIMENOW;
        $text = $db->escape($text);
        $db->query("INSERT INTO bb_order_comment SET
              order_id = $order_id,
              comment = '$text',
              comment_time = $time,
              comment_user_id = $user_id
             ");
        $html  = '<td calss="row1"><a href="profile.php?mode=viewprofile&u='.$user_id.'">'.$userdata['username'].'</a><br />'.create_date($bb_cfg['default_dateformat'], $time, $bb_cfg['board_timezone']).'</td>';
        $html .= '<td calss="row1">'.htmlentities($text).'</td>';
        $this->response['html']  = $html;
        $this->response['id'] = $order_id;
    }

    function birthday_list()
    {
        global $datastore, $lang, $bb_cfg;
        $mode = (string)$this->request['mode'];
        $html = '';
        switch ($mode) {
            case 'birthday_week':
                $stats = $datastore->get('stats');
                $datastore->enqueue(array(
                    'stats',
                ));

                if ($stats['birthday_week_list']) {
                    foreach ($stats['birthday_week_list'] as $week) {
                        $html[] = profile_url($week) . ' <span class="small">(' . birthday_age($week['user_birthday']) . ')</span>';
                    }
                    $html = sprintf($lang['BIRTHDAY_WEEK'], $bb_cfg['birthday_check_day'], implode(', ', $html));
                } else {
                    $html = sprintf($lang['NOBIRTHDAY_WEEK'], $bb_cfg['birthday_check_day']);
                }
                break;

            case 'birthday_today':
                $stats = $datastore->get('stats');
                $datastore->enqueue(array(
                    'stats',
                ));

                if ($stats['birthday_today_list']) {
                    foreach ($stats['birthday_today_list'] as $today) {
                        $html[] = profile_url($today) . ' <span class="small">(' . birthday_age($today['user_birthday']) . ')</span>';
                    }
                    $html = $lang['BIRTHDAY_TODAY'] . implode(', ', $html);
                } else {
                    $html = $lang['NOBIRTHDAY_TODAY'];
                }
                break;
        }

        $this->response['html'] = $html;
        $this->response['mode'] = $mode;
    }

    function force_update()
    {
        include_once INC_DIR . 'functions_multi_tracker.' . PHP_EXT;
        $attach_id = (int) $this->request['attach_id'];

        if( !$attach_id )
        {
            $this->response['html'] = 'ERROR';
            $this->response['erds'] = 'Invalid Attach ID';
        }
        else
        {
            $update_ex = multi_tracker_update( $attach_id, TRUE, TRUE );
            if( $update_ex === FALSE )
            {
                $this->response['html'] = 'ERROR';
                $this->response['erds'] = 'UPDATE ERROR';
            }
            else
            {
                $this->response['html'] 		= 'THIS External Torrent, Updated!';
                $this->response['complete']		= $update_ex['complete'];
                $this->response['incomplete']	= $update_ex['incomplete'];
            }
        }
    }

    function gen_rand_pass() {
        global $bb_cfg;
        $request = (string) $this->request['allow_gen'];
        if($request == true) {
            $this->response['generated_pass'] = gen_password($bb_cfg['gen_password_length']);
        }
    }
}
